# RELATÓRIO — ETAPA 2: Auditoria do projeto

## 1. Resumo

Auditoria estática completa do projeto (sem implementação de funcionalidades, exceto
onde indicado). Cobertura: todas as 20 rotas, as 19 páginas, os dois serviços centrais
(`apiClient.ts` e `mockRepository.ts`, ~1.780 linhas juntos), `seedData.ts`, tipos,
constantes de RBAC/navegação e componentes compartilhados.

**Achado principal:** o projeto está muito mais maduro do que a numeração de etapas do
Prompt Master sugere isoladamente — grande parte das etapas 7 a 13 (locais, produtos/
variações/saldo, movimentações/transferências, Kardex, estrutura de OP, fluxo de
produção, consumo/defeitos) já está implementada e, pelos comentários deixados no
próprio código, já passou por pelo menos 3 rodadas de auditoria anteriores que
encontraram e corrigiram bugs reais (ver seção 4).

**Lacuna principal:** a camada de **plataforma multiempresa** (seções 10–19 do prompt
mestre — ADM DO SITE, `/site/login`, criação de empresa, painel global, troca de
empresa) **não existe**. O sistema hoje é, na prática, um ERP multiempresa apenas no
sentido de que os dados são isolados por `empresaId` no banco mock — mas não há
nenhuma forma de logar como administrador global, criar uma nova empresa pela
interface, nem visualizar dashboard/auditoria consolidados entre empresas.

## 2. Levantamento por módulo

### ✅ Funciona bem

- **Isolamento multiempresa no dado (regra 17):** toda função exportada de
  `mockRepository.ts` que mexe em entidade de negócio recebe `empresaId` e filtra por
  ele. Única exceção legítima: `listUnidadesMedida` (unidade de medida é catálogo
  global, não por empresa — parece intencional, mas vale confirmar com o cliente/spec
  se isso está correto).
- **RBAC de empresa (etapa 4, parcial):** dois cargos (`ADMINISTRADOR`,
  `FUNCIONARIO`), permissões orientadas a `cargo_permissao` (não hardcoded), tela de
  Equipe permite criar/editar/ativar/inativar usuário e trocar cargo (promoção/
  rebaixamento na prática), múltiplos administradores por empresa são permitidos.
- **Roteamento:** as 20 rotas geradas (`routeTree.gen.ts`) batem exatamente com os 20
  arquivos em `src/routes/`; nenhuma rota órfã, nenhum import quebrado em todo o
  projeto (verificado programaticamente).
- **Produtos/variações/preços/estoque:** produto pai → variação (cor+tamanho+SKU) →
  saldo por local, 4 tipos de preço (PIX/Dinheiro/Débito/Crédito) implementados.
  Existe também um 4º tipo de produto (`SC` — Semiacabado) além de MP/AV/PC citados no
  prompt mestre; não é claramente uma inconsistência, mas não está descrito na
  especificação — vale confirmar se é intencional.
- **Transferência ≠ baixa (regra 26):** confirmado no código — são fluxos e telas
  separados (`/estoque/transferencias` vs. baixa dentro de `/estoque/entradas`).
- **Baixa com motivo obrigatório (regra 27):** `ManualStockOutPayload` exige
  `motivoId`; não existe módulo de vendas.
- **Kardex:** presente com saldo anterior/resultante, local, usuário, motivo, e link
  rápido a partir de Estoque e Dashboard ("Ver Kardex" via query string).
- **OP e fluxo de produção:** setor cadastrável pelo usuário (não fixo), envio manual
  entre setores, fracionamento (enviado/perdido), consumo de materiais via ficha
  técnica com componentes pendentes visíveis. Três bugs reais de fracionamento/RBAC/
  compras já foram encontrados e corrigidos em auditorias anteriores (ver seção 4) —
  não reabri-los.
- **Compras:** status `ABERTA` (editável) / `CONCLUIDA` (fecha e baixa saldo),
  validação de itens antes de mutar o banco em memória (bug de estado parcial já
  corrigido, ver seção 4), fornecedor fornece só matéria-prima.
- **Paginação progressiva (regra 36):** `useProgressiveList` (10 → "Ver mais 10",
  reset ao filtrar) reutilizado de forma consistente nas 6 telas que precisam dela.
- **Dark/Light mode:** variáveis de tema presentes em `styles.css` (não aprofundado
  nesta etapa — pertence à Etapa 16).

### ⚠️ Incompleto / faltando (relativo ao Prompt Master)

1. **ADM DO SITE inexistente (seções 10, 11.1, 12, 13, 16, 19, 20 do prompt).** Não há:
   - rota `/site/login` nem qualquer tela de plataforma;
   - criação de empresa pela interface ("Nova Empresa" com dados da empresa +
     administrador inicial);
   - tela de gerenciamento de empresas (listar, ativar/inativar, ver administrador);
   - troca de contexto de empresa por um super-admin;
   - dashboard global (empresas totais/ativas/inativas, usuários totais);
   - auditoria global (hoje `auditoria` só existe por empresa).
   Hoje as duas empresas do seed (`Malharia Estrela`, `Vitória Malhas`) só existem
   porque foram escritas à mão em `seedData.ts` — não há como criar uma terceira sem
   editar código.
2. **Login único (`/login`) mistura o papel do seletor de empresa** que deveria, pela
   spec, ficar só no login da empresa — o que é razoável como solução interina, mas
   assume que sempre existirá uma lista pública de empresas para logar, sem
   diferenciação de portal.
3. **Auditoria (regra 20):** existe e registra ação/usuário/empresa/data, mas está
   escopada só à empresa logada — não há o nível "Auditoria Global" do ADM do site
   (dependente do item 1).
4. **Estoque mínimo (regra 25):** não verificado nesta etapa se o campo é
   configurável na tela de produto e se alimenta algum alerta no dashboard além do
   `LOW_STOCK_THRESHOLD` fixo (`15`) usado no Dashboard — esse limite parece
   hardcoded no componente em vez de vir do campo de estoque mínimo por variação.
   Precisa ser confirmado/corrigido numa etapa futura (provavelmente Etapa 8, saldo).

### 🔁 Observações menores / possível duplicação

- `PRODUTO_TIPOS` tem 4 valores (`MP`, `AV`, `SC`, `PC`) mas o prompt mestre só cita
  `MP` e `AV` (produto acabado é citado como "AV" na seção 22, mas a implementação usa
  `PC` = "Produto de Confecção" para produto acabado e `AV` para aviamento — os nomes
  parecem ter divergido semanticamente da seção 22 do prompt, que chama produto
  acabado de "AV"). Isso não é um bug de código, é uma possível divergência de
  nomenclatura entre a especificação e a implementação real — registrar e confirmar
  antes de mexer, não presumir qual lado está "certo".
- Nenhuma duplicação de componente/lógica encontrada nesta auditoria (o projeto reusa
  bem `NamedCrudPanel`, `useProgressiveList`, `RequirePermission`, `StatusBadge`, etc.).

### 🐞 Bugs já corrigidos em auditorias anteriores (documentados no código, não reabrir)

Encontrados como comentários `BUG REAL ENCONTRADO` / `BUG CORRIGIDO` inline, todos já
com a correção aplicada — mantidos aqui só como registro de que já foram tratados:

1. `mockRepository.ts` — `createEstoque`/`toggleEstoque` não geravam auditoria
   (encontrado e corrigido na auditoria da Etapa 13).
2. `mockRepository.ts` — OP trocava de etapa mesmo com saldo pendente na etapa atual,
   quebrando movimentações parciais (corrigido na Etapa 7).
3. `mockRepository.ts` — etapa que nascia 100% refugada (0 recebido) travava a OP para
   sempre (encontrado e corrigido na auditoria da Etapa 8).
4. `mockRepository.ts` — `createNotaFiscal`/itens inválidos no meio da lista deixavam
   o banco em memória em estado parcial (encontrado e corrigido na auditoria da Etapa
   11).

### 🔴 Bug crítico da Etapa 1 (contexto, já resolvido)

`src/pages/estoque/page.tsx` chamava `useProgressiveList` depois de `return`s
condicionais, violando as Rules of Hooks e derrubando a tela Estoque → Saldos.
Corrigido na Etapa 1 (ver `RELATORIO_ETAPA1.md`).

## 3. Arquivos alterados nesta etapa

Nenhum. Etapa 2 é somente levantamento — nenhuma correção ou funcionalidade foi
implementada, conforme a regra da própria etapa ("não implementar tudo ainda").

## 4. Testes realizados

- Verificação programática de que toda função exportada de `mockRepository.ts` que
  manipula entidade de negócio recebe e filtra por `empresaId`.
- Verificação de que as 20 rotas em `routeTree.gen.ts` correspondem 1:1 aos 20
  arquivos de rota existentes.
- Leitura completa de: RBAC/permissões, navegação, todas as páginas de Estoque,
  Produtos, Compras, Produção (índice, detalhe, fluxos, refugos), Equipe, Cadastros,
  Auditoria, Dashboard, Login.
- Não testado (requer execução real, sem ambiente de rede neste sandbox): fluxos
  interativos completos (criar OP do zero, concluir etapa com consumo, criar nota
  fiscal e concluir, etc.) e Dark Mode/responsividade visual.

## 5. Pendências para etapas futuras

- **Etapa 3 (Fundação Multiempresa):** implementar a camada de plataforma que hoje
  não existe — ADM DO SITE, `/site/login`, criação de empresa, contexto/troca de
  empresa. Este é o maior bloco de trabalho pendente identificado nesta auditoria.
- **Etapa 6 (Painel global):** depende da Etapa 3; hoje não há onde implementá-lo.
- **Etapa 8 (Produtos/saldo):** confirmar se `LOW_STOCK_THRESHOLD` fixo no Dashboard
  deveria vir do campo de estoque mínimo por variação em vez de uma constante única.
- Confirmar a divergência de nomenclatura `AV`/`PC`/`SC` com quem definiu a spec antes
  de qualquer alteração nos tipos (não alterar o banco, e não renomear por conta
  própria sem confirmação — regra 64 do prompt mestre).

## 6. Próxima etapa

> PRÓXIMA ETAPA: 3 — Fundação Multiempresa

## 7. Prompt de continuação

```
Você está continuando o desenvolvimento do CAMISARIA ERP (multiempresa, têxtil,
React 19 + TypeScript + TanStack Start/Router + Tailwind v4 + shadcn/ui, dados mock em
localStorage via src/services/apiClient.ts + mockRepository.ts). Segue o "Prompt
Master — Camisaria ERP" (envie junto se ainda não estiver no seu contexto) e a regra
de UMA ETAPA POR VEZ.

ESTADO ATUAL:
- Etapa 1 (erro crítico): concluída — bug de Rules of Hooks em
  src/pages/estoque/page.tsx corrigido. Ver RELATORIO_ETAPA1.md.
- Etapa 2 (auditoria): concluída — ver AUDITORIA_ETAPA2.md na raiz do projeto para o
  levantamento completo. Resumo do achado principal: o projeto já tem bastante coisa
  implementada e funcionando bem (RBAC de empresa, produtos/variações/saldo,
  transferências/baixas, Kardex, OP com fluxo/fracionamento/consumo, compras) — mas a
  camada de PLATAFORMA MULTIEMPRESA (ADM DO SITE) não existe: não há /site/login, não
  há criação de empresa pela UI, não há painel global, não há troca de contexto de
  empresa por um super-admin. Hoje as empresas do seed (Malharia Estrela, Vitória
  Malhas) só existem porque foram escritas à mão em seedData.ts.

SUA TAREFA AGORA: executar SOMENTE a ETAPA 3 — Fundação Multiempresa, conforme a
seção 62 do prompt mestre. Isso significa implementar (sem alterar o banco, sem
redesign, reaproveitando o Design System/componentes shadcn já existentes):
- Conceito de empresa e contexto de empresa atual (já existe parcialmente via
  AuthContext — avalie se dá para reaproveitar ou precisa de um contexto de
  plataforma separado para o ADM do site).
- Isolamento (já garantido no mockRepository.ts, quase todas as funções já recebem
  empresaId — a base está sólida, foque em construir a camada de ADM DO SITE por
  cima, não em refazer o isolamento que já existe e funciona).
- apiClient respeitando tenant (idem — já funciona; estenda em vez de recriar).
- Dados mock: adicione um usuário ADM DO SITE ao seedData.ts (papel próprio, fora do
  `cargo` de empresa — decida a estrutura mais coerente com o banco/tipos existentes,
  sem inventar tabelas novas).
- Estrutura global mínima para viabilizar as etapas 5 e 6 seguintes (login separado
  de plataforma, painel global) — mas essas telas específicas são das PRÓXIMAS etapas
  (5 e 6), não desta. Foque nesta etapa só na fundação de dados/contexto.

ARQUIVOS RELEVANTES: src/context/AuthContext.tsx, src/services/apiClient.ts,
src/services/mockRepository.ts, src/mock/seedData.ts, src/types/index.ts,
src/constants/permissions.ts.

REGRAS QUE DEVE RESPEITAR:
- Não altere o banco de dados (bd_competeV6.sql) sob nenhuma circunstância.
- Não faça redesign nem melhorias visuais nesta etapa.
- Não implemente ainda as telas de login de plataforma nem o painel global — isso é
  Etapa 5 e 6. Foque na fundação (dados, contexto, isolamento).
- Preserve tudo que já funciona (RBAC de empresa, produtos, estoque, produção,
  compras) — não precisa mexer nesses módulos nesta etapa.
- Ao final, PARE e produza: resumo, arquivos alterados, testes realizados,
  pendências, "PRÓXIMA ETAPA: X — NOME", prompt de continuação completo, e o ZIP
  atualizado.

CRITÉRIO DE CONCLUSÃO: existe uma estrutura de dados e de contexto que permite,
nas próximas duas etapas, construir o login de plataforma e o painel global sem
precisar redesenhar a fundação.
```

## 8. ZIP atualizado

Nenhuma alteração de código nesta etapa — o ZIP entregue contém o mesmo código da
Etapa 1 (já corrigido), acrescido deste relatório de auditoria.
