// Validação funcional da Etapa 11 (Compras e Estoque). Roda as funções
// REAIS de src/services/mockRepository.ts em Node (mesma técnica de
// scripts/validate-op-etapa6/7/8/9/10.ts).
//
// A auditoria desta etapa encontrou 2 lacunas reais:
//   1. createNotaFiscal não rejeitava SKU duplicado dentro da mesma
//      nota (achado desde a Etapa 0 — UNIQUE (nota_fiscal_id,
//      produto_variacao_id) em nota_fiscal_item no bd_competeV6.sql).
//      Além disso, a validação dos itens acontecia DEPOIS de a nota (e
//      itens anteriores) já terem sido inseridos no `database` em
//      memória — um item inválido no meio da lista deixava a nota e os
//      itens processados até ali "presos" no banco em memória, mesmo
//      sem persist() ter sido chamado.
//   2. Não existia NENHUMA forma de editar uma nota EM_ABERTO (regra
//      21 do prompt mestre) — só create/complete/cancel.
//
// Este script confirma por teste real (não leitura de código):
//   - SKU duplicado na criação é rejeitado, com mensagem clara, e NÃO
//     deixa a nota/itens anteriores presos no banco em memória.
//   - Nota EM_ABERTO pode ser editada (número, fornecedor, itens) SEM
//     alterar nenhum saldo de estoque.
//   - updateNotaFiscal também rejeita SKU duplicado e valida itens.
//   - updateNotaFiscal rejeita edição de nota que não está mais ABERTA
//     (CONCLUIDA ou CANCELADA).
//   - completeNotaFiscal gera Kardex COMPRA com quantidade exata de
//     cada item e atualiza o saldo físico corretamente; a nota edição
//     não é mais permitida depois de concluída.
//   - cancelNotaFiscal nunca mexe em estoque/Kardex.
//   - manualStockOut com natureza AJUSTE (mecanismo de estorno já
//     existente na arquitetura — comentário do próprio banco: "Estorno
//     se faz com um novo lançamento de natureza AJUSTE") consegue
//     reverter uma entrada de compra sem apagar o histórico do Kardex
//     original.
//
// Não inventa nenhuma tabela/coluna fora do bd_competeV6.sql.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 11" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

const variacoes = repo.listVariacoes(E1, true);
const estoques = repo.listEstoques(E1, true);
const fornecedores = repo.listFornecedores(E1, true);
const unidadeTeste = repo.listUnidadesMedida()[0].id;

const skuA = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
let fornecedor1 = fornecedores[0];
if (!fornecedor1) {
  fornecedor1 = repo.createFornecedor(E1, { nome: "Fornecedor Teste Etapa 11", cnpj: null, email: null, telefone: null });
}

assert(!!skuA && !!estFabrica && !!fornecedor1, "Massa de dados do seed encontrada (SKU camiseta, estoque fábrica, fornecedor)");

// Segundo SKU de teste, só para os cenários de múltiplos itens.
const produtoB = repo.createProduto(E1, USUARIO, {
  nome: "Componente Teste Etapa11 — B",
  tipo: "MP",
  colecaoId: null,
  unidadeMedidaId: unidadeTeste,
  ncm: null,
  cest: null,
  origem: null,
  categoriaIds: [],
  variacoes: [{ corId: null, tamanhoId: null, sku: "MP-TESTE-E11-B", codigoBarras: null, precos: [] }],
});
const skuB = repo.listVariacoesDoProduto(produtoB.id, E1)[0];

function saldoDe(variacaoId: number, estoqueId: number): number {
  return repo.getSaldosDaVariacao(variacaoId, E1).find((s) => s.estoqueId === estoqueId)?.quantidade ?? 0;
}

function kardexDaVariacao(variacaoId: number): number {
  return repo.listKardex(E1).filter((k) => k.produtoVariacaoId === variacaoId).length;
}

// ===================================================================
// CENÁRIO 1 — SKU duplicado é rejeitado na CRIAÇÃO, e não deixa a nota
// nem itens anteriores presos no banco em memória.
// ===================================================================
const notasAntes = repo.listNotasFiscais(E1).length;
let erroDuplicado: string | null = null;
try {
  repo.createNotaFiscal(E1, USUARIO, {
    numero: "NF-TESTE-E11-DUP",
    fornecedorId: fornecedor1.id,
    estoqueId: estFabrica.id,
    dataEmissao: new Date().toISOString(),
    observacao: null,
    itens: [
      { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 10, valorUnitario: 5 },
      { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 3, valorUnitario: 5 }, // mesmo SKU
    ],
  });
} catch (err) {
  erroDuplicado = err instanceof Error ? err.message : "erro desconhecido";
}
assert(erroDuplicado !== null, "createNotaFiscal REJEITA SKU duplicado dentro da mesma nota");
assert(erroDuplicado !== null && erroDuplicado.toLowerCase().includes("sku"), `Mensagem de erro é clara sobre o motivo (SKU duplicado): "${erroDuplicado}"`);
assert(repo.listNotasFiscais(E1).length === notasAntes, "A tentativa rejeitada NÃO deixa a nota presa no banco em memória (nenhuma nota nova persistiu)");

// ===================================================================
// CENÁRIO 2 — criação válida com 2 SKUs diferentes, depois EDIÇÃO da
// nota (ainda ABERTA) sem alterar nenhum saldo de estoque.
// ===================================================================
const saldoAAntes = saldoDe(skuA.id, estFabrica.id);
const saldoBAntes = saldoDe(skuB.id, estFabrica.id);
const kardexAAntes = kardexDaVariacao(skuA.id);
const kardexBAntes = kardexDaVariacao(skuB.id);

const nota1 = repo.createNotaFiscal(E1, USUARIO, {
  numero: "NF-TESTE-E11-001",
  fornecedorId: fornecedor1.id,
  estoqueId: estFabrica.id,
  dataEmissao: new Date().toISOString(),
  observacao: "Nota original",
  itens: [
    { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 10, valorUnitario: 5 },
    { produtoVariacaoId: skuB.id, unidadeMedidaId: unidadeTeste, quantidade: 20, valorUnitario: 2 },
  ],
});
assert(nota1.status === "ABERTA", "Nota criada corretamente com status ABERTA");
assert(saldoDe(skuA.id, estFabrica.id) === saldoAAntes && saldoDe(skuB.id, estFabrica.id) === saldoBAntes, "Criação de nota ABERTA não altera nenhum saldo de estoque");

const notaEditada = repo.updateNotaFiscal(nota1.id, E1, USUARIO, {
  numero: "NF-TESTE-E11-001-EDITADA",
  fornecedorId: fornecedor1.id,
  estoqueId: estFabrica.id,
  dataEmissao: new Date().toISOString(),
  observacao: "Nota corrigida — quantidade do item A ajustada",
  itens: [
    { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 15, valorUnitario: 5.5 }, // quantidade e valor corrigidos
    { produtoVariacaoId: skuB.id, unidadeMedidaId: unidadeTeste, quantidade: 20, valorUnitario: 2 },
  ],
});
assert(notaEditada.numero === "NF-TESTE-E11-001-EDITADA", "updateNotaFiscal aplica a alteração de número");
const itensEditados = repo.listItensDaNota(nota1.id, E1);
assert(itensEditados.length === 2, `updateNotaFiscal substitui a lista de itens corretamente (2 itens): ${itensEditados.length}`);
const itemAEditado = itensEditados.find((i) => i.produtoVariacaoId === skuA.id)!;
assert(itemAEditado.quantidade === 15 && itemAEditado.valorUnitario === 5.5, `Item A refletiu a correção de quantidade/valor (15 / 5.5): ${itemAEditado.quantidade} / ${itemAEditado.valorUnitario}`);
assert(notaEditada.valorTotal === 15 * 5.5 + 20 * 2, `valorTotal da nota recalculado corretamente após a edição: ${notaEditada.valorTotal} == ${15 * 5.5 + 20 * 2}`);
assert(
  saldoDe(skuA.id, estFabrica.id) === saldoAAntes && saldoDe(skuB.id, estFabrica.id) === saldoBAntes,
  "EDIÇÃO da nota ABERTA não altera NENHUM saldo de estoque (regra 21 — só concluir gera entrada)",
);
assert(
  kardexDaVariacao(skuA.id) === kardexAAntes && kardexDaVariacao(skuB.id) === kardexBAntes,
  "EDIÇÃO da nota ABERTA não gera NENHUM lançamento de Kardex",
);

// updateNotaFiscal também valida itens (reaproveita validarItensNota).
let erroEdicaoDuplicada: string | null = null;
try {
  repo.updateNotaFiscal(nota1.id, E1, USUARIO, {
    numero: "NF-TESTE-E11-001-EDITADA",
    fornecedorId: fornecedor1.id,
    estoqueId: estFabrica.id,
    dataEmissao: new Date().toISOString(),
    observacao: null,
    itens: [
      { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 1, valorUnitario: 1 },
      { produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 2, valorUnitario: 1 },
    ],
  });
} catch (err) {
  erroEdicaoDuplicada = err instanceof Error ? err.message : "erro desconhecido";
}
assert(erroEdicaoDuplicada !== null && erroEdicaoDuplicada.toLowerCase().includes("sku"), `updateNotaFiscal também rejeita SKU duplicado: "${erroEdicaoDuplicada}"`);

// ===================================================================
// CENÁRIO 3 — completeNotaFiscal gera Kardex COMPRA com quantidade
// exata de cada item e atualiza o saldo físico; depois disso, a nota
// não pode mais ser editada nem cancelada.
// ===================================================================
const notaConcluida = repo.completeNotaFiscal(nota1.id, E1, USUARIO);
assert(notaConcluida.status === "CONCLUIDA", "completeNotaFiscal conclui a nota (status CONCLUIDA)");
assert(saldoDe(skuA.id, estFabrica.id) === saldoAAntes + 15, `Saldo físico do SKU A aumentou exatamente 15 (quantidade do item editado): ${saldoDe(skuA.id, estFabrica.id)} == ${saldoAAntes + 15}`);
assert(saldoDe(skuB.id, estFabrica.id) === saldoBAntes + 20, `Saldo físico do SKU B aumentou exatamente 20: ${saldoDe(skuB.id, estFabrica.id)} == ${saldoBAntes + 20}`);

const kardexComprasNota1 = repo
  .listKardex(E1)
  .filter((k) => itensEditados.some((i) => i.id === k.notaFiscalItemId) && k.natureza === "COMPRA");
assert(kardexComprasNota1.length === 2, `completeNotaFiscal gera 1 lançamento Kardex COMPRA por item (2 itens, 2 lançamentos): ${kardexComprasNota1.length}`);
const kardexCompraA = kardexComprasNota1.find((k) => k.produtoVariacaoId === skuA.id)!;
assert(kardexCompraA.quantidade === 15 && kardexCompraA.sentido === "ENTRADA", `Kardex COMPRA do SKU A tem a quantidade EXATA do item (15) e sentido ENTRADA: ${kardexCompraA.quantidade} / ${kardexCompraA.sentido}`);
assert(kardexCompraA.notaFiscalItemId === itemAEditado.id, "Kardex COMPRA referencia o item da nota como documento relacionado (notaFiscalItemId)");

let erroEditarConcluida: string | null = null;
try {
  repo.updateNotaFiscal(nota1.id, E1, USUARIO, {
    numero: "NAO-DEVERIA-FUNCIONAR",
    fornecedorId: fornecedor1.id,
    estoqueId: estFabrica.id,
    dataEmissao: new Date().toISOString(),
    observacao: null,
    itens: [{ produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 1, valorUnitario: 1 }],
  });
} catch (err) {
  erroEditarConcluida = err instanceof Error ? err.message : "erro desconhecido";
}
assert(erroEditarConcluida !== null, "updateNotaFiscal REJEITA edição de nota já CONCLUIDA");

let erroCancelarConcluida: string | null = null;
try {
  repo.cancelNotaFiscal(nota1.id, E1, USUARIO);
} catch (err) {
  erroCancelarConcluida = err instanceof Error ? err.message : "erro desconhecido";
}
assert(erroCancelarConcluida !== null, "cancelNotaFiscal REJEITA cancelar nota já CONCLUIDA");

// ===================================================================
// CENÁRIO 4 — cancelNotaFiscal (numa nota ainda ABERTA) nunca mexe em
// estoque/Kardex.
// ===================================================================
const nota2 = repo.createNotaFiscal(E1, USUARIO, {
  numero: "NF-TESTE-E11-002-CANCELAR",
  fornecedorId: fornecedor1.id,
  estoqueId: estFabrica.id,
  dataEmissao: new Date().toISOString(),
  observacao: null,
  itens: [{ produtoVariacaoId: skuA.id, unidadeMedidaId: unidadeTeste, quantidade: 7, valorUnitario: 3 }],
});
const saldoAAntesCancelar = saldoDe(skuA.id, estFabrica.id);
const kardexAAntesCancelar = kardexDaVariacao(skuA.id);
const notaCancelada = repo.cancelNotaFiscal(nota2.id, E1, USUARIO);
assert(notaCancelada.status === "CANCELADA", "cancelNotaFiscal cancela a nota ABERTA com sucesso");
assert(saldoDe(skuA.id, estFabrica.id) === saldoAAntesCancelar, "Cancelamento de nota ABERTA não altera saldo de estoque");
assert(kardexDaVariacao(skuA.id) === kardexAAntesCancelar, "Cancelamento de nota ABERTA não gera lançamento de Kardex");

// ===================================================================
// CENÁRIO 5 — estorno de uma compra concluída por engano usa o
// mecanismo JÁ EXISTENTE na arquitetura: manualStockOut com natureza
// AJUSTE (comentário do próprio bd_competeV6.sql: "Estorno se faz com
// um novo lançamento de natureza AJUSTE"). Não apaga o Kardex
// original da compra — só lança um novo movimento de saída.
// ===================================================================
const saldoAAntesEstorno = saldoDe(skuA.id, estFabrica.id);
const kardexCountAntesEstorno = repo.listKardex(E1).length;
repo.manualStockOut(E1, USUARIO, {
  produtoVariacaoId: skuA.id,
  estoqueId: estFabrica.id,
  quantidade: 15,
  natureza: "AJUSTE",
  observacao: "Estorno da nota NF-TESTE-E11-001-EDITADA lançada por engano (teste Etapa 11)",
});
assert(saldoDe(skuA.id, estFabrica.id) === saldoAAntesEstorno - 15, `Estorno via AJUSTE reduz o saldo físico exatamente pela quantidade estornada: ${saldoDe(skuA.id, estFabrica.id)} == ${saldoAAntesEstorno - 15}`);
assert(repo.listKardex(E1).length === kardexCountAntesEstorno + 1, "Estorno gera um NOVO lançamento de Kardex (não apaga/edita o lançamento original da compra)");
assert(
  repo.listKardex(E1).some((k) => k.id === kardexCompraA.id),
  "O lançamento Kardex ORIGINAL da compra continua existindo e imutável após o estorno (histórico preservado)",
);

// ===================================================================
// Invariante global de sempre (mesmo padrão dos scripts anteriores).
// ===================================================================
const saldosFinais = repo.listSaldos(E1);
const invarianteReserva = saldosFinais.every((s) => s.quantidadeReservada >= -1e-9 && s.quantidadeReservada <= s.quantidade + 1e-9);
assert(invarianteReserva, `Invariante global — 0 <= reservada <= quantidade em todos os ${saldosFinais.length} saldos da empresa`);

console.log(falhas === 0 ? "\nTUDO OK — cenários da Etapa 11 (SKU duplicado rejeitado, edição de nota ABERTA sem tocar estoque, conclusão gera Kardex exato, cancelamento não mexe em estoque, estorno via AJUSTE preserva histórico)." : `\n${falhas} FALHA(S) na Etapa 11.`);
process.exit(falhas === 0 ? 0 : 1);
