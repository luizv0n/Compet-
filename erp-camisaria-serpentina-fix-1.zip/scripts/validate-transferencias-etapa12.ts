// Validação funcional da Etapa 12 (Transferências). Roda as funções
// REAIS de src/services/mockRepository.ts em Node (mesma técnica de
// scripts/validate-op-etapa6/7/8/9/10.ts e validate-compras-etapa11.ts).
//
// AUDITORIA DESTA ETAPA (código lido antes de qualquer alteração):
//   - transferStock (mockRepository.ts) já existia, completo: valida
//     origem != destino, quantidade > 0, gera exatamente 2 lançamentos
//     de Kardex (SAIDA na origem + ENTRADA no destino, natureza
//     TRANSFERENCIA) via applyKardexAndBalance, que por sua vez já
//     valida saldo suficiente (RepositoryError se insuficiente) e
//     grava saldoAnterior/saldoResultante em cada lançamento.
//   - apiClient.estoques.transfer já expõe a função 1:1.
//   - src/pages/estoque/transferencias/page.tsx JÁ EXISTE: formulário
//     completo (SKU, origem, destino, quantidade, observação),
//     bloqueia origem==destino na própria UI antes de chamar a API,
//     mostra saldo disponível da origem, lista as transferências
//     recentes filtrando o Kardex por natureza TRANSFERENCIA, e já lê
//     ?variacao=&estoque= da querystring para pré-selecionar SKU e
//     origem quando aberta a partir de uma ação rápida.
//   - src/pages/estoque/page.tsx JÁ TEM a ação rápida "Transferir" ao
//     lado de "Kardex" em cada linha da listagem de saldos, com o
//     MESMO padrão visual (botão pequeno + ícone + texto) — não foi
//     necessário criar nada, nem duplicar tela, nem inventar um
//     segundo padrão de ação rápida.
//   - Nenhuma mudança de schema pendente para Transferências no
//     bd_competeV6.sql (mesma conclusão das auditorias das Etapas 0 e
//     11) — kardex.natureza já contempla 'TRANSFERENCIA' e a tabela de
//     saldo (produto_estoque) já é chaveada por
//     (produto_variacao_id, estoque_id).
//
// CONCLUSÃO: transferStock, apiClient e a tela de Transferências já
// estavam OK (nenhum bug real encontrado). Esta etapa é
// principalmente sobre CONFIRMAR isso com testes reais, como pedido
// no prompt de continuação — nenhuma correção de código foi
// necessária em mockRepository.ts, apiClient.ts ou nas páginas de
// estoque.
//
// Cenários cobertos (item 2 do prompt de continuação):
//   1. Fábrica → Loja Centro
//   2. Loja Centro → Fábrica
//   3. Loja Centro → Loja Norte (loja → loja)
//   4. Origem == destino é rejeitado com mensagem clara
//   5. Quantidade <= 0 é rejeitada
//   6. Transferência com saldo insuficiente na origem é rejeitada, com
//      mensagem limpa (a mesma que chegaria até a UI via apiClient)
//   7. Em cada transferência válida: exatamente 2 lançamentos de
//      Kardex (1 SAIDA + 1 ENTRADA) com a MESMA quantidade; saldo da
//      origem cai exatamente a quantidade transferida; saldo do
//      destino sobe exatamente a mesma quantidade (sem perda/ganho).
//
// Não inventa nenhuma tabela/coluna fora do bd_competeV6.sql.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 12" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

function saldoDe(produtoVariacaoId: number, estoqueId: number) {
  const row = repo.listSaldos(E1).find((s) => s.produtoVariacaoId === produtoVariacaoId && s.estoqueId === estoqueId);
  return row?.quantidade ?? 0;
}

const estoques = repo.listEstoques(E1, true);
const fabrica = estoques.find((e) => e.nome === "Fábrica")!;
const lojaCentro = estoques.find((e) => e.nome === "Loja Centro")!;
const lojaNorte = estoques.find((e) => e.nome === "Loja Norte")!;
assert(!!fabrica && !!lojaCentro && !!lojaNorte, "Massa de dados do seed encontrada (Fábrica, Loja Centro, Loja Norte da empresa 1)");

const variacoes = repo.listVariacoes(E1, true);
const sku = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
assert(!!sku, "SKU de teste (PC-CAM-PRETO-M) encontrado no seed");

// -----------------------------------------------------------------
// Cenário 1 — Fábrica → Loja Centro
// -----------------------------------------------------------------
{
  const antesOrigem = saldoDe(sku.id, fabrica.id);
  const antesDestino = saldoDe(sku.id, lojaCentro.id);
  const kardexAntes = repo.listKardex(E1).length;
  const qtd = 5;

  repo.transferStock(E1, USUARIO, {
    produtoVariacaoId: sku.id,
    estoqueOrigemId: fabrica.id,
    estoqueDestinoId: lojaCentro.id,
    quantidade: qtd,
    observacao: "Teste Etapa 12 — Fábrica → Loja Centro",
  });

  const depoisOrigem = saldoDe(sku.id, fabrica.id);
  const depoisDestino = saldoDe(sku.id, lojaCentro.id);
  const novosLancamentos = repo.listKardex(E1).length - kardexAntes;

  assert(novosLancamentos === 2, `Fábrica → Loja Centro gera exatamente 2 lançamentos de Kardex: ${novosLancamentos}`);
  assert(depoisOrigem === antesOrigem - qtd, `Saldo da origem (Fábrica) caiu exatamente ${qtd}: ${antesOrigem} → ${depoisOrigem}`);
  assert(depoisDestino === antesDestino + qtd, `Saldo do destino (Loja Centro) subiu exatamente ${qtd}: ${antesDestino} → ${depoisDestino}`);

  const novos = repo
    .listKardex(E1)
    .filter((k) => k.natureza === "TRANSFERENCIA")
    .sort((a, b) => a.id - b.id)
    .slice(-2);
  const saida = novos.find((k) => k.sentido === "SAIDA")!;
  const entrada = novos.find((k) => k.sentido === "ENTRADA")!;
  assert(!!saida && !!entrada, "Um lançamento SAIDA e um lançamento ENTRADA foram gerados");
  assert(saida.quantidade === qtd && entrada.quantidade === qtd, `Ambos os lançamentos têm a MESMA quantidade (${qtd})`);
  assert(saida.estoqueId === fabrica.id, "Lançamento SAIDA está no estoque de origem (Fábrica)");
  assert(entrada.estoqueId === lojaCentro.id, "Lançamento ENTRADA está no estoque de destino (Loja Centro)");
  assert(
    saida.saldoAnterior === antesOrigem && saida.saldoResultante === depoisOrigem,
    "Lançamento SAIDA registra saldoAnterior/saldoResultante corretos",
  );
  assert(
    entrada.saldoAnterior === antesDestino && entrada.saldoResultante === depoisDestino,
    "Lançamento ENTRADA registra saldoAnterior/saldoResultante corretos",
  );
}

// -----------------------------------------------------------------
// Cenário 2 — Loja Centro → Fábrica
// -----------------------------------------------------------------
{
  const antesOrigem = saldoDe(sku.id, lojaCentro.id);
  const antesDestino = saldoDe(sku.id, fabrica.id);
  const kardexAntes = repo.listKardex(E1).length;
  const qtd = 3;

  repo.transferStock(E1, USUARIO, {
    produtoVariacaoId: sku.id,
    estoqueOrigemId: lojaCentro.id,
    estoqueDestinoId: fabrica.id,
    quantidade: qtd,
  });

  const depoisOrigem = saldoDe(sku.id, lojaCentro.id);
  const depoisDestino = saldoDe(sku.id, fabrica.id);
  const novosLancamentos = repo.listKardex(E1).length - kardexAntes;

  assert(novosLancamentos === 2, `Loja Centro → Fábrica gera exatamente 2 lançamentos de Kardex: ${novosLancamentos}`);
  assert(depoisOrigem === antesOrigem - qtd, `Saldo da origem (Loja Centro) caiu exatamente ${qtd}: ${antesOrigem} → ${depoisOrigem}`);
  assert(depoisDestino === antesDestino + qtd, `Saldo do destino (Fábrica) subiu exatamente ${qtd}: ${antesDestino} → ${depoisDestino}`);
}

// -----------------------------------------------------------------
// Cenário 3 — Loja Centro → Loja Norte (loja → loja)
// -----------------------------------------------------------------
{
  const antesOrigem = saldoDe(sku.id, lojaCentro.id);
  const antesDestino = saldoDe(sku.id, lojaNorte.id);
  const kardexAntes = repo.listKardex(E1).length;
  const qtd = 2;

  repo.transferStock(E1, USUARIO, {
    produtoVariacaoId: sku.id,
    estoqueOrigemId: lojaCentro.id,
    estoqueDestinoId: lojaNorte.id,
    quantidade: qtd,
  });

  const depoisOrigem = saldoDe(sku.id, lojaCentro.id);
  const depoisDestino = saldoDe(sku.id, lojaNorte.id);
  const novosLancamentos = repo.listKardex(E1).length - kardexAntes;

  assert(novosLancamentos === 2, `Loja Centro → Loja Norte gera exatamente 2 lançamentos de Kardex: ${novosLancamentos}`);
  assert(depoisOrigem === antesOrigem - qtd, `Saldo da origem (Loja Centro) caiu exatamente ${qtd}: ${antesOrigem} → ${depoisOrigem}`);
  assert(depoisDestino === antesDestino + qtd, `Saldo do destino (Loja Norte) subiu exatamente ${qtd}: ${antesDestino} → ${depoisDestino}`);
}

// -----------------------------------------------------------------
// Cenário 4 — Origem == destino é rejeitado
// -----------------------------------------------------------------
{
  let erro: unknown = null;
  try {
    repo.transferStock(E1, USUARIO, {
      produtoVariacaoId: sku.id,
      estoqueOrigemId: fabrica.id,
      estoqueDestinoId: fabrica.id,
      quantidade: 1,
    });
  } catch (e) {
    erro = e;
  }
  assert(erro instanceof repo.RepositoryError, "Origem == destino é REJEITADA com RepositoryError");
  assert(
    erro instanceof Error && /diferentes/i.test(erro.message),
    `Mensagem de erro é clara sobre origem/destino iguais: "${erro instanceof Error ? erro.message : erro}"`,
  );
}

// -----------------------------------------------------------------
// Cenário 5 — Quantidade <= 0 é rejeitada
// -----------------------------------------------------------------
{
  let erroZero: unknown = null;
  try {
    repo.transferStock(E1, USUARIO, {
      produtoVariacaoId: sku.id,
      estoqueOrigemId: fabrica.id,
      estoqueDestinoId: lojaCentro.id,
      quantidade: 0,
    });
  } catch (e) {
    erroZero = e;
  }
  assert(erroZero instanceof repo.RepositoryError, "Quantidade == 0 é REJEITADA com RepositoryError");

  let erroNegativo: unknown = null;
  try {
    repo.transferStock(E1, USUARIO, {
      produtoVariacaoId: sku.id,
      estoqueOrigemId: fabrica.id,
      estoqueDestinoId: lojaCentro.id,
      quantidade: -4,
    });
  } catch (e) {
    erroNegativo = e;
  }
  assert(erroNegativo instanceof repo.RepositoryError, "Quantidade negativa é REJEITADA com RepositoryError");
}

// -----------------------------------------------------------------
// Cenário 6 — Saldo insuficiente na origem é rejeitado
// -----------------------------------------------------------------
{
  const saldoOrigemAntes = saldoDe(sku.id, lojaNorte.id);
  const saldoDestinoAntes = saldoDe(sku.id, fabrica.id);
  const kardexAntes = repo.listKardex(E1).length;

  let erro: unknown = null;
  try {
    repo.transferStock(E1, USUARIO, {
      produtoVariacaoId: sku.id,
      estoqueOrigemId: lojaNorte.id,
      estoqueDestinoId: fabrica.id,
      quantidade: saldoOrigemAntes + 1000,
    });
  } catch (e) {
    erro = e;
  }
  assert(erro instanceof repo.RepositoryError, "Transferência com saldo insuficiente é REJEITADA com RepositoryError");
  assert(
    erro instanceof Error && /saldo dispon[íi]vel/i.test(erro.message),
    `Mensagem de erro chega limpa (a mesma que a UI usa em err.message): "${erro instanceof Error ? erro.message : erro}"`,
  );

  const saldoOrigemDepois = saldoDe(sku.id, lojaNorte.id);
  const saldoDestinoDepois = saldoDe(sku.id, fabrica.id);
  const novosLancamentos = repo.listKardex(E1).length - kardexAntes;
  assert(saldoOrigemDepois === saldoOrigemAntes, "Saldo insuficiente rejeitado: saldo de origem NÃO foi alterado");
  assert(saldoDestinoDepois === saldoDestinoAntes, "Saldo insuficiente rejeitado: saldo de destino NÃO foi alterado (falha atômica — SAIDA falhou antes da ENTRADA)");
  assert(novosLancamentos === 0, "Saldo insuficiente rejeitado: NENHUM lançamento de Kardex foi gerado (nem o SAIDA que falhou)");
}

// -----------------------------------------------------------------
// Invariante global — nenhuma transferência mexeu em reserva, e
// 0 <= reservada <= quantidade continua valendo para todo o seed.
// -----------------------------------------------------------------
{
  const saldos = repo.listSaldos(E1);
  const ok = saldos.every((s) => s.quantidadeReservada >= 0 && s.quantidadeReservada <= s.quantidade + 1e-9);
  assert(ok, `Invariante global — 0 <= reservada <= quantidade em todos os ${saldos.length} saldos da empresa (transferência não mexe em reserva)`);
}

console.log("");
if (falhas > 0) {
  console.error(`${falhas} FALHA(S) encontradas na Etapa 12.`);
  process.exit(1);
} else {
  console.log(
    "TUDO OK — cenários da Etapa 12 (Fábrica→Loja, Loja→Fábrica, Loja→Loja, origem==destino rejeitada, quantidade<=0 rejeitada, saldo insuficiente rejeitado sem deixar Kardex/saldo inconsistente, saldos exatos em origem e destino).",
  );
}
