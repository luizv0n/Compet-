// Validação funcional da Etapa 10 (finalização da OP). Roda as funções
// REAIS de src/services/mockRepository.ts em Node (mesma técnica de
// scripts/validate-op-etapa6/7/8/9.ts).
//
// A auditoria desta etapa concluiu que a finalização (última etapa →
// quantidade boa → estoque destino → PRODUCAO_ENTRADA → Kardex → OP
// concluída) já estava implementada e coberta INDIRETAMENTE pelos
// cenários das Etapas 8 e 9 — nenhum bug real de finalização foi
// encontrado. Este script fecha a lacuna que faltava: um teste
// EXPLÍCITO, focado só na finalização, com os 3 cenários pedidos pelo
// prompt de continuação:
//
//   1. Sem refugo, com MÚLTIPLAS levas parciais na última etapa (não
//      uma leva única) — confirma que cada leva gera seu próprio
//      Kardex PRODUCAO_ENTRADA com a quantidade EXATA daquela leva, e
//      que a soma bate com quantidadeProduzida.
//   2. Refugo distribuído em VÁRIAS etapas diferentes do fluxo.
//   3. Refugo só na ÚLTIMA etapa, também em múltiplas levas parciais
//      (mistura boas+perdida na mesma movimentação, regra da Etapa 8).
//
// Em todos os 3: produzida + refugada == prevista EXATAMENTE, a OP
// termina CONCLUIDA com etapaAtualId null, e nenhuma etapa da OP fica
// em AGUARDANDO/EM_EXECUCAO (todas CONCLUIDA — nenhuma PULADA é usada
// nestes cenários porque toda etapa recebe material real).
//
// Não inventa nenhuma tabela/coluna fora do bd_competeV6.sql.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 10" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

const variacoes = repo.listVariacoes(E1, true);
const estoques = repo.listEstoques(E1, true);
const fluxos = repo.listFluxos(E1, true);
const motivos = repo.listMotivosPerda(E1, true);

const skuCamiseta = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
const fluxoCamiseta = fluxos.find((f) => f.nome.toLowerCase().includes("camiseta"))!;
const motivo1 = motivos[0];
const etapasFluxo = repo.listEtapasDoFluxo(fluxoCamiseta.id, E1);

assert(!!skuCamiseta && !!estFabrica && !!fluxoCamiseta && !!motivo1 && etapasFluxo.length >= 3, "Massa de dados do seed encontrada (SKU camiseta, estoque fábrica, fluxo com >= 3 etapas)");

function novaOP(quantidadePrevista: number, lote: string) {
  return repo.createOrdemProducao(E1, USUARIO, {
    produtoVariacaoId: skuCamiseta.id,
    fluxoProducaoId: fluxoCamiseta.id,
    quantidadePrevista,
    lote,
    estoqueOrigemId: estFabrica.id,
    estoqueDestinoId: estFabrica.id,
    dataAbertura: new Date().toISOString(),
    observacao: null,
  });
}

// listKardex ordena por dataMovimentacao DESC — dentro do mesmo
// milissegundo (comum neste script síncrono) a ordem relativa entre
// empates não é necessariamente a ordem de inserção. Para verificar
// "a leva N gerou a entrada N", ordenamos por `id` (atribuído em
// ordem crescente por nextIdFor a cada push, portanto cronológico de
// verdade) em vez de confiar na ordenação por data do listKardex.
function producaoEntradasDaOP(opId: number) {
  return repo
    .listKardex(E1)
    .filter((k) => k.ordemProducaoId === opId && k.natureza === "PRODUCAO_ENTRADA" && k.sentido === "ENTRADA")
    .sort((a, b) => Number(a.id) - Number(b.id))
    .map((k) => k.quantidade);
}

function etapasDaOPSemAbertas(opId: number): boolean {
  const etapas = repo.listEtapasDaOP(opId, E1);
  return etapas.every((e) => e.status !== "AGUARDANDO" && e.status !== "EM_EXECUCAO");
}

// ===================================================================
// CENÁRIO 1 — sem refugo, múltiplas levas parciais na ÚLTIMA etapa.
// ===================================================================
// Corte e Costura (e demais etapas intermediárias, se houver mais que
// 2) avançam 100% boas de uma vez. Na ÚLTIMA etapa, a leva de 10 é
// entregue em 3 movimentações parciais (4 + 3 + 3), simulando
// entregas reais de produto acabado ao longo do dia.
const op1 = novaOP(10, "L-TESTE-ETAPA10-PARCIAIS");
repo.releaseOrdemProducao(op1.id, E1, USUARIO);

// Avança 100% boas por todas as etapas, exceto a última, que será
// fechada em 3 levas parciais.
{
  let opAtual = repo.getOrdemProducao(op1.id, E1)!;
  let guard = 0;
  while (guard < 20) {
    guard++;
    const etapas = repo.listEtapasDaOP(op1.id, E1);
    const etapaAtual = etapas.find((e) => e.id === opAtual.etapaAtualId)!;
    const ehUltima = !etapas.some((e) => e.sequencia === etapaAtual.sequencia + 1);
    if (ehUltima) break;
    const disponivel = etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida;
    const r = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: disponivel, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Etapa intermediária 100% boas" });
    opAtual = r.op;
  }
}

// 3 levas parciais na última etapa: 4, 3 e 3.
const r1a = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 4, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Última etapa — leva 1/3" });
assert(r1a.op.status !== "CONCLUIDA", "Cenário 1 — leva parcial 1/3 (4 un.) não conclui a OP ainda");
assert(producaoEntradasDaOP(op1.id).length === 1 && producaoEntradasDaOP(op1.id)[0] === 4, `Cenário 1 — leva 1/3 gera Kardex PRODUCAO_ENTRADA com a quantidade EXATA da leva (4): ${JSON.stringify(producaoEntradasDaOP(op1.id))}`);

const r1b = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 3, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Última etapa — leva 2/3" });
assert(r1b.op.status !== "CONCLUIDA", "Cenário 1 — leva parcial 2/3 (+3 un., total 7/10) não conclui a OP ainda");
assert(producaoEntradasDaOP(op1.id).length === 2 && producaoEntradasDaOP(op1.id)[1] === 3, `Cenário 1 — leva 2/3 gera um SEGUNDO Kardex PRODUCAO_ENTRADA (não acumula no primeiro), com quantidade EXATA (3): ${JSON.stringify(producaoEntradasDaOP(op1.id))}`);

const r1c = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 3, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Última etapa — leva 3/3, fecha a OP" });
assert(r1c.op.status === "CONCLUIDA", "Cenário 1 — leva parcial 3/3 (+3 un., total 10/10) conclui a OP");
assert(producaoEntradasDaOP(op1.id).length === 3 && producaoEntradasDaOP(op1.id)[2] === 3, `Cenário 1 — leva 3/3 gera um TERCEIRO Kardex PRODUCAO_ENTRADA com quantidade EXATA (3): ${JSON.stringify(producaoEntradasDaOP(op1.id))}`);
assert(
  producaoEntradasDaOP(op1.id).reduce((a, b) => a + b, 0) === 10,
  `Cenário 1 — soma das 3 entradas PRODUCAO_ENTRADA (4+3+3=10) bate com quantidadeProduzida (${r1c.op.quantidadeProduzida})`,
);
assert(r1c.op.quantidadeProduzida === 10 && r1c.op.quantidadeRefugada === 0, `Cenário 1 — produzida=10, refugada=0 (${r1c.op.quantidadeProduzida}/${r1c.op.quantidadeRefugada})`);
assert(r1c.op.quantidadeProduzida + r1c.op.quantidadeRefugada === r1c.op.quantidadePrevista, "Cenário 1 — produzida + refugada == prevista EXATAMENTE (sem refugo)");
assert(r1c.op.etapaAtualId === null, "Cenário 1 — OP concluída fica com etapaAtualId null");
assert(etapasDaOPSemAbertas(op1.id), "Cenário 1 — nenhuma etapa da OP fica em AGUARDANDO/EM_EXECUCAO após a conclusão");

// ===================================================================
// CENÁRIO 2 — refugo distribuído em VÁRIAS etapas diferentes.
// ===================================================================
// Prevista = 20. Refugo de 2 na 1ª etapa, 3 na 2ª etapa (se houver),
// e o restante 100% boas até o fim. Confirma que quantidadeRefugada
// acumula corretamente através de várias etapas e que o total bate.
const op2 = novaOP(20, "L-TESTE-ETAPA10-REFUGO-DISTRIBUIDO");
repo.releaseOrdemProducao(op2.id, E1, USUARIO);

const totalEtapasOp2 = etapasFluxo.length;
let refugoAcumuladoEsperado = 0;
{
  let opAtual = repo.getOrdemProducao(op2.id, E1)!;
  let guard = 0;
  let etapasComRefugo = 0;
  while (opAtual.status !== "CONCLUIDA" && guard < 40) {
    guard++;
    const etapas = repo.listEtapasDaOP(op2.id, E1);
    const etapaAtual = etapas.find((e) => e.id === opAtual.etapaAtualId)!;
    const disponivel = etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida;
    // Refuga uma pequena quantidade nas duas primeiras etapas do fluxo
    // (se ainda houver saldo suficiente para isso), boas no restante.
    const perder = etapasComRefugo < 2 && etapaAtual.sequencia <= 2 && disponivel > 2 ? 2 : 0;
    if (perder > 0) etapasComRefugo++;
    const enviar = disponivel - perder;
    const r = repo.moveProductionOrder(E1, USUARIO, {
      ordemProducaoId: op2.id,
      quantidadeEnviada: enviar,
      quantidadePerdida: perder,
      motivoPerdaId: perder > 0 ? motivo1.id : null,
      observacao: perder > 0 ? `Refugo distribuído — etapa seq ${etapaAtual.sequencia}` : "Boas",
    });
    if (perder > 0) refugoAcumuladoEsperado += perder;
    opAtual = r.op;
  }
  assert(opAtual.status === "CONCLUIDA", "Cenário 2 — OP conclui normalmente com refugo distribuído em etapas diferentes");
  assert(etapasComRefugo >= 2 || totalEtapasOp2 < 2, `Cenário 2 — refugo foi de fato lançado em pelo menos 2 etapas diferentes (etapasComRefugo=${etapasComRefugo})`);
  assert(opAtual.quantidadeRefugada === refugoAcumuladoEsperado, `Cenário 2 — quantidadeRefugada acumulada corretamente através de várias etapas (${opAtual.quantidadeRefugada} == ${refugoAcumuladoEsperado})`);
  assert(opAtual.quantidadeProduzida + opAtual.quantidadeRefugada === opAtual.quantidadePrevista, `Cenário 2 — produzida (${opAtual.quantidadeProduzida}) + refugada (${opAtual.quantidadeRefugada}) == prevista (${opAtual.quantidadePrevista}) EXATAMENTE`);
  assert(opAtual.etapaAtualId === null, "Cenário 2 — OP concluída fica com etapaAtualId null");
  assert(etapasDaOPSemAbertas(op2.id), "Cenário 2 — nenhuma etapa da OP fica em AGUARDANDO/EM_EXECUCAO após a conclusão");
}

// ===================================================================
// CENÁRIO 3 — refugo só na ÚLTIMA etapa, também em múltiplas levas
// parciais (mistura boas + perdida na mesma movimentação).
// ===================================================================
const op3 = novaOP(15, "L-TESTE-ETAPA10-REFUGO-FINAL");
repo.releaseOrdemProducao(op3.id, E1, USUARIO);

{
  let opAtual = repo.getOrdemProducao(op3.id, E1)!;
  let guard = 0;
  while (guard < 20) {
    guard++;
    const etapas = repo.listEtapasDaOP(op3.id, E1);
    const etapaAtual = etapas.find((e) => e.id === opAtual.etapaAtualId)!;
    const ehUltima = !etapas.some((e) => e.sequencia === etapaAtual.sequencia + 1);
    if (ehUltima) break;
    const disponivel = etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida;
    const r = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op3.id, quantidadeEnviada: disponivel, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Etapa intermediária 100% boas" });
    opAtual = r.op;
  }
}

// Leva 1: 6 boas + 2 perdidas (mistura na mesma movimentação — regra
// da Etapa 8: boas + refugo na MESMA movimentação).
const r3a = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op3.id, quantidadeEnviada: 6, quantidadePerdida: 2, motivoPerdaId: motivo1.id, observacao: "Última etapa — leva 1/2, com refugo" });
assert(r3a.op.status !== "CONCLUIDA", "Cenário 3 — leva 1/2 (6 boas + 2 perdidas, total 8/15) não conclui a OP ainda");
assert(producaoEntradasDaOP(op3.id).length === 1 && producaoEntradasDaOP(op3.id)[0] === 6, `Cenário 3 — leva 1/2 gera Kardex PRODUCAO_ENTRADA só com as boas (6), refugo não entra como produto acabado: ${JSON.stringify(producaoEntradasDaOP(op3.id))}`);

// Leva 2: 6 boas + 1 perdida — fecha exatamente em 15 (6+2+6+1=15).
const r3b = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op3.id, quantidadeEnviada: 6, quantidadePerdida: 1, motivoPerdaId: motivo1.id, observacao: "Última etapa — leva 2/2, fecha a OP" });
assert(r3b.op.status === "CONCLUIDA", "Cenário 3 — leva 2/2 fecha exatamente em 15/15 e conclui a OP");
assert(producaoEntradasDaOP(op3.id).length === 2 && producaoEntradasDaOP(op3.id)[1] === 6, `Cenário 3 — leva 2/2 gera um SEGUNDO Kardex PRODUCAO_ENTRADA só com as boas (6): ${JSON.stringify(producaoEntradasDaOP(op3.id))}`);
assert(r3b.op.quantidadeProduzida === 12 && r3b.op.quantidadeRefugada === 3, `Cenário 3 — produzida=12 (6+6), refugada=3 (2+1) (${r3b.op.quantidadeProduzida}/${r3b.op.quantidadeRefugada})`);
assert(r3b.op.quantidadeProduzida + r3b.op.quantidadeRefugada === r3b.op.quantidadePrevista, `Cenário 3 — produzida (${r3b.op.quantidadeProduzida}) + refugada (${r3b.op.quantidadeRefugada}) == prevista (${r3b.op.quantidadePrevista}) EXATAMENTE, refugo só na última etapa`);
assert(r3b.op.etapaAtualId === null, "Cenário 3 — OP concluída fica com etapaAtualId null");
assert(etapasDaOPSemAbertas(op3.id), "Cenário 3 — nenhuma etapa da OP fica em AGUARDANDO/EM_EXECUCAO após a conclusão");

// ===================================================================
// Verificação extra: uma OP já CONCLUIDA nunca aceita nova
// movimentação (guard da Etapa 9 continua valendo após a finalização
// desta etapa — não foi enfraquecido).
// ===================================================================
try {
  repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 1, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Não deveria ser aceita" });
  assert(false, "Cenário extra — movimentação em OP já concluída deveria lançar erro, mas não lançou");
} catch (err) {
  const msg = err instanceof Error ? err.message : "";
  assert(msg.toLowerCase().includes("encerrada"), `Cenário extra — guard de status continua rejeitando movimentação em OP concluída (Etapa 9, não enfraquecido): "${msg}"`);
}

// ===================================================================
// Invariante global de sempre (mesmo padrão dos scripts anteriores).
// ===================================================================
const saldosFinais = repo.listSaldos(E1);
const invarianteReserva = saldosFinais.every((s) => s.quantidadeReservada >= -1e-9 && s.quantidadeReservada <= s.quantidade + 1e-9);
assert(invarianteReserva, `Invariante global — 0 <= reservada <= quantidade em todos os ${saldosFinais.length} saldos da empresa`);

console.log(falhas === 0 ? "\nTUDO OK — cenários da Etapa 10 (finalização: múltiplas levas na última etapa, refugo distribuído, refugo só no final, invariante produzida+refugada==prevista, nenhuma etapa aberta após conclusão)." : `\n${falhas} FALHA(S) na Etapa 10.`);
process.exit(falhas === 0 ? 0 : 1);
