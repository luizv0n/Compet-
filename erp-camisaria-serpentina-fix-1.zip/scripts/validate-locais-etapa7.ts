// Validação funcional da Etapa 7 (Locais e estrutura de estoque). Roda
// as funções REAIS de src/services/mockRepository.ts em Node (mesma
// técnica dos demais scripts/validate-*.ts: fora do browser,
// loadDatabase() cai para buildSeedDatabase() e saveDatabase() vira
// no-op — então este script valida a lógica de negócio, não a
// persistência em localStorage, que só existe no browser real).
//
// Cobre o que foi implementado/corrigido nesta etapa:
//   1. updateEstoque (não existia antes — só create/toggle): edita
//      nome e endereço, preserva campos não enviados, e respeita a
//      mesma regra de nome único por empresa que create já respeitava.
//   2. Isolamento multiempresa em updateEstoque/toggleEstoque (regra
//      17 do prompt mestre) — mesmo padrão já validado para as demais
//      entidades nas etapas 3/4.
//   3. Relação local <-> saldo (produto_estoque) usada pela tela de
//      Locais para mostrar saldo físico total por local (seção 15/21).
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const E2 = 2;
const USUARIO = { id: 1, nome: "Teste Etapa 7" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

const locaisAntes = repo.listEstoques(E1, true);
assert(locaisAntes.length >= 1, `Seed tem ao menos 1 local de estoque na empresa 1 (${locaisAntes.length})`);
const fabrica = locaisAntes.find((l) => l.nome.toLowerCase().includes("fábrica") || l.nome.toLowerCase().includes("fabrica"));
assert(!!fabrica, "Local 'Fábrica' existe no seed da empresa 1");

const novo = repo.createEstoque(E1, USUARIO, {
  nome: "Loja Teste Etapa7",
  cep: "01310100",
  logradouro: "Av. Paulista",
  numero: "1000",
  complemento: "Loja 2",
  bairro: "Bela Vista",
  cidade: "São Paulo",
  estado: "SP",
});
assert(novo.ativo === true, "Novo local nasce ativo");
assert(
  novo.cep === "01310100" && novo.logradouro === "Av. Paulista" && novo.numero === "1000" && novo.bairro === "Bela Vista",
  "Campos de endereço completos são persistidos na criação",
);

assert(
  (() => {
    try {
      repo.createEstoque(E1, USUARIO, { nome: "Loja Teste Etapa7" });
      return false;
    } catch {
      return true;
    }
  })(),
  "Nome de local duplicado na mesma empresa é rejeitado",
);

const editado = repo.updateEstoque(novo.id, E1, USUARIO, { nome: "Loja Teste Etapa7 Editada", cidade: "Campinas" });
assert(editado.nome === "Loja Teste Etapa7 Editada", "updateEstoque atualiza o nome");
assert(editado.cidade === "Campinas", "updateEstoque atualiza a cidade");
assert(editado.logradouro === "Av. Paulista", "updateEstoque preserva campos não enviados (logradouro)");

assert(
  (() => {
    try {
      repo.updateEstoque(editado.id, E1, USUARIO, { nome: fabrica!.nome });
      return false;
    } catch {
      return true;
    }
  })(),
  "updateEstoque rejeita renomear para um nome já usado por outro local",
);

const semMudanca = repo.updateEstoque(editado.id, E1, USUARIO, { nome: editado.nome, bairro: "Centro" });
assert(semMudanca.nome === editado.nome, "updateEstoque permite salvar mantendo o próprio nome");

const toggled = repo.toggleEstoque(novo.id, E1, USUARIO);
assert(toggled.ativo === false, "toggleEstoque inativa o local");
repo.toggleEstoque(novo.id, E1, USUARIO);

const locaisE2 = repo.listEstoques(E2, true);
assert(!locaisE2.some((l) => l.id === novo.id), "Local criado na empresa 1 não aparece na listagem da empresa 2 (isolamento)");
assert(
  (() => {
    try {
      repo.updateEstoque(novo.id, E2, USUARIO, { nome: "Invasão" });
      return false;
    } catch {
      return true;
    }
  })(),
  "updateEstoque com empresaId de outro tenant é rejeitado",
);
assert(
  (() => {
    try {
      repo.toggleEstoque(novo.id, E2, USUARIO);
      return false;
    } catch {
      return true;
    }
  })(),
  "toggleEstoque com empresaId de outro tenant é rejeitado",
);

const saldosE1 = repo.listSaldos(E1);
assert(Array.isArray(saldosE1), "listSaldos(empresaId) retorna array (base do resumo de saldo por local na tela de Locais)");

console.log(`\n${falhas === 0 ? "TODOS OS TESTES PASSARAM" : `${falhas} FALHA(S)`}`);
process.exit(falhas === 0 ? 0 : 1);
