// Validação funcional da Etapa 9 (consumo de componentes). Roda as
// funções REAIS de src/services/mockRepository.ts em Node (mesma técnica
// de scripts/validate-op-etapa6/7/8.ts).
//
// consumirComponentesPendentes já existe desde a Etapa 6 e é chamada em
// vários pontos (conclusão normal de etapa, fechamento em cadeia da
// Etapa 8, rede de segurança na conclusão da OP). Este script não cria
// um segundo motor de consumo — confirma por teste real (não por leitura
// de código) que a integração está fina o suficiente:
//
//   1. Um componente cujo setor_id bate com uma etapa fechada
//      AUTOMATICAMENTE pela cadeia da Etapa 8 (0 recebido, sem nenhuma
//      movimentação manual do usuário) é consumido mesmo assim.
//   2. Uma OP cancelada nunca mais aceita movimentação (e portanto nunca
//      mais gera consumo) — moveProductionOrder agora rejeita
//      explicitamente por status (correção desta etapa: antes o bloqueio
//      só acontecia "de graça" porque cancelOrdemProducao zera
//      etapaAtualId; agora há uma checagem de status explícita e uma
//      mensagem clara).
//   3. Um componente cujo setor_id não bate com NENHUMA etapa do fluxo
//      da OP ("setor órfão") nunca é tocado pelos consumos por-etapa —
//      fica pendente até a rede de segurança da conclusão da OP
//      consumi-lo (sem filtro de setor).
//
// Não inventa nenhuma tabela/coluna fora do bd_competeV6.sql: setores e
// produto_componente.setor_id já existem no schema; este script só cria
// registros novos usando os repositórios já existentes (createSetor,
// createProduto, addComponente, directStockIn), do mesmo jeito que a UI
// faria.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 9" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

const variacoes = repo.listVariacoes(E1, true);
const estoques = repo.listEstoques(E1, true);
const fluxos = repo.listFluxos(E1, true);
const motivos = repo.listMotivosPerda(E1, true);

const skuCamiseta = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
const fluxoCamiseta = fluxos.find((f) => f.nome.toLowerCase().includes("camiseta"))!;
const motivo1 = motivos[0];
const etapasFluxo = repo.listEtapasDoFluxo(fluxoCamiseta.id, E1);
const setorSecagem = etapasFluxo.find((e) => e.sequencia === 4)!; // "Secagem" no seed padrão — meio do fluxo, sem componente próprio

assert(!!skuCamiseta && !!estFabrica && !!fluxoCamiseta && !!motivo1 && !!setorSecagem, "Massa de dados do seed encontrada (SKU camiseta, estoque fábrica, fluxo com >= 4 etapas)");

function kardexDaOp(opId: number) {
  return repo.listKardex(E1).filter((k) => k.ordemProducaoId === opId);
}

function consumoDe(opId: number, produtoVariacaoId: number): number {
  return kardexDaOp(opId)
    .filter((k) => k.produtoVariacaoId === produtoVariacaoId && k.natureza === "PRODUCAO_CONSUMO" && k.sentido === "SAIDA")
    .reduce((acc, k) => acc + k.quantidade, 0);
}

function novaOP(quantidadePrevista: number, lote: string) {
  return repo.createOrdemProducao(E1, USUARIO, {
    produtoVariacaoId: skuCamiseta.id,
    fluxoProducaoId: fluxoCamiseta.id,
    quantidadePrevista,
    lote,
    estoqueOrigemId: estFabrica.id,
    estoqueDestinoId: estFabrica.id,
    dataAbertura: new Date().toISOString(),
    observacao: null,
  });
}

function moveThrows(opId: number, payload: { quantidadeEnviada: number; quantidadePerdida: number; motivoPerdaId?: number | null }): string | null {
  try {
    repo.moveProductionOrder(E1, USUARIO, {
      ordemProducaoId: opId,
      quantidadeEnviada: payload.quantidadeEnviada,
      quantidadePerdida: payload.quantidadePerdida,
      motivoPerdaId: payload.motivoPerdaId ?? null,
      observacao: "Teste Etapa 9",
    });
    return null;
  } catch (err) {
    return err instanceof Error ? err.message : "erro desconhecido";
  }
}

// -------------------------------------------------------------------
// Setup: um setor "órfão" (existe na empresa, mas não está em NENHUM
// fluxo) + dois materiais de teste novos, adicionados à ficha técnica
// da camiseta — um com setor_id batendo com uma etapa do MEIO do fluxo
// (Secagem), outro com setor_id órfão (fora de qualquer fluxo).
// -------------------------------------------------------------------
const setorOrfao = repo.createSetor(E1, { nome: "Revisão Teste Etapa9 (órfã)", codigo: "REV-T9", tipo: "INTERNO" });

const unidadeTeste = repo.listUnidadesMedida()[0].id;

const produtoCascata = repo.createProduto(E1, USUARIO, {
  nome: "Componente Teste Etapa9 — Cascata",
  tipo: "MP",
  colecaoId: null,
  unidadeMedidaId: unidadeTeste,
  ncm: null,
  cest: null,
  origem: null,
  categoriaIds: [],
  variacoes: [{ corId: null, tamanhoId: null, sku: "MP-TESTE-E9-CASCATA", codigoBarras: null, precos: [] }],
});
const varCascata = repo.listVariacoesDoProduto(produtoCascata.id, E1)[0];

const produtoOrfao = repo.createProduto(E1, USUARIO, {
  nome: "Componente Teste Etapa9 — Órfão",
  tipo: "MP",
  colecaoId: null,
  unidadeMedidaId: unidadeTeste,
  ncm: null,
  cest: null,
  origem: null,
  categoriaIds: [],
  variacoes: [{ corId: null, tamanhoId: null, sku: "MP-TESTE-E9-ORFAO", codigoBarras: null, precos: [] }],
});
const varOrfao = repo.listVariacoesDoProduto(produtoOrfao.id, E1)[0];

repo.addComponente(E1, USUARIO, { produtoPaiId: skuCamiseta.id, produtoFilhoId: varCascata.id, quantidade: 2, setorId: setorSecagem.setorId, observacao: null });
repo.addComponente(E1, USUARIO, { produtoPaiId: skuCamiseta.id, produtoFilhoId: varOrfao.id, quantidade: 1.5, setorId: setorOrfao.id, observacao: null });

// Estoque físico generoso para os dois materiais de teste, na Fábrica.
repo.directStockIn(E1, USUARIO, { produtoVariacaoId: varCascata.id, estoqueId: estFabrica.id, quantidade: 1000, observacao: "Estoque de teste — Etapa 9" });
repo.directStockIn(E1, USUARIO, { produtoVariacaoId: varOrfao.id, estoqueId: estFabrica.id, quantidade: 1000, observacao: "Estoque de teste — Etapa 9" });

const componentesCamiseta = repo.listComponentes(skuCamiseta.id, E1).filter((c) => c.ativo);
assert(
  componentesCamiseta.some((c) => c.produtoFilhoId === varCascata.id && c.setorId === setorSecagem.setorId),
  "Componente de teste 'Cascata' adicionado à ficha técnica com setor_id = Secagem (etapa do meio do fluxo)",
);
assert(
  componentesCamiseta.some((c) => c.produtoFilhoId === varOrfao.id && c.setorId === setorOrfao.id),
  "Componente de teste 'Órfão' adicionado à ficha técnica com setor_id que não pertence a nenhuma etapa do fluxo",
);

// ===================================================================
// CENÁRIO 1 — consumo em etapa fechada automaticamente pela cadeia
// (Etapa 8), sem nenhuma movimentação manual do usuário sobre ela.
// ===================================================================
// Fluxo: Corte(1) e Costura(2) avançam 100% boas normalmente até a
// Lavanderia(3) receber a leva inteira. Na Lavanderia, 100% vira refugo
// — isso fecha a Lavanderia com 0 enviado adiante, e a etapa seguinte
// (Secagem(4), onde está o componente 'Cascata') nasce com
// quantidade_recebida = 0 e é fechada pela cadeia da Etapa 8, SEM
// nenhuma movimentação manual do usuário sobre ela.
const op1 = novaOP(10, "L-TESTE-ETAPA9-CASCATA");
repo.releaseOrdemProducao(op1.id, E1, USUARIO);

repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 10, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Corte 100% boas" });
repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 10, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Costura 100% boas" });

const etapasOp1AntesLavanderia = repo.listEtapasDaOP(op1.id, E1);
const etapaSecagemOp1 = etapasOp1AntesLavanderia.find((e) => e.sequencia === 4)!;
assert(etapaSecagemOp1.status === "AGUARDANDO", "Pré-condição — etapa Secagem da OP1 ainda não foi tocada (AGUARDANDO) antes do refugo total na Lavanderia");
assert(consumoDe(op1.id, varCascata.id) === 0, "Pré-condição — componente 'Cascata' ainda com consumo 0 (nada foi lançado antes da cadeia disparar)");

const { op: op1AposLavanderia } = repo.moveProductionOrder(E1, USUARIO, {
  ordemProducaoId: op1.id,
  quantidadeEnviada: 0,
  quantidadePerdida: 10,
  motivoPerdaId: motivo1.id,
  observacao: "Lavanderia — 100% refugo, dispara a cadeia da Etapa 8 a partir da Secagem",
});

const etapasOp1Depois = repo.listEtapasDaOP(op1.id, E1);
const etapaSecagemOp1Depois = etapasOp1Depois.find((e) => e.sequencia === 4)!;
assert(op1AposLavanderia.status === "CONCLUIDA", "OP1 conclui direto — 100% refugo na Lavanderia não deixa nada para as etapas seguintes produzirem");
assert(etapaSecagemOp1Depois.status === "CONCLUIDA" && etapaSecagemOp1Depois.quantidadeRecebida === 0, "Etapa Secagem da OP1 foi fechada automaticamente pela cadeia (CONCLUIDA, 0 recebido, nenhuma movimentação manual)");
assert(consumoDe(op1.id, varCascata.id) === 2 * 10, `Componente 'Cascata' (setor_id = Secagem, etapa fechada só pela cadeia) foi consumido integralmente: ${consumoDe(op1.id, varCascata.id)} == ${2 * 10}`);

// ===================================================================
// CENÁRIO 2 — OP cancelada nunca mais aceita movimentação (logo, nunca
// mais gera consumo depois do cancelamento).
// ===================================================================
const op2 = novaOP(10, "L-TESTE-ETAPA9-CANCELADA");
repo.releaseOrdemProducao(op2.id, E1, USUARIO);
// Movimentação parcial real ANTES do cancelamento — para garantir que
// existe consumo/rastro genuíno no meio do processo (não uma OP virgem).
repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op2.id, quantidadeEnviada: 4, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Parcial antes do cancelamento" });

const consumoAntesCancelar = kardexDaOp(op2.id).filter((k) => k.natureza === "PRODUCAO_CONSUMO").reduce((acc, k) => acc + k.quantidade, 0);
const opCancelada = repo.cancelOrdemProducao(op2.id, E1, USUARIO);
assert(opCancelada.status === "CANCELADA", "OP2 cancelada com sucesso");
assert(opCancelada.etapaAtualId === null, "OP2 cancelada fica sem etapa ativa (etapaAtualId = null)");

const erroMoveAposCancelar = moveThrows(op2.id, { quantidadeEnviada: 1, quantidadePerdida: 0 });
assert(erroMoveAposCancelar !== null, "moveProductionOrder REJEITA movimentação numa OP já cancelada");
assert(erroMoveAposCancelar !== null && erroMoveAposCancelar.toLowerCase().includes("encerrada"), `A mensagem de erro é explícita sobre o motivo (status encerrado), não genérica: "${erroMoveAposCancelar}"`);

const consumoDepoisTentativa = kardexDaOp(op2.id).filter((k) => k.natureza === "PRODUCAO_CONSUMO").reduce((acc, k) => acc + k.quantidade, 0);
assert(consumoDepoisTentativa === consumoAntesCancelar, "Nenhum novo consumo foi lançado no Kardex pela tentativa de movimentação rejeitada (nem consumido, nem em dobro)");

// Também cobre o caso de tentar mover uma OP já CONCLUIDA (mesma guarda).
const op2b = novaOP(3, "L-TESTE-ETAPA9-CONCLUIDA");
repo.releaseOrdemProducao(op2b.id, E1, USUARIO);
let opLoop = repo.getOrdemProducao(op2b.id, E1)!;
let guardLoop = 0;
while (opLoop.status !== "CONCLUIDA" && guardLoop < 20) {
  guardLoop++;
  const etapaLoop = repo.listEtapasDaOP(op2b.id, E1).find((e) => e.id === opLoop.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const r = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op2b.id, quantidadeEnviada: disponivelLoop, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Boas até concluir" });
  opLoop = r.op;
}
assert(opLoop.status === "CONCLUIDA", "Pré-condição — OP2b concluída normalmente (100% boas) para testar a guarda também neste status");
const erroMoveAposConcluir = moveThrows(op2b.id, { quantidadeEnviada: 1, quantidadePerdida: 0 });
assert(erroMoveAposConcluir !== null && erroMoveAposConcluir.toLowerCase().includes("encerrada"), `moveProductionOrder também rejeita, com a mesma mensagem clara, uma OP já CONCLUIDA: "${erroMoveAposConcluir}"`);

// ===================================================================
// CENÁRIO 3 — componente com setor_id órfão (não bate com nenhuma etapa
// do fluxo) só é consumido pela rede de segurança na conclusão da OP.
// ===================================================================
const op3 = novaOP(6, "L-TESTE-ETAPA9-ORFAO");
repo.releaseOrdemProducao(op3.id, E1, USUARIO);

assert(consumoDe(op3.id, varOrfao.id) === 0, "Pré-condição — componente 'Órfão' com consumo 0 logo após a liberação (só reservado, não consumido)");

let opOrfaoAtual = repo.getOrdemProducao(op3.id, E1)!;
let guardOrfao = 0;
while (opOrfaoAtual.status !== "CONCLUIDA" && guardOrfao < 20) {
  guardOrfao++;
  const etapaLoop = repo.listEtapasDaOP(op3.id, E1).find((e) => e.id === opOrfaoAtual.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const ehUltimaEtapa = !repo.listEtapasDaOP(op3.id, E1).some((e) => e.sequencia === etapaLoop.sequencia + 1);
  // Uma etapa antes de concluir, confirma que o componente órfão AINDA
  // está com consumo 0 — prova que nenhuma etapa "normal" (fechamento
  // por setor_id que bate com uma etapa real) nunca o consome.
  if (ehUltimaEtapa) {
    assert(consumoDe(op3.id, varOrfao.id) === 0, "Componente 'Órfão' segue com consumo 0 até faltar só a última etapa (nenhuma etapa do fluxo bate com o setor_id dele)");
  }
  const r = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op3.id, quantidadeEnviada: disponivelLoop, quantidadePerdida: 0, motivoPerdaId: null, observacao: "Boas até concluir" });
  opOrfaoAtual = r.op;
}
assert(opOrfaoAtual.status === "CONCLUIDA", "Pré-condição — OP3 concluída (100% boas, sem refugo, para isolar o efeito do setor órfão)");
assert(consumoDe(op3.id, varOrfao.id) === 1.5 * 6, `Componente 'Órfão' (setor_id fora do fluxo) é consumido integralmente na conclusão da OP, pela rede de segurança: ${consumoDe(op3.id, varOrfao.id)} == ${1.5 * 6}`);

// ===================================================================
// Invariante global de sempre (mesmo padrão dos scripts anteriores).
// ===================================================================
const saldosFinais = repo.listSaldos(E1);
const invarianteReserva = saldosFinais.every((s) => s.quantidadeReservada >= -1e-9 && s.quantidadeReservada <= s.quantidade + 1e-9);
assert(invarianteReserva, `Invariante global — 0 <= reservada <= quantidade em todos os ${saldosFinais.length} saldos da empresa`);

console.log(falhas === 0 ? "\nTUDO OK — cenários da Etapa 9 (consumo em etapa fechada por cadeia, OP cancelada/concluída bloqueia movimentação, setor órfão coberto pela rede de segurança)." : `\n${falhas} FALHA(S) na Etapa 9.`);
process.exit(falhas === 0 ? 0 : 1);
