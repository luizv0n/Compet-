// Validação funcional da Etapa 7 (OP: execução). Roda as funções REAIS
// de src/services/mockRepository.ts em Node (mesma técnica do
// scripts/validate-op-etapa6.ts: fora do browser, loadDatabase() cai
// para buildSeedDatabase() e saveDatabase() vira no-op).
//
// Este script cobre especificamente o que mudou/foi auditado na Etapa 7
// (não repete os cenários de reserva/consumo por setor já cobertos em
// validate-op-etapa6.ts — rode os dois):
//
//   1. moveProductionOrder rejeita quantidade_enviada/quantidade_perdida
//      não inteiras (regra: colunas INT no banco).
//   2. Múltiplas movimentações PARCIAIS na mesma etapa não permitem que
//      concluída + perdida ultrapasse o recebido (regra 18), e a soma
//      acumulada bate exatamente com o total enviado ao longo delas.
//   3. A fórmula de "consumo pendente por componente" usada na tela de
//      detalhe da OP (ProdutoComponente.quantidade * quantidade_prevista
//      − soma do Kardex PRODUCAO_CONSUMO/SAIDA daquela OP+componente)
//      reflete corretamente um cenário de reserva insuficiente.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 7" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

function saldoDe(variacaoId: number, estoqueId: number) {
  const saldos = repo.getSaldosDaVariacao(variacaoId, E1);
  const row = saldos.find((s) => s.estoqueId === estoqueId);
  if (!row) throw new Error(`saldo não encontrado para variação ${variacaoId} / estoque ${estoqueId}`);
  return row;
}

const variacoes = repo.listVariacoes(E1, true);
const estoques = repo.listEstoques(E1, true);
const fluxos = repo.listFluxos(E1, true);

const skuCamiseta = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const skuLinha = variacoes.find((v) => v.sku === "AV-LINHA-PRETA")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
const fluxoCamiseta = fluxos.find((f) => f.nome.toLowerCase().includes("camiseta"))!;

assert(!!skuCamiseta && !!skuLinha && !!estFabrica && !!fluxoCamiseta, "Massa de dados do seed encontrada (SKU camiseta/linha, estoque fábrica, fluxo)");

// -------------------------------------------------------------------
// Cenário 1 — rejeição de quantidades não inteiras.
// -------------------------------------------------------------------
const op1 = repo.createOrdemProducao(E1, USUARIO, {
  produtoVariacaoId: skuCamiseta.id,
  fluxoProducaoId: fluxoCamiseta.id,
  quantidadePrevista: 5,
  lote: "L-TESTE-ETAPA7-1",
  estoqueOrigemId: estFabrica.id,
  estoqueDestinoId: estFabrica.id,
  dataAbertura: new Date().toISOString(),
  observacao: null,
});
const { avisos: avisosRelease1 } = repo.releaseOrdemProducao(op1.id, E1, USUARIO);
assert(avisosRelease1.length === 0, "OP1 — liberação sem avisos (saldo suficiente para 5 un., mesma massa da Etapa 6/Cenário 1)");

function moveThrows(payload: { quantidadeEnviada: number; quantidadePerdida: number }): string | null {
  try {
    repo.moveProductionOrder(E1, USUARIO, {
      ordemProducaoId: op1.id,
      quantidadeEnviada: payload.quantidadeEnviada,
      quantidadePerdida: payload.quantidadePerdida,
      observacao: "Teste inteiro",
    });
    return null;
  } catch (err) {
    return err instanceof Error ? err.message : "erro desconhecido";
  }
}

assert(moveThrows({ quantidadeEnviada: 2.5, quantidadePerdida: 0 }) !== null, "Rejeita quantidade_enviada decimal (2.5)");
assert(moveThrows({ quantidadeEnviada: 0, quantidadePerdida: 1.1 }) !== null, "Rejeita quantidade_perdida decimal (1.1)");
assert(moveThrows({ quantidadeEnviada: -1, quantidadePerdida: 0 }) !== null, "Rejeita quantidade_enviada negativa");

// -------------------------------------------------------------------
// Cenário 2 — múltiplas movimentações PARCIAIS na mesma etapa não
// podem, somadas, ultrapassar o recebido; e a soma bate certinho.
// -------------------------------------------------------------------
let etapas1 = repo.listEtapasDaOP(op1.id, E1);
let etapaAtual1 = etapas1.find((e) => e.id === repo.getOrdemProducao(op1.id, E1)!.etapaAtualId)!;
const recebidaEtapa1 = etapaAtual1.quantidadeRecebida; // 5
assert(recebidaEtapa1 === 5, `Etapa 1 recebeu a quantidade prevista da OP (${recebidaEtapa1} == 5)`);

// 3 movimentações parciais: 2 + 2 + 1 = 5 (exatamente o disponível)
const { op: opAposMov1 } = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 2, quantidadePerdida: 0, observacao: "parcial 1" });
let etapaPos1 = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === etapaAtual1.id)!;
assert(etapaPos1.quantidadeConcluida === 2 && etapaPos1.status === "EM_EXECUCAO", "Movimentação parcial 1/3 (2 un.) não conclui a etapa e acumula corretamente");
assert(opAposMov1.etapaAtualId === etapaAtual1.id, "OP permanece na mesma etapa após movimentação parcial que não a esgota (bug da Etapa 7 corrigido)");

const { op: opAposMov2 } = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 2, quantidadePerdida: 0, observacao: "parcial 2" });
let etapaPos2 = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === etapaAtual1.id)!;
assert(etapaPos2.quantidadeConcluida === 4 && etapaPos2.status === "EM_EXECUCAO", "Movimentação parcial 2/3 (+2 un.) acumula para 4/5");
assert(opAposMov2.etapaAtualId === etapaAtual1.id, "OP ainda permanece na mesma etapa após a 2ª movimentação parcial");

// tenta extrapolar antes da última parcial: 4 concluído, tentar enviar 2 (>1 disponível) deve falhar
const excedeAntesDaUltima = moveThrows({ quantidadeEnviada: 2, quantidadePerdida: 0 });
assert(excedeAntesDaUltima !== null, "Rejeita movimentação que ultrapassaria o disponível da etapa após parciais anteriores (4 + 2 > 5)");
let etapaPosTentativaInvalida = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === etapaAtual1.id)!;
assert(etapaPosTentativaInvalida.quantidadeConcluida === 4, "Tentativa rejeitada NÃO altera o estado acumulado da etapa (permanece em 4)");

const { op: opAposMov3 } = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: 1, quantidadePerdida: 0, observacao: "parcial 3 — fecha a etapa" });
let etapaPos3 = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === etapaAtual1.id)!;
assert(etapaPos3.quantidadeConcluida === 5 && etapaPos3.status === "CONCLUIDA", "Movimentação parcial 3/3 (+1 un.) fecha a etapa exatamente em 5/5");
assert(opAposMov3.etapaAtualId !== etapaAtual1.id, "OP só avança para a próxima etapa quando a atual esgota de fato, na última parcial");

// -------------------------------------------------------------------
// Cenário 3 — fórmula de consumo pendente (a mesma que a tela de
// detalhe da OP usa) reflete corretamente uma reserva insuficiente.
// -------------------------------------------------------------------
function consumoPendentePorComponente(opId: number, produtoVariacaoId: number, quantidadePrevista: number) {
  const componentes = repo.listComponentes(produtoVariacaoId, E1).filter((c) => c.ativo);
  const kardex = repo.listKardex(E1);
  return componentes
    .map((c) => {
      const necessario = c.quantidade * quantidadePrevista;
      const consumido = kardex
        .filter((k) => k.ordemProducaoId === opId && k.produtoVariacaoId === c.produtoFilhoId && k.natureza === "PRODUCAO_CONSUMO" && k.sentido === "SAIDA")
        .reduce((acc, k) => acc + k.quantidade, 0);
      return { componenteId: c.id, produtoFilhoId: c.produtoFilhoId, pendente: necessario - consumido };
    })
    .filter((x) => x.pendente > 1e-9);
}

// OP1 concluiu com saldo suficiente (mesmo cenário "feliz" da Etapa 6) —
// não deve sobrar nenhum componente pendente.
// Percorre as etapas restantes da OP1 até concluir de fato.
let opAtual1 = repo.getOrdemProducao(op1.id, E1)!;
let guard1 = 0;
while (opAtual1.status !== "CONCLUIDA" && guard1 < 20) {
  guard1++;
  const etapasLoop = repo.listEtapasDaOP(op1.id, E1);
  const etapaLoop = etapasLoop.find((e) => e.id === opAtual1.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const { op: novaOp } = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op1.id, quantidadeEnviada: disponivelLoop, quantidadePerdida: 0, observacao: "fechando OP1" });
  opAtual1 = novaOp;
}
assert(opAtual1.status === "CONCLUIDA", "OP1 concluída ao final do cenário 2/3 combinados");
const pendentesOp1 = consumoPendentePorComponente(op1.id, skuCamiseta.id, op1.quantidadePrevista);
assert(pendentesOp1.length === 0, "OP1 (saldo suficiente) não deixa nenhum componente com consumo pendente ao concluir");

// OP2 — força insuficiência de saldo de linha (mesmo padrão do cenário 2
// da Etapa 6), conclui a OP inteira e confirma que a fórmula de
// pendência acusa exatamente o componente/quantidade que faltou.
const saldoLinhaAntesOp2 = saldoDe(skuLinha.id, estFabrica.id).quantidade;
const QTD_OP2 = 20; // mesmo múltiplo usado na Etapa 6 para estourar o saldo de linha
const op2 = repo.createOrdemProducao(E1, USUARIO, {
  produtoVariacaoId: skuCamiseta.id,
  fluxoProducaoId: fluxoCamiseta.id,
  quantidadePrevista: QTD_OP2,
  lote: "L-TESTE-ETAPA7-2",
  estoqueOrigemId: estFabrica.id,
  estoqueDestinoId: estFabrica.id,
  dataAbertura: new Date().toISOString(),
  observacao: null,
});
const { avisos: avisosOp2 } = repo.releaseOrdemProducao(op2.id, E1, USUARIO);
assert(avisosOp2.length > 0, "OP2 — liberação gera aviso de estoque insuficiente (pré-condição do cenário)");

let opAtual2 = repo.getOrdemProducao(op2.id, E1)!;
let guard2 = 0;
while (opAtual2.status !== "CONCLUIDA" && guard2 < 20) {
  guard2++;
  const etapasLoop = repo.listEtapasDaOP(op2.id, E1);
  const etapaLoop = etapasLoop.find((e) => e.id === opAtual2.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const { op: novaOp } = repo.moveProductionOrder(E1, USUARIO, { ordemProducaoId: op2.id, quantidadeEnviada: disponivelLoop, quantidadePerdida: 0, observacao: "fechando OP2 (com shortfall)" });
  opAtual2 = novaOp;
}
assert(opAtual2.status === "CONCLUIDA", "OP2 concluída mesmo com shortfall (regra 16 — nunca bloqueia)");

const pendentesOp2 = consumoPendentePorComponente(op2.id, skuCamiseta.id, opAtual2.quantidadePrevista);
const pendenteLinhaOp2 = pendentesOp2.find((p) => p.produtoFilhoId === skuLinha.id);
assert(!!pendenteLinhaOp2 && pendenteLinhaOp2.pendente > 0, "OP2 — fórmula de pendência acusa consumo pendente do componente 'linha' (o mesmo que faltou saldo na reserva)");
const componentesCamisetaOp2 = repo.listComponentes(skuCamiseta.id, E1).filter((c) => c.ativo);
const compLinhaOp2 = componentesCamisetaOp2.find((c) => c.produtoFilhoId === skuLinha.id)!;
const necessarioLinhaOp2 = compLinhaOp2.quantidade * QTD_OP2;
const consumidoLinhaOp2 = necessarioLinhaOp2 - (pendenteLinhaOp2?.pendente ?? 0);
assert(
  Math.abs(consumidoLinhaOp2 - saldoLinhaAntesOp2) < 1e-9,
  `OP2 — consumido de linha (${consumidoLinhaOp2}) bate com todo o saldo físico disponível antes da OP (${saldoLinhaAntesOp2}) — consumiu o que pôde, o resto ficou pendente`,
);

// -------------------------------------------------------------------
// Invariante global (mesma checagem da Etapa 6, garantindo ausência de
// regressão introduzida pelos cenários acima).
// -------------------------------------------------------------------
const todosSaldos = repo.listSaldos(E1);
const violacoes = todosSaldos.filter((s) => s.quantidadeReservada < -1e-9 || s.quantidadeReservada > s.quantidade + 1e-9);
assert(violacoes.length === 0, `Invariante global — 0 <= reservada <= quantidade em todos os ${todosSaldos.length} saldos da empresa`);

console.log(`\n${falhas === 0 ? "TUDO OK" : `${falhas} FALHA(S)`} — cenários da Etapa 7 (validação de inteiros, movimentações parciais múltiplas, fórmula de consumo pendente).`);
if (falhas > 0) process.exit(1);
