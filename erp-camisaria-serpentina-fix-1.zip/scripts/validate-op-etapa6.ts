// Validação funcional da Etapa 6 (liberação + reserva + consumo por
// setor). Roda as funções REAIS de src/services/mockRepository.ts em
// Node (fora do browser, loadDatabase() cai para buildSeedDatabase() e
// saveDatabase() vira no-op — ver src/services/storage.ts), então este
// script exercita a lógica de negócio de verdade, não uma cópia dela.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 6" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

function saldoDe(variacaoId: number, estoqueId: number) {
  const saldos = repo.getSaldosDaVariacao(variacaoId, E1);
  const row = saldos.find((s) => s.estoqueId === estoqueId);
  if (!row) throw new Error(`saldo não encontrado para variação ${variacaoId} / estoque ${estoqueId}`);
  return row;
}

// Localiza SKUs/fluxo/estoque a partir do seed (mesmos definidos em
// src/mock/seedData.ts para a empresa E1).
const variacoes = repo.listVariacoes(E1, true);
const produtos = repo.listProdutos(E1, true);
const estoques = repo.listEstoques(E1, true);
const fluxos = repo.listFluxos(E1, true);

const skuCamiseta = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const skuTecido = variacoes.find((v) => v.sku === "MP-TEC-PV-PRETO")!;
const skuLinha = variacoes.find((v) => v.sku === "AV-LINHA-PRETA")!;
const skuEtiqueta = variacoes.find((v) => v.sku === "AV-ETIQ-COMP")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
const fluxoCamiseta = fluxos.find((f) => f.nome.toLowerCase().includes("camiseta"))!;

assert(!!skuCamiseta, "SKU PC-CAM-PRETO-M encontrado no seed");
assert(!!skuTecido && !!skuLinha && !!skuEtiqueta, "Componentes da ficha técnica (tecido/linha/etiqueta) encontrados");
assert(!!estFabrica, "Estoque Fábrica encontrado");
assert(!!fluxoCamiseta, "Fluxo de produção da camiseta encontrado");

const componentes = repo.listComponentes(skuCamiseta.id, E1).filter((c) => c.ativo);
const compTecido = componentes.find((c) => c.produtoFilhoId === skuTecido.id)!;
const compLinha = componentes.find((c) => c.produtoFilhoId === skuLinha.id)!;
const compEtiqueta = componentes.find((c) => c.produtoFilhoId === skuEtiqueta.id)!;

// -------------------------------------------------------------------
// Cenário 1 — caminho feliz: quantidade dentro do saldo de todos os
// componentes. Reserva na liberação, consumo por etapa, zero avisos.
// -------------------------------------------------------------------
const QTD_1 = 5;
const saldoTecidoAntes = saldoDe(skuTecido.id, estFabrica.id).quantidade;
const saldoLinhaAntes = saldoDe(skuLinha.id, estFabrica.id).quantidade;
const saldoEtiquetaAntes = saldoDe(skuEtiqueta.id, estFabrica.id).quantidade;

const op1 = repo.createOrdemProducao(E1, USUARIO, {
  produtoVariacaoId: skuCamiseta.id,
  fluxoProducaoId: fluxoCamiseta.id,
  quantidadePrevista: QTD_1,
  lote: "L-TESTE-ETAPA6-1",
  estoqueOrigemId: estFabrica.id,
  estoqueDestinoId: estFabrica.id,
  dataAbertura: new Date().toISOString(),
  observacao: null,
});

const { op: op1Liberada, avisos: avisosRelease1 } = repo.releaseOrdemProducao(op1.id, E1, USUARIO);
assert(avisosRelease1.length === 0, "Cenário 1 — liberação sem avisos (saldo suficiente)");

const necessarioTecido1 = compTecido.quantidade * QTD_1;
const necessarioLinha1 = compLinha.quantidade * QTD_1;
const necessarioEtiqueta1 = compEtiqueta.quantidade * QTD_1;

const saldoTecidoPosLiberacao = saldoDe(skuTecido.id, estFabrica.id);
assert(
  Math.abs(saldoTecidoPosLiberacao.quantidadeReservada - necessarioTecido1) < 1e-9,
  `Cenário 1 — tecido reservado corretamente na liberação (${saldoTecidoPosLiberacao.quantidadeReservada} == ${necessarioTecido1})`,
);
assert(
  Math.abs(saldoTecidoPosLiberacao.quantidade - saldoTecidoAntes) < 1e-9,
  "Cenário 1 — físico do tecido NÃO debitado ainda na liberação (reserva != consumo)",
);

// Percorre as etapas do fluxo até a conclusão, enviando 100% do
// recebido em cada uma (sem refugo), até a OP concluir.
let etapas = repo.listEtapasDaOP(op1.id, E1);
let guard = 0;
let opAtual = op1Liberada;
while (opAtual.status !== "CONCLUIDA" && guard < 20) {
  guard++;
  etapas = repo.listEtapasDaOP(op1.id, E1);
  const etapaAtual = etapas.find((e) => e.id === opAtual.etapaAtualId)!;
  const disponivel = etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida;
  const { op: novaOp } = repo.moveProductionOrder(E1, USUARIO, {
    ordemProducaoId: op1.id,
    quantidadeEnviada: disponivel,
    quantidadePerdida: 0,
    observacao: "Movimento de teste — sem refugo",
  });
  opAtual = novaOp;
}
assert(opAtual.status === "CONCLUIDA", "Cenário 1 — OP concluída após percorrer todas as etapas");
assert(opAtual.quantidadeProduzida === QTD_1, `Cenário 1 — quantidade produzida bate com a prevista (${opAtual.quantidadeProduzida} == ${QTD_1})`);

const saldoTecidoFinal = saldoDe(skuTecido.id, estFabrica.id);
const saldoLinhaFinal = saldoDe(skuLinha.id, estFabrica.id);
const saldoEtiquetaFinal = saldoDe(skuEtiqueta.id, estFabrica.id);

assert(saldoTecidoFinal.quantidadeReservada === 0, "Cenário 1 — reserva do tecido zerada após consumo (nada preso)");
assert(saldoLinhaFinal.quantidadeReservada === 0, "Cenário 1 — reserva da linha zerada após consumo");
assert(saldoEtiquetaFinal.quantidadeReservada === 0, "Cenário 1 — reserva da etiqueta zerada após consumo");
assert(
  Math.abs(saldoTecidoAntes - saldoTecidoFinal.quantidade - necessarioTecido1) < 1e-9,
  "Cenário 1 — físico do tecido debitado exatamente o necessário",
);
assert(
  Math.abs(saldoLinhaAntes - saldoLinhaFinal.quantidade - necessarioLinha1) < 1e-9,
  "Cenário 1 — físico da linha debitado exatamente o necessário",
);
assert(
  Math.abs(saldoEtiquetaAntes - saldoEtiquetaFinal.quantidade - necessarioEtiqueta1) < 1e-9,
  "Cenário 1 — físico da etiqueta debitado exatamente o necessário",
);

const kardexOp1 = repo.listKardex(E1).filter((k) => k.ordemProducaoId === op1.id);
const consumoTecido = kardexOp1.filter((k) => k.produtoVariacaoId === skuTecido.id && k.natureza === "PRODUCAO_CONSUMO");
const consumoLinha = kardexOp1.filter((k) => k.produtoVariacaoId === skuLinha.id && k.natureza === "PRODUCAO_CONSUMO");
const consumoEtiqueta = kardexOp1.filter((k) => k.produtoVariacaoId === skuEtiqueta.id && k.natureza === "PRODUCAO_CONSUMO");
assert(consumoTecido.length === 1, "Cenário 1 — consumo do tecido lançado 1x no Kardex (na conclusão do Corte)");
assert(consumoLinha.length === 1, "Cenário 1 — consumo da linha lançado 1x no Kardex (na conclusão da Costura)");
assert(consumoEtiqueta.length === 1, "Cenário 1 — consumo da etiqueta lançado 1x no Kardex (na conclusão do Acabamento)");
const entradaProdutoAcabado = kardexOp1.find((k) => k.produtoVariacaoId === skuCamiseta.id && k.natureza === "PRODUCAO_ENTRADA");
assert(!!entradaProdutoAcabado && entradaProdutoAcabado.quantidade === QTD_1, "Cenário 1 — entrada do produto acabado lançada no Kardex");

// -------------------------------------------------------------------
// Cenário 2 — insuficiência de estoque (linha): liberação NÃO deve
// bloquear, deve gerar aviso e reservar só o que houver disponível.
// -------------------------------------------------------------------
const saldoLinhaAntes2 = saldoDe(skuLinha.id, estFabrica.id).quantidade; // já refletindo o consumo do cenário 1
const QTD_2 = 20; // 20 * 12 = 240 de linha necessários, bem acima do saldo restante
const op2 = repo.createOrdemProducao(E1, USUARIO, {
  produtoVariacaoId: skuCamiseta.id,
  fluxoProducaoId: fluxoCamiseta.id,
  quantidadePrevista: QTD_2,
  lote: "L-TESTE-ETAPA6-2",
  estoqueOrigemId: estFabrica.id,
  estoqueDestinoId: estFabrica.id,
  dataAbertura: new Date().toISOString(),
  observacao: null,
});

let liberouSemThrow = true;
let avisosRelease2: string[] = [];
try {
  const { avisos } = repo.releaseOrdemProducao(op2.id, E1, USUARIO);
  avisosRelease2 = avisos;
} catch {
  liberouSemThrow = false;
}
assert(liberouSemThrow, "Cenário 2 — liberação NÃO bloqueia mesmo com estoque insuficiente (regra 16)");
assert(avisosRelease2.length > 0, "Cenário 2 — liberação gera aviso de estoque insuficiente");

const saldoLinhaPosLiberacao2 = saldoDe(skuLinha.id, estFabrica.id);
assert(
  Math.abs(saldoLinhaPosLiberacao2.quantidadeReservada - saldoLinhaAntes2) < 1e-9,
  `Cenário 2 — reservou só o disponível (${saldoLinhaPosLiberacao2.quantidadeReservada} == saldo físico ${saldoLinhaAntes2}), não os 240 necessários`,
);
assert(
  saldoLinhaPosLiberacao2.quantidadeReservada <= saldoLinhaPosLiberacao2.quantidade + 1e-9,
  "Cenário 2 — invariante quantidade_reservada <= quantidade mantida mesmo em shortfall",
);

// Cancela a OP-2 e confirma que a reserva parcial foi liberada de volta.
const op2Cancelada = repo.cancelOrdemProducao(op2.id, E1, USUARIO);
assert(op2Cancelada.status === "CANCELADA", "Cenário 2 — OP cancelada com sucesso");
const saldoLinhaPosCancelamento = saldoDe(skuLinha.id, estFabrica.id);
assert(
  saldoLinhaPosCancelamento.quantidadeReservada === 0,
  `Cenário 2 — reserva pendente liberada ao cancelar a OP (reservada = ${saldoLinhaPosCancelamento.quantidadeReservada})`,
);
assert(
  Math.abs(saldoLinhaPosCancelamento.quantidade - saldoLinhaAntes2) < 1e-9,
  "Cenário 2 — físico da linha inalterado pelo cancelamento (nada foi consumido, só reservado)",
);

// -------------------------------------------------------------------
// Invariante global: 0 <= quantidade_reservada <= quantidade em TODO
// o saldo da empresa, depois de todos os cenários acima.
// -------------------------------------------------------------------
const todosSaldos = repo.listSaldos(E1);
const violacoes = todosSaldos.filter((s) => s.quantidadeReservada < -1e-9 || s.quantidadeReservada > s.quantidade + 1e-9);
assert(violacoes.length === 0, `Invariante global — 0 <= reservada <= quantidade em todos os ${todosSaldos.length} saldos da empresa`);

console.log(`\n${falhas === 0 ? "TUDO OK" : `${falhas} FALHA(S)`} — cenários da Etapa 6 (reserva, consumo por setor, shortfall não bloqueante, cancelamento libera reserva).`);
if (falhas > 0) process.exit(1);
