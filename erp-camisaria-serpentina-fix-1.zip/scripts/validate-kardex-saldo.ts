// Script de validação (Etapa 3) — reconstrói, para cada par
// produtoVariacaoId+estoqueId, a sequência de saldoAnterior/saldoResultante
// das movimentações do Kardex (ordenadas por data) e confere que:
//   1. saldoResultante de uma linha == saldoAnterior da próxima linha
//      (mesma variação+estoque);
//   2. saldoResultante == saldoAnterior + quantidade (ENTRADA) ou
//      saldoAnterior - quantidade (SAIDA);
//   3. o saldo final da reconstrução bate com o saldo armazenado em
//      produto_estoque (tabela `saldos` do seed) para o mesmo par.
// Roda direto sobre src/mock/seedData.ts (fonte da verdade do mock),
// sem depender de React/Vite — apenas tsx.
import { buildSeedDatabase } from "../src/mock/seedData";

const db = buildSeedDatabase();
let erros = 0;

// --- 1) e 2): consistência interna da cadeia de saldos do Kardex ---
const porChave = new Map<string, typeof db.kardex>();
for (const k of db.kardex) {
  const chave = `${k.empresaId}:${k.produtoVariacaoId}:${k.estoqueId}`;
  if (!porChave.has(chave)) porChave.set(chave, []);
  porChave.get(chave)!.push(k);
}

for (const [chave, entradas] of porChave) {
  const ordenadas = [...entradas].sort((a, b) => (a.dataMovimentacao < b.dataMovimentacao ? -1 : 1));
  let saldoEsperado: number | null = null;
  for (const k of ordenadas) {
    if (saldoEsperado !== null && Math.abs(k.saldoAnterior - saldoEsperado) > 1e-9) {
      console.error(
        `[ERRO] ${chave}: kardex #${k.id} — saldoAnterior (${k.saldoAnterior}) difere do saldoResultante da linha anterior (${saldoEsperado})`,
      );
      erros++;
    }
    const saldoCalculado = k.sentido === "ENTRADA" ? k.saldoAnterior + k.quantidade : k.saldoAnterior - k.quantidade;
    if (Math.abs(saldoCalculado - k.saldoResultante) > 1e-9) {
      console.error(
        `[ERRO] ${chave}: kardex #${k.id} — saldoResultante (${k.saldoResultante}) não bate com saldoAnterior ${k.sentido === "ENTRADA" ? "+" : "-"} quantidade (esperado ${saldoCalculado})`,
      );
      erros++;
    }
    saldoEsperado = k.saldoResultante;
  }

  // --- 3) saldo final da reconstrução vs. saldo armazenado (produto_estoque) ---
  const [empresaIdStr, variacaoIdStr, estoqueIdStr] = chave.split(":").map(Number) as unknown as [number, number, number];
  const saldoArmazenado = db.saldos.find(
    (s) => s.empresaId === empresaIdStr && s.produtoVariacaoId === variacaoIdStr && s.estoqueId === estoqueIdStr,
  );
  if (saldoArmazenado && saldoEsperado !== null && Math.abs(saldoArmazenado.quantidade - saldoEsperado) > 1e-9) {
    console.error(
      `[ERRO] ${chave}: saldo reconstruído pelo Kardex (${saldoEsperado}) difere do saldo armazenado em produto_estoque (${saldoArmazenado.quantidade})`,
    );
    erros++;
  }
}

// --- 4) invariante da Etapa 2: quantidade_reservada sempre entre 0 e quantidade ---
for (const s of db.saldos) {
  if (s.quantidadeReservada < 0 || s.quantidadeReservada > s.quantidade + 1e-9) {
    console.error(
      `[ERRO] saldo empresa=${s.empresaId} variacao=${s.produtoVariacaoId} estoque=${s.estoqueId}: quantidadeReservada (${s.quantidadeReservada}) fora do intervalo [0, quantidade=${s.quantidade}]`,
    );
    erros++;
  }
}

console.log(`Pares variação+estoque com movimentação no Kardex: ${porChave.size}`);
console.log(`Linhas de Kardex verificadas: ${db.kardex.length}`);
console.log(`Linhas de produto_estoque verificadas: ${db.saldos.length}`);
if (erros === 0) {
  console.log("OK — reconstrução do saldo do Kardex e invariante de reserva conferem para todo o seed.");
  process.exit(0);
} else {
  console.error(`FALHOU — ${erros} inconsistência(s) encontrada(s).`);
  process.exit(1);
}
