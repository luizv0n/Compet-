// Validação funcional da Etapa 8 (OP: refugo e fracionamento). Roda as
// funções REAIS de src/services/mockRepository.ts em Node (mesma técnica
// de scripts/validate-op-etapa6.ts e validate-op-etapa7.ts).
//
// O banco já modela "boas" (quantidade) e "perdidas" (quantidade_perdida
// + motivo_perda_id) como dois campos da MESMA movimentação — não como
// duas movimentações separadas. Este script não cria um fluxo paralelo;
// confirma por teste real (não por leitura de código):
//
//   1. Boas e refugo são gravados juntos, numa única movimentação, com
//      motivo vinculado à parte perdida.
//   2. Refugo puro (quantidade_enviada = 0) exige motivo e é aceito.
//   3. quantidade_perdida sozinha excedendo o disponível da etapa é
//      rejeitada, mesmo com quantidade_enviada = 0.
//   4. Refugo NUNCA gera Kardex PRODUCAO_ENTRADA — nem quando ocorre na
//      última etapa, misturado com peças boas na mesma leva.
//   5. OP conclui corretamente com refugo parcial distribuído por várias
//      etapas, e produzida + refugada == prevista, sempre.
//   6. BUG REAL encontrado nesta auditoria e corrigido em
//      moveProductionOrder: se 100% de uma leva vira refugo numa etapa
//      NÃO final, a próxima etapa nascia com quantidade_recebida = 0 e
//      virava "atual" mesmo assim — como o formulário exige total > 0,
//      essa etapa fantasma nunca fechava e a OP ficava presa para
//      sempre. Corrigido com fechamento em cadeia de etapas que nascem
//      já esgotadas. Este script teste explicitamente esse cenário.
import * as repo from "../src/services/mockRepository";

const E1 = 1;
const USUARIO = { id: 1, nome: "Teste Etapa 8" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

const variacoes = repo.listVariacoes(E1, true);
const estoques = repo.listEstoques(E1, true);
const fluxos = repo.listFluxos(E1, true);
const motivos = repo.listMotivosPerda(E1, true);

const skuCamiseta = variacoes.find((v) => v.sku === "PC-CAM-PRETO-M")!;
const estFabrica = estoques.find((e) => e.nome.toLowerCase().includes("fábrica") || e.nome.toLowerCase().includes("fabrica"))!;
const fluxoCamiseta = fluxos.find((f) => f.nome.toLowerCase().includes("camiseta"))!;
const motivo1 = motivos[0];

assert(!!skuCamiseta && !!estFabrica && !!fluxoCamiseta && !!motivo1, "Massa de dados do seed encontrada (SKU camiseta, estoque fábrica, fluxo, motivo de perda)");

function kardexDaOp(opId: number) {
  return repo.listKardex(E1).filter((k) => k.ordemProducaoId === opId);
}

function novaOP(quantidadePrevista: number, lote: string) {
  const op = repo.createOrdemProducao(E1, USUARIO, {
    produtoVariacaoId: skuCamiseta.id,
    fluxoProducaoId: fluxoCamiseta.id,
    quantidadePrevista,
    lote,
    estoqueOrigemId: estFabrica.id,
    estoqueDestinoId: estFabrica.id,
    dataAbertura: new Date().toISOString(),
    observacao: null,
  });
  repo.releaseOrdemProducao(op.id, E1, USUARIO);
  return op;
}

function moveThrows(opId: number, payload: { quantidadeEnviada: number; quantidadePerdida: number; motivoPerdaId?: number | null }): string | null {
  try {
    repo.moveProductionOrder(E1, USUARIO, {
      ordemProducaoId: opId,
      quantidadeEnviada: payload.quantidadeEnviada,
      quantidadePerdida: payload.quantidadePerdida,
      motivoPerdaId: payload.motivoPerdaId ?? null,
      observacao: "Teste refugo",
    });
    return null;
  } catch (err) {
    return err instanceof Error ? err.message : "erro desconhecido";
  }
}

// -------------------------------------------------------------------
// Cenário 1 — boas + refugo na MESMA movimentação; motivo obrigatório
// para qualquer perda, inclusive refugo puro (envio = 0).
// -------------------------------------------------------------------
const op1 = novaOP(10, "L-TESTE-ETAPA8-1");

assert(moveThrows(op1.id, { quantidadeEnviada: 0, quantidadePerdida: 3 }) !== null, "Rejeita perda sem motivo_perda_id, mesmo com quantidade_enviada = 0 (refugo puro)");

const movsAntes1 = repo.listMovimentacoesDaOP(op1.id, E1).length;
const { op: op1AposLeva1 } = repo.moveProductionOrder(E1, USUARIO, {
  ordemProducaoId: op1.id,
  quantidadeEnviada: 7,
  quantidadePerdida: 3,
  motivoPerdaId: motivo1.id,
  observacao: "leva 1 — 7 boas + 3 refugadas, fecha a etapa 1 (7+3=10)",
});
const movimentacoesOp1 = repo.listMovimentacoesDaOP(op1.id, E1);
assert(op1AposLeva1.quantidadeRefugada === 3, "OP1 acumula quantidadeRefugada = 3 após a leva 1 (boas+refugo na mesma movimentação)");
assert(movimentacoesOp1.length === movsAntes1 + 1, "A leva 1 gerou exatamente UMA movimentação (boas + refugo juntos, não duas separadas)");
const movLeva1 = movimentacoesOp1[0];
assert(movLeva1.quantidade === 7 && movLeva1.quantidadePerdida === 3 && movLeva1.motivoPerdaId === motivo1.id, "A movimentação da leva 1 tem quantidade=7 (boa), quantidade_perdida=3 (refugo) e motivo_perda_id no MESMO registro");

// -------------------------------------------------------------------
// Cenário 2 — quantidade_perdida sozinha excedendo o disponível da
// (nova) etapa atual é rejeitada, mesmo com quantidade_enviada = 0.
// -------------------------------------------------------------------
let etapaAtualOp1 = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === repo.getOrdemProducao(op1.id, E1)!.etapaAtualId)!;
const disponivelAtualOp1 = etapaAtualOp1.quantidadeRecebida - etapaAtualOp1.quantidadeConcluida - etapaAtualOp1.quantidadePerdida;
assert(disponivelAtualOp1 === 7, `Etapa 2 da OP1 recebeu exatamente as 7 boas enviadas na leva 1 (${disponivelAtualOp1} == 7)`);
const excedeSoRefugo = moveThrows(op1.id, { quantidadeEnviada: 0, quantidadePerdida: disponivelAtualOp1 + 1, motivoPerdaId: motivo1.id });
assert(excedeSoRefugo !== null, `Rejeita quantidade_perdida (${disponivelAtualOp1 + 1}) sozinha excedendo o disponível da etapa (${disponivelAtualOp1}), mesmo com envio = 0`);

// -------------------------------------------------------------------
// Cenário 3 — leva com refugo PARCIAL (não 100%) segue normalmente:
// parte boa avança, parte perdida fica registrada, etapa fecha quando
// esgota. Percorre o resto do fluxo todo como boa a partir daqui para
// garantir que o produto chegue ao fim (mistura refugo parcial + fluxo
// saudável, sem apagar 100% da produção).
// -------------------------------------------------------------------
const { op: op1AposLeva2 } = repo.moveProductionOrder(E1, USUARIO, {
  ordemProducaoId: op1.id,
  quantidadeEnviada: 6,
  quantidadePerdida: 1,
  motivoPerdaId: motivo1.id,
  observacao: "leva 2 — refugo parcial (1 de 7), fecha a etapa 2",
});
assert(op1AposLeva2.quantidadeRefugada === 4, "OP1 acumula quantidadeRefugada = 4 (3 da leva 1 + 1 da leva 2)");

let opAtual1 = repo.getOrdemProducao(op1.id, E1)!;
let guard1 = 0;
while (opAtual1.status !== "CONCLUIDA" && guard1 < 30) {
  guard1++;
  const etapaLoop = repo.listEtapasDaOP(op1.id, E1).find((e) => e.id === opAtual1.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const { op: novaOpState } = repo.moveProductionOrder(E1, USUARIO, {
    ordemProducaoId: op1.id,
    quantidadeEnviada: disponivelLoop,
    quantidadePerdida: 0,
    observacao: "resto do fluxo sem novas perdas — fecha a OP1",
  });
  opAtual1 = novaOpState;
}
assert(opAtual1.status === "CONCLUIDA", "OP1 concluída ao final, com refugo parcial registrado em duas etapas diferentes");
assert(
  Math.abs(opAtual1.quantidadeProduzida + opAtual1.quantidadeRefugada - opAtual1.quantidadePrevista) < 1e-9,
  `OP1 — produzida (${opAtual1.quantidadeProduzida}) + refugada (${opAtual1.quantidadeRefugada}) == prevista (${opAtual1.quantidadePrevista}) exatamente`,
);
assert(opAtual1.quantidadeProduzida === 6, `OP1 — produzida bate com o que sobrou depois do refugo parcial (6 de 10 previstas, já que 4 foram refugadas: ${opAtual1.quantidadeProduzida})`);

// Confirma no Kardex: entrada de produto acabado == quantidadeProduzida,
// nunca inclui a parte refugada.
const kardexOp1 = kardexDaOp(op1.id);
const entradasOp1 = kardexOp1.filter((k) => k.natureza === "PRODUCAO_ENTRADA" && k.sentido === "ENTRADA");
const somaEntradasOp1 = entradasOp1.reduce((acc, k) => acc + k.quantidade, 0);
assert(entradasOp1.length > 0, "OP1 — Kardex registrou entrada(s) PRODUCAO_ENTRADA (produto acabado)");
assert(Math.abs(somaEntradasOp1 - opAtual1.quantidadeProduzida) < 1e-9, `OP1 — soma das entradas PRODUCAO_ENTRADA (${somaEntradasOp1}) == quantidadeProduzida (${opAtual1.quantidadeProduzida})`);
assert(somaEntradasOp1 < opAtual1.quantidadePrevista - 1e-9, "OP1 — entrada de produto acabado é estritamente menor que a prevista, pois houve refugo");

// -------------------------------------------------------------------
// Cenário 4 — refugo misturado com boas NA ÚLTIMA etapa: a parte boa
// gera PRODUCAO_ENTRADA, a parte refugada NÃO, na mesma movimentação.
// -------------------------------------------------------------------
const op2 = novaOP(4, "L-TESTE-ETAPA8-2");
let opAtual2 = repo.getOrdemProducao(op2.id, E1)!;
let guard2 = 0;
while (opAtual2.status !== "CONCLUIDA" && guard2 < 30) {
  guard2++;
  const etapasLoop = repo.listEtapasDaOP(op2.id, E1);
  const etapaLoop = etapasLoop.find((e) => e.id === opAtual2.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const ehUltimaEtapa = !etapasLoop.some((e) => e.sequencia === etapaLoop.sequencia + 1);
  const perder = ehUltimaEtapa && disponivelLoop > 1 ? 1 : 0;
  const { op: novaOpState } = repo.moveProductionOrder(E1, USUARIO, {
    ordemProducaoId: op2.id,
    quantidadeEnviada: disponivelLoop - perder,
    quantidadePerdida: perder,
    motivoPerdaId: perder > 0 ? motivo1.id : null,
    observacao: ehUltimaEtapa ? "última etapa — 1 refugada junto com o resto boas" : "envio integral, sem perda",
  });
  opAtual2 = novaOpState;
}
assert(opAtual2.status === "CONCLUIDA", "OP2 concluída");
assert(opAtual2.quantidadeRefugada === 1, `OP2 — 1 unidade refugada na última etapa (${opAtual2.quantidadeRefugada})`);
assert(opAtual2.quantidadeProduzida === 3, `OP2 — 3 unidades produzidas (4 previstas − 1 refugada) (${opAtual2.quantidadeProduzida})`);
const kardexOp2 = kardexDaOp(op2.id);
const entradasOp2 = kardexOp2.filter((k) => k.natureza === "PRODUCAO_ENTRADA" && k.sentido === "ENTRADA");
const somaEntradasOp2 = entradasOp2.reduce((acc, k) => acc + k.quantidade, 0);
assert(Math.abs(somaEntradasOp2 - 3) < 1e-9, `OP2 — Kardex registra entrada de exatamente 3 (a peça refugada na mesma leva não entra) (${somaEntradasOp2})`);

// -------------------------------------------------------------------
// Cenário 5 — BUG REAL corrigido nesta etapa: 100% de refugo numa
// etapa NÃO final. A próxima etapa nasceria com recebida = 0 e ficaria
// "presa" para sempre sem a correção. Confirma que a OP conclui
// corretamente, sem etapa fantasma pendente, e sem produto acabado
// além do que realmente sobrou (aqui, zero).
// -------------------------------------------------------------------
const op3 = novaOP(5, "L-TESTE-ETAPA8-3-refugo-total-etapa-intermediaria");
const etapasOp3 = repo.listEtapasDaOP(op3.id, E1);
assert(etapasOp3.length >= 2, "OP3 — fluxo da camiseta tem ao menos 2 etapas (pré-condição para testar refugo total numa etapa intermediária)");

// Refuga 100% da primeira etapa (etapa 1, que não é a última do fluxo).
const { op: op3AposRefugoTotal } = repo.moveProductionOrder(E1, USUARIO, {
  ordemProducaoId: op3.id,
  quantidadeEnviada: 0,
  quantidadePerdida: 5,
  motivoPerdaId: motivo1.id,
  observacao: "100% de refugo na 1ª etapa — cenário do bug corrigido",
});
assert(op3AposRefugoTotal.status === "CONCLUIDA", "OP3 — conclui IMEDIATAMENTE após 100% de refugo na 1ª etapa (nada resta para as etapas seguintes)");
assert(op3AposRefugoTotal.etapaAtualId === null, "OP3 — etapaAtualId fica null (sem etapa fantasma pendente travando a OP)");
assert(op3AposRefugoTotal.quantidadeRefugada === 5, `OP3 — quantidadeRefugada = 5 (100% da prevista) (${op3AposRefugoTotal.quantidadeRefugada})`);
assert(op3AposRefugoTotal.quantidadeProduzida === 0, `OP3 — quantidadeProduzida = 0 (nada sobreviveu para virar produto acabado) (${op3AposRefugoTotal.quantidadeProduzida})`);

const etapasOp3Depois = repo.listEtapasDaOP(op3.id, E1);
const etapasNaoConcluidas = etapasOp3Depois.filter((e) => e.status !== "CONCLUIDA");
assert(etapasNaoConcluidas.length === 0, `OP3 — todas as ${etapasOp3Depois.length} etapas do fluxo terminam CONCLUIDA (nenhuma fica travada em AGUARDANDO/EM_EXECUCAO com 0 recebido)`);
for (const et of etapasOp3Depois) {
  assert(et.quantidadeRecebida - et.quantidadeConcluida - et.quantidadePerdida <= 1e-9, `OP3 — etapa seq ${et.sequencia} não deixa saldo pendente (recebida=${et.quantidadeRecebida}, concluída=${et.quantidadeConcluida}, perdida=${et.quantidadePerdida})`);
}
const kardexOp3 = kardexDaOp(op3.id);
const entradasOp3 = kardexOp3.filter((k) => k.natureza === "PRODUCAO_ENTRADA" && k.sentido === "ENTRADA");
assert(entradasOp3.length === 0, "OP3 — nenhuma entrada PRODUCAO_ENTRADA no Kardex (100% refugo não gera produto acabado)");

// -------------------------------------------------------------------
// Cenário 6 — mesmo bug, mas o refugo total acontece na ÚLTIMA etapa
// (já coberto indiretamente na Etapa 7/cenário de shortfall, mas
// reconfirmado aqui como parte do conjunto de regressão do refugo).
// -------------------------------------------------------------------
const op4 = novaOP(3, "L-TESTE-ETAPA8-4-refugo-total-ultima-etapa");
let opAtual4 = repo.getOrdemProducao(op4.id, E1)!;
let guard4 = 0;
while (opAtual4.status !== "CONCLUIDA" && guard4 < 30) {
  guard4++;
  const etapasLoop = repo.listEtapasDaOP(op4.id, E1);
  const etapaLoop = etapasLoop.find((e) => e.id === opAtual4.etapaAtualId)!;
  const disponivelLoop = etapaLoop.quantidadeRecebida - etapaLoop.quantidadeConcluida - etapaLoop.quantidadePerdida;
  const ehUltimaEtapa = !etapasLoop.some((e) => e.sequencia === etapaLoop.sequencia + 1);
  const { op: novaOpState } = repo.moveProductionOrder(E1, USUARIO, {
    ordemProducaoId: op4.id,
    quantidadeEnviada: ehUltimaEtapa ? 0 : disponivelLoop,
    quantidadePerdida: ehUltimaEtapa ? disponivelLoop : 0,
    motivoPerdaId: ehUltimaEtapa ? motivo1.id : null,
    observacao: ehUltimaEtapa ? "última etapa — refugo total" : "envio integral",
  });
  opAtual4 = novaOpState;
}
assert(opAtual4.status === "CONCLUIDA", "OP4 concluída mesmo com 100% de refugo na última etapa");
assert(opAtual4.quantidadeProduzida === 0 && opAtual4.quantidadeRefugada === 3, `OP4 — produzida=0, refugada=3 (${opAtual4.quantidadeProduzida}/${opAtual4.quantidadeRefugada})`);
const entradasOp4 = kardexDaOp(op4.id).filter((k) => k.natureza === "PRODUCAO_ENTRADA" && k.sentido === "ENTRADA");
assert(entradasOp4.length === 0, "OP4 — nenhuma entrada PRODUCAO_ENTRADA no Kardex");

// -------------------------------------------------------------------
// Invariante global (mesma checagem das Etapas 6/7, garantindo
// ausência de regressão introduzida pelos cenários acima).
// -------------------------------------------------------------------
const todosSaldos = repo.listSaldos(E1);
const violacoes = todosSaldos.filter((s) => s.quantidadeReservada < -1e-9 || s.quantidadeReservada > s.quantidade + 1e-9);
assert(violacoes.length === 0, `Invariante global — 0 <= reservada <= quantidade em todos os ${todosSaldos.length} saldos da empresa`);

console.log(`\n${falhas === 0 ? "TUDO OK" : `${falhas} FALHA(S)`} — cenários da Etapa 8 (refugo na mesma movimentação, refugo puro, refugo nunca vira produto acabado, bug de etapa fantasma com 100% de refugo corrigido).`);
if (falhas > 0) process.exit(1);
