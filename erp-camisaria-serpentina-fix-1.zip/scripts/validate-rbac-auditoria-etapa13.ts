// Validação funcional da Etapa 13 (Auditoria e RBAC). Roda as funções
// REAIS de src/services/mockRepository.ts em Node (mesma técnica de
// scripts/validate-op-etapa6/7/8/9/10.ts,
// validate-compras-etapa11.ts e validate-transferencias-etapa12.ts).
//
// AUDITORIA DESTA ETAPA (código lido antes de qualquer alteração):
//   - RBAC é inteiramente orientado a dados: cargo -> permissaoIds ->
//     nome da permissão (src/constants/permissions.ts). getSessionContext
//     (mockRepository.ts) resolve usuário -> cargo -> lista de nomes de
//     permissão; AuthContext.hasPermission só faz
//     state.permissoes.includes(perm). RequirePermission usa isso para
//     bloquear a PÁGINA inteira quando a permissão falta (não só botões
//     individuais) — confirmado em src/pages/equipe/page.tsx (bloqueada
//     por TEAM_MANAGE) e src/pages/estoque/locais/page.tsx (bloqueada
//     por STOCK_LOCATIONS_MANAGE).
//   - FUNCIONARIO_PERMISSIONS (permissions.ts) NÃO inclui TEAM_MANAGE
//     nem STOCK_LOCATIONS_MANAGE — exatamente a regra 24 do prompt
//     mestre ("Funcionário não deve poder cadastrar usuários, alterar
//     usuários, cadastrar novos locais de estoque"). O seed
//     (seedData.ts) gera os dois cargos (ADMINISTRADOR/FUNCIONARIO)
//     A PARTIR dessas constantes, para as duas empresas do seed (E1 e
//     E2) — não há uma segunda fonte de verdade duplicada.
//   - As funções de escrita em mockRepository.ts (createUsuario,
//     createProduto, transferStock, etc.) NÃO reforçam permissão
//     internamente — apenas a UI (RequirePermission + hasPermission)
//     impede o acesso. Isso é INTENCIONAL e consistente em TODO o
//     projeto (nenhuma função de domínio checa cargo/permissão em
//     lugar nenhum) — não é uma lacuna desta etapa especificamente, é
//     a arquitetura atual do sistema, compatível com a regra 4 do
//     prompt mestre ("Este NÃO é o backend... preparado para receber o
//     backend posteriormente", que fará a aplicação real das
//     permissões). Não foi adicionada uma camada de enforcement no
//     domínio nesta etapa: isso criaria uma segunda arquitetura de
//     autorização paralela à existente (RequirePermission na UI), na
//     contramão da regra 24/29 do prompt mestre ("preservar os cargos
//     existentes... não inventar um sistema paralelo").
//   - Auditoria (logAudit) já cobre a MAIORIA das operações
//     importantes: produto, variação, preço, ficha técnica, fluxo, OP
//     (criação/liberação/refugo/movimentação/cancelamento/pausa),
//     estoque (entrada/baixa/transferência), nota fiscal
//     (criação/edição/conclusão/cancelamento), usuário
//     (criação/edição/ativação), login. Os "cadastros de apoio"
//     (coleção, cor, tamanho, categoria, unidade, fornecedor, setor,
//     motivo de perda) NUNCA geraram auditoria — padrão consistente e
//     preservado (não é o alvo da regra 22, que fala em "operações
//     importantes").
//
//   BUG REAL ENCONTRADO: createEstoque/toggleEstoque (locais de
//   estoque — Fábrica/Loja) eram a ÚNICA exceção a esse padrão: apesar
//   de exigirem uma permissão elevada e distinta
//   (STOCK_LOCATIONS_MANAGE, igual em sensibilidade a TEAM_MANAGE — a
//   própria regra 24 do prompt mestre cita as duas juntas), essas duas
//   funções não geravam NENHUM registro de auditoria, ao contrário de
//   createUsuario/updateUsuario/toggleUsuario (a outra operação
//   sensível citada pela mesma regra), que sempre logaram. Corrigido
//   reaproveitando o padrão logAudit já existente (mesma assinatura
//   usada por transferStock/manualStockOut/createUsuario) — nenhuma
//   segunda arquitetura de auditoria foi criada. apiClient.estoques.
//   create/toggle e src/pages/estoque/locais/page.tsx foram ajustados
//   para passar o `actor` (mesmo padrão já usado por
//   apiClient.estoques.transfer/manualOut/directIn).
//
// Cenários cobertos:
//   1. RBAC (dados) — FUNCIONARIO não tem TEAM_MANAGE nem
//      STOCK_LOCATIONS_MANAGE em NENHUMA das duas empresas do seed;
//      ADMINISTRADOR tem TODAS as permissões (ALL_PERMISSIONS) nas
//      duas empresas.
//   2. Multi-tenant — nenhuma leitura (produtos, variações, estoque,
//      Kardex, compras, OP, ficha técnica/componentes, fluxos,
//      equipe/usuários, cargos, auditoria) de uma empresa retorna
//      registros de outra empresa.
//   3. Multi-tenant — getSessionContext(usuarioId de E1, empresaId=E2)
//      não retorna contexto válido (usuário não pertence à empresa).
//   4. Auditoria — createEstoque/toggleEstoque (BUG corrigido nesta
//      etapa) geram registro de auditoria correto (ação, entidade,
//      descrição, usuário, empresa).
//   5. Auditoria — createUsuario/updateUsuario/toggleUsuario (já
//      existente) continuam gerando auditoria correta, sem regressão.
//   6. Auditoria — todo registro de auditoria criado nos testes acima
//      pertence à empresa correta (isolamento também na auditoria).
//
// Não inventa nenhuma tabela/coluna fora do bd_competeV6.sql.
import * as repo from "../src/services/mockRepository";
import { PERMISSIONS, FUNCIONARIO_PERMISSIONS, ALL_PERMISSIONS, ROLE_NAMES } from "../src/constants/permissions";

const E1 = 1;
const E2 = 2;
const USUARIO = { id: 1, nome: "Teste Etapa 13" };

let falhas = 0;
function assert(cond: boolean, msg: string) {
  if (!cond) {
    console.error(`[FALHA] ${msg}`);
    falhas++;
  } else {
    console.log(`[OK] ${msg}`);
  }
}

// -----------------------------------------------------------------
// Cenário 1 — RBAC orientado a dados (as duas empresas do seed)
// -----------------------------------------------------------------
for (const empresaId of [E1, E2]) {
  const cargos = repo.listCargos(empresaId);
  const admin = cargos.find((c) => c.nome === ROLE_NAMES.ADMIN)!;
  const funcionario = cargos.find((c) => c.nome === ROLE_NAMES.FUNCIONARIO)!;
  assert(!!admin && !!funcionario, `Empresa ${empresaId} tem os 2 cargos do seed (ADMINISTRADOR, FUNCIONARIO)`);

  const usuarios = repo.listUsuarios(empresaId, true);
  const usuarioAdmin = usuarios.find((u) => u.cargoId === admin.id)!;
  const usuarioFunc = usuarios.find((u) => u.cargoId === funcionario.id)!;

  const ctxAdmin = repo.getSessionContext(usuarioAdmin.id, empresaId)!;
  const ctxFunc = repo.getSessionContext(usuarioFunc.id, empresaId)!;

  assert(
    ALL_PERMISSIONS.every((p) => ctxAdmin.permissoes.includes(p)),
    `Empresa ${empresaId} — ADMINISTRADOR possui TODAS as ${ALL_PERMISSIONS.length} permissões`,
  );
  assert(
    !ctxFunc.permissoes.includes(PERMISSIONS.TEAM_MANAGE),
    `Empresa ${empresaId} — FUNCIONARIO NÃO tem equipe.gerenciar (regra 24: não pode cadastrar/alterar usuários)`,
  );
  assert(
    !ctxFunc.permissoes.includes(PERMISSIONS.STOCK_LOCATIONS_MANAGE),
    `Empresa ${empresaId} — FUNCIONARIO NÃO tem estoque.locais.gerenciar (regra 24: não pode cadastrar locais de estoque)`,
  );
  assert(
    FUNCIONARIO_PERMISSIONS.every((p) => ctxFunc.permissoes.includes(p)),
    `Empresa ${empresaId} — FUNCIONARIO tem exatamente as permissões operacionais esperadas (produção, compras, estoque, transferências, Kardex)`,
  );
}

// -----------------------------------------------------------------
// Cenário 2 — Multi-tenant: nenhuma leitura vaza entre empresas
// -----------------------------------------------------------------
{
  const produtos1 = repo.listProdutos(E1, true);
  const produtos2 = repo.listProdutos(E2, true);
  assert(
    produtos1.every((p) => p.empresaId === E1) && produtos2.every((p) => p.empresaId === E2),
    "Produtos — nenhum registro de E1 aparece em E2 e vice-versa",
  );

  const variacoes1 = repo.listVariacoes(E1, true);
  const variacoes2 = repo.listVariacoes(E2, true);
  assert(
    variacoes1.every((v) => v.empresaId === E1) && variacoes2.every((v) => v.empresaId === E2),
    "Variações/SKU — isolamento por empresa confirmado",
  );

  const estoques1 = repo.listEstoques(E1, true);
  const estoques2 = repo.listEstoques(E2, true);
  assert(
    estoques1.every((e) => e.empresaId === E1) && estoques2.every((e) => e.empresaId === E2),
    "Estoques (locais) — isolamento por empresa confirmado",
  );

  const saldos1 = repo.listSaldos(E1);
  const saldos2 = repo.listSaldos(E2);
  assert(
    saldos1.every((s) => s.empresaId === E1) && saldos2.every((s) => s.empresaId === E2),
    "Saldos de estoque — isolamento por empresa confirmado",
  );

  const kardex1 = repo.listKardex(E1);
  const kardex2 = repo.listKardex(E2);
  assert(
    kardex1.every((k) => k.empresaId === E1) && kardex2.every((k) => k.empresaId === E2),
    "Kardex — isolamento por empresa confirmado",
  );

  const notas1 = repo.listNotasFiscais(E1);
  const notas2 = repo.listNotasFiscais(E2);
  assert(
    notas1.every((n) => n.empresaId === E1) && notas2.every((n) => n.empresaId === E2),
    "Notas fiscais (Compras) — isolamento por empresa confirmado",
  );

  const ops1 = repo.listOrdensProducao(E1);
  const ops2 = repo.listOrdensProducao(E2);
  assert(
    ops1.every((o) => o.empresaId === E1) && ops2.every((o) => o.empresaId === E2),
    "Ordens de Produção — isolamento por empresa confirmado",
  );

  const fluxos1 = repo.listFluxos(E1, true);
  const fluxos2 = repo.listFluxos(E2, true);
  assert(
    fluxos1.every((f) => f.empresaId === E1) && fluxos2.every((f) => f.empresaId === E2),
    "Fluxos de produção — isolamento por empresa confirmado",
  );

  // Ficha técnica (componentes) — testada via um produto pai de cada empresa
  const produtoPai1 = produtos1.find((p) => p.tipo === "PC" || p.tipo === "SC") ?? produtos1[0];
  const produtoPai2 = produtos2.find((p) => p.tipo === "PC" || p.tipo === "SC") ?? produtos2[0];
  if (produtoPai1 && produtoPai2) {
    const comp1 = repo.listComponentes(produtoPai1.id, E1);
    const comp2 = repo.listComponentes(produtoPai2.id, E2);
    assert(
      comp1.every((c) => c.empresaId === E1) && comp2.every((c) => c.empresaId === E2),
      "Ficha técnica (componentes) — isolamento por empresa confirmado",
    );
  }

  const usuarios1 = repo.listUsuarios(E1, true);
  const usuarios2 = repo.listUsuarios(E2, true);
  assert(
    usuarios1.every((u) => u.empresaId === E1) && usuarios2.every((u) => u.empresaId === E2),
    "Equipe (usuários) — isolamento por empresa confirmado",
  );

  const cargos1 = repo.listCargos(E1);
  const cargos2 = repo.listCargos(E2);
  assert(
    cargos1.every((c) => c.empresaId === E1) && cargos2.every((c) => c.empresaId === E2),
    "Cargos — isolamento por empresa confirmado (cada empresa tem seus próprios registros de permissão/cargo)",
  );

  const audit1 = repo.listAuditLog(E1);
  const audit2 = repo.listAuditLog(E2);
  assert(
    audit1.every((a) => a.empresaId === E1) && audit2.every((a) => a.empresaId === E2),
    "Auditoria — isolamento por empresa confirmado",
  );
}

// -----------------------------------------------------------------
// Cenário 3 — getSessionContext rejeita combinação usuário/empresa
// que não existe (usuário de E1 não pertence a E2)
// -----------------------------------------------------------------
{
  const usuarioE1 = repo.listUsuarios(E1, true)[0];
  const ctxCruzado = repo.getSessionContext(usuarioE1.id, E2);
  assert(ctxCruzado === null, "getSessionContext(usuário de E1, empresaId=E2) retorna null — sem vazamento de sessão entre empresas");
}

// -----------------------------------------------------------------
// Cenário 4 — BUG CORRIGIDO: createEstoque/toggleEstoque agora geram
// auditoria (mesmo padrão de createUsuario/toggleUsuario)
// -----------------------------------------------------------------
{
  const auditAntes = repo.listAuditLog(E1).length;
  const novoLocal = repo.createEstoque(E1, USUARIO, {
    nome: "Loja Teste Etapa 13",
    cep: null,
    logradouro: null,
    numero: null,
    complemento: null,
    bairro: null,
    cidade: null,
    estado: null,
  });
  const auditDepoisCreate = repo.listAuditLog(E1);
  assert(auditDepoisCreate.length === auditAntes + 1, "createEstoque gera exatamente 1 novo registro de auditoria");
  const logCreate = auditDepoisCreate[0];
  assert(logCreate.acao === "CRIACAO" && logCreate.entidade === "Estoque (local)", "Registro de auditoria da criação tem ação CRIACAO e entidade correta");
  assert(logCreate.usuarioId === USUARIO.id && logCreate.empresaId === E1, "Registro de auditoria referencia o usuário e a empresa corretos");
  assert(logCreate.descricao.includes("Loja Teste Etapa 13"), "Descrição da auditoria menciona o nome do local criado");

  const auditAntesToggle = repo.listAuditLog(E1).length;
  const toggled = repo.toggleEstoque(novoLocal.id, E1, USUARIO);
  const auditDepoisToggle = repo.listAuditLog(E1);
  assert(auditDepoisToggle.length === auditAntesToggle + 1, "toggleEstoque gera exatamente 1 novo registro de auditoria");
  assert(toggled.ativo === false, "toggleEstoque inativou o local recém-criado (estava ativo)");
  const logToggle = auditDepoisToggle[0];
  assert(logToggle.acao === "INATIVACAO" && logToggle.entidade === "Estoque (local)", "Registro de auditoria da inativação tem ação INATIVACAO e entidade correta");
}

// -----------------------------------------------------------------
// Cenário 5 — Sem regressão: createUsuario/updateUsuario/toggleUsuario
// continuam gerando auditoria corretamente
// -----------------------------------------------------------------
{
  const cargos = repo.listCargos(E1);
  const funcCargo = cargos.find((c) => c.nome === ROLE_NAMES.FUNCIONARIO)!;
  const auditAntes = repo.listAuditLog(E1).length;
  const novoUsuario = repo.createUsuario(E1, USUARIO, {
    nome: "Usuário Teste Etapa 13",
    login: `teste.etapa13.${Date.now()}`,
    email: `teste.etapa13.${Date.now()}@exemplo.com`,
    senha: "123456",
    cargoId: funcCargo.id,
  });
  assert(repo.listAuditLog(E1).length === auditAntes + 1, "createUsuario continua gerando 1 registro de auditoria (sem regressão)");

  const auditAntesUpdate = repo.listAuditLog(E1).length;
  repo.updateUsuario(novoUsuario.id, E1, USUARIO, { nome: "Usuário Teste Etapa 13 (editado)" });
  assert(repo.listAuditLog(E1).length === auditAntesUpdate + 1, "updateUsuario continua gerando 1 registro de auditoria (sem regressão)");

  const auditAntesToggle = repo.listAuditLog(E1).length;
  repo.toggleUsuario(novoUsuario.id, E1, USUARIO);
  assert(repo.listAuditLog(E1).length === auditAntesToggle + 1, "toggleUsuario continua gerando 1 registro de auditoria (sem regressão)");
}

// -----------------------------------------------------------------
// Cenário 6 — Todos os registros de auditoria gerados nos testes
// acima pertencem à empresa correta (isolamento também na auditoria
// recém-gerada, não só no seed)
// -----------------------------------------------------------------
{
  const auditE1 = repo.listAuditLog(E1);
  const auditE2 = repo.listAuditLog(E2);
  assert(auditE1.every((a) => a.empresaId === E1), "Todo o log de auditoria de E1 (seed + testes acima) pertence a E1");
  assert(auditE2.every((a) => a.empresaId === E2), "Log de auditoria de E2 permanece intocado pelos testes rodados em E1");
}

console.log("");
if (falhas > 0) {
  console.error(`${falhas} FALHA(S) encontradas na Etapa 13.`);
  process.exit(1);
} else {
  console.log(
    "TUDO OK — cenários da Etapa 13 (RBAC orientado a dados correto nas 2 empresas, isolamento multi-tenant em todas as entidades testadas, sessão cruzada rejeitada, auditoria de locais de estoque corrigida e sem regressão em auditoria de usuário).",
  );
}
