# Camisaria ERP — Front-end

ERP multiempresa (multi-tenant) voltado para confecções têxteis: catálogo de
produtos e variações (SKU), ficha técnica (BOM), estoque por local com Kardex,
compras (notas fiscais de entrada), produção (fluxos, setores e ordens de
produção com fracionamento e refugo), equipe/RBAC e auditoria.

Front-end completo e funcional operando sobre dados simulados
(localStorage), com a camada de acesso a dados isolada em
`src/services/apiClient.ts` para permitir a troca futura dos mocks por um
backend real (REST/JWT/Prisma) sem reescrever as telas.

## Stack

- React 19 + TypeScript
- TanStack Start / TanStack Router (file-based routing em `src/routes`)
- Tailwind CSS v4 + shadcn/ui (Radix UI)
- TanStack Query
- Vite

## Estrutura

```
src/
  routes/          Rotas (TanStack Router, file-based)
  pages/           Telas (componentes de página usados pelas rotas)
  components/
    ui/            Componentes base (shadcn/ui)
    common/        Componentes compartilhados de domínio (PageHeader, StatusBadge, etc.)
    layout/        AppShell, Header, Sidebar
  services/
    apiClient.ts       Fachada assíncrona — único ponto de acesso a dados usado pelas telas
    mockRepository.ts  Regras de negócio sobre o banco mock (estoque, Kardex, produção, compras...)
    storage.ts         Persistência em localStorage
  mock/seedData.ts  Dados iniciais (duas empresas, para validar isolamento multiempresa)
  types/            Tipos de domínio (espelham as tabelas do banco) e ViewModels de apresentação
  context/          AuthContext (sessão/RBAC) e ToastContext
  constants/        Permissões (RBAC) e itens de navegação
```

## Rodando localmente

Requer Node.js e npm.

```sh
npm i
npm run dev
```

Outros scripts disponíveis: `npm run build`, `npm run preview`, `npm run lint`, `npm run format`.

## Acesso de demonstração

Duas empresas são semeadas para validar o isolamento multi-tenant. Senha
`123456` para todos os usuários de exemplo:

| Empresa           | Login               | Cargo                        |
| ----------------- | -------------------- | ----------------------------- |
| Malharia Estrela   | `admin.estrela`      | Administrador (acesso total) |
| Malharia Estrela   | `producao.estrela`   | Funcionário (operacional)    |
| Vitória Malhas     | `admin.vitoria`      | Administrador (acesso total) |
| Vitória Malhas     | `producao.vitoria`   | Funcionário (operacional)    |

## Notas de arquitetura

- Toda operação que afeta saldo de estoque grava `produto_estoque` e um
  lançamento de Kardex de forma atômica (ver `applyKardexAndBalance` em
  `mockRepository.ts`), e é registrada na auditoria.
- O RBAC é orientado a permissões (`cargo` → `cargo_permissao` → `permissao`),
  não a papéis fixos no código — ver `src/constants/permissions.ts`.
- Próxima integração planejada: backend real com JWT + Prisma, substituindo
  apenas `apiClient.ts`/`mockRepository.ts`.

---

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://erp-fabric-forge.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/23e44ea2-75b6-4c15-b09c-d395e0b458cb).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.
