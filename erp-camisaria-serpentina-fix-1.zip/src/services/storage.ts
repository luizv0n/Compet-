// =====================================================================
// storage.ts — única camada que toca localStorage diretamente.
//
// Fluxo: seedData -> storage -> mockRepository -> apiClient -> UI
//
// Na primeira execução, o banco em memória é inicializado a partir de
// seedData.ts. A partir daí, todo o estado é persistido em
// localStorage sob uma única chave, e sobrevive a refresh da página.
// =====================================================================

import type { Database } from "@/mock/seedData";
import { buildSeedDatabase, CURRENT_SEED_VERSION } from "@/mock/seedData";

const STORAGE_KEY = "camisaria_erp_db_v1";
const SESSION_KEY = "camisaria_erp_session_v1";
// Chave separada da sessão de empresa: um ADM DO SITE não é um Usuario
// de empresa (ver nota de limitação em types/index.ts), então sua
// sessão mock não pode conviver na mesma chave/estrutura de StoredSession.
const PLATFORM_SESSION_KEY = "camisaria_erp_platform_session_v1";

function isBrowser(): boolean {
  return typeof window !== "undefined";
}

function safeParse<T>(raw: string | null): T | null {
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

/**
 * Lê o banco mock do localStorage, semeando na primeira execução.
 *
 * Regra crítica (Etapa 2 do prompt de continuação — persistência de
 * empresas): se já existe um banco salvo, ele é a fonte da verdade e
 * NUNCA é descartado, mesmo que `CURRENT_SEED_VERSION` tenha mudado
 * desde que foi salvo. Um bump de versão serve apenas para permitir que
 * uma versão nova do `Database` introduza chaves de nível superior que
 * ainda não existiam (ex.: uma nova "tabela") — essas chaves são
 * completadas a partir de um seed fresco, mas todo o conteúdo já salvo
 * (empresas, usuários, produtos, etc.) é preservado como está.
 * Descartar o banco existente e recriar do zero só acontece quando
 * NÃO HÁ banco nenhum salvo ainda (primeira execução).
 */
export function loadDatabase(): Database {
  if (!isBrowser()) {
    return buildSeedDatabase();
  }
  const existing = safeParse<Database>(localStorage.getItem(STORAGE_KEY));
  if (!existing) {
    const fresh = buildSeedDatabase();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    return fresh;
  }
  if (existing.__seedVersion !== CURRENT_SEED_VERSION) {
    const fresh = buildSeedDatabase();
    // A ordem importa: `fresh` primeiro, `existing` por cima — assim
    // qualquer chave nova que só exista em `fresh` é preenchida, e
    // qualquer chave que já exista em `existing` (mesmo vazia) prevalece
    // intacta, sem jamais ser substituída pelo conteúdo do seed.
    const migrated: Database = { ...fresh, ...existing, __seedVersion: CURRENT_SEED_VERSION };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(migrated));
    return migrated;
  }
  return existing;
}

export function saveDatabase(db: Database): void {
  if (!isBrowser()) return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}

export function resetDatabase(): Database {
  const fresh = buildSeedDatabase();
  if (isBrowser()) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
  }
  return fresh;
}

// Sessão mock (usuário logado). Isolada em outra chave para poder ser
// limpa no logout sem afetar os dados de negócio.
export interface StoredSession {
  usuarioId: number;
  empresaId: number;
}

export function loadSession(): StoredSession | null {
  if (!isBrowser()) return null;
  return safeParse<StoredSession>(localStorage.getItem(SESSION_KEY));
}

export function saveSession(session: StoredSession): void {
  if (!isBrowser()) return;
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}

export function clearSession(): void {
  if (!isBrowser()) return;
  localStorage.removeItem(SESSION_KEY);
}

// Sessão mock do ADM DO SITE (plataforma). Independente da sessão de
// empresa acima — os dois podem, em tese, coexistir no mesmo navegador
// sem conflito, embora a UI (etapas 5/6) deva orientar o uso de um
// portal por vez.
export interface StoredPlatformSession {
  adminId: number;
  /** Empresa que o ADM DO SITE está "visitando" no momento, se houver. */
  empresaContextoId: number | null;
}

export function loadPlatformSession(): StoredPlatformSession | null {
  if (!isBrowser()) return null;
  return safeParse<StoredPlatformSession>(localStorage.getItem(PLATFORM_SESSION_KEY));
}

export function savePlatformSession(session: StoredPlatformSession): void {
  if (!isBrowser()) return;
  localStorage.setItem(PLATFORM_SESSION_KEY, JSON.stringify(session));
}

export function clearPlatformSession(): void {
  if (!isBrowser()) return;
  localStorage.removeItem(PLATFORM_SESSION_KEY);
}
