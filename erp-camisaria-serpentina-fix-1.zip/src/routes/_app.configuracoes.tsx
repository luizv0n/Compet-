import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/configuracoes/page";

export const Route = createFileRoute("/_app/configuracoes")({
  head: () => ({
    meta: [
      { title: "Configurações — Camisaria ERP" },
      { name: "description", content: "Configurações da empresa." },
      { property: "og:title", content: "Configurações — Camisaria ERP" },
      { property: "og:description", content: "Configurações da empresa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
