import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/estoque/entradas/page";

export const Route = createFileRoute("/_app/estoque/entradas")({
  head: () => ({
    meta: [
      { title: "Entradas — Camisaria ERP" },
      { name: "description", content: "Entrada direta de produto acabado em estoque." },
      { property: "og:title", content: "Entradas — Camisaria ERP" },
      { property: "og:description", content: "Entrada direta de produto acabado em estoque." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
