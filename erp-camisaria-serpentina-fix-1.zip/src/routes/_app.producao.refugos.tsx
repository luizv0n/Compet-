import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/producao/refugos/page";

export const Route = createFileRoute("/_app/producao/refugos")({
  head: () => ({
    meta: [
      { title: "Refugos — Camisaria ERP" },
      { name: "description", content: "Peças defeituosas e motivos de perda." },
      { property: "og:title", content: "Refugos — Camisaria ERP" },
      { property: "og:description", content: "Peças defeituosas e motivos de perda." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
