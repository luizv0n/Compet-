import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/site/empresas-page";

export const Route = createFileRoute("/_siteApp/site/empresas")({
  head: () => ({
    meta: [{ title: "Empresas — Camisaria ERP" }],
  }),
  component: Page,
});
