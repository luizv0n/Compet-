import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/auditoria/page";

export const Route = createFileRoute("/_app/auditoria")({
  head: () => ({
    meta: [
      { title: "Auditoria — Camisaria ERP" },
      { name: "description", content: "Histórico cronológico das ações realizadas no ERP." },
      { property: "og:title", content: "Auditoria — Camisaria ERP" },
      { property: "og:description", content: "Histórico cronológico das ações realizadas no ERP." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
