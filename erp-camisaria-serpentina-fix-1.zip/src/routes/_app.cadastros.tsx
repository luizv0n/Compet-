import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/cadastros/page";

export const Route = createFileRoute("/_app/cadastros")({
  head: () => ({
    meta: [
      { title: "Cadastros — Camisaria ERP" },
      { name: "description", content: "Cores, tamanhos, coleções, categorias, unidades e setores." },
      { property: "og:title", content: "Cadastros — Camisaria ERP" },
      { property: "og:description", content: "Cores, tamanhos, coleções, categorias, unidades e setores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
