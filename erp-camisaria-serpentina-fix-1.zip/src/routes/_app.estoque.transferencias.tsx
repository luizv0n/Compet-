import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/estoque/transferencias/page";

export const Route = createFileRoute("/_app/estoque/transferencias")({
  head: () => ({
    meta: [
      { title: "Transferências — Camisaria ERP" },
      { name: "description", content: "Movimentação de saldo entre locais de estoque." },
      { property: "og:title", content: "Transferências — Camisaria ERP" },
      { property: "og:description", content: "Movimentação de saldo entre locais de estoque." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
