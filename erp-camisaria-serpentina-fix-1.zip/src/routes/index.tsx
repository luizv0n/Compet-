import { createFileRoute } from "@tanstack/react-router";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { useAuth } from "@/context/AuthContext";
import { LoadingState } from "@/components/common/LoadingState";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Camisaria ERP — Estoque, Compras e PCP" },
      {
        name: "description",
        content:
          "ERP multiempresa para confecção têxtil: catálogo de produtos, estoque por variação, compras e produção.",
      },
      { property: "og:title", content: "Camisaria ERP — Estoque, Compras e PCP" },
      {
        property: "og:description",
        content: "ERP multiempresa para confecção têxtil: produtos, estoque, compras e produção.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const { loading, usuario } = useAuth();
  const router = useRouter();

  React.useEffect(() => {
    if (loading) return;
    router.replace(usuario ? "/dashboard" : "/login");
  }, [loading, usuario, router]);

  return (
    <div className="flex h-dvh items-center justify-center bg-background">
      <LoadingState />
    </div>
  );
}
