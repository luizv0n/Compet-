import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/estoque/page";

export const Route = createFileRoute("/_app/estoque/")({
  head: () => ({
    meta: [
      { title: "Estoque — Camisaria ERP" },
      { name: "description", content: "Saldos por variação e local de estoque." },
      { property: "og:title", content: "Estoque — Camisaria ERP" },
      { property: "og:description", content: "Saldos por variação e local de estoque." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
