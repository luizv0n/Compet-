import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/producao/detail/page";

export const Route = createFileRoute("/_app/producao/$id")({
  head: () => ({
    meta: [
      { title: "Ordem de produção — Camisaria ERP" },
      { name: "description", content: "Detalhe da OP, etapas e movimentações." },
      { property: "og:title", content: "Ordem de produção — Camisaria ERP" },
      { property: "og:description", content: "Detalhe da OP, etapas e movimentações." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
