import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/site/auditoria-page";

export const Route = createFileRoute("/_siteApp/site/auditoria")({
  head: () => ({
    meta: [{ title: "Auditoria Global — Camisaria ERP" }],
  }),
  component: Page,
});
