import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/estoque/kardex/page";

export const Route = createFileRoute("/_app/estoque/kardex")({
  head: () => ({
    meta: [
      { title: "Kardex — Camisaria ERP" },
      { name: "description", content: "Razão imutável de movimentações de estoque." },
      { property: "og:title", content: "Kardex — Camisaria ERP" },
      { property: "og:description", content: "Razão imutável de movimentações de estoque." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
