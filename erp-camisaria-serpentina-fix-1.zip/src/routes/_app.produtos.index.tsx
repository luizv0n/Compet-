import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/produtos/page";

export const Route = createFileRoute("/_app/produtos/")({
  head: () => ({
    meta: [
      { title: "Produtos — Camisaria ERP" },
      { name: "description", content: "Catálogo de produtos, variações e preços." },
      { property: "og:title", content: "Produtos — Camisaria ERP" },
      { property: "og:description", content: "Catálogo de produtos, variações e preços." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
