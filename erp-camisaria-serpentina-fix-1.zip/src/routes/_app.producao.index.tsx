import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/producao/page";

export const Route = createFileRoute("/_app/producao/")({
  head: () => ({
    meta: [
      { title: "Produção — Camisaria ERP" },
      { name: "description", content: "Ordens de produção e acompanhamento de PCP." },
      { property: "og:title", content: "Produção — Camisaria ERP" },
      { property: "og:description", content: "Ordens de produção e acompanhamento de PCP." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
