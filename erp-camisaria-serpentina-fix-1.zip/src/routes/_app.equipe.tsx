import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/equipe/page";

export const Route = createFileRoute("/_app/equipe")({
  head: () => ({
    meta: [
      { title: "Equipe — Camisaria ERP" },
      { name: "description", content: "Gestão de usuários e cargos da empresa." },
      { property: "og:title", content: "Equipe — Camisaria ERP" },
      { property: "og:description", content: "Gestão de usuários e cargos da empresa." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
