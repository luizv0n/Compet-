import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/login-page";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar — Camisaria ERP" },
      { name: "description", content: "Acesse o Camisaria ERP com empresa, usuário e senha." },
      { property: "og:title", content: "Entrar — Camisaria ERP" },
      { property: "og:description", content: "Acesse o Camisaria ERP com empresa, usuário e senha." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
