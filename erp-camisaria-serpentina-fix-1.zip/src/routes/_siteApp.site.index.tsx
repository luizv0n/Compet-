import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/site/dashboard-page";

export const Route = createFileRoute("/_siteApp/site/")({
  head: () => ({
    meta: [{ title: "Painel da Plataforma — Camisaria ERP" }],
  }),
  component: Page,
});
