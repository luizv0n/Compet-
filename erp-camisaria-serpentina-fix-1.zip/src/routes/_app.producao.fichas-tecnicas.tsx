import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/producao/fichas-tecnicas/page";

export const Route = createFileRoute("/_app/producao/fichas-tecnicas")({
  head: () => ({
    meta: [
      { title: "Fichas técnicas — Camisaria ERP" },
      { name: "description", content: "Componentes consumidos por variação." },
      { property: "og:title", content: "Fichas técnicas — Camisaria ERP" },
      { property: "og:description", content: "Componentes consumidos por variação." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
