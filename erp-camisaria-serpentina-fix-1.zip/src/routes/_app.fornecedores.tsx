import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/fornecedores/page";

export const Route = createFileRoute("/_app/fornecedores")({
  head: () => ({
    meta: [
      { title: "Fornecedores — Camisaria ERP" },
      { name: "description", content: "Cadastro e manutenção de fornecedores." },
      { property: "og:title", content: "Fornecedores — Camisaria ERP" },
      { property: "og:description", content: "Cadastro e manutenção de fornecedores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
