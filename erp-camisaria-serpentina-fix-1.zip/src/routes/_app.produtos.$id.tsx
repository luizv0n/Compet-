import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/produtos/detail/page";

export const Route = createFileRoute("/_app/produtos/$id")({
  head: () => ({
    meta: [
      { title: "Produto — Camisaria ERP" },
      { name: "description", content: "Detalhe do produto, variações, preços e ficha técnica." },
      { property: "og:title", content: "Produto — Camisaria ERP" },
      { property: "og:description", content: "Detalhe do produto, variações, preços e ficha técnica." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
