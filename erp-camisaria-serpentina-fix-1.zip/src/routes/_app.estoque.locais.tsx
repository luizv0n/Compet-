import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/estoque/locais/page";

export const Route = createFileRoute("/_app/estoque/locais")({
  head: () => ({
    meta: [
      { title: "Locais de estoque — Camisaria ERP" },
      { name: "description", content: "Cadastro de fábricas, lojas e depósitos." },
      { property: "og:title", content: "Locais de estoque — Camisaria ERP" },
      { property: "og:description", content: "Cadastro de fábricas, lojas e depósitos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
