import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/site/login-page";

export const Route = createFileRoute("/site/login")({
  head: () => ({
    meta: [
      { title: "Portal da Plataforma — Camisaria ERP" },
      { name: "description", content: "Acesso do ADM DO SITE à administração global do Camisaria ERP." },
      { property: "og:title", content: "Portal da Plataforma — Camisaria ERP" },
      { property: "og:description", content: "Acesso do ADM DO SITE à administração global do Camisaria ERP." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
