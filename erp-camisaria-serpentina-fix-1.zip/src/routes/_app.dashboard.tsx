import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/dashboard/page";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — Camisaria ERP" },
      { name: "description", content: "Indicadores de estoque, produção e movimentações da confecção." },
      { property: "og:title", content: "Dashboard — Camisaria ERP" },
      { property: "og:description", content: "Indicadores de estoque, produção e movimentações da confecção." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
