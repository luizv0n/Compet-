import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/producao/fluxos/page";

export const Route = createFileRoute("/_app/producao/fluxos")({
  head: () => ({
    meta: [
      { title: "Fluxos e setores — Camisaria ERP" },
      { name: "description", content: "Fluxos de produção e setores internos ou terceirizados." },
      { property: "og:title", content: "Fluxos e setores — Camisaria ERP" },
      { property: "og:description", content: "Fluxos de produção e setores internos ou terceirizados." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
