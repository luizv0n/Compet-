import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/site/nova-empresa-page";

export const Route = createFileRoute("/_siteApp/site/nova-empresa")({
  head: () => ({
    meta: [{ title: "Nova Empresa — Camisaria ERP" }],
  }),
  component: Page,
});
