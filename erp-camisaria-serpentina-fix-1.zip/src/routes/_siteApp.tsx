import { createFileRoute, Outlet } from "@tanstack/react-router";
import { PlatformShell } from "@/components/layout/PlatformShell";

export const Route = createFileRoute("/_siteApp")({
  component: SiteAppLayout,
});

function SiteAppLayout() {
  return (
    <PlatformShell>
      <Outlet />
    </PlatformShell>
  );
}
