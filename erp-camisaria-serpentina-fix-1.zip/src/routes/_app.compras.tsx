import { createFileRoute } from "@tanstack/react-router";
import Page from "@/pages/compras/page";

export const Route = createFileRoute("/_app/compras")({
  head: () => ({
    meta: [
      { title: "Compras — Camisaria ERP" },
      { name: "description", content: "Notas fiscais de entrada de matéria-prima e aviamentos." },
      { property: "og:title", content: "Compras — Camisaria ERP" },
      { property: "og:description", content: "Notas fiscais de entrada de matéria-prima e aviamentos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Page,
});
