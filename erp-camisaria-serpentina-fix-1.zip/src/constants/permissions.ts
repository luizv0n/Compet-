// =====================================================================
// Catálogo de permissões — espelha a tabela `permissao`, com nomes
// estáveis usados pela camada de RBAC do frontend (cargo -> cargo_permissao
// -> permissao). ADMINISTRADOR recebe todas; FUNCIONARIO recebe o
// subconjunto operacional listado no prompt (produção, compras, estoque,
// transferências, consultas, Kardex).
// =====================================================================

export const PERMISSIONS = {
  DASHBOARD_VIEW: "dashboard.visualizar",

  PRODUCTS_VIEW: "produtos.visualizar",
  PRODUCTS_MANAGE: "produtos.gerenciar",

  SUPPORT_TABLES_VIEW: "cadastros.visualizar",
  SUPPORT_TABLES_MANAGE: "cadastros.gerenciar",

  SUPPLIERS_VIEW: "fornecedores.visualizar",
  SUPPLIERS_MANAGE: "fornecedores.gerenciar",

  INVENTORY_VIEW: "estoque.visualizar",
  INVENTORY_MANAGE: "estoque.gerenciar",
  STOCK_LOCATIONS_MANAGE: "estoque.locais.gerenciar",
  TRANSFERS_MANAGE: "transferencias.gerenciar",
  KARDEX_VIEW: "kardex.visualizar",

  PURCHASES_VIEW: "compras.visualizar",
  PURCHASES_MANAGE: "compras.gerenciar",

  PRODUCTION_VIEW: "producao.visualizar",
  PRODUCTION_MANAGE: "producao.gerenciar",
  BOM_MANAGE: "fichatecnica.gerenciar",
  FLOWS_MANAGE: "fluxos.gerenciar",
  SECTORS_MANAGE: "setores.gerenciar",
  DEFECTS_VIEW: "refugos.visualizar",
  DEFECTS_MANAGE: "refugos.gerenciar",

  TEAM_MANAGE: "equipe.gerenciar",
  AUDIT_VIEW: "auditoria.visualizar",

  // Configurações da empresa (Etapa 15) — nenhuma permissão existente
  // cobre "alterar configurações administrativas da empresa" (as mais
  // próximas, TEAM_MANAGE e STOCK_LOCATIONS_MANAGE, são específicas de
  // outros cadastros), então esta é a menor permissão nova necessária,
  // seguindo exatamente o padrão de nome já usado acima.
  SETTINGS_MANAGE: "configuracoes.gerenciar",
} as const;

export type PermissionKey = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

export const ALL_PERMISSIONS: PermissionKey[] = Object.values(PERMISSIONS);

export const ROLE_NAMES = {
  ADMIN: "ADMINISTRADOR",
  FUNCIONARIO: "FUNCIONARIO",
} as const;

// =====================================================================
// Agrupamento por módulo — usado somente pela tela "Cargos e
// permissões" (Equipe) para exibir o catálogo acima de forma legível.
// Não é uma segunda fonte de verdade: cada entrada aponta para uma
// chave já existente em PERMISSIONS. Os módulos seguem exatamente os
// grupos já usados em constants/navigation.tsx.
// =====================================================================
export interface PermissionModule {
  module: string;
  label: string;
  items: { key: PermissionKey; label: string }[];
}

export const PERMISSION_MODULES: PermissionModule[] = [
  { module: "dashboard", label: "Dashboard", items: [{ key: PERMISSIONS.DASHBOARD_VIEW, label: "Visualizar" }] },
  {
    module: "produtos",
    label: "Produtos",
    items: [
      { key: PERMISSIONS.PRODUCTS_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.PRODUCTS_MANAGE, label: "Gerenciar" },
    ],
  },
  {
    module: "cadastros",
    label: "Cadastros",
    items: [
      { key: PERMISSIONS.SUPPORT_TABLES_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.SUPPORT_TABLES_MANAGE, label: "Gerenciar" },
    ],
  },
  {
    module: "fornecedores",
    label: "Fornecedores",
    items: [
      { key: PERMISSIONS.SUPPLIERS_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.SUPPLIERS_MANAGE, label: "Gerenciar" },
    ],
  },
  {
    module: "estoque",
    label: "Estoque",
    items: [
      { key: PERMISSIONS.INVENTORY_VIEW, label: "Visualizar saldos" },
      { key: PERMISSIONS.INVENTORY_MANAGE, label: "Gerenciar (entradas/baixas)" },
      { key: PERMISSIONS.STOCK_LOCATIONS_MANAGE, label: "Gerenciar locais" },
      { key: PERMISSIONS.TRANSFERS_MANAGE, label: "Transferências" },
      { key: PERMISSIONS.KARDEX_VIEW, label: "Visualizar Kardex" },
    ],
  },
  {
    module: "compras",
    label: "Compras",
    items: [
      { key: PERMISSIONS.PURCHASES_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.PURCHASES_MANAGE, label: "Gerenciar" },
    ],
  },
  {
    module: "producao",
    label: "Produção",
    items: [
      { key: PERMISSIONS.PRODUCTION_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.PRODUCTION_MANAGE, label: "Gerenciar" },
      { key: PERMISSIONS.BOM_MANAGE, label: "Fichas técnicas" },
      { key: PERMISSIONS.FLOWS_MANAGE, label: "Fluxos" },
      { key: PERMISSIONS.SECTORS_MANAGE, label: "Setores" },
    ],
  },
  {
    module: "refugos",
    label: "Refugos",
    items: [
      { key: PERMISSIONS.DEFECTS_VIEW, label: "Visualizar" },
      { key: PERMISSIONS.DEFECTS_MANAGE, label: "Gerenciar" },
    ],
  },
  { module: "equipe", label: "Equipe", items: [{ key: PERMISSIONS.TEAM_MANAGE, label: "Gerenciar" }] },
  { module: "auditoria", label: "Auditoria", items: [{ key: PERMISSIONS.AUDIT_VIEW, label: "Visualizar" }] },
  { module: "configuracoes", label: "Configurações", items: [{ key: PERMISSIONS.SETTINGS_MANAGE, label: "Gerenciar" }] },
];

/**
 * Pares "gerenciar depende de visualizar" — usados apenas pela UI de
 * cargos para manter a seleção coerente (marcar Gerenciar marca
 * Visualizar junto; desmarcar Visualizar desmarca Gerenciar). Não é
 * uma regra nova de autorização: cada tela já é protegida pela
 * permissão de visualização correspondente (ver RequirePermission nas
 * páginas), então gerenciar sem visualizar já era inacessível na
 * prática — isto só evita salvar essa combinação incoerente.
 */
export const MANAGE_REQUIRES_VIEW: Partial<Record<PermissionKey, PermissionKey>> = {
  [PERMISSIONS.PRODUCTS_MANAGE]: PERMISSIONS.PRODUCTS_VIEW,
  [PERMISSIONS.SUPPORT_TABLES_MANAGE]: PERMISSIONS.SUPPORT_TABLES_VIEW,
  [PERMISSIONS.SUPPLIERS_MANAGE]: PERMISSIONS.SUPPLIERS_VIEW,
  [PERMISSIONS.INVENTORY_MANAGE]: PERMISSIONS.INVENTORY_VIEW,
  [PERMISSIONS.PURCHASES_MANAGE]: PERMISSIONS.PURCHASES_VIEW,
  [PERMISSIONS.PRODUCTION_MANAGE]: PERMISSIONS.PRODUCTION_VIEW,
  [PERMISSIONS.DEFECTS_MANAGE]: PERMISSIONS.DEFECTS_VIEW,
};

/** Permissões padrão do cargo FUNCIONARIO no seed. */
export const FUNCIONARIO_PERMISSIONS: PermissionKey[] = [
  PERMISSIONS.DASHBOARD_VIEW,
  PERMISSIONS.PRODUCTS_VIEW,
  PERMISSIONS.SUPPORT_TABLES_VIEW,
  PERMISSIONS.SUPPLIERS_VIEW,
  PERMISSIONS.INVENTORY_VIEW,
  PERMISSIONS.INVENTORY_MANAGE,
  PERMISSIONS.TRANSFERS_MANAGE,
  PERMISSIONS.KARDEX_VIEW,
  PERMISSIONS.PURCHASES_VIEW,
  PERMISSIONS.PURCHASES_MANAGE,
  PERMISSIONS.PRODUCTION_VIEW,
  PERMISSIONS.PRODUCTION_MANAGE,
  PERMISSIONS.BOM_MANAGE,
  PERMISSIONS.FLOWS_MANAGE,
  PERMISSIONS.SECTORS_MANAGE,
  PERMISSIONS.DEFECTS_VIEW,
  PERMISSIONS.DEFECTS_MANAGE,
];
