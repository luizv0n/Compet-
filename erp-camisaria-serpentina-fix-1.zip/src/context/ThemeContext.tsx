"use client";
// =====================================================================
// ThemeContext.tsx — Etapa 16 (Design System, seção 40 do prompt
// mestre: "DARK MODE — Obrigatório: Light Mode; Dark Mode.").
//
// AUDITORIA (antes de implementar): src/styles.css só definia tokens
// para `:root` (claro). Não havia bloco `.dark`, nem ThemeProvider,
// nem toggle, nem nenhuma referência a "dark"/"theme" em todo o
// projeto (busca "dark:"/"ThemeProvider"/"useTheme" — zero
// resultados). Ou seja: dark mode não existia, apesar de obrigatório.
// Esta etapa implementa o que faltava, sem tocar em nenhuma regra de
// negócio nem em rotas.
//
// Padrão de persistência: mesma técnica já usada pelo projeto para
// sessão/DB mock (src/services/storage.ts) — uma chave dedicada no
// localStorage do NAVEGADOR (não é armazenamento de artifact de chat;
// é a persistência real da aplicação, como o próprio README já
// documenta para o resto do estado).
// =====================================================================
import * as React from "react";

export type Theme = "light" | "dark";

const THEME_STORAGE_KEY = "camisaria_erp_theme_v1";

interface ThemeContextValue {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

const ThemeContext = React.createContext<ThemeContextValue | null>(null);

function isBrowser(): boolean {
  return typeof window !== "undefined";
}

function applyThemeClass(theme: Theme) {
  if (!isBrowser()) return;
  document.documentElement.classList.toggle("dark", theme === "dark");
}

function readInitialTheme(): Theme {
  if (!isBrowser()) return "light";
  const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
  if (stored === "light" || stored === "dark") return stored;
  // Sem preferência salva: respeita o tema do sistema operacional na
  // primeira visita (comportamento padrão esperado em ERPs modernos).
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = React.useState<Theme>(() => readInitialTheme());

  // A classe já é aplicada de forma síncrona pelo script inline em
  // __root.tsx (evita flash de tema errado no primeiro paint). Este
  // efeito mantém a classe sincronizada em trocas subsequentes.
  React.useEffect(() => {
    applyThemeClass(theme);
  }, [theme]);

  const setTheme = React.useCallback((next: Theme) => {
    setThemeState(next);
    if (isBrowser()) window.localStorage.setItem(THEME_STORAGE_KEY, next);
  }, []);

  const toggleTheme = React.useCallback(() => {
    setTheme(theme === "dark" ? "light" : "dark");
  }, [theme, setTheme]);

  const value = React.useMemo(() => ({ theme, setTheme, toggleTheme }), [theme, setTheme, toggleTheme]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme(): ThemeContextValue {
  const ctx = React.useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme deve ser usado dentro de ThemeProvider");
  return ctx;
}

/**
 * Script inline para colar em <head>, ANTES da hidratação — decide a
 * classe "dark" no <html> de forma síncrona (mesma técnica usada por
 * bibliotecas como next-themes) para não haver flash de tema claro
 * antes do React montar. Mantido como string simples porque roda fora
 * do bundle React (injetado via <script dangerouslySetInnerHTML>).
 */
export const THEME_INIT_SCRIPT = `
(function () {
  try {
    var stored = window.localStorage.getItem("${THEME_STORAGE_KEY}");
    var dark = stored ? stored === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
    if (dark) document.documentElement.classList.add("dark");
  } catch (e) {}
})();
`;
