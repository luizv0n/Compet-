"use client";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { apiClient } from "@/services/apiClient";
import { loadSession, saveSession, clearSession } from "@/services/storage";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import type { Empresa, ID, Usuario } from "@/types";
import { ALL_PERMISSIONS, type PermissionKey } from "@/constants/permissions";

interface AuthState {
  loading: boolean;
  usuario: Usuario | null;
  empresa: Empresa | null;
  cargoNome: string | null;
  cargoIsAdmin: boolean;
  permissoes: string[];
  /** true quando não há usuário de empresa logado e o acesso vem do ADM DO
   *  SITE navegando no contexto desta empresa (Etapa 26). */
  viaPlataforma: boolean;
}

interface AuthContextValue extends AuthState {
  login: (empresaId: ID, login: string, senha: string) => Promise<void>;
  logout: () => void;
  hasPermission: (perm: PermissionKey) => boolean;
  isAdmin: boolean;
  actor: { id: ID; nome: string } | null;
  /** Troca o usuário logado sem senha, mantendo a mesma empresa — atalho para alternar entre perfis durante testes. */
  switchUser: (usuarioId: ID) => Promise<void>;
}

const AuthContext = React.createContext<AuthContextValue | null>(null);

const EMPTY_SESSION_STATE: AuthState = {
  loading: false,
  usuario: null,
  empresa: null,
  cargoNome: null,
  cargoIsAdmin: false,
  permissoes: [],
  viaPlataforma: false,
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = React.useState<AuthState>({ ...EMPTY_SESSION_STATE, loading: true });
  const router = useRouter();
  // Sessão do ADM DO SITE (Etapa 26) — usada aqui só para descobrir se ele
  // está "visitando" uma empresa (empresaContextoId) quando não há usuário
  // de empresa logado. Não cria uma segunda sessão: quando não há
  // empresaContextoId, este bloco não interfere em nada do fluxo abaixo.
  const platform = usePlatformAuth();

  const hydrate = React.useCallback(async () => {
    const stored = loadSession();
    if (stored) {
      const ctx = await apiClient.auth.sessionContext(stored.usuarioId, stored.empresaId);
      if (!ctx || !ctx.usuario.ativo) {
        clearSession();
        setState({ ...EMPTY_SESSION_STATE });
        return;
      }
      setState({
        loading: false,
        usuario: ctx.usuario,
        empresa: ctx.empresa ?? null,
        cargoNome: ctx.cargo?.nome ?? null,
        cargoIsAdmin: ctx.cargo?.isAdmin ?? false,
        permissoes: ctx.permissoes,
        viaPlataforma: false,
      });
      return;
    }

    // Não há usuário de empresa logado. Se o ADM DO SITE estiver com uma
    // empresa selecionada como contexto, ele navega nos módulos dela usando
    // esta mesma sessão de Auth — sem senha, sem Usuario novo, só emprestando
    // a identidade do admin de plataforma para as ações (auditoria etc.).
    if (platform.loading) return; // aguarda a sessão de plataforma resolver antes de decidir
    if (platform.admin && platform.empresaContextoId) {
      const empresa = await apiClient.plataforma.getEmpresa(platform.empresaContextoId);
      if (empresa && empresa.ativo) {
        setState({
          loading: false,
          usuario: null,
          empresa,
          cargoNome: "ADM DO SITE",
          cargoIsAdmin: true,
          permissoes: ALL_PERMISSIONS,
          viaPlataforma: true,
        });
        return;
      }
      // Etapa 35 (achado) / Etapa 38: a empresa em contexto deixou de existir
      // ou foi inativada — possivelmente por outra aba/sessão do ADM DO SITE,
      // já que a Etapa 28 só cobre a inativação feita a partir desta mesma
      // tela. Encerra o contexto obsoleto aqui também, para que o ADM DO
      // SITE nunca fique "preso" navegando (ou tentando navegar) numa
      // empresa que não está mais disponível, em nenhuma aba.
      platform.setEmpresaContexto(null);
    }
    setState({ ...EMPTY_SESSION_STATE });
  }, [platform.loading, platform.admin, platform.empresaContextoId, platform.setEmpresaContexto]);

  React.useEffect(() => {
    hydrate();
  }, [hydrate]);

  const login = React.useCallback(async (empresaId: ID, login: string, senha: string) => {
    const usuario = await apiClient.auth.login(empresaId, login, senha);
    saveSession({ usuarioId: usuario.id, empresaId });
    await hydrate();
  }, [hydrate]);

  const switchUser = React.useCallback(async (usuarioId: ID) => {
    if (!state.empresa) return;
    saveSession({ usuarioId, empresaId: state.empresa.id });
    await hydrate();
  }, [state.empresa, hydrate]);

  const logout = React.useCallback(() => {
    clearSession();
    if (state.viaPlataforma) {
      // Estava navegando nos módulos da empresa como ADM DO SITE: sair
      // significa voltar ao painel global de plataforma, não ao /login da
      // empresa (que exigiria um Usuario que ele não tem).
      platform.setEmpresaContexto(null);
      setState({ ...EMPTY_SESSION_STATE });
      router.push("/site");
      return;
    }
    setState({ ...EMPTY_SESSION_STATE });
    router.push("/login");
  }, [router, state.viaPlataforma, platform]);

  const hasPermission = React.useCallback(
    (perm: PermissionKey) => state.permissoes.includes(perm),
    [state.permissoes],
  );

  const value: AuthContextValue = {
    ...state,
    login,
    logout,
    hasPermission,
    isAdmin: state.cargoIsAdmin,
    actor: state.usuario
      ? { id: state.usuario.id, nome: state.usuario.nome }
      : state.viaPlataforma && platform.admin
        ? { id: platform.admin.id, nome: `${platform.admin.nome} (ADM DO SITE)` }
        : null,
    switchUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = React.useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}
