"use client";
import * as React from "react";
import { CheckCircle2, XCircle, Info, X } from "lucide-react";
import { cn } from "@/lib/utils";

export type ToastVariant = "success" | "error" | "info";

interface ToastItem {
  id: number;
  title: string;
  description?: string;
  variant: ToastVariant;
}

export interface ToastInput {
  title: string;
  description?: string;
  variant?: ToastVariant;
}

interface ToastContextValue {
  toast: (item: ToastInput) => void;
}

const ToastContext = React.createContext<ToastContextValue | null>(null);

let idCounter = 1;

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = React.useState<ToastItem[]>([]);

  const toast = React.useCallback((item: ToastInput) => {
    const id = idCounter++;
    setItems((prev) => [...prev, { variant: "info", ...item, id }]);
    setTimeout(() => {
      setItems((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const dismiss = (id: number) => setItems((prev) => prev.filter((t) => t.id !== id));

  return (
    <ToastContext.Provider value={{ toast }}>
      {children}
      <div className="pointer-events-none fixed bottom-4 right-4 z-[100] flex w-full max-w-sm flex-col gap-2">
        {items.map((item) => (
          <div
            key={item.id}
            className={cn(
              "pointer-events-auto flex items-start gap-3 rounded-lg border bg-card p-3.5 shadow-lg animate-in slide-in-from-bottom-2 fade-in-0",
              item.variant === "success" && "border-success/30",
              item.variant === "error" && "border-destructive/30",
              item.variant === "info" && "border-border",
            )}
          >
            {item.variant === "success" && <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-success" />}
            {item.variant === "error" && <XCircle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />}
            {item.variant === "info" && <Info className="mt-0.5 h-4 w-4 shrink-0 text-primary" />}
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{item.title}</p>
              {item.description && <p className="mt-0.5 text-xs text-muted-foreground">{item.description}</p>}
            </div>
            <button onClick={() => dismiss(item.id)} className="text-muted-foreground hover:text-foreground">
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = React.useContext(ToastContext);
  if (!ctx) throw new Error("useToast deve ser usado dentro de ToastProvider");
  return ctx;
}
