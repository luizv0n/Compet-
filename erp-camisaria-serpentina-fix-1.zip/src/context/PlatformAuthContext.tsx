"use client";
// =====================================================================
// PlatformAuthContext.tsx — sessão mock do ADM DO SITE (plataforma).
//
// Por que um contexto separado de AuthContext, e não uma extensão dele:
// AuthContext (e a sessão que ele carrega, `Sessao`) é modelado em cima
// de `Usuario`, que SEMPRE pertence a uma empresa (`empresaId`
// obrigatório — ver a nota de limitação de banco em types/index.ts).
// O ADM DO SITE não tem esse vínculo por definição (seção 11.1 do
// prompt mestre: "acessar qualquer empresa"), então forçá-lo dentro de
// AuthContext exigiria tornar `empresaId` opcional em todo o contexto
// hoje usado pelas telas de empresa — um risco desnecessário para os
// módulos que já funcionam. Os dois contextos coexistem, cada um lendo
// sua própria chave de sessão (ver services/storage.ts), e nenhuma tela
// hoje precisa dos dois ao mesmo tempo.
// =====================================================================
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { apiClient } from "@/services/apiClient";
import {
  loadPlatformSession,
  savePlatformSession,
  clearPlatformSession,
} from "@/services/storage";
import type { AdminPlataforma, ID } from "@/types";

interface PlatformAuthState {
  loading: boolean;
  admin: AdminPlataforma | null;
  /** Empresa que o ADM DO SITE está "visitando" no momento (seção 16 do prompt mestre). */
  empresaContextoId: ID | null;
}

interface PlatformAuthContextValue extends PlatformAuthState {
  login: (login: string, senha: string) => Promise<void>;
  logout: () => void;
  actor: { id: ID; nome: string } | null;
  /** Entra/sai do contexto de uma empresa específica sem abrir uma segunda sessão. */
  setEmpresaContexto: (empresaId: ID | null) => void;
}

const PlatformAuthContext = React.createContext<PlatformAuthContextValue | null>(null);

export function PlatformAuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = React.useState<PlatformAuthState>({
    loading: true,
    admin: null,
    empresaContextoId: null,
  });
  const router = useRouter();

  const hydrate = React.useCallback(async () => {
    const stored = loadPlatformSession();
    if (!stored) {
      setState((s) => ({ ...s, loading: false }));
      return;
    }
    const ctx = await apiClient.plataforma.sessionContext(stored.adminId);
    if (!ctx || !ctx.admin.ativo) {
      clearPlatformSession();
      setState((s) => ({ ...s, loading: false }));
      return;
    }
    setState({
      loading: false,
      admin: ctx.admin,
      empresaContextoId: stored.empresaContextoId ?? null,
    });
  }, []);

  React.useEffect(() => {
    hydrate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = React.useCallback(
    async (login: string, senha: string) => {
      const admin = await apiClient.plataforma.login(login, senha);
      savePlatformSession({ adminId: admin.id, empresaContextoId: null });
      await hydrate();
    },
    [hydrate],
  );

  const logout = React.useCallback(() => {
    clearPlatformSession();
    setState({ loading: false, admin: null, empresaContextoId: null });
    router.push("/site/login");
  }, [router]);

  const setEmpresaContexto = React.useCallback((empresaId: ID | null) => {
    setState((s) => {
      if (!s.admin) return s;
      savePlatformSession({ adminId: s.admin.id, empresaContextoId: empresaId });
      return { ...s, empresaContextoId: empresaId };
    });
  }, []);

  const value: PlatformAuthContextValue = {
    ...state,
    login,
    logout,
    actor: state.admin ? { id: state.admin.id, nome: state.admin.nome } : null,
    setEmpresaContexto,
  };

  return <PlatformAuthContext.Provider value={value}>{children}</PlatformAuthContext.Provider>;
}

export function usePlatformAuth() {
  const ctx = React.useContext(PlatformAuthContext);
  if (!ctx) throw new Error("usePlatformAuth deve ser usado dentro de PlatformAuthProvider");
  return ctx;
}
