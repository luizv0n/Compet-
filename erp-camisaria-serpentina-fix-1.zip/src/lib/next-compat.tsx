/**
 * Camada fina de compatibilidade: expõe uma API parecida com a do Next.js
 * (Link / useRouter / usePathname / useParams) sobre o TanStack Router.
 * Mantida isolada para facilitar a futura troca por chamadas nativas.
 */
import * as React from "react";
import {
  Link as RouterLink,
  useNavigate,
  useParams as useRouterParams,
  useRouterState,
} from "@tanstack/react-router";

type AnchorProps = Omit<React.ComponentPropsWithoutRef<"a">, "href">;

export interface LinkProps extends AnchorProps {
  href: string;
  replace?: boolean;
  children?: React.ReactNode;
}

/** "/estoque/kardex?variacao=5" -> { pathname: "/estoque/kardex", search: { variacao: "5" } } */
function splitHref(href: string): { pathname: string; search?: Record<string, string> } {
  const [pathname, qs] = href.split("?");
  if (!qs) return { pathname };
  return { pathname, search: Object.fromEntries(new URLSearchParams(qs)) };
}

export function Link({ href, replace, children, ...rest }: LinkProps) {
  const { pathname, search } = splitHref(href);
  return (
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    <RouterLink to={pathname as any} search={search as any} replace={replace} {...rest}>
      {children}
    </RouterLink>
  );
}

export default Link;

export function useRouter() {
  const navigate = useNavigate();
  return React.useMemo(
    () => ({
      push: (href: string) => {
        const { pathname, search } = splitHref(href);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        void navigate({ to: pathname as any, search: search as any });
      },
      replace: (href: string) => {
        const { pathname, search } = splitHref(href);
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        void navigate({ to: pathname as any, search: search as any, replace: true });
      },
      back: () => window.history.back(),
      refresh: () => {},
      prefetch: () => {},
    }),
    [navigate],
  );
}

export function usePathname(): string {
  return useRouterState({ select: (s) => s.location.pathname });
}

export function useParams<T extends Record<string, string>>(): T {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return useRouterParams({ strict: false } as any) as T;
}

/** Espelha o `useSearchParams()` do Next.js — leitura da query string atual. */
export function useSearchParams(): URLSearchParams {
  const search = useRouterState({ select: (s) => s.location.search }) as Record<string, unknown>;
  return React.useMemo(() => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(search ?? {})) {
      if (value !== undefined && value !== null) params.set(key, String(value));
    }
    return params;
  }, [search]);
}
