// =====================================================================
// validators.ts — validação/normalização de documentos e contatos.
//
// Etapa 7 (prompt de continuação — validação real de CNPJ): aceita
// CNPJ com ou sem máscara ("12.345.678/0001-90" ou "12345678000190"),
// normaliza para os 14 dígitos puros e calcula os dígitos
// verificadores pelo algoritmo oficial, de forma que dois valores
// equivalentes (mascarado ou não) sejam sempre tratados como o mesmo
// CNPJ. Nenhuma consulta externa é feita — a validação é puramente
// matemática/local, como exige a Etapa 15 (CEP) do mesmo prompt.
// =====================================================================

/**
 * Validação de formato de e-mail (Etapa 9). Não verifica se o domínio
 * existe de fato — é uma checagem sintática (usuário@domínio.tld),
 * suficiente para barrar e-mails obviamente inválidos sem depender de
 * nenhuma consulta externa, na mesma linha da validação local de CNPJ.
 */
export function isValidEmail(value: string): boolean {
  const email = value.trim();
  if (!email) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** Remove tudo que não for dígito. Uso interno para CNPJ, CEP, telefone, etc. */
export function onlyDigits(value: string): string {
  return value.replace(/\D/g, "");
}

/**
 * Normaliza um CNPJ para seus 14 dígitos puros, independente de vir
 * mascarado ("12.345.678/0001-90") ou não ("12345678000190"). Usar
 * sempre este valor para persistir e para comparar duplicidade — é o
 * que garante que "12.345.678/0001-90" e "12345678000190" sejam
 * reconhecidos como o mesmo CNPJ.
 */
export function normalizeCnpj(value: string): string {
  return onlyDigits(value);
}

/**
 * Aplica a máscara visual de CNPJ (00.000.000/0000-00) progressivamente,
 * conforme os dígitos disponíveis — funciona tanto para digitação
 * parcial (Etapa 8) quanto para formatar um valor já completo vindo do
 * banco (que é sempre armazenado normalizado, sem máscara). Aceita
 * texto já mascarado como entrada (ex.: ao editar um valor existente)
 * porque primeiro extrai só os dígitos.
 */
export function formatCnpj(value: string): string {
  const digits = onlyDigits(value).slice(0, 14);
  let out = digits.slice(0, 2);
  if (digits.length > 2) out += "." + digits.slice(2, 5);
  if (digits.length > 5) out += "." + digits.slice(5, 8);
  if (digits.length > 8) out += "/" + digits.slice(8, 12);
  if (digits.length > 12) out += "-" + digits.slice(12, 14);
  return out;
}

/**
 * Aplica a máscara visual de CEP (00000-000) progressivamente, no mesmo
 * espírito de `formatCnpj` (Etapa 12). Aceita texto já mascarado como
 * entrada — extrai só os dígitos antes de remontar — então serve tanto
 * para digitação parcial quanto para formatar um valor completo vindo
 * do banco. A validação de formato propriamente dita (Etapa 15) e a
 * normalização para armazenamento continuam sendo feitas à parte, com
 * os dígitos puros (`onlyDigits`) — esta função é só para exibição.
 */
export function formatCep(value: string): string {
  const digits = onlyDigits(value).slice(0, 8);
  let out = digits.slice(0, 5);
  if (digits.length > 5) out += "-" + digits.slice(5, 8);
  return out;
}

/**
 * Valida o formato do CEP (Etapa 15): exatamente 8 dígitos numéricos,
 * aceitando o valor com ou sem a máscara visual (00000-000). Não
 * consulta nenhum serviço externo (ViaCEP ou qualquer API) — é
 * puramente formato, na mesma linha da validação local de CNPJ. Uma
 * sequência de dígito repetido (00000000, 11111111, ...) também não
 * corresponde a um CEP real e é rejeitada, mesmo tendo o tamanho certo.
 */
export function isValidCep(value: string): boolean {
  const digits = onlyDigits(value);
  if (digits.length !== 8) return false;
  if (/^(\d)\1{7}$/.test(digits)) return false;
  return true;
}

/**
 * Aplica a máscara visual de telefone fixo — (00) 0000-0000 — no mesmo
 * espírito de `formatCnpj`/`formatCep` (Etapa 13). Limita a 10 dígitos
 * (DDD + 8 dígitos do número), o padrão de telefone fixo brasileiro.
 * A máscara de celular (11 dígitos, Etapa 14) é uma função separada.
 * Assim como as demais, só formata a exibição; o campo continua opcional
 * e nada aqui força obrigatoriedade.
 */
export function formatTelefone(value: string): string {
  const digits = onlyDigits(value).slice(0, 10);
  if (digits.length === 0) return "";
  if (digits.length <= 2) return "(" + digits;
  const ddd = digits.slice(0, 2);
  const numero = digits.slice(2);
  let out = `(${ddd}) ${numero.slice(0, 4)}`;
  if (numero.length > 4) out += "-" + numero.slice(4, 8);
  return out;
}

/**
 * Aplica a máscara visual de celular — (00) 00000-0000 — mesmo padrão
 * de `formatTelefone` (Etapa 13), mas com 11 dígitos (DDD + 9 dígitos
 * do número, incluindo o nono dígito do celular brasileiro) em vez
 * dos 10 do telefone fixo.
 */
export function formatCelular(value: string): string {
  const digits = onlyDigits(value).slice(0, 11);
  if (digits.length === 0) return "";
  if (digits.length <= 2) return "(" + digits;
  const ddd = digits.slice(0, 2);
  const numero = digits.slice(2);
  let out = `(${ddd}) ${numero.slice(0, 5)}`;
  if (numero.length > 5) out += "-" + numero.slice(5, 9);
  return out;
}

function cnpjCheckDigit(base: string): number {
  const weights =
    base.length === 12
      ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
      : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
  let sum = 0;
  for (let i = 0; i < base.length; i++) {
    sum += parseInt(base[i], 10) * weights[i];
  }
  const rest = sum % 11;
  return rest < 2 ? 0 : 11 - rest;
}

/**
 * Valida um CNPJ pelo algoritmo oficial dos dígitos verificadores.
 * Aceita o valor mascarado ou não (normaliza antes de calcular).
 * Rejeita tamanho incorreto e sequências de dígito repetido
 * (00000000000000, 11111111111111, ...), que passariam no cálculo
 * mas nunca são CNPJs válidos emitidos.
 */
export function isValidCnpj(value: string): boolean {
  const digits = normalizeCnpj(value);
  if (digits.length !== 14) return false;
  if (/^(\d)\1{13}$/.test(digits)) return false;

  const base = digits.slice(0, 12);
  const dv1 = cnpjCheckDigit(base);
  const dv2 = cnpjCheckDigit(base + String(dv1));
  return digits === base + String(dv1) + String(dv2);
}
