import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** BRL — R$ 1.234,56 */
export function formatBRL(value: number): string {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(value ?? 0);
}

/** Número com casas decimais variáveis (para quantidades fracionadas, ex. metros). */
export function formatQty(value: number, decimals = 2): string {
  const isInt = Number.isInteger(value);
  return new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: isInt ? 0 : decimals,
    maximumFractionDigits: decimals,
  }).format(value ?? 0);
}

/** DD/MM/YYYY */
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("pt-BR", { timeZone: "America/Sao_Paulo" }).format(d);
}

/** DD/MM/YYYY HH:mm */
export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function nowISO(): string {
  return new Date().toISOString();
}

let counter = 0;
/** Gera IDs incrementais estáveis dentro da sessão do mock. */
export function nextId(seed = 1): number {
  counter += 1;
  return seed + counter;
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function slugify(text: string): string {
  return text
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export function pad(n: number, len = 4): string {
  return String(n).padStart(len, "0");
}
