"use client";
// =====================================================================
// SitePlataformaAuditoriaPage (/site/auditoria) — Auditoria Global,
// seção 20 do prompt mestre ("ADM do site: Auditoria Global").
//
// Fonte: apiClient.plataforma.auditoria.list() — a trilha separada
// (auditLogPlataforma) de ações que não pertencem a nenhuma empresa
// específica (criar/ativar/inativar empresa, editar dados cadastrais,
// login de plataforma). Ações que o ADM DO SITE eventualmente vier a
// executar DENTRO do contexto de uma empresa continuam na trilha de
// empresa (AuditLogEntry) e aparecem na tela /auditoria de cada
// empresa — esta tela não duplica isso.
// =====================================================================
import * as React from "react";
import { History } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { apiClient } from "@/services/apiClient";
import { formatDateTime } from "@/lib/utils";
import type { AuditAction, AuditLogPlataformaEntry } from "@/types";

// Subconjunto de AuditAction que a trilha de plataforma realmente usa
// (ver logAuditPlataforma em mockRepository.ts): criação/ativação/
// inativação/edição de empresa e login de plataforma.
const ACTION_LABEL: Partial<Record<AuditAction, string>> = {
  CRIACAO: "Criação",
  EDICAO: "Edição",
  ATIVACAO: "Ativação",
  INATIVACAO: "Inativação",
  LOGIN: "Login",
};

const ACTION_VARIANT: Partial<Record<AuditAction, "default" | "success" | "warning" | "destructive" | "info" | "accent">> = {
  CRIACAO: "info",
  EDICAO: "default",
  ATIVACAO: "success",
  INATIVACAO: "warning",
  LOGIN: "default",
};

export default function SitePlataformaAuditoriaPage() {
  const [loading, setLoading] = React.useState(true);
  const [entries, setEntries] = React.useState<AuditLogPlataformaEntry[]>([]);
  const [query, setQuery] = React.useState("");
  const [acaoFiltro, setAcaoFiltro] = React.useState("TODAS");

  React.useEffect(() => {
    (async () => {
      setLoading(true);
      const e = await apiClient.plataforma.auditoria.list();
      setEntries(e);
      setLoading(false);
    })();
  }, []);

  const acoesPresentes = Array.from(new Set(entries.map((e) => e.acao)));

  const filtered = entries.filter((e) => {
    if (acaoFiltro !== "TODAS" && e.acao !== acaoFiltro) return false;
    if (query && !`${e.descricao} ${e.entidade} ${e.adminNome}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, acaoFiltro]);

  if (loading) return <LoadingState label="Carregando auditoria global…" />;

  return (
    <div>
      <PageHeader title="Auditoria Global" description="Ações do ADM DO SITE que não pertencem a nenhuma empresa específica." />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar na descrição…" />
        <Select value={acaoFiltro} onValueChange={setAcaoFiltro}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODAS">Todas as ações</SelectItem>
            {acoesPresentes.map((a) => (
              <SelectItem key={a} value={a}>
                {ACTION_LABEL[a] ?? a}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={History} title="Nenhum registro de auditoria encontrado" />
      ) : (
        <>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Administrador</TableHead>
                  <TableHead>Ação</TableHead>
                  <TableHead>Entidade</TableHead>
                  <TableHead>Descrição</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{formatDateTime(e.dataHora)}</TableCell>
                    <TableCell className="text-foreground">{e.adminNome}</TableCell>
                    <TableCell>
                      <Badge variant={ACTION_VARIANT[e.acao] ?? "default"}>{ACTION_LABEL[e.acao] ?? e.acao}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{e.entidade}</TableCell>
                    <TableCell className="text-sm text-foreground">{e.descricao}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}
    </div>
  );
}
