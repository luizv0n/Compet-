"use client";
// =====================================================================
// SitePlataformDashboardPage (/site) — Dashboard do ADM DO SITE.
//
// Seção 19 do prompt mestre: empresas totais, ativas, inativas,
// usuários totais, empresas recentes, atividade recente, alertas
// administrativos. Propositalmente NÃO mistura KPIs de produção,
// estoque, OP ou vendas de uma empresa específica — isso pertence ao
// Dashboard de empresa (src/pages/dashboard/page.tsx), que continua
// intocado.
//
// Fonte dos dados: apenas apiClient.plataforma.* (listEmpresas,
// listUsuarios, auditoria.list) — nenhuma fonte nova foi inventada,
// só a leitura “global” que a seção 17 do prompt mestre já reserva
// como exceção para o ADM DO SITE.
// =====================================================================
import * as React from "react";
import { Building2, Users, UserX, PlusCircle, ArrowRight, AlertTriangle, CheckCircle2 } from "lucide-react";
import { Link } from "@/lib/next-compat";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { apiClient } from "@/services/apiClient";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LoadingState } from "@/components/common/LoadingState";
import { EmptyState } from "@/components/common/EmptyState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { formatDateTime } from "@/lib/utils";
import { ROLE_NAMES } from "@/constants/permissions";
import type { Empresa, Usuario, Cargo, AuditLogPlataformaEntry } from "@/types";

export default function SitePlataformDashboardPage() {
  const { admin } = usePlatformAuth();
  const [loading, setLoading] = React.useState(true);
  const [empresas, setEmpresas] = React.useState<Empresa[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);
  const [cargos, setCargos] = React.useState<Cargo[]>([]);
  const [auditoria, setAuditoria] = React.useState<AuditLogPlataformaEntry[]>([]);

  React.useEffect(() => {
    (async () => {
      setLoading(true);
      const [e, u, c, a] = await Promise.all([
        apiClient.plataforma.listEmpresas(true),
        apiClient.plataforma.listUsuarios(),
        apiClient.plataforma.listCargos(),
        apiClient.plataforma.auditoria.list(),
      ]);
      setEmpresas(e);
      setUsuarios(u);
      setCargos(c);
      setAuditoria(a);
      setLoading(false);
    })();
  }, []);

  if (loading) return <LoadingState label="Carregando painel da plataforma…" />;

  const empresasAtivas = empresas.filter((e) => e.ativo);
  const empresasInativas = empresas.filter((e) => !e.ativo);
  const usuariosAtivos = usuarios.filter((u) => u.ativo);

  const empresasRecentes = [...empresas]
    .sort((a, b) => new Date(b.criadoEm).getTime() - new Date(a.criadoEm).getTime())
    .slice(0, 5);

  const atividadeRecente = auditoria.slice(0, 8);

  // Empresas ativas sem nenhum administrador ativo — alerta administrativo
  // relevante (não é KPI operacional de empresa, é saúde do cadastro que
  // só o ADM DO SITE precisa enxergar).
  const empresasSemAdminAtivo = empresasAtivas.filter((empresa) => {
    const cargosDaEmpresa = cargos.filter((c) => c.empresaId === empresa.id && c.nome === ROLE_NAMES.ADMIN);
    const cargoIds = new Set(cargosDaEmpresa.map((c) => c.id));
    return !usuarios.some((u) => u.empresaId === empresa.id && u.ativo && cargoIds.has(u.cargoId));
  });

  const kpis = [
    { label: "Empresas totais", value: empresas.length, sub: `${empresasAtivas.length} ativas`, icon: Building2 },
    { label: "Empresas ativas", value: empresasAtivas.length, sub: `${empresasInativas.length} inativas`, icon: CheckCircle2 },
    { label: "Empresas inativas", value: empresasInativas.length, sub: "aguardando reativação", icon: UserX },
    { label: "Usuários totais", value: usuarios.length, sub: `${usuariosAtivos.length} ativos`, icon: Users },
  ];

  return (
    <div>
      <PageHeader
        title={`Olá, ${admin?.nome ?? "administrador"}`}
        description="Painel da Plataforma — administração global do Camisaria ERP."
        actions={
          <Button asChild size="sm">
            <Link href="/site/nova-empresa">
              <PlusCircle className="h-4 w-4" />
              Nova empresa
            </Link>
          </Button>
        }
      />

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) => (
          <Card key={kpi.label}>
            <CardContent className="flex items-start justify-between p-5">
              <div>
                <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{kpi.label}</p>
                <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground">{kpi.value}</p>
                <p className="mt-1 text-xs text-muted-foreground">{kpi.sub}</p>
              </div>
              <div className="rounded-md bg-accent/10 p-2">
                <kpi.icon className="h-4 w-4 text-accent" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {empresasSemAdminAtivo.length > 0 && (
        <Card className="mt-6 border-warning/40 bg-warning/5">
          <CardHeader className="flex-row items-center gap-2 space-y-0">
            <AlertTriangle className="h-4 w-4 text-warning" />
            <CardTitle className="text-sm">Alertas administrativos</CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ul className="flex flex-col gap-1.5 text-sm text-foreground">
              {empresasSemAdminAtivo.map((empresa) => (
                <li key={empresa.id} className="flex items-center gap-2">
                  <span className="text-warning">🟡</span>
                  <span>
                    <span className="font-medium">{empresa.nomeFantasia}</span> está ativa mas não tem nenhum
                    administrador ativo.
                  </span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle>Empresas recentes</CardTitle>
            <Link href="/site/empresas" className="flex items-center gap-1 text-xs font-medium text-accent hover:underline">
              Ver todas <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {empresasRecentes.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState icon={Building2} title="Nenhuma empresa cadastrada" />
              </div>
            ) : (
              <div className="divide-y border-t">
                {empresasRecentes.map((empresa) => (
                  <div key={empresa.id} className="flex items-center justify-between px-5 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-foreground">{empresa.nomeFantasia}</p>
                      <p className="text-xs text-muted-foreground">
                        {empresa.cidade}/{empresa.estado} · cadastrada em {formatDateTime(empresa.criadoEm)}
                      </p>
                    </div>
                    <ActiveBadge ativo={empresa.ativo} />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle>Atividade recente</CardTitle>
            <Link href="/site/auditoria" className="flex items-center gap-1 text-xs font-medium text-accent hover:underline">
              Ver auditoria completa <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {atividadeRecente.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState title="Nenhuma atividade registrada" />
              </div>
            ) : (
              <div className="divide-y border-t">
                {atividadeRecente.map((entry) => (
                  <div key={entry.id} className="flex items-center justify-between px-5 py-2.5">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-foreground">{entry.descricao}</p>
                      <p className="text-xs text-muted-foreground">
                        {entry.adminNome} · {formatDateTime(entry.dataHora)}
                      </p>
                    </div>
                    <Badge variant="default" className="shrink-0">
                      {entry.entidade}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
