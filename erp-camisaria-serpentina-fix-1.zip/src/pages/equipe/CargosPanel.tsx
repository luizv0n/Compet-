"use client";
import * as React from "react";
import { Plus, Pencil, Trash2, ShieldCheck, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSION_MODULES, MANAGE_REQUIRES_VIEW, PERMISSIONS, type PermissionKey } from "@/constants/permissions";
import type { Cargo, Permissao, Usuario } from "@/types";

type CargoComContagem = Cargo & { funcionarios: number };

const emptyForm = { nome: "", descricao: "", permissaoIds: new Set<number>() };

export function CargosPanel() {
  const { empresa, actor, hasPermission, isAdmin } = useAuth();
  const { toast } = useToast();

  const [loading, setLoading] = React.useState(true);
  const [cargos, setCargos] = React.useState<CargoComContagem[]>([]);
  const [permissoes, setPermissoes] = React.useState<Permissao[]>([]);
  const [query, setQuery] = React.useState("");

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<CargoComContagem | null>(null);
  const [membros, setMembros] = React.useState<Usuario[]>([]);
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);
  const [pendingSave, setPendingSave] = React.useState(false);
  const [confirmDelete, setConfirmDelete] = React.useState<CargoComContagem | null>(null);

  const canManage = hasPermission(PERMISSIONS.TEAM_MANAGE);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [c, p] = await Promise.all([apiClient.equipe.cargosComContagem(empresa.id), apiClient.permissoes.list(empresa.id)]);
    setCargos(c);
    setPermissoes(p);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  // Permissões concedíveis pelo usuário logado — administrador concede
  // qualquer uma; um funcionário com equipe.gerenciar só pode conceder
  // permissões que ele mesmo possui (seção 18 — evita escalada de
  // privilégio mesmo que a validação real esteja no repositório).
  const nomeParaId = React.useMemo(() => new Map(permissoes.map((p) => [p.nome, p.id])), [permissoes]);
  function canGrant(key: PermissionKey) {
    return isAdmin || hasPermission(key);
  }

  const filtered = cargos.filter((c) => c.nome.toLowerCase().includes(query.toLowerCase()));

  async function openCreate() {
    setEditing(null);
    setMembros([]);
    setForm({ ...emptyForm, permissaoIds: new Set() });
    setDialogOpen(true);
  }

  async function openEdit(item: CargoComContagem) {
    if (!empresa) return;
    setEditing(item);
    setForm({ nome: item.nome, descricao: item.descricao ?? "", permissaoIds: new Set(item.permissaoIds) });
    setDialogOpen(true);
    const detail = await apiClient.equipe.cargoDetalhe(item.id, empresa.id);
    setMembros(detail.funcionarios);
  }

  function togglePermissao(key: PermissionKey, checked: boolean) {
    const id = nomeParaId.get(key);
    if (id === undefined) return;
    setForm((f) => {
      const next = new Set(f.permissaoIds);
      const dependente = MANAGE_REQUIRES_VIEW[key];
      if (checked) {
        next.add(id);
        // Marcar "Gerenciar" também marca o "Visualizar" correspondente,
        // para nunca salvar uma combinação incoerente (seção 11).
        if (dependente) {
          const depId = nomeParaId.get(dependente);
          if (depId !== undefined) next.add(depId);
        }
      } else {
        next.delete(id);
        // Desmarcar "Visualizar" desmarca qualquer "Gerenciar" que dependa dele.
        for (const [manageKey, viewKey] of Object.entries(MANAGE_REQUIRES_VIEW)) {
          if (viewKey === key) {
            const manageId = nomeParaId.get(manageKey);
            if (manageId !== undefined) next.delete(manageId);
          }
        }
      }
      return { ...f, permissaoIds: next };
    });
  }

  function requestSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.nome.trim()) {
      toast({ title: "Informe o nome do cargo.", variant: "error" });
      return;
    }
    if (editing) {
      setPendingSave(true); // pede confirmação — afeta todos os funcionários do cargo
    } else {
      handleSave();
    }
  }

  async function handleSave() {
    if (!empresa || !actor) return;
    setSubmitting(true);
    try {
      const permissaoIds = Array.from(form.permissaoIds);
      if (editing) {
        await apiClient.equipe.updateCargo(editing.id, empresa.id, actor, {
          nome: form.nome.trim(),
          descricao: form.descricao.trim() || null,
          permissaoIds,
        });
        toast({ title: "Cargo atualizado", description: "Os funcionários deste cargo já estão usando as novas permissões.", variant: "success" });
      } else {
        await apiClient.equipe.createCargo(empresa.id, actor, {
          nome: form.nome.trim(),
          descricao: form.descricao.trim() || null,
          permissaoIds,
        });
        toast({ title: "Cargo criado", variant: "success" });
      }
      setDialogOpen(false);
      setPendingSave(false);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleDelete() {
    if (!empresa || !actor || !confirmDelete) return;
    try {
      await apiClient.equipe.toggleCargo(confirmDelete.id, empresa.id, actor);
      toast({ title: "Cargo excluído", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível excluir o cargo", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;
  if (loading) return <LoadingState />;

  return (
    <>
      <div className="mb-4 flex items-center justify-between gap-3">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar cargo…" />
        {canManage && (
          <Button size="sm" onClick={openCreate}>
            <Plus className="h-4 w-4" /> Novo cargo
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={ShieldCheck} title="Nenhum cargo encontrado" />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Cargo</TableHead>
                <TableHead>Funcionários</TableHead>
                <TableHead>Permissões</TableHead>
                {canManage && <TableHead className="text-right">Ações</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium text-foreground">
                    <div className="flex items-center gap-2">
                      {c.nome}
                      {c.isAdmin && <Badge variant="accent">Protegido</Badge>}
                    </div>
                    {c.descricao && <p className="text-xs text-muted-foreground">{c.descricao}</p>}
                  </TableCell>
                  <TableCell className="text-muted-foreground">{c.funcionarios}</TableCell>
                  <TableCell className="text-muted-foreground">{c.isAdmin ? "Todas" : c.permissaoIds.length}</TableCell>
                  {canManage && (
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button onClick={() => openEdit(c)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        {!c.isAdmin && (
                          <button
                            onClick={() => setConfirmDelete(c)}
                            className="text-muted-foreground hover:text-destructive"
                            title={c.funcionarios > 0 ? "Cargo possui funcionários vinculados" : "Excluir cargo"}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) setPendingSave(false); }}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>{editing ? `Editar cargo — ${editing.nome}` : "Novo cargo"}</DialogTitle>
            {editing && (
              <DialogDescription>
                {membros.length} funcionário{membros.length === 1 ? "" : "s"} com este cargo
              </DialogDescription>
            )}
          </DialogHeader>
          <form onSubmit={requestSubmit} className="flex flex-col gap-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="cnome">Nome do cargo</Label>
                <Input
                  id="cnome"
                  value={form.nome}
                  disabled={!!editing?.isAdmin}
                  onChange={(e) => setForm({ ...form, nome: e.target.value })}
                  autoFocus
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="cdesc">Descrição</Label>
                <Input id="cdesc" value={form.descricao} onChange={(e) => setForm({ ...form, descricao: e.target.value })} />
              </div>
            </div>

            {editing?.isAdmin ? (
              <p className="rounded-md border border-dashed bg-secondary/50 p-3 text-sm text-muted-foreground">
                Este é o cargo administrativo padrão da empresa. Ele sempre possui todas as permissões e não pode ser
                renomeado, ter permissões removidas nem ser excluído.
              </p>
            ) : (
              <div className="flex flex-col gap-4">
                <Label>Permissões</Label>
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  {PERMISSION_MODULES.map((mod) => (
                    <div key={mod.module} className="rounded-lg border p-3">
                      <p className="mb-2 text-sm font-medium text-foreground">{mod.label}</p>
                      <div className="flex flex-col gap-2">
                        {mod.items.map((item) => {
                          const checked = form.permissaoIds.has(nomeParaId.get(item.key) ?? -1);
                          const grantable = canGrant(item.key);
                          return (
                            <label
                              key={item.key}
                              className={`flex items-center gap-2 text-sm ${grantable ? "text-foreground" : "text-muted-foreground/50"}`}
                              title={grantable ? undefined : "Você não pode conceder uma permissão que não possui"}
                            >
                              <Checkbox
                                checked={checked}
                                disabled={!grantable}
                                onCheckedChange={(v) => togglePermissao(item.key, v === true)}
                              />
                              {item.label}
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {editing && membros.length > 0 && (
              <div className="flex flex-col gap-1.5">
                <Label className="flex items-center gap-1.5">
                  <Users className="h-3.5 w-3.5" /> Funcionários deste cargo
                </Label>
                <div className="flex flex-wrap gap-1.5">
                  {membros.map((m) => (
                    <Badge key={m.id} variant="outline">
                      {m.nome}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              {!editing?.isAdmin && (
                <Button type="submit" loading={submitting}>
                  {editing ? "Salvar alterações" : "Criar cargo"}
                </Button>
              )}
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={pendingSave}
        onOpenChange={setPendingSave}
        title="Salvar alterações nas permissões?"
        description={`As alterações afetarão todos os ${editing?.funcionarios ?? 0} funcionário(s) que possuem este cargo.`}
        confirmLabel="Salvar alterações"
        onConfirm={handleSave}
      />

      <ConfirmDialog
        open={!!confirmDelete}
        onOpenChange={(o) => !o && setConfirmDelete(null)}
        title={confirmDelete ? `Excluir ${confirmDelete.nome}?` : ""}
        description={
          confirmDelete && confirmDelete.funcionarios > 0
            ? "Este cargo possui funcionários vinculados. Altere o cargo desses funcionários antes de excluí-lo."
            : "Esta ação não pode ser desfeita."
        }
        confirmLabel="Excluir cargo"
        destructive
        onConfirm={handleDelete}
      />
    </>
  );
}
