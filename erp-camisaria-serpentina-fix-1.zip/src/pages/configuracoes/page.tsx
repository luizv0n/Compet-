"use client";
import * as React from "react";
import { AlertTriangle, Settings } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { LoadingState } from "@/components/common/LoadingState";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import type { ConfiguracaoEmpresa, Estoque } from "@/types";

export default function ConfiguracoesPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.SETTINGS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [config, setConfig] = React.useState<ConfiguracaoEmpresa | null>(null);
  // Estoques ativos — únicas opções que podem ser escolhidas (seção 11:
  // nunca oferecer um estoque inativo como opção).
  const [estoquesAtivos, setEstoquesAtivos] = React.useState<Estoque[]>([]);
  // Estoques da empresa incluindo inativos — usado só para conseguir
  // exibir o nome do estoque configurado caso ele tenha sido inativado
  // depois de virar o padrão (seção 11).
  const [estoquesTodos, setEstoquesTodos] = React.useState<Estoque[]>([]);
  const [estoqueId, setEstoqueId] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [c, ativos, todos] = await Promise.all([
      apiClient.configuracoes.get(empresa.id),
      apiClient.estoques.list(empresa.id),
      apiClient.estoques.list(empresa.id, true),
    ]);
    setConfig(c);
    setEstoquesAtivos(ativos);
    setEstoquesTodos(todos);
    setEstoqueId(c?.estoquePadraoEntradaMpId ? String(c.estoquePadraoEntradaMpId) : "");
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const estoqueConfigurado = config?.estoquePadraoEntradaMpId
    ? (estoquesTodos.find((e) => e.id === config.estoquePadraoEntradaMpId) ?? null)
    : null;
  // Configurado mas não está mais entre os estoques ativos da empresa
  // (foi inativado ou não pertence mais a ela) — seção 11: nunca trocar
  // silenciosamente, só sinalizar que precisa ser atualizado.
  const precisaAtualizar = !!config?.estoquePadraoEntradaMpId && (!estoqueConfigurado || !estoqueConfigurado.ativo);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!estoqueId) {
      toast({ title: "Selecione um estoque.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      await apiClient.configuracoes.setEstoquePadraoEntradaMP(empresa.id, actor, Number(estoqueId));
      toast({ title: "Configurações salvas com sucesso.", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar as configurações.", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.SETTINGS_MANAGE}>
      <PageHeader title="Configurações" description="Configurações da empresa." />

      {loading ? (
        <LoadingState />
      ) : (
        <Card className="max-w-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-4 w-4 text-muted-foreground" />
              Entrada de matéria-prima
            </CardTitle>
            <CardDescription>
              Define o estoque selecionado automaticamente para receber matérias-primas quando uma Nota de entrada for
              finalizada.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <Label>Estoque padrão</Label>
                <Select value={estoqueId} onValueChange={setEstoqueId} disabled={!canManage}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar estoque" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoquesAtivos.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {precisaAtualizar && (
                  <Badge variant="warning" className="mt-1 w-fit">
                    <AlertTriangle className="h-3 w-3" />
                    {estoqueConfigurado
                      ? `"${estoqueConfigurado.nome}" foi inativado — escolha outro estoque padrão.`
                      : "O estoque configurado não está mais disponível — escolha outro estoque padrão."}
                  </Badge>
                )}
              </div>
              {canManage && (
                <div>
                  <Button type="submit" loading={submitting}>
                    Salvar configurações
                  </Button>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      )}
    </RequirePermission>
  );
}
