"use client";
import * as React from "react";
import { Plus, Pencil, Truck } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import type { Fornecedor } from "@/types";

const emptyForm = { nome: "", cnpj: "", email: "", telefone: "" };

export default function FornecedoresPage() {
  const { empresa, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.SUPPLIERS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [items, setItems] = React.useState<Fornecedor[]>([]);
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Fornecedor | null>(null);
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    setItems(await apiClient.fornecedores.list(empresa.id, true));
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const filtered = items.filter((i) => (i.nome + " " + (i.cnpj ?? "")).toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setDialogOpen(true);
  }
  function openEdit(item: Fornecedor) {
    setEditing(item);
    setForm({ nome: item.nome, cnpj: item.cnpj ?? "", email: item.email ?? "", telefone: item.telefone ?? "" });
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !form.nome.trim()) return;
    setSubmitting(true);
    try {
      const data = {
        nome: form.nome.trim(),
        cnpj: form.cnpj.trim() || null,
        email: form.email.trim() || null,
        telefone: form.telefone.trim() || null,
      };
      if (editing) {
        await apiClient.fornecedores.update(editing.id, empresa.id, data);
        toast({ title: "Fornecedor atualizado", variant: "success" });
      } else {
        await apiClient.fornecedores.create(empresa.id, data);
        toast({ title: "Fornecedor cadastrado", variant: "success" });
      }
      setDialogOpen(false);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: Fornecedor) {
    if (!empresa) return;
    try {
      await apiClient.fornecedores.toggle(item.id, empresa.id);
      toast({ title: item.ativo ? "Fornecedor inativado" : "Fornecedor ativado", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.SUPPLIERS_VIEW}>
      <PageHeader
        title="Fornecedores"
        description="Fornecedores de matéria-prima, aviamento e facções terceirizadas."
        actions={
          canManage && (
            <Button onClick={openCreate} size="sm">
              <Plus className="h-4 w-4" /> Novo fornecedor
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar por nome ou CNPJ…" />
          </div>
          {filtered.length === 0 ? (
            <EmptyState icon={Truck} title="Nenhum fornecedor encontrado" />
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>CNPJ</TableHead>
                    <TableHead>Contato</TableHead>
                    <TableHead>Status</TableHead>
                    {canManage && <TableHead className="text-right">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">{item.cnpj || "—"}</TableCell>
                      <TableCell className="text-muted-foreground">
                        <div className="flex flex-col text-xs">
                          <span>{item.email || "—"}</span>
                          <span>{item.telefone || "—"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <ActiveBadge ativo={item.ativo} />
                      </TableCell>
                      {canManage && (
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-3">
                            <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                            <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar fornecedor" : "Novo fornecedor"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="fnome">Nome / razão social</Label>
              <Input id="fnome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="fcnpj">CNPJ</Label>
              <Input id="fcnpj" value={form.cnpj} onChange={(e) => setForm({ ...form, cnpj: e.target.value })} placeholder="Somente números" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="femail">Email</Label>
                <Input id="femail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ftel">Telefone</Label>
                <Input id="ftel" value={form.telefone} onChange={(e) => setForm({ ...form, telefone: e.target.value })} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
