"use client";
import * as React from "react";
import { Plus, Building2, Pencil, PackageSearch } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UFS } from "@/constants/uf";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatCep } from "@/lib/validators";
import { Link } from "@/lib/next-compat";
import type { Estoque, ProdutoEstoque } from "@/types";

const emptyForm = { nome: "", cep: "", logradouro: "", numero: "", complemento: "", bairro: "", cidade: "", estado: "" };

export default function LocaisEstoquePage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.STOCK_LOCATIONS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [items, setItems] = React.useState<Estoque[]>([]);
  const [saldos, setSaldos] = React.useState<ProdutoEstoque[]>([]);
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Estoque | null>(null);
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    // saldos é usado só para dar contexto ("relacionamento com estoque",
    // seção 15 do prompt mestre) — a fonte de verdade do saldo continua
    // sendo a tela /estoque, aqui é só um resumo por local.
    const [locais, saldosDaEmpresa] = await Promise.all([
      apiClient.estoques.list(empresa.id, true),
      apiClient.estoques.saldos(empresa.id),
    ]);
    setItems(locais);
    setSaldos(saldosDaEmpresa);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const filtered = items.filter((i) => i.nome.toLowerCase().includes(query.toLowerCase()));

  function saldoResumoDoLocal(estoqueId: number) {
    const doLocal = saldos.filter((s) => s.estoqueId === estoqueId);
    const total = doLocal.reduce((sum, s) => sum + s.quantidade, 0);
    const skus = doLocal.filter((s) => s.quantidade !== 0).length;
    return { total, skus };
  }

  function openCreate() {
    setEditing(null);
    setForm(emptyForm);
    setDialogOpen(true);
  }

  function openEdit(item: Estoque) {
    setEditing(item);
    setForm({
      nome: item.nome,
      cep: formatCep(item.cep ?? ""),
      logradouro: item.logradouro ?? "",
      numero: item.numero ?? "",
      complemento: item.complemento ?? "",
      bairro: item.bairro ?? "",
      cidade: item.cidade ?? "",
      estado: item.estado ?? "",
    });
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !form.nome.trim()) return;
    setSubmitting(true);
    const payload = {
      nome: form.nome.trim(),
      cep: form.cep.replace(/\D/g, "").trim() || null,
      logradouro: form.logradouro.trim() || null,
      numero: form.numero.trim() || null,
      complemento: form.complemento.trim() || null,
      bairro: form.bairro.trim() || null,
      cidade: form.cidade.trim() || null,
      estado: form.estado.trim() || null,
    };
    try {
      if (editing) {
        await apiClient.estoques.update(editing.id, empresa.id, actor, payload);
        toast({ title: "Local atualizado", variant: "success" });
      } else {
        await apiClient.estoques.create(empresa.id, actor, payload);
        toast({ title: "Estoque cadastrado", variant: "success" });
      }
      setDialogOpen(false);
      setEditing(null);
      setForm(emptyForm);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: Estoque) {
    if (!empresa || !actor) return;
    try {
      await apiClient.estoques.toggle(item.id, empresa.id, actor);
      toast({ title: item.ativo ? "Estoque inativado" : "Estoque ativado", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.STOCK_LOCATIONS_MANAGE}>
      <PageHeader
        title="Locais de estoque"
        description="Fábrica, lojas e demais locais físicos onde o saldo é controlado."
        actions={
          canManage && (
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Novo local
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar local…" />
          </div>
          {filtered.length === 0 ? (
            <EmptyState icon={Building2} title="Nenhum local cadastrado" />
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Cidade/UF</TableHead>
                    <TableHead className="text-right">Saldo físico</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((item) => {
                    const resumo = saldoResumoDoLocal(item.id);
                    return (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {item.cidade ? `${item.cidade}/${item.estado}` : "—"}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="font-semibold tabular-nums text-foreground">
                            <Qty value={resumo.total} />
                          </div>
                          <div className="text-[11px] text-muted-foreground">
                            {resumo.skus} {resumo.skus === 1 ? "SKU" : "SKUs"} com saldo
                          </div>
                        </TableCell>
                        <TableCell>
                          <ActiveBadge ativo={item.ativo} />
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex flex-wrap justify-end items-center gap-1">
                            <Button variant="ghost" size="sm" asChild>
                              <Link href={`/estoque?estoque=${item.id}`}>
                                <PackageSearch className="h-3.5 w-3.5" /> Ver no estoque
                              </Link>
                            </Button>
                            {canManage && (
                              <>
                                <Button variant="ghost" size="sm" onClick={() => openEdit(item)}>
                                  <Pencil className="h-3.5 w-3.5" /> Editar
                                </Button>
                                <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar local de estoque" : "Novo local de estoque"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="enome">Nome</Label>
              <Input id="enome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} placeholder="Ex.: Loja Sul" autoFocus />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ecep">CEP</Label>
                <Input id="ecep" maxLength={9} value={form.cep} onChange={(e) => setForm({ ...form, cep: formatCep(e.target.value) })} placeholder="00000-000" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ebairro">Bairro</Label>
                <Input id="ebairro" value={form.bairro} onChange={(e) => setForm({ ...form, bairro: e.target.value })} />
              </div>
            </div>
            <div className="grid grid-cols-[1fr_auto] gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="elogradouro">Logradouro</Label>
                <Input id="elogradouro" value={form.logradouro} onChange={(e) => setForm({ ...form, logradouro: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5 w-24">
                <Label htmlFor="enumero">Número</Label>
                <Input id="enumero" value={form.numero} onChange={(e) => setForm({ ...form, numero: e.target.value })} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="ecomplemento">Complemento</Label>
              <Input id="ecomplemento" value={form.complemento} onChange={(e) => setForm({ ...form, complemento: e.target.value })} />
            </div>
            <div className="grid grid-cols-[1fr_auto] gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ecidade">Cidade</Label>
                <Input id="ecidade" value={form.cidade} onChange={(e) => setForm({ ...form, cidade: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5 w-28">
                <Label htmlFor="eestado">UF</Label>
                <Select value={form.estado || undefined} onValueChange={(v) => setForm({ ...form, estado: v })}>
                  <SelectTrigger id="eestado">
                    <SelectValue placeholder="UF" />
                  </SelectTrigger>
                  <SelectContent>
                    {UFS.map((uf) => (
                      <SelectItem key={uf.sigla} value={uf.sigla}>
                        {uf.sigla}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
