"use client";
import * as React from "react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { LoadingState } from "@/components/common/LoadingState";
import { SearchInput } from "@/components/common/SearchInput";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { useKardexData } from "@/hooks/useKardexData";
import { useSearchParams } from "@/lib/next-compat";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { PERMISSIONS } from "@/constants/permissions";
import { KARDEX_NATUREZA_LABEL } from "@/types";
import type { KardexNatureza } from "@/types";
import { KardexTable } from "@/components/kardex/KardexTable";

export default function KardexPage() {
  const { empresa } = useAuth();
  const searchParams = useSearchParams();
  const {
    loading,
    produtos,
    variacoes,
    estoques,
    usuarios,
    kardex,
    documentoDaMovimentacao,
  } = useKardexData();

  const [query, setQuery] = React.useState("");
  // Pré-seleciona a variação (e, opcionalmente, o estoque/local) quando a
  // página é aberta via ação rápida "Kardex" de Produtos (?variacao=ID) ou
  // de Estoque (?variacao=ID&estoque=ID) — ver
  // src/pages/produtos/detail/page.tsx e src/pages/estoque/page.tsx.
  const [variacaoFiltro, setVariacaoFiltro] = React.useState(() => searchParams.get("variacao") ?? "TODAS");
  const [estoqueFiltro, setEstoqueFiltro] = React.useState(() => searchParams.get("estoque") ?? "TODOS");
  const [naturezaFiltro, setNaturezaFiltro] = React.useState("TODAS");

  const filtered = kardex.filter((k) => {
    if (variacaoFiltro !== "TODAS" && k.produtoVariacaoId !== Number(variacaoFiltro)) return false;
    if (estoqueFiltro !== "TODOS" && k.estoqueId !== Number(estoqueFiltro)) return false;
    if (naturezaFiltro !== "TODAS" && k.natureza !== naturezaFiltro) return false;
    if (query) {
      const variacao = variacoes.find((v) => v.id === k.produtoVariacaoId);
      const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
      const haystack = `${produto?.nome ?? ""} ${variacao?.sku ?? ""}`.toLowerCase();
      if (!haystack.includes(query.toLowerCase())) return false;
    }
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, variacaoFiltro, estoqueFiltro, naturezaFiltro]);

  if (!empresa) return null;
  if (loading) return <LoadingState />;

  return (
    <RequirePermission perm={PERMISSIONS.KARDEX_VIEW}>
      <PageHeader title="Kardex" description="Razão de estoque — histórico imutável de todas as movimentações." />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar por produto ou SKU…" />
        <Select value={variacaoFiltro} onValueChange={setVariacaoFiltro}>
          <SelectTrigger className="w-full sm:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODAS">Todas as variações</SelectItem>
            {variacoes.map((v) => {
              const produto = produtos.find((p) => p.id === v.produtoId);
              return (
                <SelectItem key={v.id} value={String(v.id)}>
                  {produto?.nome} — {v.sku}
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
        <Select value={estoqueFiltro} onValueChange={setEstoqueFiltro}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODOS">Todos os estoques</SelectItem>
            {estoques.map((e) => (
              <SelectItem key={e.id} value={String(e.id)}>
                {e.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={naturezaFiltro} onValueChange={setNaturezaFiltro}>
          <SelectTrigger className="w-full sm:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODAS">Todas as naturezas</SelectItem>
            {(Object.keys(KARDEX_NATUREZA_LABEL) as KardexNatureza[]).map((n) => (
              <SelectItem key={n} value={n}>
                {KARDEX_NATUREZA_LABEL[n]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <KardexTable
        entries={filtered}
        visible={visible}
        hasMore={hasMore}
        remaining={remaining}
        onShowMore={showMore}
        produtos={produtos}
        variacoes={variacoes}
        estoques={estoques}
        usuarios={usuarios}
        documentoDaMovimentacao={documentoDaMovimentacao}
      />
    </RequirePermission>
  );
}
