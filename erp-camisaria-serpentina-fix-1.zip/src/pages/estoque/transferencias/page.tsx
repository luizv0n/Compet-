"use client";
import * as React from "react";
import { ArrowLeftRight, Check, ChevronsUpDown, Plus, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { cn, formatDateTime } from "@/lib/utils";
import { useSearchParams } from "@/lib/next-compat";
import type { Produto, ProdutoVariacao, Estoque, ProdutoEstoque, Cor, Tamanho, UnidadeMedida, KardexEntry } from "@/types";

export default function TransferenciasPage() {
  const { empresa, actor } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearchParams();

  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [saldos, setSaldos] = React.useState<ProdutoEstoque[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);
  const [kardex, setKardex] = React.useState<KardexEntry[]>([]);

  const [origemId, setOrigemId] = React.useState(() => searchParams.get("estoque") ?? "");
  const [destinoId, setDestinoId] = React.useState("");
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  // Seletor progressivo do item a adicionar (Ajuste da Seleção de Produtos):
  // produto -> atributos existentes daquele produto (cor/tamanho, quando
  // houver) -> variação resolvida -> quantidade. Nada aqui é persistido até
  // o item entrar em `carrinho`.
  const [produtoPopoverOpen, setProdutoPopoverOpen] = React.useState(false);
  const [selProdutoId, setSelProdutoId] = React.useState("");
  const [selCorId, setSelCorId] = React.useState("");
  const [selTamanhoId, setSelTamanhoId] = React.useState("");
  const [selVariacaoManualId, setSelVariacaoManualId] = React.useState("");
  const [itemQuantidade, setItemQuantidade] = React.useState("");

  // Itens já adicionados à transferência em edição — cada um mantém o mesmo
  // par produtoVariacaoId/quantidade que o formulário anterior enviava numa
  // única chamada; ao confirmar, cada item é enviado com a mesma chamada de
  // sempre (ver handleSubmit).
  type CarrinhoItem = { variacaoId: number; quantidade: number };
  const [carrinho, setCarrinho] = React.useState<CarrinhoItem[]>([]);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, e, s, co, ta, un, k] = await Promise.all([
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.estoques.list(empresa.id),
      apiClient.estoques.saldos(empresa.id),
      apiClient.cores.list(empresa.id),
      apiClient.tamanhos.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.kardex.list(empresa.id),
    ]);
    setProdutos(p);
    setVariacoes(v);
    setEstoques(e);
    setSaldos(s);
    setCores(co);
    setTamanhos(ta);
    setUnidades(un);
    setKardex(k.filter((row) => row.natureza === "TRANSFERENCIA").slice(0, 20));
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  // Pré-seleciona produto/cor/tamanho e estoque de origem quando a página é
  // aberta via ação rápida "Transferir" de Estoque (?variacao=ID&estoque=ID)
  // — ver src/pages/estoque/page.tsx. Substitui o antigo pré-preenchimento
  // direto do Select único; agora resolvemos a variação e aplicamos os
  // mesmos atributos no seletor progressivo. Roda uma única vez, quando as
  // variações chegam.
  const deepLinkApplied = React.useRef(false);
  React.useEffect(() => {
    if (deepLinkApplied.current || variacoes.length === 0) return;
    const preVariacaoId = searchParams.get("variacao");
    if (preVariacaoId) {
      const v = variacoes.find((vv) => vv.id === Number(preVariacaoId));
      if (v) {
        setSelProdutoId(String(v.produtoId));
        setSelCorId(v.corId != null ? String(v.corId) : "");
        setSelTamanhoId(v.tamanhoId != null ? String(v.tamanhoId) : "");
        setSelVariacaoManualId(String(v.id));
      }
    }
    deepLinkApplied.current = true;
  }, [variacoes, searchParams]);

  // Produtos pesquisáveis no primeiro passo do seletor — apenas produtos com
  // ao menos uma variação ativa, mesmo universo que o Select único já
  // restringia (`variacoes.filter(v => v.ativo)`). O texto de busca cobre
  // nome do produto e os SKUs de suas variações.
  const produtosBuscaveis = React.useMemo(() => {
    const map = new Map<number, { produto: Produto; skus: string[] }>();
    for (const v of variacoes) {
      if (!v.ativo) continue;
      const produto = produtos.find((p) => p.id === v.produtoId);
      if (!produto) continue;
      let entry = map.get(produto.id);
      if (!entry) {
        entry = { produto, skus: [] };
        map.set(produto.id, entry);
      }
      entry.skus.push(v.sku);
    }
    return Array.from(map.values()).sort((a, b) => a.produto.nome.localeCompare(b.produto.nome));
  }, [produtos, variacoes]);

  const produtoSelecionado = produtos.find((p) => String(p.id) === selProdutoId);
  const unidadeSelecionada = produtoSelecionado ? unidades.find((u) => u.id === produtoSelecionado.unidadeMedidaId) : undefined;

  // Variações ativas do produto escolhido, e quais atributos elas de fato
  // usam — não assume Cor + Tamanho fixos (seção 12 do prompt): matéria-
  // prima e aviamento costumam ter só Cor, ou nenhum atributo (variação
  // padrão única).
  const variacoesDoProdutoSelecionado = React.useMemo(
    () => variacoes.filter((v) => v.ativo && String(v.produtoId) === selProdutoId),
    [variacoes, selProdutoId],
  );
  const temCor = variacoesDoProdutoSelecionado.some((v) => v.corId != null);
  const temTamanho = variacoesDoProdutoSelecionado.some((v) => v.tamanhoId != null);

  const coresDisponiveis = React.useMemo(() => {
    const ids = new Set(variacoesDoProdutoSelecionado.map((v) => v.corId).filter((id): id is number => id != null));
    return cores.filter((c) => ids.has(c.id));
  }, [variacoesDoProdutoSelecionado, cores]);

  const tamanhosDisponiveis = React.useMemo(() => {
    const base = temCor && selCorId ? variacoesDoProdutoSelecionado.filter((v) => v.corId === Number(selCorId)) : variacoesDoProdutoSelecionado;
    const ids = new Set(base.map((v) => v.tamanhoId).filter((id): id is number => id != null));
    return tamanhos.filter((t) => ids.has(t.id));
  }, [variacoesDoProdutoSelecionado, temCor, selCorId, tamanhos]);

  // Resolve a variação exata a partir dos atributos escolhidos. Quando o
  // produto não usa Cor nem Tamanho e tem mais de uma variação ativa (caso
  // raro, sem atributo que diferencie), cai para a seleção manual por SKU.
  const variacaoResolvida = React.useMemo(() => {
    if (!selProdutoId) return null;
    if (!temCor && !temTamanho) {
      if (variacoesDoProdutoSelecionado.length === 1) return variacoesDoProdutoSelecionado[0];
      if (variacoesDoProdutoSelecionado.length > 1) {
        return variacoesDoProdutoSelecionado.find((v) => String(v.id) === selVariacaoManualId) ?? null;
      }
      return null;
    }
    if (temCor && !selCorId) return null;
    if (temTamanho && !selTamanhoId) return null;
    return (
      variacoesDoProdutoSelecionado.find(
        (v) => (!temCor || v.corId === Number(selCorId)) && (!temTamanho || v.tamanhoId === Number(selTamanhoId)),
      ) ?? null
    );
  }, [selProdutoId, temCor, temTamanho, variacoesDoProdutoSelecionado, selCorId, selTamanhoId, selVariacaoManualId]);

  // Mesmo cálculo de saldo disponível que a tela já usava (soma do
  // produto_estoque para a variação + estoque escolhidos) — só passou a
  // olhar para a variação resolvida pelo seletor progressivo em vez do
  // Select único.
  const saldoItemDisponivel = React.useMemo(() => {
    if (!variacaoResolvida || !origemId) return null;
    const row = saldos.find((s) => s.produtoVariacaoId === variacaoResolvida.id && s.estoqueId === Number(origemId));
    return row?.quantidade ?? 0;
  }, [variacaoResolvida, origemId, saldos]);

  function resetSeletorItem() {
    setSelProdutoId("");
    setSelCorId("");
    setSelTamanhoId("");
    setSelVariacaoManualId("");
    setItemQuantidade("");
  }

  function handleAddItem() {
    if (!variacaoResolvida) return;
    const qtd = Number(itemQuantidade.replace(",", "."));
    if (!itemQuantidade || !(qtd > 0)) {
      toast({ title: "Informe uma quantidade válida.", variant: "error" });
      return;
    }
    // Evita adicionar a mesma variação duas vezes na mesma transferência —
    // não havia essa possibilidade no formulário anterior (um único item),
    // então não existia regra prévia para preservar; mantemos o item já
    // presente e pedimos para remover antes de ajustar a quantidade.
    if (carrinho.some((i) => i.variacaoId === variacaoResolvida.id)) {
      toast({
        title: "Este SKU já foi adicionado.",
        description: "Remova o item da lista para alterar a quantidade.",
        variant: "error",
      });
      return;
    }
    setCarrinho((prev) => [...prev, { variacaoId: variacaoResolvida.id, quantidade: qtd }]);
    resetSeletorItem();
  }

  function removeCarrinhoItem(variacaoId: number) {
    setCarrinho((prev) => prev.filter((i) => i.variacaoId !== variacaoId));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!origemId || !destinoId) {
      toast({ title: "Selecione o estoque de origem e de destino.", variant: "error" });
      return;
    }
    if (origemId === destinoId) {
      toast({ title: "Estoque de origem e destino devem ser diferentes.", variant: "error" });
      return;
    }
    if (carrinho.length === 0) {
      toast({ title: "Adicione ao menos um produto à transferência.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      // A confirmação continua chamando exatamente o mesmo endpoint/payload
      // de antes (apiClient.estoques.transfer), uma vez por item da lista —
      // nenhuma regra de origem/destino/cálculo/Kardex foi alterada, só
      // passou a poder ser disparada para mais de um item de uma vez.
      for (const item of carrinho) {
        await apiClient.estoques.transfer(empresa.id, actor, {
          produtoVariacaoId: item.variacaoId,
          estoqueOrigemId: Number(origemId),
          estoqueDestinoId: Number(destinoId),
          quantidade: item.quantidade,
          observacao: observacao.trim() || undefined,
        });
        setCarrinho((prev) => prev.filter((i) => i.variacaoId !== item.variacaoId));
      }
      toast({ title: carrinho.length > 1 ? "Transferências realizadas" : "Transferência realizada", variant: "success" });
      setObservacao("");
      reload();
    } catch (err) {
      toast({
        title: "Não foi possível concluir a transferência",
        description: err instanceof Error ? err.message : undefined,
        variant: "error",
      });
      reload();
    } finally {
      setSubmitting(false);
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.TRANSFERS_MANAGE}>
      <PageHeader title="Transferências" description="Movimente saldo de um SKU entre dois estoques da mesma empresa." />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Nova transferência</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-1.5">
                <Label>Estoque de origem</Label>
                <Select value={origemId} onValueChange={setOrigemId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoques.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Estoque de destino</Label>
                <Select value={destinoId} onValueChange={setDestinoId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoques
                      .filter((e) => String(e.id) !== origemId)
                      .map((e) => (
                        <SelectItem key={e.id} value={String(e.id)}>
                          {e.nome}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Seleção progressiva do item — pesquisa de produto, depois
                  atributos existentes daquele produto, depois saldo e
                  quantidade (Ajuste da Seleção de Produtos). */}
              <div className="flex flex-col gap-3 rounded-md border p-3">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Adicionar produto</p>

                <div className="flex flex-col gap-1.5">
                  <Label>Produto</Label>
                  <Popover open={produtoPopoverOpen} onOpenChange={setProdutoPopoverOpen}>
                    <PopoverTrigger asChild>
                      <Button
                        type="button"
                        variant="outline"
                        role="combobox"
                        aria-expanded={produtoPopoverOpen}
                        className="w-full justify-between font-normal"
                      >
                        <span className="truncate">
                          {produtoSelecionado ? produtoSelecionado.nome : "Pesquisar produto ou código…"}
                        </span>
                        <ChevronsUpDown className="h-4 w-4 shrink-0 opacity-50" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[--radix-popover-trigger-width] p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Pesquisar produto ou código…" />
                        <CommandList>
                          <CommandEmpty>Nenhum produto encontrado.</CommandEmpty>
                          <CommandGroup>
                            {produtosBuscaveis.map((entry) => (
                              <CommandItem
                                key={entry.produto.id}
                                value={`${entry.produto.nome} ${entry.skus.join(" ")}`}
                                onSelect={() => {
                                  resetSeletorItem();
                                  setSelProdutoId(String(entry.produto.id));
                                  setProdutoPopoverOpen(false);
                                }}
                              >
                                <Check
                                  className={cn(
                                    "h-4 w-4",
                                    selProdutoId === String(entry.produto.id) ? "opacity-100" : "opacity-0",
                                  )}
                                />
                                <div className="flex flex-col">
                                  <span>{entry.produto.nome}</span>
                                  <span className="text-xs text-muted-foreground">
                                    {entry.skus.length} {entry.skus.length === 1 ? "SKU" : "SKUs"}
                                  </span>
                                </div>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Atributos progressivos — só aparecem se o produto
                    selecionado realmente usa Cor e/ou Tamanho. Não assume o
                    par fixo Cor + Tamanho para todos os produtos. */}
                {selProdutoId && temCor && (
                  <div className="flex flex-col gap-1.5">
                    <Label>Cor</Label>
                    <Select
                      value={selCorId}
                      onValueChange={(v) => {
                        setSelCorId(v);
                        setSelTamanhoId("");
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {coresDisponiveis.map((c) => (
                          <SelectItem key={c.id} value={String(c.id)}>
                            {c.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {selProdutoId && temTamanho && (!temCor || selCorId) && (
                  <div className="flex flex-col gap-1.5">
                    <Label>Tamanho</Label>
                    <Select value={selTamanhoId} onValueChange={setSelTamanhoId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {tamanhosDisponiveis.map((t) => (
                          <SelectItem key={t.id} value={String(t.id)}>
                            {t.nome}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Caso raro: produto sem Cor nem Tamanho e com mais de uma
                    variação ativa — nada no modelo diferencia as variações,
                    então oferecemos o SKU diretamente. */}
                {selProdutoId && !temCor && !temTamanho && variacoesDoProdutoSelecionado.length > 1 && (
                  <div className="flex flex-col gap-1.5">
                    <Label>Variação</Label>
                    <Select value={selVariacaoManualId} onValueChange={setSelVariacaoManualId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o SKU" />
                      </SelectTrigger>
                      <SelectContent>
                        {variacoesDoProdutoSelecionado.map((v) => (
                          <SelectItem key={v.id} value={String(v.id)}>
                            {v.sku}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {variacaoResolvida && (
                  <>
                    <p className="text-xs text-muted-foreground">
                      {origemId ? (
                        <>
                          Disponível: <Qty value={saldoItemDisponivel ?? 0} unit={unidadeSelecionada?.sigla} />
                        </>
                      ) : (
                        "Selecione o estoque de origem para ver o saldo disponível."
                      )}
                    </p>
                    <div className="flex flex-col gap-1.5">
                      <Label>Quantidade</Label>
                      <Input value={itemQuantidade} onChange={(e) => setItemQuantidade(e.target.value)} placeholder="Ex.: 10" />
                    </div>
                    <Button type="button" variant="secondary" onClick={handleAddItem}>
                      <Plus className="h-4 w-4" /> Adicionar produto
                    </Button>
                  </>
                )}
              </div>

              {/* Produtos já adicionados a esta transferência — mesmo padrão
                  visual de lista de itens com remoção já usado em Compras
                  (src/pages/compras/page.tsx). */}
              {carrinho.length > 0 && (
                <div className="flex flex-col gap-2">
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Produtos selecionados</p>
                  <div className="flex flex-col gap-2">
                    {carrinho.map((item) => {
                      const variacao = variacoes.find((v) => v.id === item.variacaoId);
                      const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                      const cor = variacao?.corId != null ? cores.find((c) => c.id === variacao.corId) : undefined;
                      const tamanho = variacao?.tamanhoId != null ? tamanhos.find((t) => t.id === variacao.tamanhoId) : undefined;
                      const unidade = produto ? unidades.find((u) => u.id === produto.unidadeMedidaId) : undefined;
                      const descricaoVariacao = [cor?.nome, tamanho?.nome].filter(Boolean).join(" / ");
                      return (
                        <div key={item.variacaoId} className="flex items-center justify-between gap-2 rounded-md border px-3 py-2">
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium text-foreground">
                              {produto?.nome}
                              {descricaoVariacao ? ` — ${descricaoVariacao}` : ""}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Quantidade: <Qty value={item.quantidade} unit={unidade?.sigla} />
                            </p>
                          </div>
                          <button
                            type="button"
                            onClick={() => removeCarrinhoItem(item.variacaoId)}
                            className="shrink-0 text-muted-foreground hover:text-destructive"
                            aria-label="Remover"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-1.5">
                <Label>Observação (opcional)</Label>
                <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
              </div>
              <Button type="submit" loading={submitting} disabled={carrinho.length === 0}>
                <ArrowLeftRight className="h-4 w-4" /> Confirmar transferência
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Transferências recentes</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <LoadingState />
            ) : kardex.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState icon={ArrowLeftRight} title="Nenhuma transferência registrada" />
              </div>
            ) : (
              <div className="border-t">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Produto</TableHead>
                      <TableHead>Estoque</TableHead>
                      <TableHead className="text-right">Qtd.</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {kardex.map((k) => {
                      const variacao = variacoes.find((v) => v.id === k.produtoVariacaoId);
                      const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                      const estoque = estoques.find((e) => e.id === k.estoqueId);
                      return (
                        <TableRow key={k.id}>
                          <TableCell className="text-xs text-muted-foreground">{formatDateTime(k.dataMovimentacao)}</TableCell>
                          <TableCell className="text-foreground">
                            {produto?.nome} <span className="text-muted-foreground">({variacao?.sku})</span>
                          </TableCell>
                          <TableCell className="text-muted-foreground">{estoque?.nome}</TableCell>
                          <TableCell className={`text-right font-medium tabular-nums ${k.sentido === "ENTRADA" ? "text-success" : "text-destructive"}`}>
                            {k.sentido === "ENTRADA" ? "+" : "−"}
                            <Qty value={k.quantidade} />
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </RequirePermission>
  );
}
