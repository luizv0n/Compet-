"use client";
import * as React from "react";
import { PackagePlus, MinusCircle } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { useSearchParams } from "@/lib/next-compat";
import type { Produto, ProdutoVariacao, Estoque, ProdutoEstoque, MotivoPerda } from "@/types";

export default function EntradasEstoquePage() {
  const { empresa, actor } = useAuth();
  const { toast } = useToast();
  const searchParams = useSearchParams();
  // Ação rápida "Dar baixa" de Estoque abre direto na aba de baixa manual,
  // já com SKU e estoque pré-selecionados (?tab=baixa&variacao=ID&estoque=ID)
  // — ver src/pages/estoque/page.tsx.
  const defaultTab = searchParams.get("tab") === "baixa" ? "baixa" : "entrada";
  const initialVariacaoId = searchParams.get("variacao") ?? "";
  const initialEstoqueId = searchParams.get("estoque") ?? "";

  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [saldos, setSaldos] = React.useState<ProdutoEstoque[]>([]);
  const [motivos, setMotivos] = React.useState<MotivoPerda[]>([]);

  React.useEffect(() => {
    if (!empresa) return;
    (async () => {
      const [p, v, e, s, m] = await Promise.all([
        apiClient.produtos.list(empresa.id),
        apiClient.variacoes.list(empresa.id),
        apiClient.estoques.list(empresa.id),
        apiClient.estoques.saldos(empresa.id),
        apiClient.motivosPerda.list(empresa.id),
      ]);
      setProdutos(p);
      setVariacoes(v);
      setEstoques(e);
      setSaldos(s);
      setMotivos(m);
    })();
  }, [empresa]);

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.INVENTORY_MANAGE}>
      <PageHeader title="Entrada / Baixa direta" description="Entrada direta de produto acabado e baixas manuais (perda, ajuste, devolução)." />

      <Tabs defaultValue={defaultTab}>
        <TabsList>
          <TabsTrigger value="entrada">Entrada direta</TabsTrigger>
          <TabsTrigger value="baixa">Baixa manual</TabsTrigger>
        </TabsList>

        <TabsContent value="entrada">
          <EntradaForm produtos={produtos} variacoes={variacoes} estoques={estoques} empresaId={empresa.id} actor={actor} toast={toast} />
        </TabsContent>
        <TabsContent value="baixa">
          <BaixaForm
            produtos={produtos}
            variacoes={variacoes}
            estoques={estoques}
            saldos={saldos}
            motivos={motivos}
            initialVariacaoId={initialVariacaoId}
            initialEstoqueId={initialEstoqueId}
            empresaId={empresa.id}
            actor={actor}
            toast={toast}
          />
        </TabsContent>
      </Tabs>
    </RequirePermission>
  );
}

function EntradaForm({
  produtos,
  variacoes,
  estoques,
  empresaId,
  actor,
  toast,
}: {
  produtos: Produto[];
  variacoes: ProdutoVariacao[];
  estoques: Estoque[];
  empresaId: number;
  actor: { id: number; nome: string } | null;
  toast: (t: { title: string; description?: string; variant?: "success" | "error" | "info" }) => void;
}) {
  const [variacaoId, setVariacaoId] = React.useState("");
  const [estoqueId, setEstoqueId] = React.useState("");
  const [quantidade, setQuantidade] = React.useState("");
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!actor || !variacaoId || !estoqueId || !quantidade) {
      toast({ title: "Preencha todos os campos.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      await apiClient.producao.directEntry(empresaId, actor, {
        produtoVariacaoId: Number(variacaoId),
        estoqueId: Number(estoqueId),
        quantidade: Number(quantidade.replace(",", ".")),
        observacao: observacao.trim() || undefined,
      });
      toast({ title: "Entrada registrada", variant: "success" });
      setQuantidade("");
      setObservacao("");
    } catch (err) {
      toast({ title: "Não foi possível registrar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card className="max-w-xl">
      <CardHeader>
        <CardTitle>Entrada direta de produto acabado</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label>Produto / SKU</Label>
            <Select value={variacaoId} onValueChange={setVariacaoId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o SKU" />
              </SelectTrigger>
              <SelectContent>
                {variacoes
                  .filter((v) => v.ativo)
                  .map((v) => {
                    const produto = produtos.find((p) => p.id === v.produtoId);
                    return (
                      <SelectItem key={v.id} value={String(v.id)}>
                        {produto?.nome} — {v.sku}
                      </SelectItem>
                    );
                  })}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Estoque de destino</Label>
            <Select value={estoqueId} onValueChange={setEstoqueId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {estoques.map((e) => (
                  <SelectItem key={e.id} value={String(e.id)}>
                    {e.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Quantidade</Label>
            <Input value={quantidade} onChange={(e) => setQuantidade(e.target.value)} placeholder="Ex.: 100" />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Observação (opcional)</Label>
            <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
          </div>
          <Button type="submit" loading={submitting}>
            <PackagePlus className="h-4 w-4" /> Registrar entrada
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

function BaixaForm({
  produtos,
  variacoes,
  estoques,
  saldos,
  motivos,
  initialVariacaoId,
  initialEstoqueId,
  empresaId,
  actor,
  toast,
}: {
  produtos: Produto[];
  variacoes: ProdutoVariacao[];
  estoques: Estoque[];
  saldos: ProdutoEstoque[];
  motivos: MotivoPerda[];
  initialVariacaoId?: string;
  initialEstoqueId?: string;
  empresaId: number;
  actor: { id: number; nome: string } | null;
  toast: (t: { title: string; description?: string; variant?: "success" | "error" | "info" }) => void;
}) {
  const [variacaoId, setVariacaoId] = React.useState(initialVariacaoId ?? "");
  const [estoqueId, setEstoqueId] = React.useState(initialEstoqueId ?? "");
  const [natureza, setNatureza] = React.useState<"PERDA" | "AJUSTE" | "DEVOLUCAO">("PERDA");
  const [motivoId, setMotivoId] = React.useState("");
  const [quantidade, setQuantidade] = React.useState("");
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const saldoDisponivel = React.useMemo(() => {
    if (!variacaoId || !estoqueId) return null;
    return saldos.find((s) => s.produtoVariacaoId === Number(variacaoId) && s.estoqueId === Number(estoqueId))?.quantidade ?? 0;
  }, [variacaoId, estoqueId, saldos]);

  // Aviso imediato de saldo insuficiente (client-side, só para feedback —
  // a validação definitiva continua no apiClient/mockRepository). Evita que
  // o usuário só descubra o problema depois de submeter o formulário.
  const quantidadeExcedeSaldo = React.useMemo(() => {
    if (saldoDisponivel === null || !quantidade) return false;
    const qtd = Number(quantidade.replace(",", "."));
    return !Number.isNaN(qtd) && qtd > saldoDisponivel;
  }, [quantidade, saldoDisponivel]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!actor || !variacaoId || !estoqueId || !quantidade || !observacao.trim()) {
      toast({ title: "Preencha todos os campos, incluindo o motivo.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      await apiClient.estoques.manualOut(empresaId, actor, {
        produtoVariacaoId: Number(variacaoId),
        estoqueId: Number(estoqueId),
        quantidade: Number(quantidade.replace(",", ".")),
        natureza,
        motivoPerdaId: natureza === "PERDA" && motivoId ? Number(motivoId) : null,
        observacao: observacao.trim(),
      });
      toast({ title: "Baixa registrada", variant: "success" });
      setQuantidade("");
      setObservacao("");
    } catch (err) {
      toast({ title: "Não foi possível registrar a baixa", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Card className="max-w-xl">
      <CardHeader>
        <CardTitle>Baixa manual de estoque</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="flex flex-col gap-1.5">
            <Label>Produto / SKU</Label>
            <Select value={variacaoId} onValueChange={setVariacaoId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o SKU" />
              </SelectTrigger>
              <SelectContent>
                {variacoes.map((v) => {
                  const produto = produtos.find((p) => p.id === v.produtoId);
                  return (
                    <SelectItem key={v.id} value={String(v.id)}>
                      {produto?.nome} — {v.sku}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Estoque</Label>
            <Select value={estoqueId} onValueChange={setEstoqueId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione" />
              </SelectTrigger>
              <SelectContent>
                {estoques.map((e) => (
                  <SelectItem key={e.id} value={String(e.id)}>
                    {e.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {saldoDisponivel !== null && (
              <p className="text-xs text-muted-foreground">
                Disponível: <Qty value={saldoDisponivel} />
              </p>
            )}
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Natureza da baixa</Label>
            <Select value={natureza} onValueChange={(v) => setNatureza(v as typeof natureza)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="PERDA">Perda</SelectItem>
                <SelectItem value="AJUSTE">Ajuste</SelectItem>
                <SelectItem value="DEVOLUCAO">Devolução</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {natureza === "PERDA" && (
            <div className="flex flex-col gap-1.5">
              <Label>Motivo</Label>
              <Select value={motivoId} onValueChange={setMotivoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o motivo" />
                </SelectTrigger>
                <SelectContent>
                  {motivos.map((m) => (
                    <SelectItem key={m.id} value={String(m.id)}>
                      {m.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="flex flex-col gap-1.5">
            <Label>Quantidade</Label>
            <Input value={quantidade} onChange={(e) => setQuantidade(e.target.value)} placeholder="Ex.: 5" aria-invalid={quantidadeExcedeSaldo} />
            {quantidadeExcedeSaldo && (
              <p className="text-xs text-destructive">
                Quantidade maior que o saldo disponível (<Qty value={saldoDisponivel ?? 0} />).
              </p>
            )}
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>
              Motivo / observação <span className="text-destructive">*</span>
            </Label>
            <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} placeholder="Obrigatório para qualquer baixa manual" />
          </div>
          <Button type="submit" variant="destructive" loading={submitting} disabled={quantidadeExcedeSaldo}>
            <MinusCircle className="h-4 w-4" /> Confirmar baixa
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
