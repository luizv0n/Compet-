"use client";
import * as React from "react";
import { Warehouse, PackagePlus, History, ArrowLeftRight, MinusCircle, ChevronDown } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { Link, useSearchParams } from "@/lib/next-compat";
import { cn } from "@/lib/utils";
import type { Produto, ProdutoVariacao, Estoque, ProdutoEstoque, Cor, Tamanho, UnidadeMedida, EstoqueMinimo } from "@/types";
import { KardexDrawer } from "@/components/kardex/KardexDrawer";

export default function EstoquePage() {
  const { empresa, hasPermission } = useAuth();
  const canManage = hasPermission(PERMISSIONS.INVENTORY_MANAGE);
  const canTransfer = hasPermission(PERMISSIONS.TRANSFERS_MANAGE);
  // Suporta o deep link "Ver no estoque" vindo da tela de Locais
  // (Etapa 7) — mesmo padrão de leitura de query string já usado em
  // Kardex e Transferências (src/lib/next-compat.tsx).
  const searchParams = useSearchParams();

  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [saldos, setSaldos] = React.useState<ProdutoEstoque[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);
  const [minimos, setMinimos] = React.useState<EstoqueMinimo[]>([]);

  const [query, setQuery] = React.useState("");
  const [estoqueFiltro, setEstoqueFiltro] = React.useState<string>(() => searchParams.get("estoque") ?? "TODOS");
  // Kardex agora abre em Drawer contextual (sem navegar) — guarda o produto
  // e a variação que originaram o clique para pré-selecionar no Drawer.
  const [kardexAlvo, setKardexAlvo] = React.useState<{ produtoId: number; variacaoId: number } | null>(null);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, e, s, co, ta, un, mn] = await Promise.all([
      apiClient.produtos.list(empresa.id, true),
      apiClient.variacoes.list(empresa.id, true),
      apiClient.estoques.list(empresa.id),
      apiClient.estoques.saldos(empresa.id),
      apiClient.cores.list(empresa.id),
      apiClient.tamanhos.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.estoques.minimos(empresa.id),
    ]);
    setProdutos(p);
    setVariacoes(v);
    setEstoques(e);
    setSaldos(s);
    setCores(co);
    setTamanhos(ta);
    setUnidades(un);
    setMinimos(mn);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  // Query string usada pelas ações rápidas (Kardex/Transferir/Dar baixa) desta
  // linha — inclui o estoque atualmente selecionado no filtro, quando houver
  // um local específico escolhido (mesmo mecanismo de src/lib/next-compat.tsx
  // usado em Produtos, ver src/pages/produtos/detail/page.tsx).
  function quickActionQuery(variacaoId: number) {
    return estoqueFiltro === "TODOS" ? `variacao=${variacaoId}` : `variacao=${variacaoId}&estoque=${estoqueFiltro}`;
  }

  // BUG CRÍTICO CORRIGIDO (Etapa 1): `rows` e o useProgressiveList() abaixo
  // estavam calculados depois dos `return` condicionais de loading/empresa.
  // Isso viola as Rules of Hooks — na primeira renderização (loading=true)
  // o hook nunca era chamado; quando os dados chegavam e loading virava
  // false, o mesmo componente passava a chamar um hook a mais que na
  // renderização anterior, e o React derrubava a árvore com "Rendered more
  // hooks than during the previous render.", capturado pelo error boundary
  // (tela "This page didn't load"). Todas as outras páginas que usam
  // useProgressiveList (auditoria, compras, refugos, produção, kardex) já
  // seguiam a ordem correta — só esta tela tinha a inversão. Basta calcular
  // `rows` e chamar o hook sempre, antes de qualquer return condicional.
  const rows = variacoes
    .map((v) => {
      const produto = produtos.find((p) => p.id === v.produtoId);
      const cor = cores.find((c) => c.id === v.corId);
      const tamanho = tamanhos.find((t) => t.id === v.tamanhoId);
      const unidade = unidades.find((u) => u.id === produto?.unidadeMedidaId);
      const saldosDaVariacao = saldos.filter((s) => s.produtoVariacaoId === v.id);

      // Física, reservada e disponível — sempre calculadas na tela, nunca
      // armazenadas. Disponível = física - reservada (produto_estoque no
      // bd_competeV6.sql; quantidade_reservada ainda é sempre 0 na prática,
      // pois nenhuma regra de negócio grava nela até a Etapa 6/liberação de
      // OP — mas a conta já fica correta para quando isso mudar).
      const fisicaTotal = saldosDaVariacao.reduce((sum, s) => sum + s.quantidade, 0);
      const reservadaTotal = saldosDaVariacao.reduce((sum, s) => sum + s.quantidadeReservada, 0);

      const saldoLocal = estoqueFiltro === "TODOS" ? null : saldosDaVariacao.find((s) => s.estoqueId === Number(estoqueFiltro));
      const fisica = estoqueFiltro === "TODOS" ? fisicaTotal : saldoLocal?.quantidade ?? 0;
      const reservada = estoqueFiltro === "TODOS" ? reservadaTotal : saldoLocal?.quantidadeReservada ?? 0;
      const disponivel = fisica - reservada;

      const minimo = minimos.find((m) => m.produtoVariacaoId === v.id)?.quantidade ?? null;
      const abaixoDoMinimo = minimo != null && fisicaTotal < minimo;

      return { variacao: v, produto, cor, tamanho, unidade, saldosDaVariacao, fisica, reservada, disponivel, minimo, abaixoDoMinimo };
    })
    .filter((row) => {
      if (!query) return true;
      const haystack = `${row.produto?.nome ?? ""} ${row.variacao.sku} ${row.cor?.nome ?? ""} ${row.tamanho?.nome ?? ""}`.toLowerCase();
      return haystack.includes(query.toLowerCase());
    })
    .sort((a, b) => (a.produto?.nome ?? "").localeCompare(b.produto?.nome ?? ""));

  // Agrupamento visual (Etapa — Ajuste Visual Estoque/Saldo): reorganiza as
  // mesmas `rows` já calculadas acima pelo produto pai, seguindo o mesmo
  // conceito de "cartão expansível com tabela interna" já usado em
  // Compras (src/pages/compras/page.tsx). Nenhum valor é recalculado —
  // os totais do produto pai são apenas a soma dos valores de física,
  // reservada e disponível que cada variação já traz.
  type Row = (typeof rows)[number];
  type ProdutoGroup = {
    key: string;
    produto?: Produto;
    rows: Row[];
    fisicaTotal: number;
    reservadaTotal: number;
    disponivelTotal: number;
  };
  const groupsMap = new Map<string, ProdutoGroup>();
  for (const row of rows) {
    const key = row.produto ? String(row.produto.id) : `sem-produto-${row.variacao.id}`;
    let group = groupsMap.get(key);
    if (!group) {
      group = { key, produto: row.produto, rows: [], fisicaTotal: 0, reservadaTotal: 0, disponivelTotal: 0 };
      groupsMap.set(key, group);
    }
    group.rows.push(row);
    group.fisicaTotal += row.fisica;
    group.reservadaTotal += row.reservada;
    group.disponivelTotal += row.disponivel;
  }
  const grupos = Array.from(groupsMap.values());

  const [expandedKeys, setExpandedKeys] = React.useState<Set<string>>(new Set());
  function toggleGrupo(key: string) {
    setExpandedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  }

  const { visible, hasMore, showMore, remaining } = useProgressiveList(grupos, [query, estoqueFiltro]);

  if (!empresa) return null;
  if (loading) return <LoadingState />;

  return (
    <RequirePermission perm={PERMISSIONS.INVENTORY_VIEW}>
      <PageHeader
        title="Estoque"
        description="Saldo físico, reservado e disponível por SKU e local. Selecione um estoque específico ou veja o total consolidado."
        actions={
          canManage && (
            <Link href="/estoque/entradas">
              <Button size="sm" variant="secondary">
                <PackagePlus className="h-4 w-4" /> Entrada direta
              </Button>
            </Link>
          )
        }
      />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar por produto, SKU, cor ou tamanho…" />
        <Select value={estoqueFiltro} onValueChange={setEstoqueFiltro}>
          <SelectTrigger className="w-full sm:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODOS">Todos os estoques (consolidado)</SelectItem>
            {estoques.map((e) => (
              <SelectItem key={e.id} value={String(e.id)}>
                {e.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {rows.length === 0 ? (
        <EmptyState icon={Warehouse} title="Nenhum saldo encontrado" />
      ) : (
        <>
          {/* Agrupamento por produto pai (mesmo conceito de cartão expansível
              já usado em Catálogo/Produtos e no expand-in-place de Compras):
              cada produto é uma linha principal com os totais já calculados
              acima; expandindo, aparecem as variações com seus próprios
              valores — nenhum dado novo, apenas reorganização visual. */}
          <div className="flex flex-col gap-3">
            {visible.map((grupo) => {
              const expanded = expandedKeys.has(grupo.key);
              const unidade = grupo.rows[0]?.unidade;
              return (
                <div key={grupo.key} className="rounded-lg border">
                  <button
                    className="flex w-full flex-col gap-3 px-4 py-3 text-left sm:flex-row sm:items-center sm:justify-between"
                    onClick={() => toggleGrupo(grupo.key)}
                    aria-expanded={expanded}
                  >
                    <div>
                      <p className="text-sm font-medium text-foreground">
                        {grupo.produto?.nome ?? "Sem produto"}
                        {grupo.rows.every((r) => !r.variacao.ativo) && (
                          <Badge variant="outline" className="ml-2">
                            Inativo
                          </Badge>
                        )}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {grupo.rows.length} {grupo.rows.length === 1 ? "variação" : "variações"}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 sm:gap-6">
                      <div className="grid grid-cols-3 gap-x-4 text-right">
                        <div>
                          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                            Física {estoqueFiltro === "TODOS" ? "(total)" : ""}
                          </p>
                          <p className="font-semibold tabular-nums text-foreground">
                            <Qty value={grupo.fisicaTotal} unit={unidade?.sigla} />
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Reservada</p>
                          <p className="tabular-nums text-muted-foreground">
                            <Qty value={grupo.reservadaTotal} unit={unidade?.sigla} />
                          </p>
                        </div>
                        <div>
                          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Disponível</p>
                          <p className="font-semibold tabular-nums text-foreground">
                            <Qty value={grupo.disponivelTotal} unit={unidade?.sigla} />
                          </p>
                        </div>
                      </div>
                      <ChevronDown
                        className={cn(
                          "h-4 w-4 shrink-0 text-muted-foreground transition-transform duration-200",
                          expanded && "rotate-180",
                        )}
                      />
                    </div>
                  </button>
                  {expanded && (
                    <div className="border-t">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>SKU</TableHead>
                            <TableHead>Cor</TableHead>
                            <TableHead>Tamanho</TableHead>
                            <TableHead className="text-right">
                              Física {estoqueFiltro === "TODOS" ? "(total)" : ""}
                            </TableHead>
                            <TableHead className="text-right">Reservada</TableHead>
                            <TableHead className="text-right">Disponível</TableHead>
                            <TableHead className="text-right">Ações</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {grupo.rows.map((row) => (
                            <TableRow key={row.variacao.id}>
                              <TableCell className="font-mono text-xs font-medium text-foreground">
                                {row.variacao.sku}
                                {!row.variacao.ativo && (
                                  <Badge variant="outline" className="ml-2">
                                    Inativo
                                  </Badge>
                                )}
                                {row.abaixoDoMinimo && (
                                  <Badge variant="outline" className="ml-2 border-warning/40 text-warning">
                                    Abaixo do mínimo ({row.minimo})
                                  </Badge>
                                )}
                              </TableCell>
                              <TableCell className="text-muted-foreground">{row.cor?.nome ?? "—"}</TableCell>
                              <TableCell className="text-muted-foreground">{row.tamanho?.nome ?? "—"}</TableCell>
                              <TableCell className="text-right">
                                <div className="font-semibold tabular-nums text-foreground">
                                  <Qty value={row.fisica} unit={row.unidade?.sigla} />
                                </div>
                                {estoqueFiltro === "TODOS" && row.saldosDaVariacao.length > 0 && (
                                  <div className="mt-0.5 flex flex-wrap justify-end gap-x-2 text-[11px] text-muted-foreground">
                                    {row.saldosDaVariacao
                                      .filter((s) => s.quantidade !== 0)
                                      .map((s) => (
                                        <span key={s.estoqueId}>
                                          {estoques.find((e) => e.id === s.estoqueId)?.nome}: <Qty value={s.quantidade} />
                                        </span>
                                      ))}
                                  </div>
                                )}
                              </TableCell>
                              <TableCell className="text-right tabular-nums text-muted-foreground">
                                <Qty value={row.reservada} unit={row.unidade?.sigla} />
                              </TableCell>
                              <TableCell className="text-right">
                                <span className="font-semibold tabular-nums text-foreground">
                                  <Qty value={row.disponivel} unit={row.unidade?.sigla} />
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex flex-wrap justify-end gap-1">
                                  {row.produto && (
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => setKardexAlvo({ produtoId: row.produto!.id, variacaoId: row.variacao.id })}
                                    >
                                      <History className="h-3.5 w-3.5" /> Kardex
                                    </Button>
                                  )}
                                  {canTransfer && (
                                    <Button variant="ghost" size="sm" asChild>
                                      <Link href={`/estoque/transferencias?${quickActionQuery(row.variacao.id)}`}>
                                        <ArrowLeftRight className="h-3.5 w-3.5" /> Transferir
                                      </Link>
                                    </Button>
                                  )}
                                  {canManage && (
                                    <Button variant="ghost" size="sm" asChild>
                                      <Link href={`/estoque/entradas?tab=baixa&${quickActionQuery(row.variacao.id)}`}>
                                        <MinusCircle className="h-3.5 w-3.5" /> Dar baixa
                                      </Link>
                                    </Button>
                                  )}
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}

      {/* Kardex — Drawer contextual do produto (não navega de página) */}
      <KardexDrawer
        open={kardexAlvo !== null}
        onOpenChange={(o) => !o && setKardexAlvo(null)}
        produtoId={kardexAlvo?.produtoId ?? null}
        initialVariacaoId={kardexAlvo?.variacaoId}
        initialEstoqueId={estoqueFiltro !== "TODOS" ? Number(estoqueFiltro) : undefined}
      />
    </RequirePermission>
  );
}
