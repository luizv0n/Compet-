"use client";
import * as React from "react";
import { useParams, useRouter } from "@/lib/next-compat";
import { ArrowLeft, Plus, Pencil, DollarSign, Barcode, History, AlertTriangle } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { LoadingState } from "@/components/common/LoadingState";
import { EmptyState } from "@/components/common/EmptyState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { PRODUTO_TIPOS } from "@/types";
import type { Produto, ProdutoVariacao, Cor, Tamanho, Colecao, Categoria } from "@/types";
import { Link } from "@/lib/next-compat";
import { KardexDrawer } from "@/components/kardex/KardexDrawer";
import { ProdutoFormDialog } from "@/components/produtos/ProdutoFormDialog";

export default function ProdutoDetalhePage() {
  const params = useParams<{ id: string }>();
  const produtoId = Number(params.id);
  const router = useRouter();
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.PRODUCTS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [produto, setProduto] = React.useState<Produto | null>(null);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [colecoes, setColecoes] = React.useState<Colecao[]>([]);
  const [categorias, setCategorias] = React.useState<Categoria[]>([]);
  const [unidades, setUnidades] = React.useState<import("@/types").UnidadeMedida[]>([]);
  const [tiposPagamento, setTiposPagamento] = React.useState<{ id: number; nome: string }[]>([]);

  const [produtoDialogOpen, setProdutoDialogOpen] = React.useState(false);
  const [variacaoDialogOpen, setVariacaoDialogOpen] = React.useState(false);
  const [editingVariacao, setEditingVariacao] = React.useState<ProdutoVariacao | null>(null);
  const [addForm, setAddForm] = React.useState({ corId: "", tamanhoId: "", sku: "", precoBase: "" });
  const [precoDialog, setPrecoDialog] = React.useState<ProdutoVariacao | null>(null);
  const [precos, setPrecos] = React.useState<Record<number, string>>({});
  const [minimos, setMinimos] = React.useState<Record<number, number | null>>({});
  const [minimoDialog, setMinimoDialog] = React.useState<ProdutoVariacao | null>(null);
  const [minimoValor, setMinimoValor] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  // Kardex agora abre em Drawer contextual (sem navegar) — guarda apenas
  // qual variação disparou o clique para pré-selecioná-la no Drawer.
  const [kardexVariacaoId, setKardexVariacaoId] = React.useState<number | null>(null);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, co, ta, col, cat, un, tp, mn] = await Promise.all([
      apiClient.produtos.get(produtoId, empresa.id),
      apiClient.produtos.variacoes(produtoId, empresa.id),
      apiClient.cores.list(empresa.id),
      apiClient.tamanhos.list(empresa.id),
      apiClient.colecoes.list(empresa.id),
      apiClient.categorias.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.tiposPagamento.list(empresa.id),
      apiClient.estoques.minimos(empresa.id),
    ]);
    setProduto(p ?? null);
    setVariacoes(v);
    setCores(co);
    setTamanhos(ta);
    setColecoes(col);
    setCategorias(cat);
    setUnidades(un);
    setTiposPagamento(tp);
    const minimoMap: Record<number, number | null> = {};
    for (const vr of v) {
      minimoMap[vr.id] = mn.find((m) => m.produtoVariacaoId === vr.id)?.quantidade ?? null;
    }
    setMinimos(minimoMap);
    setLoading(false);
  }, [empresa, produtoId]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  async function handleToggleProduto() {
    if (!empresa || !actor || !produto) return;
    await apiClient.produtos.toggle(produto.id, empresa.id, actor);
    toast({ title: produto.ativo ? "Produto inativado" : "Produto ativado", variant: "success" });
    reload();
  }

  async function handleToggleVariacao(v: ProdutoVariacao) {
    if (!empresa || !actor) return;
    await apiClient.produtos.toggleVariacao(v.id, empresa.id, actor);
    toast({ title: v.ativo ? "SKU inativado" : "SKU ativado", variant: "success" });
    reload();
  }

  function openAddVariacao() {
    setEditingVariacao(null);
    setAddForm({ corId: "", tamanhoId: "", sku: "", precoBase: "" });
    setVariacaoDialogOpen(true);
    // Sugere o próximo SKU sequencial (CAM-000001, CAM-000002, ...); o campo
    // continua editável e o usuário pode substituir o valor antes de salvar.
    if (empresa) {
      apiClient.produtos.nextSku(empresa.id).then((sku) => {
        setAddForm((f) => ({ ...f, sku }));
      });
    }
  }

  function openEditVariacao(v: ProdutoVariacao) {
    setEditingVariacao(v);
    setAddForm({
      corId: v.corId ? String(v.corId) : "",
      tamanhoId: v.tamanhoId ? String(v.tamanhoId) : "",
      sku: v.sku,
      precoBase: "",
    });
    setVariacaoDialogOpen(true);
  }

  async function handleSaveVariacao(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !produto) return;
    if (!addForm.sku.trim()) {
      toast({ title: "Informe o SKU.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (editingVariacao) {
        await apiClient.produtos.updateVariacao(editingVariacao.id, empresa.id, actor, {
          corId: addForm.corId ? Number(addForm.corId) : null,
          tamanhoId: addForm.tamanhoId ? Number(addForm.tamanhoId) : null,
          sku: addForm.sku.trim().toUpperCase(),
        });
        toast({ title: "Variação atualizada", variant: "success" });
      } else {
        const precoBase = Number(addForm.precoBase.replace(",", ".")) || 0;
        await apiClient.produtos.addVariacao(produto.id, empresa.id, actor, {
          corId: addForm.corId ? Number(addForm.corId) : null,
          tamanhoId: addForm.tamanhoId ? Number(addForm.tamanhoId) : null,
          sku: addForm.sku.trim().toUpperCase(),
          codigoBarras: null,
          precos: tiposPagamento.map((tp) => ({ tipoPagamentoId: tp.id, valor: precoBase })),
        });
        toast({ title: "Variação adicionada", variant: "success" });
      }
      setVariacaoDialogOpen(false);
      setEditingVariacao(null);
      setAddForm({ corId: "", tamanhoId: "", sku: "", precoBase: "" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function openPrecoDialog(v: ProdutoVariacao) {
    if (!empresa) return;
    setPrecoDialog(v);
    const rows = await apiClient.produtos.precosDaVariacao(v.id, empresa.id);
    const map: Record<number, string> = {};
    for (const tp of tiposPagamento) {
      const row = rows.find((r) => r.tipoPagamentoId === tp.id);
      map[tp.id] = row ? String(row.valor) : "0";
    }
    setPrecos(map);
  }

  async function handleSavePrecos(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !precoDialog) return;
    setSubmitting(true);
    try {
      await apiClient.produtos.updatePrecos(
        precoDialog.id,
        empresa.id,
        actor,
        Object.entries(precos).map(([tipoPagamentoId, valor]) => ({
          tipoPagamentoId: Number(tipoPagamentoId),
          valor: Number(String(valor).replace(",", ".")) || 0,
        })),
      );
      toast({ title: "Preços atualizados", variant: "success" });
      setPrecoDialog(null);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  function openMinimoDialog(v: ProdutoVariacao) {
    setMinimoDialog(v);
    setMinimoValor(minimos[v.id] != null ? String(minimos[v.id]) : "");
  }

  async function handleSaveMinimo(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !minimoDialog) return;
    const quantidade = Number(minimoValor.replace(",", "."));
    if (!minimoValor.trim() || Number.isNaN(quantidade) || quantidade < 0) {
      toast({ title: "Informe um estoque mínimo válido.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      await apiClient.estoques.setMinimo(minimoDialog.id, empresa.id, actor, quantidade);
      toast({ title: "Estoque mínimo atualizado", variant: "success" });
      setMinimoDialog(null);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  if (!empresa) return null;
  if (loading) return <LoadingState />;
  if (!produto) return <EmptyState title="Produto não encontrado" />;

  const tipoLabel = PRODUTO_TIPOS.find((t) => t.value === produto.tipo)?.label ?? produto.tipo;

  return (
    <RequirePermission perm={PERMISSIONS.PRODUCTS_VIEW}>
      <Button variant="ghost" size="sm" className="mb-2 -ml-2" onClick={() => router.push("/produtos")}>
        <ArrowLeft className="h-4 w-4" /> Voltar para produtos
      </Button>
      <PageHeader
        title={produto.nome}
        description={`${tipoLabel} · Unidade de medida do produto`}
        actions={
          canManage && (
            <div className="flex items-center gap-3">
              <Button variant="outline" size="sm" onClick={() => setProdutoDialogOpen(true)}>
                <Pencil className="h-3.5 w-3.5" /> Editar produto
              </Button>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Ativo</span>
                <Switch checked={produto.ativo} onCheckedChange={handleToggleProduto} />
              </div>
            </div>
          )
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Informações</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 text-sm">
            <Row label="Tipo" value={<Badge variant="outline">{tipoLabel}</Badge>} />
            <Row label="NCM" value={produto.ncm ?? "—"} />
            <Row label="CEST" value={produto.cest ?? "—"} />
            <Row label="Origem" value={produto.origem ?? "—"} />
            <Row label="Status" value={<ActiveBadge ativo={produto.ativo} />} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle>Variações (SKUs)</CardTitle>
            {canManage && (
              <Button size="sm" onClick={openAddVariacao}>
                <Plus className="h-4 w-4" /> Nova variação
              </Button>
            )}
          </CardHeader>
          <CardContent className="p-0">
            {variacoes.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState icon={Barcode} title="Nenhuma variação cadastrada" />
              </div>
            ) : (
              <div className="border-t">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>SKU</TableHead>
                      <TableHead>Cor</TableHead>
                      <TableHead>Tamanho</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Preços</TableHead>
                      <TableHead className="text-right">Mínimo</TableHead>
                      <TableHead className="text-right">Kardex</TableHead>
                      {canManage && <TableHead className="text-right">Ações</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {variacoes.map((v) => {
                      const cor = cores.find((c) => c.id === v.corId);
                      const tamanho = tamanhos.find((t) => t.id === v.tamanhoId);
                      return (
                        <TableRow key={v.id}>
                          <TableCell className="font-mono text-xs font-medium text-foreground">{v.sku}</TableCell>
                          <TableCell className="text-muted-foreground">{cor?.nome ?? "—"}</TableCell>
                          <TableCell className="text-muted-foreground">{tamanho?.nome ?? "—"}</TableCell>
                          <TableCell>
                            <ActiveBadge ativo={v.ativo} />
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => openPrecoDialog(v)}>
                              <DollarSign className="h-3.5 w-3.5" /> Preços
                            </Button>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => openMinimoDialog(v)}>
                              <AlertTriangle className="h-3.5 w-3.5" />
                              {minimos[v.id] != null ? minimos[v.id] : "Definir"}
                            </Button>
                          </TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm" onClick={() => setKardexVariacaoId(v.id)}>
                              <History className="h-3.5 w-3.5" /> Kardex
                            </Button>
                          </TableCell>
                          {canManage && (
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-3">
                                <button
                                  onClick={() => openEditVariacao(v)}
                                  className="text-muted-foreground hover:text-foreground"
                                  aria-label="Editar variação"
                                >
                                  <Pencil className="h-3.5 w-3.5" />
                                </button>
                                <Switch checked={v.ativo} onCheckedChange={() => handleToggleVariacao(v)} />
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <p className="mt-4 text-xs text-muted-foreground">
        Para definir a ficha técnica (componentes consumidos por um SKU), acesse{" "}
        <Link href="/producao/fichas-tecnicas" className="text-accent hover:underline">
          Produção → Fichas técnicas
        </Link>
        .
      </p>

      {/* Editar produto (mesmo formulário/componente usado na listagem) */}
      <ProdutoFormDialog
        open={produtoDialogOpen}
        onOpenChange={setProdutoDialogOpen}
        mode="edit"
        produto={produto}
        colecoes={colecoes}
        categorias={categorias}
        cores={cores}
        tamanhos={tamanhos}
        unidades={unidades}
        tiposPagamento={tiposPagamento}
        onSaved={reload}
      />

      {/* Nova variação / Editar variação */}
      <Dialog open={variacaoDialogOpen} onOpenChange={setVariacaoDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editingVariacao ? "Editar variação" : "Nova variação"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveVariacao} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="vsku">SKU</Label>
              <Input id="vsku" value={addForm.sku} onChange={(e) => setAddForm({ ...addForm, sku: e.target.value })} autoFocus />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label>Cor</Label>
                <Select value={addForm.corId} onValueChange={(v) => setAddForm({ ...addForm, corId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sem cor" />
                  </SelectTrigger>
                  <SelectContent>
                    {cores.map((c) => (
                      <SelectItem key={c.id} value={String(c.id)}>
                        {c.nome} {c.estampa ? `— ${c.estampa}` : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Tamanho</Label>
                <Select value={addForm.tamanhoId} onValueChange={(v) => setAddForm({ ...addForm, tamanhoId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sem tamanho" />
                  </SelectTrigger>
                  <SelectContent>
                    {tamanhos.map((t) => (
                      <SelectItem key={t.id} value={String(t.id)}>
                        {t.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {editingVariacao ? (
              <p className="text-xs text-muted-foreground">
                Para alterar os preços desta variação, use a ação "Preços" na tabela.
              </p>
            ) : (
              <div className="flex flex-col gap-1.5">
                <Label>Preço base (opcional)</Label>
                <Input value={addForm.precoBase} onChange={(e) => setAddForm({ ...addForm, precoBase: e.target.value })} placeholder="Ex.: 39,90" />
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setVariacaoDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                {editingVariacao ? "Salvar alterações" : "Salvar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Preços */}
      <Dialog open={!!precoDialog} onOpenChange={(o) => !o && setPrecoDialog(null)}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>Preços — {precoDialog?.sku}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSavePrecos} className="flex flex-col gap-3">
            {tiposPagamento.map((tp) => (
              <div key={tp.id} className="flex items-center gap-3">
                <Label className="w-24 shrink-0">{tp.nome}</Label>
                <Input
                  value={precos[tp.id] ?? ""}
                  onChange={(e) => setPrecos((p) => ({ ...p, [tp.id]: e.target.value }))}
                  className="text-right"
                />
              </div>
            ))}
            <DialogFooter className="mt-2">
              <Button type="button" variant="outline" onClick={() => setPrecoDialog(null)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar preços
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Estoque mínimo (Etapa 14 — regra 25 do Prompt Master) */}
      <Dialog open={!!minimoDialog} onOpenChange={(o) => !o && setMinimoDialog(null)}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>Estoque mínimo — {minimoDialog?.sku}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSaveMinimo} className="flex flex-col gap-3">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="minimoQtd">Quantidade mínima</Label>
              <Input id="minimoQtd" value={minimoValor} onChange={(e) => setMinimoValor(e.target.value)} placeholder="Ex.: 20" autoFocus />
              <p className="text-xs text-muted-foreground">
                Usado para o alerta de estoque baixo no Dashboard. Considera o saldo consolidado (todos os locais).
              </p>
            </div>
            <DialogFooter className="mt-1">
              <Button type="button" variant="outline" onClick={() => setMinimoDialog(null)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Kardex — Drawer contextual do produto (não navega de página) */}
      <KardexDrawer
        open={kardexVariacaoId !== null}
        onOpenChange={(o) => !o && setKardexVariacaoId(null)}
        produtoId={produto.id}
        initialVariacaoId={kardexVariacaoId}
      />
    </RequirePermission>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-border/60 py-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}
