"use client";
import * as React from "react";
import { Link } from "@/lib/next-compat";
import { Plus, Shirt, ChevronRight, Pencil } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { PRODUTO_TIPOS } from "@/types";
import type {
  Produto,
  ProdutoVariacao,
  Colecao,
  Categoria,
  Cor,
  Tamanho,
  UnidadeMedida,
  ProdutoTipo,
} from "@/types";
import { ProdutoFormDialog } from "@/components/produtos/ProdutoFormDialog";

const TIPO_LABEL: Record<ProdutoTipo, string> = Object.fromEntries(PRODUTO_TIPOS.map((t) => [t.value, t.label])) as Record<
  ProdutoTipo,
  string
>;

export default function ProdutosPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.PRODUCTS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [colecoes, setColecoes] = React.useState<Colecao[]>([]);
  const [categorias, setCategorias] = React.useState<Categoria[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);
  const [tiposPagamento, setTiposPagamento] = React.useState<{ id: number; nome: string }[]>([]);

  const [query, setQuery] = React.useState("");
  const [tipoFiltro, setTipoFiltro] = React.useState<string>("TODOS");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [dialogMode, setDialogMode] = React.useState<"create" | "edit">("create");
  const [editing, setEditing] = React.useState<Produto | null>(null);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, col, cat, co, ta, un, tp] = await Promise.all([
      apiClient.produtos.list(empresa.id, true),
      apiClient.variacoes.list(empresa.id, true),
      apiClient.colecoes.list(empresa.id),
      apiClient.categorias.list(empresa.id),
      apiClient.cores.list(empresa.id),
      apiClient.tamanhos.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.tiposPagamento.list(empresa.id),
    ]);
    setProdutos(p);
    setVariacoes(v);
    setColecoes(col);
    setCategorias(cat);
    setCores(co);
    setTamanhos(ta);
    setUnidades(un);
    setTiposPagamento(tp);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const filtered = produtos.filter((p) => {
    if (tipoFiltro !== "TODOS" && p.tipo !== tipoFiltro) return false;
    if (query && !p.nome.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });

  function openCreate() {
    setDialogMode("create");
    setEditing(null);
    setDialogOpen(true);
  }

  function openEdit(item: Produto) {
    setDialogMode("edit");
    setEditing(item);
    setDialogOpen(true);
  }

  async function handleToggle(item: Produto) {
    if (!empresa || !actor) return;
    try {
      await apiClient.produtos.toggle(item.id, empresa.id, actor);
      toast({ title: item.ativo ? "Produto inativado" : "Produto ativado", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.PRODUCTS_VIEW}>
      <PageHeader
        title="Produtos"
        description="Matérias-primas, aviamentos, semiacabados e produtos de confecção — e suas variações (SKUs)."
        actions={
          canManage && (
            <Button onClick={openCreate} size="sm">
              <Plus className="h-4 w-4" /> Novo produto
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar produto…" />
            <Select value={tipoFiltro} onValueChange={setTipoFiltro}>
              <SelectTrigger className="w-full sm:w-56">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODOS">Todos os tipos</SelectItem>
                {PRODUTO_TIPOS.map((t) => (
                  <SelectItem key={t.value} value={t.value}>
                    {t.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={Shirt} title="Nenhum produto encontrado" />
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead>Coleção</TableHead>
                    <TableHead>SKUs</TableHead>
                    <TableHead>Status</TableHead>
                    {canManage && <TableHead>Ativo</TableHead>}
                    <TableHead className="text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((p) => {
                    const vCount = variacoes.filter((v) => v.produtoId === p.id).length;
                    const colecao = colecoes.find((c) => c.id === p.colecaoId);
                    return (
                      <TableRow key={p.id}>
                        <TableCell className="font-medium text-foreground">
                          <Link href={`/produtos/${p.id}`} className="hover:underline">
                            {p.nome}
                          </Link>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{TIPO_LABEL[p.tipo]}</Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{colecao?.nome ?? "—"}</TableCell>
                        <TableCell className="tabular-nums">{vCount}</TableCell>
                        <TableCell>
                          <ActiveBadge ativo={p.ativo} />
                        </TableCell>
                        {canManage && (
                          <TableCell>
                            <Switch checked={p.ativo} onCheckedChange={() => handleToggle(p)} />
                          </TableCell>
                        )}
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-1">
                            {canManage && (
                              <Button variant="ghost" size="sm" onClick={() => openEdit(p)}>
                                <Pencil className="h-3.5 w-3.5" /> Editar
                              </Button>
                            )}
                            <Link href={`/produtos/${p.id}`}>
                              <Button variant="ghost" size="sm">
                                Detalhes <ChevronRight className="h-3.5 w-3.5" />
                              </Button>
                            </Link>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      <ProdutoFormDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        mode={dialogMode}
        produto={editing}
        colecoes={colecoes}
        categorias={categorias}
        cores={cores}
        tamanhos={tamanhos}
        unidades={unidades}
        tiposPagamento={tiposPagamento}
        onSaved={reload}
      />
    </RequirePermission>
  );
}
