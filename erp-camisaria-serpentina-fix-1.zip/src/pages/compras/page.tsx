"use client";
import * as React from "react";
import { Plus, ShoppingCart, Trash2, CheckCircle2, XCircle, Pencil } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { PurchaseNoteStatusBadge } from "@/components/common/StatusBadge";
import { Money, Qty } from "@/components/common/Money";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatDate } from "@/lib/utils";
import { useSearchParams } from "@/lib/next-compat";
import type { ConfiguracaoEmpresa, Produto, ProdutoVariacao, Estoque, Fornecedor, NotaFiscal, NotaFiscalItem, UnidadeMedida } from "@/types";

interface DraftItem {
  produtoVariacaoId: string;
  quantidade: string;
  valorUnitario: string;
}

export default function ComprasPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.PURCHASES_MANAGE);
  const searchParams = useSearchParams();
  // Ação rápida "Documento" do Kardex (?nota=ID) — ver
  // src/pages/estoque/kardex/page.tsx. Não há rota de detalhe dedicada para
  // uma nota; em vez de inventar uma, reaproveitamos o expand-in-place já
  // existente nesta listagem, localizando a nota pelo número na busca.
  const notaParam = searchParams.get("nota");

  const [loading, setLoading] = React.useState(true);
  const [notas, setNotas] = React.useState<NotaFiscal[]>([]);
  const [itensPorNota, setItensPorNota] = React.useState<Record<number, NotaFiscalItem[]>>({});
  const [fornecedores, setFornecedores] = React.useState<Fornecedor[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  // Configuração da empresa (Configurações > Entrada de matéria-prima) —
  // usada só para pré-selecionar o estoque destino ao ABRIR uma nota
  // nova (seção 8/12 do prompt "Configurações"). Nunca usada para editar
  // notas existentes (seção 14: notas antigas não são alteradas).
  const [config, setConfig] = React.useState<ConfiguracaoEmpresa | null>(null);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);

  const [query, setQuery] = React.useState("");
  const [statusFiltro, setStatusFiltro] = React.useState("TODAS");
  const [expandedId, setExpandedId] = React.useState<number | null>(null);
  const [confirmAction, setConfirmAction] = React.useState<{ id: number; type: "complete" | "cancel" } | null>(null);

  const [dialogOpen, setDialogOpen] = React.useState(false);
  // Nota EM_ABERTO sendo editada (regra 21 do prompt mestre: "Nota
  // EM_ABERTO: pode ser editada"). null = formulário está em modo
  // criação. Reaproveita o MESMO dialog/formulário de criação — não
  // cria uma segunda tela/dialog duplicado só para edição.
  const [editingId, setEditingId] = React.useState<number | null>(null);
  const [numero, setNumero] = React.useState("");
  const [fornecedorId, setFornecedorId] = React.useState("");
  const [estoqueId, setEstoqueId] = React.useState("");
  const [dataEmissao, setDataEmissao] = React.useState(() => new Date().toISOString().slice(0, 10));
  const [observacao, setObservacao] = React.useState("");
  const [itens, setItens] = React.useState<DraftItem[]>([{ produtoVariacaoId: "", quantidade: "", valorUnitario: "" }]);
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [n, f, e, p, v, u, c] = await Promise.all([
      apiClient.compras.list(empresa.id),
      apiClient.fornecedores.list(empresa.id),
      apiClient.estoques.list(empresa.id),
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.configuracoes.get(empresa.id),
    ]);
    setNotas(n);
    setFornecedores(f);
    setEstoques(e);
    setProdutos(p);
    setVariacoes(v);
    setUnidades(u);
    setConfig(c);
    const itensMap: Record<number, NotaFiscalItem[]> = {};
    await Promise.all(
      n.map(async (nota) => {
        itensMap[nota.id] = await apiClient.compras.itens(nota.id, empresa.id);
      }),
    );
    setItensPorNota(itensMap);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  // Ao chegar via ?nota=ID (ação rápida "Documento" do Kardex), filtra e
  // expande diretamente a nota referenciada — ver comentário acima.
  React.useEffect(() => {
    if (!notaParam || notas.length === 0) return;
    const nota = notas.find((n) => n.id === Number(notaParam));
    if (!nota) return;
    setStatusFiltro("TODAS");
    setQuery(nota.numero);
    setExpandedId(nota.id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [notaParam, notas]);

  const filtered = notas.filter((n) => {
    if (statusFiltro !== "TODAS" && n.status !== statusFiltro) return false;
    if (query) {
      const fornecedor = fornecedores.find((f) => f.id === n.fornecedorId);
      if (!`${n.numero} ${fornecedor?.nome ?? ""}`.toLowerCase().includes(query.toLowerCase())) return false;
    }
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, statusFiltro]);

  function openCreate() {
    setEditingId(null);
    setNumero("");
    setFornecedorId("");
    // Pré-seleciona o estoque padrão configurado em Configurações (seção
    // 8), mas só se ele ainda estiver entre os estoques ATIVOS da
    // empresa (seção 11: nunca aplicar silenciosamente um estoque que
    // foi inativado/removido). Sem configuração válida, o campo fica em
    // branco e a seleção manual continua obrigatória (seção 10).
    const padraoValido =
      config?.estoquePadraoEntradaMpId && estoques.some((e) => e.id === config.estoquePadraoEntradaMpId)
        ? config.estoquePadraoEntradaMpId
        : null;
    setEstoqueId(padraoValido ? String(padraoValido) : "");
    setDataEmissao(new Date().toISOString().slice(0, 10));
    setObservacao("");
    setItens([{ produtoVariacaoId: "", quantidade: "", valorUnitario: "" }]);
    setDialogOpen(true);
  }

  function openEdit(nota: NotaFiscal) {
    const nItens = itensPorNota[nota.id] ?? [];
    setEditingId(nota.id);
    setNumero(nota.numero);
    setFornecedorId(String(nota.fornecedorId));
    setEstoqueId(String(nota.estoqueId));
    setDataEmissao(nota.dataEmissao.slice(0, 10));
    setObservacao(nota.observacao ?? "");
    setItens(
      nItens.length > 0
        ? nItens.map((i) => ({ produtoVariacaoId: String(i.produtoVariacaoId), quantidade: String(i.quantidade), valorUnitario: String(i.valorUnitario) }))
        : [{ produtoVariacaoId: "", quantidade: "", valorUnitario: "" }],
    );
    setDialogOpen(true);
  }

  function updateItem(idx: number, patch: Partial<DraftItem>) {
    setItens((prev) => prev.map((it, i) => (i === idx ? { ...it, ...patch } : it)));
  }
  function addItem() {
    setItens((prev) => [...prev, { produtoVariacaoId: "", quantidade: "", valorUnitario: "" }]);
  }
  function removeItem(idx: number) {
    setItens((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!numero.trim() || !fornecedorId || !estoqueId) {
      toast({ title: "Preencha número, fornecedor e estoque destino.", variant: "error" });
      return;
    }
    const parsedItens = itens
      .filter((it) => it.produtoVariacaoId)
      .map((it) => {
        const variacao = variacoes.find((v) => v.id === Number(it.produtoVariacaoId));
        const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
        return {
          produtoVariacaoId: Number(it.produtoVariacaoId),
          unidadeMedidaId: produto?.unidadeMedidaId ?? unidades[0]?.id ?? 0,
          quantidade: Number(it.quantidade.replace(",", ".")) || 0,
          valorUnitario: Number(it.valorUnitario.replace(",", ".")) || 0,
        };
      });
    if (parsedItens.length === 0) {
      toast({ title: "Adicione ao menos um item.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        numero: numero.trim(),
        fornecedorId: Number(fornecedorId),
        estoqueId: Number(estoqueId),
        dataEmissao: new Date(dataEmissao).toISOString(),
        observacao: observacao.trim() || null,
        itens: parsedItens,
      };
      if (editingId) {
        await apiClient.compras.update(editingId, empresa.id, actor, payload);
        toast({ title: "Nota atualizada", variant: "success" });
      } else {
        await apiClient.compras.create(empresa.id, actor, payload);
        toast({ title: "Nota lançada em aberto", variant: "success" });
      }
      setDialogOpen(false);
      setEditingId(null);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleConfirmAction() {
    if (!empresa || !actor || !confirmAction) return;
    try {
      if (confirmAction.type === "complete") {
        await apiClient.compras.complete(confirmAction.id, empresa.id, actor);
        toast({ title: "Nota concluída — estoque atualizado", variant: "success" });
      } else {
        await apiClient.compras.cancel(confirmAction.id, empresa.id, actor);
        toast({ title: "Nota cancelada", variant: "success" });
      }
      reload();
    } catch (err) {
      toast({ title: "Não foi possível concluir a ação", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.PURCHASES_VIEW}>
      <PageHeader
        title="Notas de entrada"
        description="Compras de matéria-prima e aviamentos. O estoque só é atualizado quando a nota é concluída."
        actions={
          canManage && (
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Nova nota
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar por número ou fornecedor…" />
            <Select value={statusFiltro} onValueChange={setStatusFiltro}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODAS">Todos os status</SelectItem>
                <SelectItem value="ABERTA">Aberta</SelectItem>
                <SelectItem value="CONCLUIDA">Concluída</SelectItem>
                <SelectItem value="CANCELADA">Cancelada</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={ShoppingCart} title="Nenhuma nota encontrada" />
          ) : (
            <div className="flex flex-col gap-3">
              {visible.map((nota) => {
                const fornecedor = fornecedores.find((f) => f.id === nota.fornecedorId);
                const estoque = estoques.find((e) => e.id === nota.estoqueId);
                const nItens = itensPorNota[nota.id] ?? [];
                const expanded = expandedId === nota.id;
                return (
                  <div key={nota.id} className="rounded-lg border">
                    <button
                      className="flex w-full items-center justify-between px-4 py-3 text-left"
                      onClick={() => setExpandedId(expanded ? null : nota.id)}
                    >
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          Nota {nota.numero} · {fornecedor?.nome}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Emitida em {formatDate(nota.dataEmissao)} · destino: {estoque?.nome}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <Money value={nota.valorTotal ?? 0} className="text-sm font-semibold" />
                        <PurchaseNoteStatusBadge status={nota.status} />
                      </div>
                    </button>
                    {expanded && (
                      <div className="border-t px-4 py-3">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Item</TableHead>
                              <TableHead className="text-right">Qtd.</TableHead>
                              <TableHead className="text-right">Vlr. unit.</TableHead>
                              <TableHead className="text-right">Total</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {nItens.map((item) => {
                              const variacao = variacoes.find((v) => v.id === item.produtoVariacaoId);
                              const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                              return (
                                <TableRow key={item.id}>
                                  <TableCell>
                                    {produto?.nome} <span className="text-muted-foreground">({variacao?.sku})</span>
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <Qty value={item.quantidade} />
                                  </TableCell>
                                  <TableCell className="text-right">
                                    <Money value={item.valorUnitario} />
                                  </TableCell>
                                  <TableCell className="text-right font-medium">
                                    <Money value={item.valorTotal} />
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                        {nota.observacao && <p className="mt-2 text-xs text-muted-foreground">Obs.: {nota.observacao}</p>}
                        {canManage && nota.status === "ABERTA" && (
                          <div className="mt-3 flex justify-end gap-2">
                            <Button size="sm" variant="outline" onClick={() => openEdit(nota)}>
                              <Pencil className="h-4 w-4" /> Editar
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => setConfirmAction({ id: nota.id, type: "cancel" })}>
                              <XCircle className="h-4 w-4" /> Cancelar nota
                            </Button>
                            <Button size="sm" onClick={() => setConfirmAction({ id: nota.id, type: "complete" })}>
                              <CheckCircle2 className="h-4 w-4" /> Concluir e atualizar estoque
                            </Button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
              {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
            </div>
          )}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) setEditingId(null); }}>
        <DialogContent size="xl">
          <DialogHeader>
            <DialogTitle>{editingId ? "Editar nota de entrada" : "Nova nota de entrada"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div className="flex flex-col gap-1.5">
                <Label>Número</Label>
                <Input value={numero} onChange={(e) => setNumero(e.target.value)} autoFocus />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Fornecedor</Label>
                <Select value={fornecedorId} onValueChange={setFornecedorId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {fornecedores.map((f) => (
                      <SelectItem key={f.id} value={String(f.id)}>
                        {f.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Estoque destino</Label>
                <Select value={estoqueId} onValueChange={setEstoqueId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoques.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Data de emissão</Label>
                <Input type="date" value={dataEmissao} onChange={(e) => setDataEmissao(e.target.value)} />
              </div>
              <div className="flex flex-col gap-1.5 sm:col-span-2">
                <Label>Observação (opcional)</Label>
                <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={1} />
              </div>
            </div>

            <div className="rounded-md border">
              <div className="flex items-center justify-between border-b px-3 py-2">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Itens</p>
                <Button type="button" size="sm" variant="secondary" onClick={addItem}>
                  <Plus className="h-3.5 w-3.5" /> Item
                </Button>
              </div>
              <div className="flex flex-col gap-2 p-3">
                {itens.map((item, idx) => (
                  <div key={idx} className="grid grid-cols-12 items-end gap-2">
                    <div className="col-span-6 flex flex-col gap-1">
                      <Label className="text-xs">Produto / SKU</Label>
                      <Select value={item.produtoVariacaoId} onValueChange={(v) => updateItem(idx, { produtoVariacaoId: v })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {variacoes
                            .filter((v) => v.ativo)
                            .map((v) => {
                              const produto = produtos.find((p) => p.id === v.produtoId);
                              return (
                                <SelectItem key={v.id} value={String(v.id)}>
                                  {produto?.nome} — {v.sku}
                                </SelectItem>
                              );
                            })}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="col-span-2 flex flex-col gap-1">
                      <Label className="text-xs">Quantidade</Label>
                      <Input value={item.quantidade} onChange={(e) => updateItem(idx, { quantidade: e.target.value })} placeholder="0" />
                    </div>
                    <div className="col-span-3 flex flex-col gap-1">
                      <Label className="text-xs">Valor unitário</Label>
                      <Input value={item.valorUnitario} onChange={(e) => updateItem(idx, { valorUnitario: e.target.value })} placeholder="0,00" />
                    </div>
                    <div className="col-span-1 flex justify-end pb-1.5">
                      <button type="button" onClick={() => removeItem(idx)} className="text-muted-foreground hover:text-destructive">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                {editingId ? "Salvar alterações" : "Lançar nota (em aberto)"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!confirmAction}
        onOpenChange={(o) => !o && setConfirmAction(null)}
        title={confirmAction?.type === "complete" ? "Concluir nota fiscal?" : "Cancelar nota fiscal?"}
        description={
          confirmAction?.type === "complete"
            ? "O estoque será atualizado e o Kardex registrará a entrada. Esta ação não pode ser desfeita."
            : "A nota será marcada como cancelada e não poderá mais ser concluída."
        }
        confirmLabel={confirmAction?.type === "complete" ? "Concluir" : "Cancelar nota"}
        destructive={confirmAction?.type === "cancel"}
        onConfirm={handleConfirmAction}
      />
    </RequirePermission>
  );
}
