"use client";
import * as React from "react";
import {
  Plus,
  Pencil,
  FileSpreadsheet,
  ChevronRight,
  ChevronDown,
  CheckCircle2,
  AlertTriangle,
  Eye,
} from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { PRODUTO_TIPOS } from "@/types";
import type { Produto, ProdutoVariacao, Setor, ProdutoComponente, UnidadeMedida, Cor, Tamanho, ID } from "@/types";

const TIPO_LABEL: Record<string, string> = Object.fromEntries(PRODUTO_TIPOS.map((t) => [t.value, t.label]));

type FichaResumo = Record<ID, { ativos: number; inativos: number }>;

function variacaoLabel(v: ProdutoVariacao, cores: Cor[], tamanhos: Tamanho[]) {
  const cor = cores.find((c) => c.id === v.corId);
  const tamanho = tamanhos.find((t) => t.id === v.tamanhoId);
  const partes = [cor?.nome, tamanho?.nome].filter(Boolean);
  return partes.length > 0 ? partes.join(" • ") : v.sku;
}

function normaliza(texto: string) {
  return texto.toLowerCase();
}

export default function FichasTecnicasPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.BOM_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);
  const [resumo, setResumo] = React.useState<FichaResumo>({});

  // Navegação em árvore Produto Pai → Variação (regra 1 do prompt).
  const [query, setQuery] = React.useState("");
  const [expandidos, setExpandidos] = React.useState<Set<ID>>(new Set());

  // Ficha técnica aberta (Produto Pai → Variação → Ficha → Componentes).
  const [fichaVariacaoId, setFichaVariacaoId] = React.useState<ID | null>(null);
  const [fichaAberta, setFichaAberta] = React.useState(false);
  const [abrirCriacaoAoEntrar, setAbrirCriacaoAoEntrar] = React.useState(false);

  // Seleção global de produto/variação (botão "Criar ficha técnica" do topo).
  const [selecaoOpen, setSelecaoOpen] = React.useState(false);
  const [selecaoProdutoId, setSelecaoProdutoId] = React.useState("");
  const [selecaoVariacaoId, setSelecaoVariacaoId] = React.useState("");

  const [componentes, setComponentes] = React.useState<ProdutoComponente[]>([]);
  const [componentesLoading, setComponentesLoading] = React.useState(false);

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<ProdutoComponente | null>(null);
  const [produtoFilhoId, setProdutoFilhoId] = React.useState("");
  const [setorId, setSetorId] = React.useState("");
  const [quantidade, setQuantidade] = React.useState("");
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, co, ta, s, u, r] = await Promise.all([
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.cores.list(empresa.id),
      apiClient.tamanhos.list(empresa.id),
      apiClient.setores.list(empresa.id),
      apiClient.unidades.list(),
      apiClient.componentes.resumoPorPai(empresa.id),
    ]);
    setProdutos(p);
    setVariacoes(v);
    setCores(co);
    setTamanhos(ta);
    setSetores(s);
    setUnidades(u);
    setResumo(r);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  // Componentes de UMA ficha só são buscados quando ela é realmente aberta
  // (item 15 do prompt — não carregar todas as fichas ao abrir a listagem).
  const reloadComponentes = React.useCallback(async () => {
    if (!empresa || !fichaVariacaoId) {
      setComponentes([]);
      return;
    }
    setComponentesLoading(true);
    setComponentes(await apiClient.componentes.list(fichaVariacaoId, empresa.id));
    setComponentesLoading(false);
  }, [empresa, fichaVariacaoId]);

  React.useEffect(() => {
    reloadComponentes();
  }, [reloadComponentes]);

  // Produtos que podem ser "pai" de uma ficha técnica: semiacabados e
  // produtos de confecção — mesma regra de negócio já usada antes desta
  // mudança (variacoesPai filtrava por produto.tipo PC/SC).
  const produtosPai = React.useMemo(
    () => produtos.filter((p) => p.tipo === "PC" || p.tipo === "SC").sort((a, b) => a.nome.localeCompare(b.nome)),
    [produtos],
  );

  function variacoesDoProduto(produtoId: ID) {
    return variacoes.filter((v) => v.produtoId === produtoId);
  }

  function statusDaVariacao(variacaoId: ID) {
    const r = resumo[variacaoId];
    if (!r || (r.ativos === 0 && r.inativos === 0)) return "SEM_FICHA" as const;
    if (r.ativos > 0) return "ATIVA" as const;
    return "INATIVA" as const;
  }

  const isSearching = query.trim().length > 0;
  const termo = normaliza(query.trim());

  // Monta a árvore já filtrada pela pesquisa (nome do produto, variação e
  // SKU), preservando a hierarquia Produto Pai → Variação (item 7).
  const arvore = React.useMemo(() => {
    return produtosPai
      .map((produto) => {
        const todasVariacoes = variacoesDoProduto(produto.id);
        if (!isSearching) return { produto, variacoesVisiveis: todasVariacoes, temResultado: true };

        const produtoBate = normaliza(produto.nome).includes(termo);
        const variacoesVisiveis = produtoBate
          ? todasVariacoes
          : todasVariacoes.filter((v) => {
              const label = normaliza(variacaoLabel(v, cores, tamanhos));
              return normaliza(v.sku).includes(termo) || label.includes(termo);
            });
        return { produto, variacoesVisiveis, temResultado: produtoBate || variacoesVisiveis.length > 0 };
      })
      .filter((grupo) => grupo.temResultado);
  }, [produtosPai, variacoes, cores, tamanhos, isSearching, termo]);

  function toggleExpandido(produtoId: ID) {
    setExpandidos((prev) => {
      const next = new Set(prev);
      if (next.has(produtoId)) next.delete(produtoId);
      else next.add(produtoId);
      return next;
    });
  }

  function abrirFicha(variacaoId: ID, iniciarCriacao: boolean) {
    setFichaVariacaoId(variacaoId);
    setAbrirCriacaoAoEntrar(iniciarCriacao);
    setFichaAberta(true);
  }

  // Ao entrar na ficha de uma variação sem componentes ainda, já abre o
  // formulário de criação — o usuário não precisa pesquisar/selecionar o
  // SKU novamente (itens 5 e 6 do prompt).
  React.useEffect(() => {
    if (fichaAberta && abrirCriacaoAoEntrar && !componentesLoading) {
      openCreate();
      setAbrirCriacaoAoEntrar(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fichaAberta, abrirCriacaoAoEntrar, componentesLoading]);

  function openCreate() {
    setEditing(null);
    setProdutoFilhoId("");
    setSetorId("");
    setQuantidade("");
    setObservacao("");
    setDialogOpen(true);
  }

  function openEdit(item: ProdutoComponente) {
    setEditing(item);
    setProdutoFilhoId(String(item.produtoFilhoId));
    setSetorId(item.setorId ? String(item.setorId) : "");
    setQuantidade(String(item.quantidade).replace(".", ","));
    setObservacao(item.observacao ?? "");
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !fichaVariacaoId || !produtoFilhoId || !quantidade) {
      toast({ title: "Preencha o componente e a quantidade.", variant: "error" });
      return;
    }
    const quantidadeNum = Number(quantidade.replace(",", "."));
    if (!Number.isFinite(quantidadeNum) || quantidadeNum <= 0) {
      toast({ title: "A quantidade deve ser maior que zero.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.componentes.update(editing.id, empresa.id, actor, {
          setorId: setorId ? Number(setorId) : null,
          quantidade: quantidadeNum,
          observacao: observacao.trim() || null,
        });
        toast({ title: "Ficha técnica atualizada", variant: "success" });
      } else {
        await apiClient.componentes.add(empresa.id, actor, {
          produtoPaiId: fichaVariacaoId,
          produtoFilhoId: Number(produtoFilhoId),
          setorId: setorId ? Number(setorId) : null,
          quantidade: quantidadeNum,
          observacao: observacao.trim() || null,
        });
        toast({ title: "Componente adicionado à ficha técnica", variant: "success" });
      }
      setDialogOpen(false);
      setEditing(null);
      setProdutoFilhoId("");
      setSetorId("");
      setQuantidade("");
      setObservacao("");
      await reloadComponentes();
      // Atualiza o resumo da árvore (a variação passa a ter ficha, ou o
      // status dela pode ter mudado) sem recarregar produtos/variações.
      const r = await apiClient.componentes.resumoPorPai(empresa.id);
      setResumo(r);
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: ProdutoComponente) {
    if (!empresa) return;
    await apiClient.componentes.toggle(item.id, empresa.id);
    toast({ title: item.ativo ? "Componente inativado" : "Componente ativado", variant: "success" });
    await reloadComponentes();
    const r = await apiClient.componentes.resumoPorPai(empresa.id);
    setResumo(r);
  }

  function abrirSelecaoGlobal() {
    setSelecaoProdutoId("");
    setSelecaoVariacaoId("");
    setSelecaoOpen(true);
  }

  function confirmarSelecaoGlobal() {
    if (!selecaoVariacaoId) return;
    const variacaoId = Number(selecaoVariacaoId);
    const status = statusDaVariacao(variacaoId);
    setSelecaoOpen(false);
    abrirFicha(variacaoId, status === "SEM_FICHA");
  }

  if (!empresa) return null;

  const fichaVariacao = variacoes.find((v) => v.id === fichaVariacaoId);
  const fichaProduto = fichaVariacao ? produtos.find((p) => p.id === fichaVariacao.produtoId) : undefined;

  return (
    <RequirePermission perm={PERMISSIONS.BOM_MANAGE}>
      <PageHeader
        title="Ficha técnica"
        description="Componentes consumidos por cada variação de produto de confecção ou semiacabado."
        actions={
          canManage && (
            <Button size="sm" onClick={abrirSelecaoGlobal}>
              <Plus className="h-4 w-4" /> Criar ficha técnica
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4">
            <SearchInput value={query} onChange={setQuery} placeholder="Pesquisar produto, variação ou SKU..." className="sm:w-96" />
          </div>

          {arvore.length === 0 ? (
            <EmptyState
              icon={FileSpreadsheet}
              title={isSearching ? "Nenhum produto ou variação encontrado." : "Nenhum produto encontrado."}
            />
          ) : (
            <div className="flex flex-col gap-3">
              {arvore.map(({ produto, variacoesVisiveis }) => {
                const aberto = isSearching || expandidos.has(produto.id);
                return (
                  <div key={produto.id} className="rounded-lg border">
                    <button
                      type="button"
                      onClick={() => toggleExpandido(produto.id)}
                      className="flex w-full items-center justify-between gap-2 px-4 py-3 text-left hover:bg-secondary/50"
                    >
                      <div className="flex items-center gap-2">
                        {aberto ? (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        )}
                        <span className="text-sm font-semibold text-foreground">{produto.nome}</span>
                        <Badge variant="outline">{TIPO_LABEL[produto.tipo] ?? produto.tipo}</Badge>
                        {!produto.ativo && <ActiveBadge ativo={produto.ativo} />}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {variacoesDoProduto(produto.id).length} variação(ões)
                      </span>
                    </button>

                    {aberto && (
                      <div className="border-t">
                        {variacoesVisiveis.length === 0 ? (
                          <div className="px-4 py-4">
                            <p className="text-sm text-muted-foreground">Nenhuma variação cadastrada para este produto.</p>
                          </div>
                        ) : (
                          variacoesVisiveis.map((v) => {
                            const status = statusDaVariacao(v.id);
                            return (
                              <div
                                key={v.id}
                                className="flex flex-col gap-2 border-b px-4 py-3 last:border-b-0 sm:flex-row sm:items-center sm:justify-between"
                              >
                                <div>
                                  <p className="text-sm font-medium text-foreground">{variacaoLabel(v, cores, tamanhos)}</p>
                                  <div className="mt-0.5 flex flex-wrap items-center gap-2">
                                    <span className="font-mono text-xs text-muted-foreground">SKU: {v.sku}</span>
                                    {!v.ativo && <ActiveBadge ativo={v.ativo} />}
                                    {status === "ATIVA" && (
                                      <Badge variant="success">
                                        <CheckCircle2 className="h-3 w-3" /> Ficha técnica
                                      </Badge>
                                    )}
                                    {status === "INATIVA" && (
                                      <Badge variant="warning">
                                        <AlertTriangle className="h-3 w-3" /> Ficha técnica inativa
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                                <div className="flex shrink-0 justify-end">
                                  {status === "SEM_FICHA" ? (
                                    canManage ? (
                                      <Button variant="outline" size="sm" onClick={() => abrirFicha(v.id, true)}>
                                        <Plus className="h-3.5 w-3.5" /> Criar ficha técnica
                                      </Button>
                                    ) : (
                                      <span className="text-xs text-muted-foreground">Sem ficha técnica</span>
                                    )
                                  ) : (
                                    <Button variant="ghost" size="sm" onClick={() => abrirFicha(v.id, false)}>
                                      {canManage ? (
                                        <>
                                          <Pencil className="h-3.5 w-3.5" /> Editar
                                        </>
                                      ) : (
                                        <>
                                          <Eye className="h-3.5 w-3.5" /> Visualizar
                                        </>
                                      )}
                                    </Button>
                                  )}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Seleção de Produto Pai → Variação para o botão global "Criar ficha
          técnica", reaproveitando a mesma listagem de produtos/variações da
          árvore (item 6 do prompt). */}
      <Dialog open={selecaoOpen} onOpenChange={setSelecaoOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>Selecionar produto e variação</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label>Produto pai</Label>
              <Select
                value={selecaoProdutoId}
                onValueChange={(value) => {
                  setSelecaoProdutoId(value);
                  setSelecaoVariacaoId("");
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione um produto de confecção ou semiacabado" />
                </SelectTrigger>
                <SelectContent>
                  {produtosPai.map((p) => (
                    <SelectItem key={p.id} value={String(p.id)}>
                      {p.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Variação (SKU)</Label>
              <Select value={selecaoVariacaoId} onValueChange={setSelecaoVariacaoId} disabled={!selecaoProdutoId}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma variação" />
                </SelectTrigger>
                <SelectContent>
                  {selecaoProdutoId &&
                    variacoesDoProduto(Number(selecaoProdutoId)).map((v) => (
                      <SelectItem key={v.id} value={String(v.id)}>
                        {variacaoLabel(v, cores, tamanhos)} — {v.sku}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setSelecaoOpen(false)}>
              Cancelar
            </Button>
            <Button type="button" disabled={!selecaoVariacaoId} onClick={confirmarSelecaoGlobal}>
              Continuar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Ficha técnica da variação selecionada: Produto Pai → Variação →
          Ficha → Componentes (item 9 do prompt). Reaproveita 100% da lógica
          existente de listar/adicionar/editar/inativar componentes. */}
      <Sheet
        open={fichaAberta}
        onOpenChange={(open) => {
          setFichaAberta(open);
          if (!open) {
            setFichaVariacaoId(null);
            setAbrirCriacaoAoEntrar(false);
          }
        }}
      >
        <SheetContent side="right" className="flex w-full flex-col gap-4 overflow-y-auto sm:max-w-none lg:w-[60vw] lg:min-w-[720px]">
          <SheetHeader className="text-left">
            <SheetTitle className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-muted-foreground" /> Ficha técnica
            </SheetTitle>
            {fichaProduto && fichaVariacao && (
              <div className="pt-1">
                <p className="text-sm font-medium text-foreground">{fichaProduto.nome}</p>
                <p className="text-xs text-muted-foreground">
                  {variacaoLabel(fichaVariacao, cores, tamanhos)} — SKU: {fichaVariacao.sku}
                </p>
              </div>
            )}
          </SheetHeader>

          {componentesLoading ? (
            <LoadingState />
          ) : (
            <div className="rounded-lg border">
              <div className="flex items-center justify-between border-b px-4 py-3">
                <p className="text-sm font-medium text-foreground">Componentes</p>
                {canManage && (
                  <Button size="sm" onClick={openCreate}>
                    <Plus className="h-4 w-4" /> Adicionar componente
                  </Button>
                )}
              </div>
              {componentes.length === 0 ? (
                <div className="p-5">
                  <EmptyState title="Nenhum componente cadastrado para esta variação" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Componente</TableHead>
                      <TableHead>Setor de consumo</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead>Observação</TableHead>
                      <TableHead>Status</TableHead>
                      {canManage && <TableHead className="text-right">Ações</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {componentes.map((c) => {
                      const filhoVariacao = variacoes.find((v) => v.id === c.produtoFilhoId);
                      const filhoProduto = filhoVariacao ? produtos.find((p) => p.id === filhoVariacao.produtoId) : undefined;
                      const unidade = unidades.find((u) => u.id === filhoProduto?.unidadeMedidaId);
                      const setor = setores.find((s) => s.id === c.setorId);
                      return (
                        <TableRow key={c.id}>
                          <TableCell className="font-medium text-foreground">
                            {filhoProduto?.nome} <span className="text-muted-foreground">({filhoVariacao?.sku})</span>
                          </TableCell>
                          <TableCell className="text-muted-foreground">{setor?.nome ?? "—"}</TableCell>
                          <TableCell className="text-right tabular-nums">
                            <Qty value={c.quantidade} unit={unidade?.sigla} />
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{c.observacao ?? "—"}</TableCell>
                          <TableCell>
                            <ActiveBadge ativo={c.ativo} />
                          </TableCell>
                          {canManage && (
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-3">
                                <button onClick={() => openEdit(c)} className="text-muted-foreground hover:text-foreground" aria-label="Editar componente">
                                  <Pencil className="h-3.5 w-3.5" />
                                </button>
                                <Switch checked={c.ativo} onCheckedChange={() => handleToggle(c)} />
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </div>
          )}
        </SheetContent>
      </Sheet>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
      >
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar componente" : "Adicionar componente"}</DialogTitle>
          </DialogHeader>
          {fichaProduto && fichaVariacao && (
            <p className="-mt-2 text-xs text-muted-foreground">
              Produto: {fichaProduto.nome} · Variação: {variacaoLabel(fichaVariacao, cores, tamanhos)} · SKU: {fichaVariacao.sku}
            </p>
          )}
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label>Componente (matéria-prima / aviamento / semiacabado)</Label>
              <Select value={produtoFilhoId} onValueChange={setProdutoFilhoId} disabled={!!editing}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {variacoes
                    .filter((v) => v.id !== fichaVariacaoId)
                    .map((v) => {
                      const produto = produtos.find((p) => p.id === v.produtoId);
                      return (
                        <SelectItem key={v.id} value={String(v.id)}>
                          {produto?.nome} — {v.sku}
                        </SelectItem>
                      );
                    })}
                </SelectContent>
              </Select>
              {editing && <p className="text-xs text-muted-foreground">Para trocar o componente, inative este e adicione um novo.</p>}
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Setor de consumo (opcional)</Label>
              <Select value={setorId} onValueChange={setSetorId}>
                <SelectTrigger>
                  <SelectValue placeholder="Nenhum" />
                </SelectTrigger>
                <SelectContent>
                  {setores.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Quantidade (por unidade produzida)</Label>
              <Input value={quantidade} onChange={(e) => setQuantidade(e.target.value)} placeholder="Ex.: 0,85" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Observação (opcional)</Label>
              <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
