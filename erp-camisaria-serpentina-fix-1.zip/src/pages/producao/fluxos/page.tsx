"use client";
import * as React from "react";
import { Plus, Pencil, Factory, Route, GripVertical, X } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { FluxoEtapasSerpentina } from "@/components/producao/FluxoEtapasSerpentina";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import type { Setor, Fornecedor, FluxoProducao, FluxoProducaoEtapa } from "@/types";

export default function FluxosSetoresPage() {
  const { empresa, hasPermission } = useAuth();
  const canManageSetores = hasPermission(PERMISSIONS.SECTORS_MANAGE);
  const canManageFluxos = hasPermission(PERMISSIONS.FLOWS_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [fornecedores, setFornecedores] = React.useState<Fornecedor[]>([]);
  const [fluxos, setFluxos] = React.useState<FluxoProducao[]>([]);
  const [etapasPorFluxo, setEtapasPorFluxo] = React.useState<Record<number, FluxoProducaoEtapa[]>>({});

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [s, f, fl] = await Promise.all([
      apiClient.setores.list(empresa.id, true),
      apiClient.fornecedores.list(empresa.id),
      apiClient.fluxos.list(empresa.id, true),
    ]);
    setSetores(s);
    setFornecedores(f);
    setFluxos(fl);
    const etapas: Record<number, FluxoProducaoEtapa[]> = {};
    await Promise.all(
      fl.map(async (flux) => {
        etapas[flux.id] = await apiClient.fluxos.etapas(flux.id, empresa.id);
      }),
    );
    setEtapasPorFluxo(etapas);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.FLOWS_MANAGE}>
      <PageHeader title="Fluxos e setores" description="Setores de produção (internos e terceiros) e os roteiros que as ordens de produção seguem." />
      {loading ? (
        <LoadingState />
      ) : (
        <Tabs defaultValue="setores">
          <TabsList>
            <TabsTrigger value="setores">Setores</TabsTrigger>
            <TabsTrigger value="fluxos">Fluxos de produção</TabsTrigger>
          </TabsList>
          <TabsContent value="setores">
            <SetoresPanel setores={setores} fornecedores={fornecedores} canManage={canManageSetores} onChanged={reload} empresaId={empresa.id} />
          </TabsContent>
          <TabsContent value="fluxos">
            <FluxosPanel fluxos={fluxos} setores={setores} etapasPorFluxo={etapasPorFluxo} canManage={canManageFluxos} onChanged={reload} empresaId={empresa.id} />
          </TabsContent>
        </Tabs>
      )}
    </RequirePermission>
  );
}

// ---------------------------------------------------------------
// Setores
// ---------------------------------------------------------------
function SetoresPanel({
  setores,
  fornecedores,
  canManage,
  onChanged,
  empresaId,
}: {
  setores: Setor[];
  fornecedores: Fornecedor[];
  canManage: boolean;
  onChanged: () => void;
  empresaId: number;
}) {
  const { toast } = useToast();
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Setor | null>(null);
  const [form, setForm] = React.useState({ codigo: "", nome: "", tipo: "INTERNO" as "INTERNO" | "TERCEIRO", fornecedorId: "" });
  const [submitting, setSubmitting] = React.useState(false);

  const filtered = setores.filter((s) => s.nome.toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setForm({ codigo: "", nome: "", tipo: "INTERNO", fornecedorId: "" });
    setDialogOpen(true);
  }
  function openEdit(item: Setor) {
    setEditing(item);
    setForm({ codigo: item.codigo ?? "", nome: item.nome, tipo: item.tipo, fornecedorId: item.fornecedorId ? String(item.fornecedorId) : "" });
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.nome.trim()) return;
    if (form.tipo === "TERCEIRO" && !form.fornecedorId) {
      toast({ title: "Selecione o fornecedor terceirizado", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      const data = {
        codigo: form.codigo.trim() || null,
        nome: form.nome.trim(),
        tipo: form.tipo,
        fornecedorId: form.tipo === "TERCEIRO" ? Number(form.fornecedorId) : null,
        responsavelUsuarioId: editing?.responsavelUsuarioId ?? null,
      };
      if (editing) {
        await apiClient.setores.update(editing.id, empresaId, data);
        toast({ title: "Setor atualizado", variant: "success" });
      } else {
        await apiClient.setores.create(empresaId, data);
        toast({ title: "Setor cadastrado", variant: "success" });
      }
      setDialogOpen(false);
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: Setor) {
    try {
      await apiClient.setores.toggle(item.id, empresaId);
      toast({ title: item.ativo ? "Setor inativado" : "Setor ativado", variant: "success" });
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar setores…" />
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4" /> Novo setor
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Factory} title="Nenhum setor encontrado" />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Código</TableHead>
                <TableHead>Nome</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Fornecedor</TableHead>
                <TableHead>Status</TableHead>
                {canManage && <TableHead className="text-right">Ações</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">{item.codigo || "—"}</TableCell>
                  <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                  <TableCell>
                    <Badge variant={item.tipo === "INTERNO" ? "outline" : "accent"}>{item.tipo === "INTERNO" ? "Interno" : "Terceiro"}</Badge>
                  </TableCell>
                  <TableCell className="text-muted-foreground">
                    {item.fornecedorId ? fornecedores.find((f) => f.id === item.fornecedorId)?.nome ?? "—" : "—"}
                  </TableCell>
                  <TableCell>
                    <ActiveBadge ativo={item.ativo} />
                  </TableCell>
                  {canManage && (
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar setor" : "Novo setor"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="scodigo">Código</Label>
                <Input id="scodigo" value={form.codigo} onChange={(e) => setForm({ ...form, codigo: e.target.value })} placeholder="Ex.: COS" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Tipo</Label>
                <Select value={form.tipo} onValueChange={(v) => setForm({ ...form, tipo: v as "INTERNO" | "TERCEIRO" })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="INTERNO">Interno</SelectItem>
                    <SelectItem value="TERCEIRO">Terceiro (facção)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="snome">Nome</Label>
              <Input id="snome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
            </div>
            {form.tipo === "TERCEIRO" && (
              <div className="flex flex-col gap-1.5">
                <Label>Fornecedor (facção)</Label>
                <Select value={form.fornecedorId} onValueChange={(v) => setForm({ ...form, fornecedorId: v })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o fornecedor" />
                  </SelectTrigger>
                  <SelectContent>
                    {fornecedores.map((f) => (
                      <SelectItem key={f.id} value={String(f.id)}>
                        {f.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ---------------------------------------------------------------
// Fluxos de produção
// ---------------------------------------------------------------
function FluxosPanel({
  fluxos,
  setores,
  etapasPorFluxo,
  canManage,
  onChanged,
  empresaId,
}: {
  fluxos: FluxoProducao[];
  setores: Setor[];
  etapasPorFluxo: Record<number, FluxoProducaoEtapa[]>;
  canManage: boolean;
  onChanged: () => void;
  empresaId: number;
}) {
  const { toast } = useToast();
  const { actor } = useAuth();
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<FluxoProducao | null>(null);
  const [nome, setNome] = React.useState("");
  const [descricao, setDescricao] = React.useState("");
  const [etapas, setEtapas] = React.useState<number[]>([]);
  const [addSetorId, setAddSetorId] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const setoresAtivos = setores.filter((s) => s.ativo);

  function openCreate() {
    setEditing(null);
    setNome("");
    setDescricao("");
    setEtapas([]);
    setAddSetorId("");
    setDialogOpen(true);
  }

  function openEdit(fluxo: FluxoProducao) {
    setEditing(fluxo);
    setNome(fluxo.nome);
    setDescricao(fluxo.descricao ?? "");
    setEtapas((etapasPorFluxo[fluxo.id] ?? []).map((e) => e.setorId));
    setAddSetorId("");
    setDialogOpen(true);
  }

  function addEtapa() {
    if (!addSetorId) return;
    setEtapas((prev) => [...prev, Number(addSetorId)]);
    setAddSetorId("");
  }
  function removeEtapa(idx: number) {
    setEtapas((prev) => prev.filter((_, i) => i !== idx));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!nome.trim() || etapas.length === 0) {
      toast({ title: "Informe o nome e ao menos uma etapa", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.fluxos.update(editing.id, empresaId, actor ?? { id: 0, nome: "Sistema" }, {
          nome: nome.trim(),
          descricao: descricao.trim() || null,
          etapasSetorIds: etapas,
        });
        toast({ title: "Fluxo atualizado", variant: "success" });
      } else {
        await apiClient.fluxos.create(empresaId, actor ?? { id: 0, nome: "Sistema" }, nome.trim(), descricao.trim() || null, etapas);
        toast({ title: "Fluxo criado", variant: "success" });
      }
      setDialogOpen(false);
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: FluxoProducao) {
    try {
      await apiClient.fluxos.toggle(item.id, empresaId);
      toast({ title: item.ativo ? "Fluxo inativado" : "Fluxo ativado", variant: "success" });
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  return (
    <div>
      <div className="mb-4 flex justify-end">
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4" /> Novo fluxo
          </Button>
        )}
      </div>

      {fluxos.length === 0 ? (
        <EmptyState icon={Route} title="Nenhum fluxo cadastrado" />
      ) : (
        <div className="flex flex-col gap-3">
          {fluxos.map((fluxo) => (
            <div key={fluxo.id} className="rounded-lg border p-4">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-foreground">{fluxo.nome}</p>
                    <ActiveBadge ativo={fluxo.ativo} />
                  </div>
                  {fluxo.descricao && <p className="mt-0.5 text-xs text-muted-foreground">{fluxo.descricao}</p>}
                </div>
                {canManage && (
                  <div className="flex items-center gap-3">
                    <button onClick={() => openEdit(fluxo)} className="text-muted-foreground hover:text-foreground">
                      <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <Switch checked={fluxo.ativo} onCheckedChange={() => handleToggle(fluxo)} />
                  </div>
                )}
              </div>
              <FluxoEtapasSerpentina etapas={etapasPorFluxo[fluxo.id] ?? []} setores={setores} />
            </div>
          ))}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="md">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar fluxo de produção" : "Novo fluxo de produção"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="flnome">Nome</Label>
              <Input id="flnome" value={nome} onChange={(e) => setNome(e.target.value)} autoFocus />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="fldesc">Descrição (opcional)</Label>
              <Textarea id="fldesc" value={descricao} onChange={(e) => setDescricao(e.target.value)} rows={2} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Etapas (na ordem)</Label>
              <div className="flex gap-2">
                <Select value={addSetorId} onValueChange={setAddSetorId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um setor" />
                  </SelectTrigger>
                  <SelectContent>
                    {setoresAtivos.map((s) => (
                      <SelectItem key={s.id} value={String(s.id)}>
                        {s.nome} {s.tipo === "TERCEIRO" ? "(terceiro)" : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button type="button" variant="secondary" onClick={addEtapa}>
                  Adicionar
                </Button>
              </div>
              {etapas.length > 0 && (
                <div className="mt-2 flex flex-col gap-1.5 rounded-md border p-2">
                  {etapas.map((setorId, idx) => (
                    <div key={idx} className="flex items-center gap-2 rounded-md bg-secondary/50 px-2 py-1.5 text-sm">
                      <GripVertical className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="w-5 text-xs text-muted-foreground">{idx + 1}.</span>
                      <span className="flex-1 text-foreground">{setores.find((s) => s.id === setorId)?.nome}</span>
                      <button type="button" onClick={() => removeEtapa(idx)} className="text-muted-foreground hover:text-destructive">
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
