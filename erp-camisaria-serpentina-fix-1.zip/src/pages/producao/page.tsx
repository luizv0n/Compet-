"use client";
import * as React from "react";
import { Link } from "@/lib/next-compat";
import { Plus, Factory, ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { OrdemProducaoStatusBadge } from "@/components/common/StatusBadge";
import { Qty } from "@/components/common/Money";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatDate } from "@/lib/utils";
import type { Produto, ProdutoVariacao, Estoque, FluxoProducao, OrdemProducao, OrdemProducaoStatus } from "@/types";
import { OP_STATUS_LABEL } from "@/types";

export default function ProducaoPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.PRODUCTION_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [ops, setOps] = React.useState<OrdemProducao[]>([]);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [fluxos, setFluxos] = React.useState<FluxoProducao[]>([]);

  const [query, setQuery] = React.useState("");
  const [statusFiltro, setStatusFiltro] = React.useState("TODOS");

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [variacaoId, setVariacaoId] = React.useState("");
  const [fluxoId, setFluxoId] = React.useState("");
  const [quantidade, setQuantidade] = React.useState("");
  const [lote, setLote] = React.useState("");
  const [estoqueOrigemId, setEstoqueOrigemId] = React.useState("");
  const [estoqueDestinoId, setEstoqueDestinoId] = React.useState("");
  const [dataAbertura, setDataAbertura] = React.useState(() => new Date().toISOString().slice(0, 10));
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [o, p, v, e, f] = await Promise.all([
      apiClient.producao.list(empresa.id),
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.estoques.list(empresa.id),
      apiClient.fluxos.list(empresa.id),
    ]);
    setOps(o);
    setProdutos(p);
    setVariacoes(v);
    setEstoques(e);
    setFluxos(f);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const filtered = ops.filter((op) => {
    if (statusFiltro !== "TODOS" && op.status !== statusFiltro) return false;
    if (query) {
      const variacao = variacoes.find((v) => v.id === op.produtoVariacaoId);
      const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
      if (!`${op.codigo} ${produto?.nome ?? ""} ${variacao?.sku ?? ""}`.toLowerCase().includes(query.toLowerCase())) return false;
    }
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, statusFiltro]);

  // Uma OP só produz um SKU de confecção (PC) ou semiacabado (SC) — MP e AV
  // são comprados, não produzidos (mesmo filtro usado em Ficha Técnica).
  const variacoesProduziveis = variacoes.filter((v) => {
    if (!v.ativo) return false;
    const produto = produtos.find((p) => p.id === v.produtoId);
    return produto && (produto.tipo === "PC" || produto.tipo === "SC");
  });

  function openCreate() {
    setVariacaoId("");
    setFluxoId("");
    setQuantidade("");
    setLote("");
    setEstoqueOrigemId("");
    setEstoqueDestinoId("");
    setDataAbertura(new Date().toISOString().slice(0, 10));
    setObservacao("");
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!variacaoId || !fluxoId || !quantidade) {
      toast({ title: "Preencha produto, fluxo e quantidade.", variant: "error" });
      return;
    }
    const quantidadeNum = Number(quantidade);
    if (!Number.isInteger(quantidadeNum) || quantidadeNum <= 0) {
      toast({ title: "A quantidade prevista deve ser um número inteiro maior que zero.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      await apiClient.producao.create(empresa.id, actor, {
        produtoVariacaoId: Number(variacaoId),
        fluxoProducaoId: Number(fluxoId),
        quantidadePrevista: quantidadeNum,
        lote: lote.trim() || null,
        estoqueOrigemId: estoqueOrigemId ? Number(estoqueOrigemId) : null,
        estoqueDestinoId: estoqueDestinoId ? Number(estoqueDestinoId) : null,
        dataAbertura: new Date(dataAbertura).toISOString(),
        observacao: observacao.trim() || null,
      });
      toast({ title: "Ordem de produção criada — aguardando liberação", variant: "success" });
      setDialogOpen(false);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível criar a OP", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.PRODUCTION_VIEW}>
      <PageHeader
        title="Ordens de produção"
        description="Cada OP produz uma variação (SKU) seguindo um fluxo de setores."
        actions={
          canManage && (
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Nova OP
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar por código, produto ou SKU…" />
            <Select value={statusFiltro} onValueChange={setStatusFiltro}>
              <SelectTrigger className="w-full sm:w-52">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODOS">Todos os status</SelectItem>
                {(Object.keys(OP_STATUS_LABEL) as OrdemProducaoStatus[]).map((s) => (
                  <SelectItem key={s} value={s}>
                    {OP_STATUS_LABEL[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {filtered.length === 0 ? (
            <EmptyState icon={Factory} title="Nenhuma ordem de produção encontrada" />
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Produto / SKU</TableHead>
                    <TableHead>Lote</TableHead>
                    <TableHead className="w-44">Progresso</TableHead>
                    <TableHead>Abertura</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {visible.map((op) => {
                    const variacao = variacoes.find((v) => v.id === op.produtoVariacaoId);
                    const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                    return (
                      <TableRow key={op.id}>
                        <TableCell className="font-mono text-xs font-medium text-foreground">{op.codigo}</TableCell>
                        <TableCell>
                          <Link href={`/producao/${op.id}`} className="hover:underline">
                            {produto?.nome} <span className="text-muted-foreground">({variacao?.sku})</span>
                          </Link>
                        </TableCell>
                        <TableCell className="text-muted-foreground">{op.lote ?? "—"}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress
                              value={op.quantidadePrevista > 0 ? (op.quantidadeProduzida / op.quantidadePrevista) * 100 : 0}
                              className="h-1.5 w-16"
                            />
                            <span className="whitespace-nowrap text-xs tabular-nums text-muted-foreground">
                              <Qty value={op.quantidadeProduzida} decimals={0} />/<Qty value={op.quantidadePrevista} decimals={0} />
                            </span>
                            {op.quantidadeRefugada > 0 && (
                              <span className="whitespace-nowrap text-xs tabular-nums text-destructive">
                                −<Qty value={op.quantidadeRefugada} decimals={0} />
                              </span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{formatDate(op.dataAbertura)}</TableCell>
                        <TableCell>
                          <OrdemProducaoStatusBadge status={op.status} />
                        </TableCell>
                        <TableCell className="text-right">
                          <Link href={`/producao/${op.id}`}>
                            <Button variant="ghost" size="sm">
                              Detalhes <ChevronRight className="h-3.5 w-3.5" />
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>Nova ordem de produção</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div className="flex flex-col gap-1.5 sm:col-span-2">
                <Label>Produto / SKU</Label>
                <Select value={variacaoId} onValueChange={setVariacaoId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o SKU a produzir" />
                  </SelectTrigger>
                  <SelectContent>
                    {variacoesProduziveis.map((v) => {
                      const produto = produtos.find((p) => p.id === v.produtoId);
                      return (
                        <SelectItem key={v.id} value={String(v.id)}>
                          {produto?.nome} — {v.sku}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Fluxo de produção</Label>
                <Select value={fluxoId} onValueChange={setFluxoId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o fluxo" />
                  </SelectTrigger>
                  <SelectContent>
                    {fluxos.map((f) => (
                      <SelectItem key={f.id} value={String(f.id)}>
                        {f.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Quantidade prevista</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  min={1}
                  step={1}
                  value={quantidade}
                  onChange={(e) => setQuantidade(e.target.value)}
                  placeholder="Ex.: 100"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Lote (opcional)</Label>
                <Input value={lote} onChange={(e) => setLote(e.target.value)} placeholder="Ex.: L-2026-004" />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Data de abertura</Label>
                <Input type="date" value={dataAbertura} onChange={(e) => setDataAbertura(e.target.value)} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Estoque de origem (consumo)</Label>
                <Select value={estoqueOrigemId} onValueChange={setEstoqueOrigemId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Nenhum" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoques.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Estoque de destino (produto acabado)</Label>
                <Select value={estoqueDestinoId} onValueChange={setEstoqueDestinoId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Nenhum" />
                  </SelectTrigger>
                  <SelectContent>
                    {estoques.map((e) => (
                      <SelectItem key={e.id} value={String(e.id)}>
                        {e.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5 sm:col-span-2">
                <Label>Observação (opcional)</Label>
                <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Criar OP (planejada)
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
