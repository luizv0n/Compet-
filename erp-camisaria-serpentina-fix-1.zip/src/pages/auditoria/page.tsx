"use client";
import * as React from "react";
import { History } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatDateTime } from "@/lib/utils";
import type { AuditLogEntry, AuditAction, Usuario } from "@/types";

const ACTION_LABEL: Record<AuditAction, string> = {
  CRIACAO: "Criação",
  EDICAO: "Edição",
  ATIVACAO: "Ativação",
  INATIVACAO: "Inativação",
  ENTRADA: "Entrada",
  BAIXA: "Baixa",
  TRANSFERENCIA: "Transferência",
  CONCLUSAO_COMPRA: "Conclusão de compra",
  PRODUCAO: "Produção",
  REFUGO: "Refugo",
  LOGIN: "Login",
};

const ACTION_VARIANT: Record<AuditAction, "default" | "success" | "warning" | "destructive" | "info" | "accent"> = {
  CRIACAO: "info",
  EDICAO: "default",
  ATIVACAO: "success",
  INATIVACAO: "warning",
  ENTRADA: "success",
  BAIXA: "destructive",
  TRANSFERENCIA: "accent",
  CONCLUSAO_COMPRA: "success",
  PRODUCAO: "accent",
  REFUGO: "destructive",
  LOGIN: "default",
};

export default function AuditoriaPage() {
  const { empresa } = useAuth();
  const [loading, setLoading] = React.useState(true);
  const [entries, setEntries] = React.useState<AuditLogEntry[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);

  const [query, setQuery] = React.useState("");
  const [usuarioFiltro, setUsuarioFiltro] = React.useState("TODOS");
  const [acaoFiltro, setAcaoFiltro] = React.useState("TODAS");

  React.useEffect(() => {
    if (!empresa) return;
    (async () => {
      setLoading(true);
      const [e, u] = await Promise.all([apiClient.auditoria.list(empresa.id), apiClient.equipe.list(empresa.id, true)]);
      setEntries(e);
      setUsuarios(u);
      setLoading(false);
    })();
  }, [empresa]);


  const filtered = entries.filter((e) => {
    if (usuarioFiltro !== "TODOS" && e.usuarioId !== Number(usuarioFiltro)) return false;
    if (acaoFiltro !== "TODAS" && e.acao !== acaoFiltro) return false;
    if (query && !`${e.descricao} ${e.entidade} ${e.usuarioNome}`.toLowerCase().includes(query.toLowerCase())) return false;
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, usuarioFiltro, acaoFiltro]);

  if (!empresa) return null;
  if (loading) return <LoadingState />;

  return (
    <RequirePermission perm={PERMISSIONS.AUDIT_VIEW}>
      <PageHeader title="Auditoria" description="Histórico cronológico de ações relevantes no sistema." />

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:flex-wrap sm:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar na descrição…" />
        <Select value={usuarioFiltro} onValueChange={setUsuarioFiltro}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODOS">Todos os usuários</SelectItem>
            {usuarios.map((u) => (
              <SelectItem key={u.id} value={String(u.id)}>
                {u.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={acaoFiltro} onValueChange={setAcaoFiltro}>
          <SelectTrigger className="w-full sm:w-52">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODAS">Todas as ações</SelectItem>
            {(Object.keys(ACTION_LABEL) as AuditAction[]).map((a) => (
              <SelectItem key={a} value={a}>
                {ACTION_LABEL[a]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={History} title="Nenhum registro de auditoria encontrado" />
      ) : (
        <>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data/Hora</TableHead>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Ação</TableHead>
                  <TableHead>Entidade</TableHead>
                  <TableHead>Descrição</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((e) => (
                  <TableRow key={e.id}>
                    <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{formatDateTime(e.dataHora)}</TableCell>
                    <TableCell className="text-foreground">{e.usuarioNome}</TableCell>
                    <TableCell>
                      <Badge variant={ACTION_VARIANT[e.acao]}>{ACTION_LABEL[e.acao]}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{e.entidade}</TableCell>
                    <TableCell className="text-sm text-foreground">{e.descricao}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}
    </RequirePermission>
  );
}
