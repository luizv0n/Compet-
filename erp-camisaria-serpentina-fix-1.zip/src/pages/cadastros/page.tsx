"use client";
import * as React from "react";
import { Layers, Ruler as RulerIcon, Tags } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { NamedCrudPanel } from "@/components/common/NamedCrudPanel";
import { ColorsPanel } from "@/components/common/ColorsPanel";
import { UnitsPanel } from "@/components/common/UnitsPanel";
import { MotivosPerdaPanel } from "@/components/common/MotivosPerdaPanel";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { LoadingState } from "@/components/common/LoadingState";
import type { Colecao, Cor, Tamanho, Categoria, UnidadeMedida, MotivoPerda } from "@/types";

export default function CadastrosPage() {
  const { empresa, hasPermission } = useAuth();
  const canManage = hasPermission(PERMISSIONS.SUPPORT_TABLES_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [colecoes, setColecoes] = React.useState<Colecao[]>([]);
  const [cores, setCores] = React.useState<Cor[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [categorias, setCategorias] = React.useState<Categoria[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);
  const [motivosPerda, setMotivosPerda] = React.useState<MotivoPerda[]>([]);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [c, co, t, cat, u, mp] = await Promise.all([
      apiClient.colecoes.list(empresa.id, true),
      apiClient.cores.list(empresa.id, true),
      apiClient.tamanhos.list(empresa.id, true),
      apiClient.categorias.list(empresa.id, true),
      apiClient.unidades.list(true),
      apiClient.motivosPerda.list(empresa.id, true),
    ]);
    setColecoes(c);
    setCores(co);
    setTamanhos(t);
    setCategorias(cat);
    setUnidades(u);
    setMotivosPerda(mp);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.SUPPORT_TABLES_VIEW}>
      <PageHeader title="Cadastros" description="Coleções, cores, tamanhos, categorias, unidades de medida e motivos de perda usados no catálogo." />
      {loading ? (
        <LoadingState />
      ) : (
        <Tabs defaultValue="colecoes">
          <TabsList className="flex-wrap">
            <TabsTrigger value="colecoes">Coleções</TabsTrigger>
            <TabsTrigger value="cores">Cores</TabsTrigger>
            <TabsTrigger value="tamanhos">Tamanhos</TabsTrigger>
            <TabsTrigger value="categorias">Categorias</TabsTrigger>
            <TabsTrigger value="unidades">Unidades</TabsTrigger>
            <TabsTrigger value="motivosPerda">Motivos de Perda</TabsTrigger>
          </TabsList>

          <TabsContent value="colecoes">
            <NamedCrudPanel
              title="Coleções"
              singular="Coleção"
              icon={Layers}
              items={colecoes}
              loading={loading}
              canManage={canManage}
              onCreate={(nome) => apiClient.colecoes.create(empresa.id, nome)}
              onUpdate={(id, nome) => apiClient.colecoes.update(id, empresa.id, nome)}
              onToggle={(id) => apiClient.colecoes.toggle(id, empresa.id)}
              onChanged={reload}
            />
          </TabsContent>

          <TabsContent value="cores">
            <ColorsPanel items={cores} loading={loading} canManage={canManage} onChanged={reload} />
          </TabsContent>

          <TabsContent value="tamanhos">
            <NamedCrudPanel
              title="Tamanhos"
              singular="Tamanho"
              icon={RulerIcon}
              items={tamanhos}
              loading={loading}
              canManage={canManage}
              onCreate={(nome) => apiClient.tamanhos.create(empresa.id, nome)}
              onUpdate={(id, nome) => apiClient.tamanhos.update(id, empresa.id, nome)}
              onToggle={(id) => apiClient.tamanhos.toggle(id, empresa.id)}
              onChanged={reload}
            />
          </TabsContent>

          <TabsContent value="categorias">
            <NamedCrudPanel
              title="Categorias"
              singular="Categoria"
              icon={Tags}
              items={categorias}
              loading={loading}
              canManage={canManage}
              onCreate={(nome) => apiClient.categorias.create(empresa.id, nome)}
              onUpdate={(id, nome) => apiClient.categorias.update(id, empresa.id, nome)}
              onToggle={(id) => apiClient.categorias.toggle(id, empresa.id)}
              onChanged={reload}
            />
          </TabsContent>

          <TabsContent value="unidades">
            <UnitsPanel items={unidades} canManage={canManage} onChanged={reload} />
          </TabsContent>

          <TabsContent value="motivosPerda">
            <MotivosPerdaPanel items={motivosPerda} loading={loading} canManage={canManage} onChanged={reload} />
          </TabsContent>
        </Tabs>
      )}
    </RequirePermission>
  );
}
