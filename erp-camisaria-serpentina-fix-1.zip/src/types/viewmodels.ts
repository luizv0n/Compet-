import type {
  ID,
  Empresa,
  ProdutoTipo,
  OrdemProducaoStatus,
  KardexNatureza,
  KardexSentido,
  MotivoPerdaTipo,
  NotaFiscalStatus,
} from "./index";

// ---------------------------------------------------------------------
// ViewModels de leitura — combinam entidades para exibição
// ---------------------------------------------------------------------
export interface ProductVariantVM {
  id: ID;
  produtoId: ID;
  produtoNome: string;
  tipo: ProdutoTipo;
  sku: string;
  codigoBarras?: string | null;
  corNome?: string | null;
  tamanhoNome?: string | null;
  unidadeSigla: string;
  ativo: boolean;
}

export interface StockBalanceVM {
  produtoVariacaoId: ID;
  sku: string;
  produtoNome: string;
  corNome?: string | null;
  tamanhoNome?: string | null;
  unidadeSigla: string;
  estoqueId: ID | "TODOS";
  estoqueNome: string;
  quantidade: number;
  quantidadeReservada: number;
  disponivel: number;
  porEstoque?: { estoqueId: ID; estoqueNome: string; quantidade: number }[];
}

export interface KardexVM {
  id: ID;
  dataMovimentacao: string;
  produtoNome: string;
  sku: string;
  estoqueNome: string;
  sentido: KardexSentido;
  natureza: KardexNatureza;
  quantidade: number;
  saldoAnterior: number;
  saldoResultante: number;
  usuarioNome?: string;
  documento?: string | null;
  observacao?: string | null;
}

export interface OrdemProducaoVM {
  id: ID;
  codigo: string;
  produtoNome: string;
  sku: string;
  quantidadePrevista: number;
  quantidadeProduzida: number;
  quantidadeRefugada: number;
  lote?: string | null;
  dataAbertura: string;
  fluxoNome: string;
  etapaAtualNome?: string | null;
  estoqueOrigemNome?: string | null;
  estoqueDestinoNome?: string | null;
  responsavelNome?: string | null;
  observacao?: string | null;
  status: OrdemProducaoStatus;
}

export interface DefectVM {
  id: ID;
  dataMovimentacao: string;
  produtoNome: string;
  sku: string;
  opCodigo: string;
  setorNome?: string | null;
  quantidade: number;
  motivoNome?: string | null;
  motivoTipo?: MotivoPerdaTipo | null;
  usuarioNome?: string | null;
}

// ---------------------------------------------------------------------
// Filtros
// ---------------------------------------------------------------------
export interface BaseFilter {
  q?: string;
  ativo?: boolean | "TODOS";
}

export interface ProductFilter extends BaseFilter {
  tipo?: ProdutoTipo | "TODOS";
  colecaoId?: ID | "TODOS";
  categoriaId?: ID | "TODOS";
}

export interface StockFilter {
  estoqueId?: ID | "TODOS";
  q?: string;
  abaixoDoMinimo?: boolean;
}

export interface KardexFilter {
  produtoVariacaoId?: ID;
  estoqueId?: ID | "TODOS";
  natureza?: KardexNatureza | "TODAS";
  dataInicio?: string;
  dataFim?: string;
}

export interface PurchaseNoteFilter extends BaseFilter {
  status?: NotaFiscalStatus | "TODAS";
  fornecedorId?: ID | "TODOS";
}

export interface AuditFilter {
  usuarioId?: ID | "TODOS";
  acao?: string | "TODAS";
  q?: string;
  dataInicio?: string;
  dataFim?: string;
}

// ---------------------------------------------------------------------
// Payloads de criação/edição
// ---------------------------------------------------------------------
export interface CreateVariantPayload {
  corId?: ID | null;
  tamanhoId?: ID | null;
  sku: string;
  codigoBarras?: string | null;
  precos: { tipoPagamentoId: ID; valor: number }[];
}

export interface CreateProductPayload {
  nome: string;
  tipo: ProdutoTipo;
  colecaoId?: ID | null;
  unidadeMedidaId: ID;
  ncm?: string | null;
  cest?: string | null;
  origem?: string | null;
  categoriaIds: ID[];
  variacoes: CreateVariantPayload[];
}

export interface TransferPayload {
  produtoVariacaoId: ID;
  estoqueOrigemId: ID;
  estoqueDestinoId: ID;
  quantidade: number;
  observacao?: string;
}

export interface ManualStockOutPayload {
  produtoVariacaoId: ID;
  estoqueId: ID;
  quantidade: number;
  natureza: "PERDA" | "AJUSTE" | "DEVOLUCAO";
  motivoPerdaId?: ID | null;
  observacao: string;
}

export interface DirectStockInPayload {
  produtoVariacaoId: ID;
  estoqueId: ID;
  quantidade: number;
  observacao?: string;
}

export interface CreatePurchaseNoteItemPayload {
  produtoVariacaoId: ID;
  unidadeMedidaId: ID;
  quantidade: number;
  valorUnitario: number;
}

export interface CreatePurchaseNotePayload {
  numero: string;
  chaveAcesso?: string | null;
  fornecedorId: ID;
  estoqueId: ID;
  dataEmissao: string;
  observacao?: string | null;
  itens: CreatePurchaseNoteItemPayload[];
}

export interface CreateProductionOrderPayload {
  produtoVariacaoId: ID;
  fluxoProducaoId: ID;
  quantidadePrevista: number;
  lote?: string | null;
  estoqueOrigemId?: ID | null;
  estoqueDestinoId?: ID | null;
  dataAbertura: string;
  observacao?: string | null;
}

export interface ProductionMovePayload {
  ordemProducaoId: ID;
  quantidadeEnviada: number;
  quantidadePerdida: number;
  motivoPerdaId?: ID | null;
  observacao?: string;
  // Consumo real de matérias-primas registrado nesta mesma movimentação
  // (ver types/index.ts — KardexEntry.movimentacaoProducaoId). Cada item
  // gera uma baixa de estoque + lançamento de Kardex (natureza
  // PRODUCAO_CONSUMO) vinculado a esta movimentação específica, o que
  // por si só evita dupla baixa: reenviar o formulário cria uma nova
  // movimentação (novo id), nunca reaplica a mesma.
  consumos?: { produtoVariacaoId: ID; quantidade: number }[];
}

export interface FinishedGoodsEntryPayload {
  ordemProducaoId?: ID | null;
  produtoVariacaoId: ID;
  estoqueId: ID;
  quantidade: number;
  observacao?: string;
}

/**
 * Payload da tela "Nova Empresa" do ADM DO SITE (seção 13 do prompt
 * mestre): dados da empresa + administrador inicial. A criação (ver
 * `apiClient.plataforma.createEmpresa`) também gera, a partir disso, a
 * estrutura mínima necessária (permissões, cargos padrão e um local de
 * estoque padrão) — nunca dados operacionais específicos como produtos
 * ou fornecedores, que devem começar vazios.
 */
export interface CreateEmpresaPayload {
  empresa: Omit<Empresa, "id" | "ativo" | "criadoEm" | "atualizadoEm">;
  administradorInicial: {
    nome: string;
    login: string;
    email: string;
    senha: string;
  };
  /**
   * Nome do local de estoque inicial criado junto com a empresa (Etapa
   * 18). Opcional — se não informado (ou vazio), o padrão "Fábrica" é
   * usado, como sempre foi.
   */
  estoqueInicialNome?: string;
}
