"use client";
import * as React from "react";

/**
 * ProgressiveTable — paginação progressiva reutilizável (seção 12 do prompt).
 * Toda lista começa mostrando 10 registros; "Ver mais 10" soma 10; qualquer
 * mudança nos filtros (deps) reseta a contagem para 10.
 */
export function useProgressiveList<T>(items: T[], deps: React.DependencyList) {
  const [visibleCount, setVisibleCount] = React.useState(10);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  React.useEffect(() => setVisibleCount(10), deps);
  const visible = items.slice(0, visibleCount);
  const hasMore = visibleCount < items.length;
  const showMore = () => setVisibleCount((c) => c + 10);
  return { visible, hasMore, showMore, remaining: items.length - visibleCount };
}
