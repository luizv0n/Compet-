"use client";
import * as React from "react";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import type { Produto, ProdutoVariacao, Estoque, KardexEntry, Usuario, OrdemProducao, MovimentacaoProducao, NotaFiscal } from "@/types";

// Documento relacionado de uma linha de Kardex — resolvido a partir dos
// campos que o bd_competeV6.sql já modela em KardexEntry
// (notaFiscalItemId / ordemProducaoId / movimentacaoProducaoId). Movimentos
// sem origem documental (transferência, baixa manual, ajuste) não têm
// documento — não inventar um vínculo que o banco não define.
export interface DocumentoRelacionado {
  label: string;
  href: string;
}

/**
 * useKardexData — extraído de src/pages/estoque/kardex/page.tsx (sem
 * alterar nenhum cálculo/regra) para ser reaproveitado tanto pela página
 * cheia do Kardex quanto pelo novo Drawer contextual por produto
 * (src/components/kardex/KardexDrawer.tsx). Uma única fonte de dados e de
 * lógica — nada de implementação paralela do Kardex.
 */
export function useKardexData() {
  const { empresa } = useAuth();
  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);
  const [kardex, setKardex] = React.useState<KardexEntry[]>([]);
  const [ordens, setOrdens] = React.useState<OrdemProducao[]>([]);
  const [movimentacoes, setMovimentacoes] = React.useState<MovimentacaoProducao[]>([]);
  const [notas, setNotas] = React.useState<NotaFiscal[]>([]);
  // notaFiscalItemId -> nota fiscal correspondente (para o link "Nota X").
  const [itemParaNota, setItemParaNota] = React.useState<Map<number, NotaFiscal>>(new Map());

  React.useEffect(() => {
    if (!empresa) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const [p, v, e, u, k, op, mp, nf] = await Promise.all([
        apiClient.produtos.list(empresa.id, true),
        apiClient.variacoes.list(empresa.id, true),
        apiClient.estoques.list(empresa.id, true),
        apiClient.equipe.list(empresa.id, true),
        apiClient.kardex.list(empresa.id),
        apiClient.producao.list(empresa.id),
        apiClient.producao.movimentacoesEmpresa(empresa.id),
        apiClient.compras.list(empresa.id),
      ]);
      if (cancelled) return;
      setProdutos(p);
      setVariacoes(v);
      setEstoques(e);
      setUsuarios(u);
      setKardex(k);
      setOrdens(op);
      setMovimentacoes(mp);
      setNotas(nf);

      // Mesmo padrão de src/pages/compras/page.tsx: os itens de cada nota
      // só são acessíveis via apiClient.compras.itens(notaId, empresaId), não
      // existe uma listagem de itens da empresa inteira — então montamos o
      // mapa item -> nota buscando os itens de cada nota em paralelo.
      const mapa = new Map<number, NotaFiscal>();
      await Promise.all(
        nf.map(async (nota) => {
          const itens = await apiClient.compras.itens(nota.id, empresa.id);
          for (const item of itens) mapa.set(item.id, nota);
        }),
      );
      if (cancelled) return;
      setItemParaNota(mapa);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [empresa]);

  function documentoDaMovimentacao(k: KardexEntry): DocumentoRelacionado | null {
    if (k.notaFiscalItemId) {
      const nota = itemParaNota.get(k.notaFiscalItemId);
      if (nota) return { label: `Nota ${nota.numero}`, href: `/compras?nota=${nota.id}` };
    }
    if (k.ordemProducaoId) {
      const op = ordens.find((o) => o.id === k.ordemProducaoId);
      if (op) return { label: `OP ${op.codigo}`, href: `/producao/${op.id}` };
    }
    if (k.movimentacaoProducaoId) {
      const mov = movimentacoes.find((m) => m.id === k.movimentacaoProducaoId);
      const op = mov ? ordens.find((o) => o.id === mov.ordemProducaoId) : undefined;
      if (op) return { label: `OP ${op.codigo}`, href: `/producao/${op.id}` };
    }
    return null;
  }

  return {
    loading,
    produtos,
    variacoes,
    estoques,
    usuarios,
    kardex,
    ordens,
    movimentacoes,
    notas,
    itemParaNota,
    documentoDaMovimentacao,
  };
}
