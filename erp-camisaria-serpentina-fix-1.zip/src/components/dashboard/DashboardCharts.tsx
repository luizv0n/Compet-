"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Componentes de gráfico da Dashboard — redesign visual (UI/UX apenas).
 *
 * Mantêm exatamente o mesmo contrato de dados que `SvgCharts.tsx` já usava
 * (`{ label, value, tooltip? }`), para que `src/pages/dashboard/page.tsx`
 * não precise mudar nenhum cálculo, filtro ou período — apenas a
 * apresentação. Continuam sem dependência de biblioteca de gráficos
 * (SVG/CSS nativos), pelos mesmos motivos do arquivo anterior: simples de
 * manter, sem custo de bundle adicional, e mais fácil de garantir 100% de
 * paridade visual com o design system (tokens de cor via CSS variables).
 */

export interface ChartDatum {
  label: string;
  value: number;
  /** Texto exibido no tooltip ao passar o mouse — se omitido, usa `valueFormatter(value)`. */
  tooltip?: string;
}

/**
 * Puramente visual — quem posiciona é o componente-pai (cada gráfico ancora
 * o tooltip num ponto diferente), para não empilhar transforms conflitantes.
 */
function MiniTooltip({ children }: { children: React.ReactNode }) {
  return (
    <div
      className={cn(
        "pointer-events-none z-10 whitespace-nowrap rounded-md border border-border/70 bg-popover px-2.5 py-1.5 text-xs font-medium text-popover-foreground shadow-lg",
        "animate-in fade-in-0 zoom-in-95 duration-150",
      )}
    >
      {children}
    </div>
  );
}

/**
 * Gráfico de colunas — usado em "Entrada de peças por setor". Prioriza
 * comparação rápida entre setores: barra de maior valor recebe o destaque
 * vermelho da identidade visual, as demais usam um tom neutro derivado do
 * "foreground" (preto/branco conforme o tema), então funciona igual em
 * Light e Dark Mode sem cores fixas.
 */
export function EntriesBarChart({
  data,
  height = 200,
  valueFormatter = (v: number) => String(v),
  emptyLabel = "Sem dados no período",
}: {
  data: ChartDatum[];
  height?: number;
  valueFormatter?: (v: number) => string;
  emptyLabel?: string;
}) {
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null);
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  const max = Math.max(1, ...data.map((d) => d.value));
  const hasData = data.some((d) => d.value > 0);
  const plotHeight = height - 28;

  if (data.length === 0 || !hasData) {
    return (
      <div className="flex items-center justify-center text-xs text-muted-foreground" style={{ height }}>
        {emptyLabel}
      </div>
    );
  }

  const guides = [max, max / 2, 0];

  return (
    <div className="w-full select-none" style={{ height }}>
      <div className="relative" style={{ height: plotHeight }}>
        {/* Linhas de referência discretas — ajudam a estimar a escala sem "gradear" o gráfico. */}
        {guides.map((g, i) => (
          <div key={i} className="absolute inset-x-0 flex items-center gap-2" style={{ top: `${(i / (guides.length - 1)) * 100}%` }}>
            <span className="w-6 shrink-0 -translate-y-1/2 text-right font-mono text-[9px] leading-none text-muted-foreground/70">
              {Math.round(g)}
            </span>
            <div className="h-px w-full -translate-y-1/2 bg-border/60" />
          </div>
        ))}

        <div className="absolute inset-0 left-8 flex items-end gap-1.5 sm:gap-2">
          {data.map((d, i) => {
            const isMax = d.value === max && max > 0;
            const isHover = hoverIdx === i;
            const barHeightPct = mounted ? Math.max((d.value / max) * 100, d.value > 0 ? 2 : 0) : 0;
            return (
              <div
                key={d.label + i}
                className="relative flex h-full flex-1 items-end justify-center"
                onMouseEnter={() => setHoverIdx(i)}
                onMouseLeave={() => setHoverIdx((cur) => (cur === i ? null : cur))}
              >
                {isHover && (
                  <div className="absolute bottom-full left-1/2 mb-2 -translate-x-1/2">
                    <MiniTooltip>{d.tooltip ?? valueFormatter(d.value)}</MiniTooltip>
                  </div>
                )}
                <div
                  className={cn(
                    "w-full rounded-t-[4px] transition-[height,opacity,background-color] duration-500 ease-out",
                    isMax ? "bg-accent" : "bg-foreground/15",
                    isHover && !isMax && "bg-foreground/25",
                    isHover && isMax && "opacity-90",
                  )}
                  style={{ height: `${barHeightPct}%` }}
                />
              </div>
            );
          })}
        </div>
      </div>

      <div className="ml-8 mt-1.5 flex gap-1.5 sm:gap-2">
        {data.map((d, i) => (
          <span key={d.label + i} className="flex-1 truncate text-center font-mono text-[10px] text-muted-foreground">
            {d.label}
          </span>
        ))}
      </div>
    </div>
  );
}

/**
 * Barras horizontais para comparação de taxas (%) — usada em "Taxa de
 * defeitos por setor". Formato horizontal facilita a leitura percentual
 * (o valor já vem escrito ao lado da barra, sem depender de eixo/grade
 * para estimar a proporção). O maior valor (setor com mais atenção
 * necessária) recebe o vermelho de destaque; os demais ficam neutros.
 */
export function RateComparisonBars({
  data,
  valueFormatter = (v: number) => `${v}%`,
  emptyLabel = "Sem dados no período",
}: {
  data: ChartDatum[];
  valueFormatter?: (v: number) => string;
  emptyLabel?: string;
}) {
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null);
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  if (data.length === 0) {
    return <p className="py-6 text-center text-xs text-muted-foreground">{emptyLabel}</p>;
  }

  const max = Math.max(1, ...data.map((d) => d.value));
  const ordenado = data
    .map((d, originalIndex) => ({ ...d, originalIndex }))
    .sort((a, b) => b.value - a.value);

  return (
    <div className="flex flex-col gap-3">
      {ordenado.map((d, rank) => {
        const isMax = d.value === max && max > 0;
        const isHover = hoverIdx === d.originalIndex;
        const widthPct = mounted ? Math.max((d.value / max) * 100, d.value > 0 ? 3 : 0) : 0;
        return (
          <div
            key={d.label + d.originalIndex}
            className={cn("relative flex items-center gap-3 rounded-md px-1 py-0.5 transition-colors", isHover && "bg-secondary/50")}
            onMouseEnter={() => setHoverIdx(d.originalIndex)}
            onMouseLeave={() => setHoverIdx((cur) => (cur === d.originalIndex ? null : cur))}
          >
            <span className="w-14 shrink-0 truncate text-xs font-medium text-foreground sm:w-16">{d.label}</span>
            <div className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-secondary">
              <div
                className={cn("h-full rounded-full transition-[width] duration-500 ease-out", isMax ? "bg-accent" : "bg-foreground/25")}
                style={{ width: `${widthPct}%` }}
              />
            </div>
            <span className="w-12 shrink-0 text-right font-mono text-xs font-semibold tabular-nums text-foreground">
              {valueFormatter(d.value)}
            </span>
            {isHover && d.tooltip && (
              <div className="absolute -top-1 right-0 -translate-y-full">
                <MiniTooltip>{d.tooltip}</MiniTooltip>
              </div>
            )}
            {rank === 0 && d.value > 0 && <span className="sr-only">Maior taxa</span>}
          </div>
        );
      })}
    </div>
  );
}

export interface RankingDatum {
  label: string;
  value: number;
}

/**
 * Ranking horizontal refinado — usado em "Tamanhos mais movimentados".
 * O 1º colocado recebe o selo vermelho de destaque; os demais mantêm a
 * hierarquia numérica clara (posição, nome, valor, barra proporcional).
 */
export function RankingList({
  data,
  valueFormatter = (v: number) => String(v),
  emptyLabel = "Sem dados no período.",
}: {
  data: RankingDatum[];
  valueFormatter?: (v: number) => string;
  emptyLabel?: string;
}) {
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => {
    const raf = requestAnimationFrame(() => setMounted(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  if (data.length === 0) {
    return <p className="py-6 text-center text-xs text-muted-foreground">{emptyLabel}</p>;
  }

  const max = Math.max(1, ...data.map((d) => d.value));

  return (
    <div className="flex flex-col">
      {data.map((d, i) => {
        const isTop = i === 0;
        const widthPct = mounted ? Math.max((d.value / max) * 100, d.value > 0 ? 4 : 0) : 0;
        return (
          <div
            key={d.label + i}
            className={cn(
              "flex items-center gap-3 py-2 transition-colors hover:bg-secondary/40",
              i > 0 && "border-t border-border/60",
            )}
          >
            <span
              className={cn(
                "flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[10px] font-semibold",
                isTop ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground",
              )}
            >
              {i + 1}
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-2">
                <span className="truncate text-xs font-medium text-foreground">{d.label}</span>
                <span className="shrink-0 font-mono text-xs font-semibold tabular-nums text-foreground">{valueFormatter(d.value)}</span>
              </div>
              <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
                <div
                  className={cn("h-full rounded-full transition-[width] duration-500 ease-out", isTop ? "bg-accent" : "bg-foreground/20")}
                  style={{ width: `${widthPct}%` }}
                />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
