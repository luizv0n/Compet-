"use client";
import * as React from "react";
import { BookText } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SearchInput } from "@/components/common/SearchInput";
import { LoadingState } from "@/components/common/LoadingState";
import { Badge } from "@/components/ui/badge";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { useKardexData } from "@/hooks/useKardexData";
import { KardexTable } from "@/components/kardex/KardexTable";
import { KARDEX_NATUREZA_LABEL, PRODUTO_TIPOS } from "@/types";
import type { KardexNatureza } from "@/types";

interface KardexDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  // ID do produto (qualquer tipo — matéria-prima, semiacabado, acabado,
  // tecido, linha, aviamento etc.) cujo Kardex deve ser exibido. A
  // estrutura de produto/variação já existente no projeto é reaproveitada
  // sem lógica específica por tipo (item 2 do prompt).
  produtoId: number | null;
  // Pré-seleção opcional, vinda do botão "Kardex" de uma linha/SKU
  // específico (Produtos e Estoque já sabem qual variação/estoque o
  // usuário estava olhando).
  initialVariacaoId?: number | null;
  initialEstoqueId?: number | null;
}

/**
 * KardexDrawer — abre o Kardex já existente em um painel lateral sobre a
 * página atual, sem navegar. Reaproveita 100% os dados e cálculos de
 * useKardexData/KardexTable (mesma fonte usada por
 * src/pages/estoque/kardex/page.tsx) — só a apresentação é contextual ao
 * produto selecionado.
 */
export function KardexDrawer({ open, onOpenChange, produtoId, initialVariacaoId, initialEstoqueId }: KardexDrawerProps) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent
        side="right"
        className="flex w-full flex-col gap-4 overflow-hidden p-0 sm:max-w-none lg:w-[60vw] lg:min-w-[720px]"
      >
        {/* key força remontagem ao trocar de produto, garantindo que
            nenhum filtro/estado do produto anterior vaze para o novo
            (item 13 do prompt: "Evitar estados vazando entre produtos"). */}
        {produtoId != null && <KardexDrawerContent key={produtoId} produtoId={produtoId} initialVariacaoId={initialVariacaoId} initialEstoqueId={initialEstoqueId} />}
      </SheetContent>
    </Sheet>
  );
}

function KardexDrawerContent({
  produtoId,
  initialVariacaoId,
  initialEstoqueId,
}: {
  produtoId: number;
  initialVariacaoId?: number | null;
  initialEstoqueId?: number | null;
}) {
  const { loading, produtos, variacoes, estoques, usuarios, kardex, documentoDaMovimentacao } = useKardexData();

  const produto = produtos.find((p) => p.id === produtoId);
  const variacoesDoProduto = variacoes.filter((v) => v.produtoId === produtoId);
  const temVariacoes = variacoesDoProduto.length > 1;

  const [query, setQuery] = React.useState("");
  const [variacaoFiltro, setVariacaoFiltro] = React.useState(() => (initialVariacaoId ? String(initialVariacaoId) : "TODAS"));
  const [estoqueFiltro, setEstoqueFiltro] = React.useState(() => (initialEstoqueId ? String(initialEstoqueId) : "TODOS"));
  const [naturezaFiltro, setNaturezaFiltro] = React.useState("TODAS");

  const kardexDoProduto = kardex.filter((k) => variacoesDoProduto.some((v) => v.id === k.produtoVariacaoId));

  const filtered = kardexDoProduto.filter((k) => {
    if (variacaoFiltro !== "TODAS" && k.produtoVariacaoId !== Number(variacaoFiltro)) return false;
    if (estoqueFiltro !== "TODOS" && k.estoqueId !== Number(estoqueFiltro)) return false;
    if (naturezaFiltro !== "TODAS" && k.natureza !== naturezaFiltro) return false;
    if (query) {
      const variacao = variacoes.find((v) => v.id === k.produtoVariacaoId);
      const haystack = `${produto?.nome ?? ""} ${variacao?.sku ?? ""}`.toLowerCase();
      if (!haystack.includes(query.toLowerCase())) return false;
    }
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, variacaoFiltro, estoqueFiltro, naturezaFiltro]);

  const tipoLabel = produto ? PRODUTO_TIPOS.find((t) => t.value === produto.tipo)?.label ?? produto.tipo : undefined;
  // Código/SKU só é exibido no cabeçalho quando o produto tem uma única
  // variação — com várias, o SKU passa a ser exibido por linha na tabela
  // (identificação da variação em cada movimentação), como já era feito.
  const skuUnico = variacoesDoProduto.length === 1 ? variacoesDoProduto[0].sku : null;

  return (
    <>
      <SheetHeader className="border-b px-6 pb-4 pt-6 text-left">
        <div className="flex items-center justify-between gap-2">
          <SheetTitle className="flex items-center gap-2">
            <BookText className="h-4 w-4 text-muted-foreground" /> Kardex
          </SheetTitle>
        </div>
        {loading ? (
          <SheetDescription>Carregando…</SheetDescription>
        ) : (
          <div className="pt-1">
            <p className="text-base font-semibold text-foreground">{produto?.nome ?? "Produto"}</p>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              {tipoLabel && <Badge variant="outline">{tipoLabel}</Badge>}
              {skuUnico && <span className="font-mono text-xs text-muted-foreground">Código: {skuUnico}</span>}
            </div>
          </div>
        )}
      </SheetHeader>

      {loading ? (
        <LoadingState />
      ) : (
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-6 pb-6">
          <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:flex-wrap sm:items-center">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar por SKU…" />
            {temVariacoes && (
              <Select value={variacaoFiltro} onValueChange={setVariacaoFiltro}>
                <SelectTrigger className="w-full sm:w-56">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="TODAS">Todas as variações</SelectItem>
                  {variacoesDoProduto.map((v) => (
                    <SelectItem key={v.id} value={String(v.id)}>
                      {v.sku}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Select value={estoqueFiltro} onValueChange={setEstoqueFiltro}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODOS">Todos os estoques</SelectItem>
                {estoques.map((e) => (
                  <SelectItem key={e.id} value={String(e.id)}>
                    {e.nome}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={naturezaFiltro} onValueChange={setNaturezaFiltro}>
              <SelectTrigger className="w-full sm:w-56">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="TODAS">Todas as naturezas</SelectItem>
                {(Object.keys(KARDEX_NATUREZA_LABEL) as KardexNatureza[]).map((n) => (
                  <SelectItem key={n} value={n}>
                    {KARDEX_NATUREZA_LABEL[n]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <KardexTable
            entries={filtered}
            visible={visible}
            hasMore={hasMore}
            remaining={remaining}
            onShowMore={showMore}
            produtos={produtos}
            variacoes={variacoes}
            estoques={estoques}
            usuarios={usuarios}
            documentoDaMovimentacao={documentoDaMovimentacao}
            hideProdutoColumn
          />
        </div>
      )}
    </>
  );
}
