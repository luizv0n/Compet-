"use client";
import * as React from "react";
import { BookText } from "lucide-react";
import { EmptyState } from "@/components/common/EmptyState";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { Qty } from "@/components/common/Money";
import { KardexSentidoBadge } from "@/components/common/StatusBadge";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Link } from "@/lib/next-compat";
import { formatDateTime } from "@/lib/utils";
import { KARDEX_NATUREZA_LABEL } from "@/types";
import type { Produto, ProdutoVariacao, Estoque, KardexEntry, Usuario } from "@/types";
import type { DocumentoRelacionado } from "@/hooks/useKardexData";

interface KardexTableProps {
  entries: KardexEntry[];
  visible: KardexEntry[];
  hasMore: boolean;
  remaining: number;
  onShowMore: () => void;
  produtos: Produto[];
  variacoes: ProdutoVariacao[];
  estoques: Estoque[];
  usuarios: Usuario[];
  documentoDaMovimentacao: (k: KardexEntry) => DocumentoRelacionado | null;
  // Oculta a coluna "Produto" quando a tabela já está exibida em um
  // contexto de produto único (Drawer) — o nome já aparece no cabeçalho,
  // então repeti-lo em cada linha é redundante. Nenhuma coluna de dado é
  // removida (SKU continua identificando a variação); apenas adaptação de
  // apresentação (item 12 do prompt).
  hideProdutoColumn?: boolean;
}

/**
 * KardexTable — mesma estrutura de colunas, dados e cálculos já usados em
 * src/pages/estoque/kardex/page.tsx. Extraído para ser reaproveitado pelo
 * Drawer contextual sem duplicar a implementação do Kardex.
 */
export function KardexTable({
  entries,
  visible,
  hasMore,
  remaining,
  onShowMore,
  produtos,
  variacoes,
  estoques,
  usuarios,
  documentoDaMovimentacao,
  hideProdutoColumn = false,
}: KardexTableProps) {
  if (entries.length === 0) {
    return <EmptyState icon={BookText} title="Nenhuma movimentação encontrada" />;
  }

  return (
    <>
      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data/Hora</TableHead>
              {!hideProdutoColumn && <TableHead>Produto</TableHead>}
              <TableHead>SKU</TableHead>
              <TableHead>Estoque</TableHead>
              <TableHead>Sentido</TableHead>
              <TableHead>Natureza</TableHead>
              <TableHead className="text-right">Qtd.</TableHead>
              <TableHead className="text-right">Saldo ant.</TableHead>
              <TableHead className="text-right">Saldo result.</TableHead>
              <TableHead>Documento</TableHead>
              <TableHead>Usuário</TableHead>
              <TableHead>Observação</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {visible.map((k) => {
              const variacao = variacoes.find((v) => v.id === k.produtoVariacaoId);
              const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
              const estoque = estoques.find((e) => e.id === k.estoqueId);
              const usuario = usuarios.find((u) => u.id === k.usuarioId);
              const documento = documentoDaMovimentacao(k);
              return (
                <TableRow key={k.id}>
                  <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{formatDateTime(k.dataMovimentacao)}</TableCell>
                  {!hideProdutoColumn && <TableCell className="text-foreground">{produto?.nome}</TableCell>}
                  <TableCell className="font-mono text-xs text-muted-foreground">{variacao?.sku}</TableCell>
                  <TableCell className="text-muted-foreground">{estoque?.nome}</TableCell>
                  <TableCell>
                    <KardexSentidoBadge sentido={k.sentido} />
                  </TableCell>
                  <TableCell className="text-muted-foreground">{KARDEX_NATUREZA_LABEL[k.natureza]}</TableCell>
                  <TableCell className="text-right font-medium tabular-nums">
                    <Qty value={k.quantidade} />
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-muted-foreground">
                    <Qty value={k.saldoAnterior} />
                  </TableCell>
                  <TableCell className="text-right font-semibold tabular-nums">
                    <Qty value={k.saldoResultante} />
                  </TableCell>
                  <TableCell className="text-xs">
                    {documento ? (
                      <Link href={documento.href} className="text-accent hover:underline">
                        {documento.label}
                      </Link>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">{usuario?.nome ?? "—"}</TableCell>
                  <TableCell className="max-w-[220px] truncate text-xs text-muted-foreground" title={k.observacao ?? ""}>
                    {k.observacao ?? "—"}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
      {hasMore && <ShowMoreButton remaining={remaining} onClick={onShowMore} />}
    </>
  );
}
