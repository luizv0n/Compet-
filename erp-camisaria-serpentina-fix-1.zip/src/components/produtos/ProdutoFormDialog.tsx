"use client";
import * as React from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PRODUTO_TIPOS } from "@/types";
import type { Produto, Colecao, Categoria, Cor, Tamanho, UnidadeMedida, ProdutoTipo } from "@/types";

interface ProdutoFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** "create" mostra também o bloco da primeira variação (SKU); "edit" edita só os dados cadastrais do produto. */
  mode: "create" | "edit";
  /** Obrigatório quando mode === "edit". */
  produto?: Produto | null;
  colecoes: Colecao[];
  categorias: Categoria[];
  cores: Cor[];
  tamanhos: Tamanho[];
  unidades: UnidadeMedida[];
  tiposPagamento: { id: number; nome: string }[];
  onSaved: () => void;
}

const emptyForm = {
  nome: "",
  tipo: "PC" as ProdutoTipo,
  colecaoId: "",
  unidadeMedidaId: "",
  ncm: "",
  cest: "",
  origem: "0",
  categoriaIds: [] as number[],
  corId: "",
  tamanhoId: "",
  sku: "",
  precoBase: "",
};

export function ProdutoFormDialog({
  open,
  onOpenChange,
  mode,
  produto,
  colecoes,
  categorias,
  cores,
  tamanhos,
  unidades,
  tiposPagamento,
  onSaved,
}: ProdutoFormDialogProps) {
  const { empresa, actor } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);

  // Preenche o formulário sempre que o dialog abre — em modo edição, com os
  // dados atuais do produto; em modo criação, vazio (com a primeira unidade
  // disponível pré-selecionada, como antes).
  React.useEffect(() => {
    if (!open) return;
    if (mode === "edit" && produto) {
      setForm({
        ...emptyForm,
        nome: produto.nome,
        tipo: produto.tipo,
        colecaoId: produto.colecaoId ? String(produto.colecaoId) : "",
        unidadeMedidaId: String(produto.unidadeMedidaId),
        ncm: produto.ncm ?? "",
        cest: produto.cest ?? "",
        origem: produto.origem ?? "",
        categoriaIds: produto.categoriaIds ?? [],
      });
    } else {
      setForm({ ...emptyForm, unidadeMedidaId: unidades[0] ? String(unidades[0].id) : "" });
      // Sugere o próximo SKU sequencial (CAM-000001, CAM-000002, ...) para a
      // primeira variação; o campo continua editável e o usuário pode
      // substituir o valor livremente antes de salvar.
      if (empresa) {
        apiClient.produtos.nextSku(empresa.id).then((sku) => {
          setForm((f) => ({ ...f, sku }));
        });
      }
    }
  }, [open, mode, produto, unidades, empresa]);

  function toggleCategoria(id: number) {
    setForm((f) => ({
      ...f,
      categoriaIds: f.categoriaIds.includes(id) ? f.categoriaIds.filter((c) => c !== id) : [...f.categoriaIds, id],
    }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!form.nome.trim() || !form.unidadeMedidaId) {
      toast({ title: "Preencha nome e unidade de medida.", variant: "error" });
      return;
    }
    if (mode === "create" && !form.sku.trim()) {
      toast({ title: "Informe o SKU da primeira variação.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (mode === "edit" && produto) {
        await apiClient.produtos.update(produto.id, empresa.id, actor, {
          nome: form.nome.trim(),
          tipo: form.tipo,
          colecaoId: form.colecaoId ? Number(form.colecaoId) : null,
          unidadeMedidaId: Number(form.unidadeMedidaId),
          ncm: form.ncm.trim() || null,
          cest: form.cest.trim() || null,
          origem: form.origem.trim() || null,
          categoriaIds: form.categoriaIds,
        });
        toast({ title: "Produto atualizado", variant: "success" });
      } else {
        const precoBase = Number(form.precoBase.replace(",", ".")) || 0;
        await apiClient.produtos.create(empresa.id, actor, {
          nome: form.nome.trim(),
          tipo: form.tipo,
          colecaoId: form.colecaoId ? Number(form.colecaoId) : null,
          unidadeMedidaId: Number(form.unidadeMedidaId),
          ncm: form.ncm.trim() || null,
          cest: form.cest.trim() || null,
          origem: form.origem.trim() || null,
          categoriaIds: form.categoriaIds,
          variacoes: [
            {
              corId: form.corId ? Number(form.corId) : null,
              tamanhoId: form.tamanhoId ? Number(form.tamanhoId) : null,
              sku: form.sku.trim().toUpperCase(),
              codigoBarras: null,
              precos: tiposPagamento.map((tp) => ({ tipoPagamentoId: tp.id, valor: precoBase })),
            },
          ],
        });
        toast({ title: "Produto cadastrado", variant: "success" });
      }
      onOpenChange(false);
      onSaved();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent size="lg">
        <DialogHeader>
          <DialogTitle>{mode === "edit" ? "Editar produto" : "Novo produto"}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div className="flex flex-col gap-1.5 sm:col-span-2">
              <Label htmlFor="pnome">Nome</Label>
              <Input id="pnome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Tipo</Label>
              <Select
                value={form.tipo}
                onValueChange={(v) =>
                  setForm((f) => ({ ...f, tipo: v as ProdutoTipo, ...(v === "MP" ? { corId: "", tamanhoId: "" } : {}) }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRODUTO_TIPOS.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Unidade de medida</Label>
              <Select value={form.unidadeMedidaId} onValueChange={(v) => setForm({ ...form, unidadeMedidaId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {unidades.map((u) => (
                    <SelectItem key={u.id} value={String(u.id)}>
                      {u.sigla}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Coleção (opcional)</Label>
              <Select value={form.colecaoId} onValueChange={(v) => setForm({ ...form, colecaoId: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Nenhuma" />
                </SelectTrigger>
                <SelectContent>
                  {colecoes.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pncm">NCM (opcional)</Label>
              <Input id="pncm" value={form.ncm} onChange={(e) => setForm({ ...form, ncm: e.target.value })} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pcest">CEST (opcional)</Label>
              <Input id="pcest" value={form.cest} onChange={(e) => setForm({ ...form, cest: e.target.value })} />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="porigem">Origem (opcional)</Label>
              <Input id="porigem" value={form.origem} onChange={(e) => setForm({ ...form, origem: e.target.value })} />
            </div>
          </div>

          {categorias.length > 0 && (
            <div className="flex flex-col gap-1.5">
              <Label>Categorias</Label>
              <div className="flex flex-wrap gap-3 rounded-md border p-2.5">
                {categorias.map((c) => (
                  <label key={c.id} className="flex items-center gap-1.5 text-sm">
                    <Checkbox checked={form.categoriaIds.includes(c.id)} onCheckedChange={() => toggleCategoria(c.id)} />
                    {c.nome}
                  </label>
                ))}
              </div>
            </div>
          )}

          {mode === "create" && (
            <div className="rounded-md bg-secondary/40 p-3">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Primeira variação (SKU)
              </p>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <div className="flex flex-col gap-1.5">
                  <Label htmlFor="psku">SKU</Label>
                  <Input id="psku" value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="Ex.: PC-CAM-PRETO-M" />
                </div>
                <div className="flex flex-col gap-1.5">
                  <Label>Preço base (opcional)</Label>
                  <Input
                    value={form.precoBase}
                    onChange={(e) => setForm({ ...form, precoBase: e.target.value })}
                    placeholder="Ex.: 39,90"
                  />
                </div>
                {form.tipo !== "MP" && (
                  <>
                    <div className="flex flex-col gap-1.5">
                      <Label>Cor (opcional)</Label>
                      <Select value={form.corId} onValueChange={(v) => setForm({ ...form, corId: v })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Sem cor" />
                        </SelectTrigger>
                        <SelectContent>
                          {cores.map((c) => (
                            <SelectItem key={c.id} value={String(c.id)}>
                              {c.nome} {c.estampa ? `— ${c.estampa}` : ""}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <Label>Tamanho (opcional)</Label>
                      <Select value={form.tamanhoId} onValueChange={(v) => setForm({ ...form, tamanhoId: v })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Sem tamanho" />
                        </SelectTrigger>
                        <SelectContent>
                          {tamanhos.map((t) => (
                            <SelectItem key={t.id} value={String(t.id)}>
                              {t.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}
              </div>
              {form.tipo === "MP" ? (
                <p className="mt-2 text-xs text-muted-foreground">
                  Matéria-prima não usa cor/tamanho — esta é a variação padrão do item.
                </p>
              ) : (
                <p className="mt-2 text-xs text-muted-foreground">
                  Mais variações (outras cores/tamanhos) podem ser adicionadas depois, na página de detalhes do produto.
                </p>
              )}
            </div>
          )}

          {mode === "edit" && (
            <p className="text-xs text-muted-foreground">
              Para editar as variações (SKUs) deste produto, acesse a página de detalhes do produto.
            </p>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" loading={submitting}>
              {mode === "edit" ? "Salvar alterações" : "Salvar"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
