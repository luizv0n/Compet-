"use client";
import * as React from "react";
import { cn } from "@/lib/utils";

export interface BarChartDatum {
  label: string;
  value: number;
  /** Texto exibido no tooltip ao passar o mouse — se omitido, usa `value`. */
  tooltip?: string;
}

/**
 * Gráfico de barras verticais em SVG nativo (sem bibliotecas de gráfico).
 * Passe o mouse (ou toque) em uma barra para ver o valor exato do dia/categoria.
 */
export function BarChart({
  data,
  height = 160,
  barColor = "hsl(var(--accent))",
  valueFormatter = (v: number) => String(v),
  emptyLabel = "Sem dados no período",
}: {
  data: BarChartDatum[];
  height?: number;
  barColor?: string;
  valueFormatter?: (v: number) => string;
  emptyLabel?: string;
}) {
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null);

  const max = Math.max(1, ...data.map((d) => d.value));
  const hasData = data.some((d) => d.value > 0);
  const width = 100; // viewBox percentual — escala com o container via preserveAspectRatio
  const gap = 2.5;
  const barWidth = data.length > 0 ? (width - gap * (data.length + 1)) / data.length : 0;
  const chartHeight = height - 28; // espaço reservado para o rótulo do eixo X

  if (data.length === 0 || !hasData) {
    return (
      <div className="flex items-center justify-center text-xs text-muted-foreground" style={{ height }}>
        {emptyLabel}
      </div>
    );
  }

  return (
    <div className="relative w-full select-none" style={{ height }}>
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="h-full w-full overflow-visible">
        {data.map((d, i) => {
          const barHeight = (d.value / max) * (chartHeight - 4);
          const x = gap + i * (barWidth + gap);
          const y = chartHeight - barHeight;
          const isHover = hoverIdx === i;
          return (
            <g key={d.label + i}>
              {/* área de hover maior que a barra, para facilitar o toque em telas pequenas */}
              <rect
                x={x - gap / 2}
                y={0}
                width={barWidth + gap}
                height={chartHeight}
                fill="transparent"
                onMouseEnter={() => setHoverIdx(i)}
                onMouseLeave={() => setHoverIdx((cur) => (cur === i ? null : cur))}
                onTouchStart={() => setHoverIdx(i)}
              />
              <rect
                x={x}
                y={y}
                width={barWidth}
                height={Math.max(barHeight, d.value > 0 ? 1 : 0)}
                rx={1}
                fill={barColor}
                opacity={isHover ? 1 : 0.75}
                className="transition-opacity"
              />
              <text
                x={x + barWidth / 2}
                y={chartHeight + 12}
                textAnchor="middle"
                fontSize="4.2"
                fill="hsl(var(--muted-foreground))"
              >
                {d.label}
              </text>
            </g>
          );
        })}
      </svg>
      {hoverIdx !== null && data[hoverIdx] && (
        <div
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-full rounded-md border bg-popover px-2 py-1 text-xs font-medium text-popover-foreground shadow-md"
          style={{
            left: `${gap + hoverIdx * (barWidth + gap) + barWidth / 2}%`,
            top: `${((chartHeight - (data[hoverIdx].value / max) * (chartHeight - 4)) / height) * 100}%`,
          }}
        >
          {data[hoverIdx].tooltip ?? valueFormatter(data[hoverIdx].value)}
        </div>
      )}
    </div>
  );
}

export interface RankingDatum {
  label: string;
  value: number;
  sublabel?: string;
}

/** Ranking horizontal simples (barras proporcionais) — usado para "mais movimentados". */
export function RankingBars({
  data,
  valueFormatter = (v: number) => String(v),
  barColor = "hsl(var(--accent))",
}: {
  data: RankingDatum[];
  valueFormatter?: (v: number) => string;
  barColor?: string;
}) {
  const max = Math.max(1, ...data.map((d) => d.value));
  if (data.length === 0) {
    return <p className="py-2 text-xs text-muted-foreground">Sem dados no período.</p>;
  }
  return (
    <div className="flex flex-col gap-2.5">
      {data.map((d, i) => (
        <div key={d.label + i} className="flex items-center gap-2.5">
          <span className="w-5 shrink-0 text-right text-xs font-medium text-muted-foreground">{i + 1}º</span>
          <div className="min-w-0 flex-1">
            <div className="flex items-baseline justify-between gap-2">
              <span className="truncate text-xs font-medium text-foreground">{d.label}</span>
              <span className="shrink-0 text-xs font-semibold tabular-nums text-foreground">{valueFormatter(d.value)}</span>
            </div>
            <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-secondary">
              <div
                className={cn("h-full rounded-full transition-all")}
                style={{ width: `${Math.max(4, (d.value / max) * 100)}%`, backgroundColor: barColor }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
