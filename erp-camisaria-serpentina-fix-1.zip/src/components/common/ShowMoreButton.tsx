import { Button } from "@/components/ui/button";

export function ShowMoreButton({ remaining, onClick }: { remaining: number; onClick: () => void }) {
  return (
    <div className="mt-3 flex justify-center">
      <Button variant="outline" size="sm" onClick={onClick}>
        Ver mais 10 ({remaining} restantes)
      </Button>
    </div>
  );
}
