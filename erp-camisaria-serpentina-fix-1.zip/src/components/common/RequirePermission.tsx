"use client";
import * as React from "react";
import { useAuth } from "@/context/AuthContext";
import type { PermissionKey } from "@/constants/permissions";
import { ShieldAlert } from "lucide-react";

export function RequirePermission({ perm, children }: { perm: PermissionKey; children: React.ReactNode }) {
  const { hasPermission, loading } = useAuth();
  if (loading) return null;
  if (!hasPermission(perm)) {
    return (
      <div className="flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed py-16 text-center">
        <div className="rounded-full bg-secondary p-3">
          <ShieldAlert className="h-5 w-5 text-muted-foreground" />
        </div>
        <div>
          <p className="text-sm font-medium text-foreground">Acesso restrito</p>
          <p className="mt-1 max-w-sm text-sm text-muted-foreground">
            Seu cargo não tem permissão para acessar esta área. Fale com um administrador da empresa.
          </p>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}
