"use client";
import * as React from "react";
import { Plus, Pencil, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { useToast } from "@/context/ToastContext";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { MOTIVO_PERDA_TIPOS } from "@/types";
import type { MotivoPerda, MotivoPerdaTipo } from "@/types";

function tipoLabel(tipo: MotivoPerdaTipo) {
  return MOTIVO_PERDA_TIPOS.find((t) => t.value === tipo)?.label ?? tipo;
}

export function MotivosPerdaPanel({
  items,
  loading,
  canManage,
  onChanged,
}: {
  items: MotivoPerda[];
  loading: boolean;
  canManage: boolean;
  onChanged: () => void;
}) {
  const { empresa } = useAuth();
  const { toast } = useToast();
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<MotivoPerda | null>(null);
  const [nome, setNome] = React.useState("");
  const [tipo, setTipo] = React.useState<MotivoPerdaTipo>("MATERIAL");
  const [descricao, setDescricao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const filtered = items.filter((i) => (i.nome + " " + (i.descricao ?? "")).toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setNome("");
    setTipo("MATERIAL");
    setDescricao("");
    setDialogOpen(true);
  }
  function openEdit(item: MotivoPerda) {
    setEditing(item);
    setNome(item.nome);
    setTipo(item.tipo);
    setDescricao(item.descricao ?? "");
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !nome.trim()) return;
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.motivosPerda.update(editing.id, empresa.id, nome.trim(), tipo, descricao.trim() || null);
        toast({ title: "Motivo de perda atualizado", variant: "success" });
      } else {
        await apiClient.motivosPerda.create(empresa.id, nome.trim(), tipo, descricao.trim() || null);
        toast({ title: "Motivo de perda cadastrado", variant: "success" });
      }
      setDialogOpen(false);
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: MotivoPerda) {
    if (!empresa) return;
    try {
      await apiClient.motivosPerda.toggle(item.id, empresa.id);
      toast({ title: item.ativo ? "Motivo inativado" : "Motivo ativado", variant: "success" });
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar motivos de perda…" />
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4" /> Novo motivo de perda
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={AlertTriangle} title="Nenhum motivo de perda encontrado" />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Status</TableHead>
                {canManage && <TableHead className="text-right">Ações</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                  <TableCell className="text-muted-foreground">{tipoLabel(item.tipo)}</TableCell>
                  <TableCell className="text-muted-foreground">{item.descricao || "—"}</TableCell>
                  <TableCell>
                    <ActiveBadge ativo={item.ativo} />
                  </TableCell>
                  {canManage && (
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar motivo de perda" : "Novo motivo de perda"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="motivoNome">Nome</Label>
              <Input id="motivoNome" value={nome} onChange={(e) => setNome(e.target.value)} autoFocus />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Tipo</Label>
              <Select value={tipo} onValueChange={(v) => setTipo(v as MotivoPerdaTipo)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MOTIVO_PERDA_TIPOS.map((t) => (
                    <SelectItem key={t.value} value={t.value}>
                      {t.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="motivoDescricao">Descrição (opcional)</Label>
              <Input id="motivoDescricao" value={descricao} onChange={(e) => setDescricao(e.target.value)} placeholder="Ex.: Falha identificada na inspeção de qualidade" />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
