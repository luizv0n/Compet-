import { Badge } from "@/components/ui/badge";
import { OP_STATUS_LABEL, OP_ETAPA_STATUS_LABEL, type OrdemProducaoStatus, type OrdemProducaoEtapaStatus } from "@/types";

export function ActiveBadge({ ativo }: { ativo: boolean }) {
  return <Badge variant={ativo ? "success" : "outline"}>{ativo ? "Ativo" : "Inativo"}</Badge>;
}

const OP_STATUS_VARIANT: Record<OrdemProducaoStatus, "default" | "success" | "warning" | "destructive" | "info" | "accent"> = {
  PLANEJADA: "default",
  LIBERADA: "info",
  EM_PRODUCAO: "accent",
  PAUSADA: "warning",
  CONCLUIDA: "success",
  CANCELADA: "destructive",
};

export function OrdemProducaoStatusBadge({ status }: { status: OrdemProducaoStatus }) {
  return <Badge variant={OP_STATUS_VARIANT[status]}>{OP_STATUS_LABEL[status]}</Badge>;
}

const ETAPA_STATUS_VARIANT: Record<OrdemProducaoEtapaStatus, "default" | "success" | "warning" | "accent"> = {
  AGUARDANDO: "default",
  EM_EXECUCAO: "accent",
  CONCLUIDA: "success",
  PULADA: "warning",
};

export function EtapaStatusBadge({ status }: { status: OrdemProducaoEtapaStatus }) {
  return <Badge variant={ETAPA_STATUS_VARIANT[status]}>{OP_ETAPA_STATUS_LABEL[status]}</Badge>;
}

const NF_STATUS_VARIANT: Record<string, "default" | "success" | "warning" | "destructive"> = {
  ABERTA: "warning",
  CONCLUIDA: "success",
  CANCELADA: "destructive",
};
const NF_STATUS_LABEL: Record<string, string> = { ABERTA: "Aberta", CONCLUIDA: "Concluída", CANCELADA: "Cancelada" };

export function PurchaseNoteStatusBadge({ status }: { status: string }) {
  return <Badge variant={NF_STATUS_VARIANT[status] ?? "default"}>{NF_STATUS_LABEL[status] ?? status}</Badge>;
}

export function KardexSentidoBadge({ sentido }: { sentido: "ENTRADA" | "SAIDA" }) {
  return <Badge variant={sentido === "ENTRADA" ? "success" : "destructive"}>{sentido === "ENTRADA" ? "Entrada" : "Saída"}</Badge>;
}
