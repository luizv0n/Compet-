"use client";
import * as React from "react";
import { Plus, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { useToast } from "@/context/ToastContext";
import type { LucideIcon } from "lucide-react";

interface NamedEntity {
  id: number;
  nome: string;
  ativo: boolean;
}

interface NamedCrudPanelProps<T extends NamedEntity> {
  title: string;
  singular: string;
  icon: LucideIcon;
  items: T[];
  loading: boolean;
  canManage: boolean;
  onCreate: (nome: string) => Promise<unknown>;
  onUpdate: (id: number, nome: string) => Promise<unknown>;
  onToggle: (id: number) => Promise<unknown>;
  onChanged: () => void;
  extraColumn?: { header: string; render: (item: T) => React.ReactNode };
}

export function NamedCrudPanel<T extends NamedEntity>({
  title,
  singular,
  icon: Icon,
  items,
  loading,
  canManage,
  onCreate,
  onUpdate,
  onToggle,
  onChanged,
  extraColumn,
}: NamedCrudPanelProps<T>) {
  const { toast } = useToast();
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<T | null>(null);
  const [nome, setNome] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const filtered = items.filter((i) => i.nome.toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setNome("");
    setDialogOpen(true);
  }
  function openEdit(item: T) {
    setEditing(item);
    setNome(item.nome);
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!nome.trim()) return;
    setSubmitting(true);
    try {
      if (editing) {
        await onUpdate(editing.id, nome.trim());
        toast({ title: `${singular} atualizado(a)`, variant: "success" });
      } else {
        await onCreate(nome.trim());
        toast({ title: `${singular} cadastrado(a)`, variant: "success" });
      }
      setDialogOpen(false);
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: T) {
    try {
      await onToggle(item.id);
      toast({ title: item.ativo ? `${singular} inativado(a)` : `${singular} ativado(a)`, variant: "success" });
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <SearchInput value={query} onChange={setQuery} placeholder={`Buscar ${title.toLowerCase()}…`} />
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4" /> Novo {singular.toLowerCase()}
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Icon} title={`Nenhum(a) ${singular.toLowerCase()} encontrado(a)`} />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                {extraColumn && <TableHead>{extraColumn.header}</TableHead>}
                <TableHead>Status</TableHead>
                {canManage && <TableHead className="text-right">Ações</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                  {extraColumn && <TableCell>{extraColumn.render(item)}</TableCell>}
                  <TableCell>
                    <ActiveBadge ativo={item.ativo} />
                  </TableCell>
                  {canManage && (
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? `Editar ${singular.toLowerCase()}` : `Novo ${singular.toLowerCase()}`}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="nome">Nome</Label>
              <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} autoFocus />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
