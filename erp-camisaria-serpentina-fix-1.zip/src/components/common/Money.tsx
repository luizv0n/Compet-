import { formatBRL, formatQty } from "@/lib/utils";
import { cn } from "@/lib/utils";

export function Money({ value, className }: { value: number; className?: string }) {
  return <span className={cn("tabular-nums", className)}>{formatBRL(value)}</span>;
}

export function Qty({ value, unit, className, decimals = 2 }: { value: number; unit?: string; className?: string; decimals?: number }) {
  return (
    <span className={cn("tabular-nums", className)}>
      {formatQty(value, decimals)}
      {unit ? ` ${unit}` : ""}
    </span>
  );
}
