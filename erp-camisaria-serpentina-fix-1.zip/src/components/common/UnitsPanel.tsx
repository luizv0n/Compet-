"use client";
import * as React from "react";
import { Plus, Pencil, Ruler } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import type { UnidadeMedida } from "@/types";

export function UnitsPanel({ items, canManage, onChanged }: { items: UnidadeMedida[]; canManage: boolean; onChanged: () => void }) {
  const { toast } = useToast();
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<UnidadeMedida | null>(null);
  const [sigla, setSigla] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  const filtered = items.filter((i) => i.sigla.toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setSigla("");
    setDialogOpen(true);
  }
  function openEdit(item: UnidadeMedida) {
    setEditing(item);
    setSigla(item.sigla);
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!sigla.trim()) return;
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.unidades.update(editing.id, sigla.trim());
        toast({ title: "Unidade atualizada", variant: "success" });
      } else {
        await apiClient.unidades.create(sigla.trim());
        toast({ title: "Unidade cadastrada", variant: "success" });
      }
      setDialogOpen(false);
      setEditing(null);
      setSigla("");
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: UnidadeMedida) {
    try {
      await apiClient.unidades.toggle(item.id);
      toast({ title: item.ativo ? "Unidade inativada" : "Unidade ativada", variant: "success" });
      onChanged();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  return (
    <div>
      <div className="mb-3 rounded-md bg-secondary/50 px-3 py-2 text-xs text-muted-foreground">
        Unidade de medida é um catálogo global — vale para todas as empresas do sistema.
      </div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar unidades…" />
        {canManage && (
          <Button onClick={openCreate} size="sm">
            <Plus className="h-4 w-4" /> Nova unidade
          </Button>
        )}
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Ruler} title="Nenhuma unidade encontrada" />
      ) : (
        <div className="rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sigla</TableHead>
                <TableHead>Status</TableHead>
                {canManage && <TableHead className="text-right">Ações</TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-mono text-sm font-medium text-foreground">{item.sigla}</TableCell>
                  <TableCell>
                    <ActiveBadge ativo={item.ativo} />
                  </TableCell>
                  {canManage && (
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} />
                      </div>
                    </TableCell>
                  )}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar unidade de medida" : "Nova unidade de medida"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="sigla">Sigla</Label>
              <Input id="sigla" value={sigla} onChange={(e) => setSigla(e.target.value.toUpperCase())} placeholder="Ex.: MT, KG, UN" maxLength={10} autoFocus />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
