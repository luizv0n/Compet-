"use client";
import * as React from "react";
import { cn } from "@/lib/utils";
import type { FluxoProducaoEtapa, Setor } from "@/types";

interface FluxoEtapasSerpentinaProps {
  etapas: FluxoProducaoEtapa[];
  setores: Setor[];
}

// Nenhuma largura de bloco é assumida antecipadamente: o número de blocos
// por linha é recalculado a partir da largura real do container e da
// largura real de cada bloco (medida em DOM, com o mesmo conteúdo e
// tipografia do bloco visível). Estas constantes controlam apenas o teto
// visual padrão (5 por linha, conforme o layout definido) e o espaçamento
// mínimo entre blocos — nunca a posição dos conectores, que é sempre
// calculada a partir da posição real de cada bloco após o layout.
const MAX_PER_ROW = 5;
const MIN_PER_ROW = 1;
const CARD_GAP_PX = 16;
const ROW_GAP_PX = 36;

interface ConnectorPath {
  id: string;
  d: string;
}

/**
 * Etapas de um fluxo de produção (tela "Fluxos de produção") apresentadas
 * como uma trilha contínua em zigue-zague/serpentina.
 *
 * A ordem das etapas continua exatamente a cadastrada (sequencia). Ao
 * atingir o número de blocos por linha — calculado dinamicamente a partir
 * do espaço disponível, nunca de larguras fixas — o caminho desce e a
 * linha seguinte passa a correr no sentido oposto (direita→esquerda→
 * direita...). Os conectores entre os blocos são desenhados sobre um SVG
 * a partir da posição real (medida em DOM) de cada bloco, portanto tocam
 * sempre exatamente na borda dos blocos, sejam eles quais forem os seus
 * tamanhos. O visual de cada bloco (cor, borda, tipografia, número da
 * etapa e nome do setor) é o mesmo já usado nesta tela; apenas o
 * agrupamento em linhas e a forma de conectar os blocos foram alterados.
 */
export function FluxoEtapasSerpentina({ etapas, setores }: FluxoEtapasSerpentinaProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);

  const containerRef = React.useRef<HTMLDivElement>(null);
  const measureRefs = React.useRef<Array<HTMLSpanElement | null>>([]);
  const cardRefs = React.useRef<Array<HTMLDivElement | null>>([]);

  const [itemsPerRow, setItemsPerRow] = React.useState(MAX_PER_ROW);
  const [connectors, setConnectors] = React.useState<ConnectorPath[]>([]);
  const [svgSize, setSvgSize] = React.useState({ width: 0, height: 0 });

  // Quantos blocos cabem por linha, a partir da largura real do container
  // e da largura real do maior bloco (medido via elementos ocultos com o
  // mesmo conteúdo/tipografia). Nunca ultrapassa a largura disponível.
  const recomputeItemsPerRow = React.useCallback(() => {
    const container = containerRef.current;
    if (!container || ordered.length === 0) return;
    const containerWidth = container.clientWidth;
    if (containerWidth <= 0) return;
    const widths = measureRefs.current.slice(0, ordered.length).map((el) => el?.offsetWidth ?? 0);
    if (widths.length === 0 || widths.some((w) => w === 0)) return;
    const maxCardWidth = Math.max(...widths);
    const slot = maxCardWidth + CARD_GAP_PX;
    const n = Math.floor((containerWidth + CARD_GAP_PX) / slot);
    setItemsPerRow(Math.min(MAX_PER_ROW, Math.max(MIN_PER_ROW, n)));
  }, [ordered.length]);

  React.useLayoutEffect(() => {
    recomputeItemsPerRow();
  }, [recomputeItemsPerRow]);

  React.useEffect(() => {
    const container = containerRef.current;
    if (!container || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => recomputeItemsPerRow());
    ro.observe(container);
    return () => ro.disconnect();
  }, [recomputeItemsPerRow]);

  const rows = React.useMemo(() => {
    const chunks: FluxoProducaoEtapa[][] = [];
    for (let i = 0; i < ordered.length; i += itemsPerRow) {
      chunks.push(ordered.slice(i, i + itemsPerRow));
    }
    return chunks;
  }, [ordered, itemsPerRow]);

  // Desenha os conectores a partir da posição real (pós-layout) de cada
  // bloco, e não de suposições de largura. Cada conector liga a borda do
  // bloco de origem exatamente à borda do bloco seguinte: uma linha reta
  // quando os dois estão na mesma linha visual, e um traço em ângulo reto
  // (desce, atravessa, desce) quando a etapa muda de linha — sempre
  // encostando nos dois blocos, sem espaços soltos e sem setas.
  const recomputeConnectors = React.useCallback(() => {
    const container = containerRef.current;
    if (!container || ordered.length === 0) return;
    const containerRect = container.getBoundingClientRect();
    const rects = cardRefs.current.slice(0, ordered.length).map((el) => el?.getBoundingClientRect() ?? null);
    if (rects.length !== ordered.length || rects.some((r) => r === null)) return;

    const paths: ConnectorPath[] = [];
    for (let i = 0; i < ordered.length - 1; i++) {
      const a = rects[i]!;
      const b = rects[i + 1]!;
      const ax = a.left - containerRect.left;
      const ay = a.top - containerRect.top;
      const bx = b.left - containerRect.left;
      const by = b.top - containerRect.top;
      const sameRow = Math.abs(ay - by) < 1;

      if (sameRow) {
        // Liga a borda voltada de um bloco à borda voltada do próximo,
        // seguindo o sentido real em que os blocos estão dispostos nesta
        // linha (esquerda→direita ou direita→esquerda).
        const y = ay + a.height / 2;
        const goingRight = bx >= ax;
        const x1 = goingRight ? ax + a.width : ax;
        const x2 = goingRight ? bx : bx + b.width;
        paths.push({ id: `c-${i}`, d: `M ${x1} ${y} L ${x2} ${y}` });
      } else {
        // Muda de linha: sai pela base do bloco de origem e entra pelo
        // topo do bloco seguinte, com um traço em ângulo reto no meio do
        // espaçamento entre as linhas — encostando sempre nos dois blocos.
        const x1 = ax + a.width / 2;
        const y1 = ay + a.height;
        const x2 = bx + b.width / 2;
        const y2 = by;
        const midY = y1 + (y2 - y1) / 2;
        paths.push({ id: `c-${i}`, d: `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}` });
      }
    }
    setConnectors(paths);
    setSvgSize({ width: container.clientWidth, height: container.clientHeight });
  }, [ordered.length]);

  React.useLayoutEffect(() => {
    recomputeConnectors();
  }, [recomputeConnectors, rows]);

  React.useEffect(() => {
    const container = containerRef.current;
    if (!container || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(() => recomputeConnectors());
    });
    ro.observe(container);
    return () => ro.disconnect();
  }, [recomputeConnectors]);

  if (ordered.length === 0) return null;

  return (
    <div className="relative mt-3 w-full overflow-hidden">
      {/* Camada de medição: invisível e sem afetar o layout da página
         (contida pelo overflow-hidden do wrapper), usada apenas para
         descobrir a largura real de cada bloco antes de decidir quantos
         cabem por linha. */}
      <div className="pointer-events-none absolute left-0 top-0 -z-10 flex opacity-0" aria-hidden="true">
        {ordered.map((etapa, idx) => {
          const setor = setores.find((s) => s.id === etapa.setorId);
          return (
            <span
              key={etapa.id}
              ref={(el) => {
                measureRefs.current[idx] = el;
              }}
              className="whitespace-nowrap rounded-md border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground"
            >
              {etapa.sequencia}. {setor?.nome ?? "—"}
            </span>
          );
        })}
      </div>

      <div ref={containerRef} className="relative">
        <svg className="pointer-events-none absolute left-0 top-0" width={svgSize.width} height={svgSize.height} aria-hidden="true">
          {connectors.map((c) => (
            <path key={c.id} d={c.d} fill="none" stroke="currentColor" strokeWidth={1.5} className="text-muted-foreground/50" />
          ))}
        </svg>

        <div className="flex flex-col" style={{ rowGap: ROW_GAP_PX }}>
          {rows.map((row, rowIdx) => {
            const reversed = rowIdx % 2 === 1;
            const isLastRow = rowIdx === rows.length - 1;
            const startIndex = rowIdx * itemsPerRow;

            return (
              <div
                key={rowIdx}
                className={cn(
                  "flex flex-nowrap items-center",
                  reversed && "flex-row-reverse",
                  isLastRow ? "gap-4" : "justify-between"
                )}
              >
                {row.map((etapa, idx) => {
                  const globalIndex = startIndex + idx;
                  const setor = setores.find((s) => s.id === etapa.setorId);
                  return (
                    <div
                      key={etapa.id}
                      ref={(el) => {
                        cardRefs.current[globalIndex] = el;
                      }}
                      className="shrink-0 rounded-md border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground"
                    >
                      {etapa.sequencia}. {setor?.nome ?? "—"}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
