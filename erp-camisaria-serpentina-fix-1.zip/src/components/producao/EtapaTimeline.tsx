"use client";
import * as React from "react";
import { Check, CircleDashed, SkipForward } from "lucide-react";
import { cn } from "@/lib/utils";
import { Qty } from "@/components/common/Money";
import type { OrdemProducaoEtapa, OrdemProducaoEtapaStatus, Setor } from "@/types";

interface EtapaTimelineProps {
  etapas: OrdemProducaoEtapa[];
  setores: Setor[];
  etapaAtualId?: number | null;
}

const NODE_STYLE: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "border-success bg-success text-success-foreground",
  EM_EXECUCAO: "border-accent bg-accent text-accent-foreground ring-4 ring-accent/20",
  AGUARDANDO: "border-border bg-card text-muted-foreground",
  PULADA: "border-warning bg-warning text-warning-foreground",
};

/** Cor de fundo dos conectores (linhas horizontais entre etapas e linha vertical de quebra). */
const CONNECTOR_BG: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "bg-success",
  EM_EXECUCAO: "bg-accent",
  AGUARDANDO: "bg-border",
  PULADA: "bg-warning",
};

// Padrão visual fixo de etapas por linha da serpentina (item 4 da
// especificação): 5 colunas por linha (w-44 = 176px cada), qualquer que
// seja o total de etapas — a última linha simplesmente recebe o restante.
const ITEMS_PER_ROW = 5;

/**
 * Timeline das etapas de uma OP em formato serpentina/zigue-zague, em vez
 * de uma única linha horizontal com rolagem. As etapas continuam na ordem
 * original do fluxo; a cada 5 colunas (padrão visual fixo) o caminho desce
 * e a linha seguinte percorre no sentido oposto, alternando
 * direita→esquerda→direita, em vez de crescer indefinidamente para os
 * lados. As linhas são conectadas entre si por um traço vertical no lado
 * correto, sem setas. Cards, cores, ícones de status e indicadores de
 * quantidade permanecem exatamente os mesmos; apenas a estrutura do
 * layout e os conectores entre etapas foram redesenhados.
 */
export function EtapaTimeline({ etapas, setores, etapaAtualId }: EtapaTimelineProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);

  const rows: OrdemProducaoEtapa[][] = [];
  for (let i = 0; i < ordered.length; i += ITEMS_PER_ROW) {
    rows.push(ordered.slice(i, i + ITEMS_PER_ROW));
  }

  return (
    <div className="w-full px-1 py-2">
      <div className="flex flex-col">
        {rows.map((row, rowIdx) => {
          const reversed = rowIdx % 2 === 1;
          const nextRowFirst = rows[rowIdx + 1]?.[0];

          return (
            <div key={rowIdx} className="flex flex-col">
              <ol className={cn("flex items-stretch", reversed && "flex-row-reverse")}>
                {row.map((etapa, idx) => {
                  const setor = setores.find((s) => s.id === etapa.setorId);
                  const isCurrent = etapaAtualId === etapa.id;
                  const isLastInRow = idx === row.length - 1;
                  const proximaNaLinha = row[idx + 1];

                  return (
                    <li key={etapa.id} className="flex items-stretch">
                      <div className="flex w-44 shrink-0 flex-col items-center text-center">
                        <div
                          className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold transition-colors",
                            NODE_STYLE[etapa.status],
                          )}
                        >
                          {etapa.status === "CONCLUIDA" ? (
                            <Check className="h-4 w-4" />
                          ) : etapa.status === "PULADA" ? (
                            <SkipForward className="h-3.5 w-3.5" />
                          ) : etapa.status === "AGUARDANDO" ? (
                            <CircleDashed className="h-4 w-4" />
                          ) : (
                            etapa.sequencia
                          )}
                        </div>

                        <div
                          className={cn(
                            "mt-2 flex w-full flex-col gap-1.5 rounded-md border px-2.5 py-2",
                            isCurrent ? "border-accent/40 bg-accent/5" : "border-transparent",
                          )}
                        >
                          <p className={cn("truncate text-xs font-medium", isCurrent ? "text-accent" : "text-foreground")} title={setor?.nome}>
                            {setor?.nome ?? "Setor"}
                          </p>
                          <div className="flex items-center justify-center gap-2 text-[11px] tabular-nums text-muted-foreground">
                            <span title="Recebida">
                              <Qty value={etapa.quantidadeRecebida} decimals={0} />
                            </span>
                            <span className="text-success" title="Concluída">
                              →<Qty value={etapa.quantidadeConcluida} decimals={0} />
                            </span>
                            {etapa.quantidadePerdida > 0 && (
                              <span className="text-destructive" title="Perdida">
                                −<Qty value={etapa.quantidadePerdida} decimals={0} />
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Linha horizontal conectando ao próximo card da mesma linha —
                         sem seta; a cor reflete o status da etapa de destino do trecho.
                         O sentido de leitura da linha (→ nas pares, ← nas ímpares) já é
                         dado pela ordem visual dos cards (flex-row-reverse quando
                         invertida), não pelo conector. */}
                      {!isLastInRow && (
                        <div className="flex w-7 shrink-0 items-center justify-center sm:w-9">
                          <div className={cn("h-0.5 w-full rounded-full", CONNECTOR_BG[proximaNaLinha?.status ?? "AGUARDANDO"])} />
                        </div>
                      )}
                    </li>
                  );
                })}
              </ol>

              {/* Conector de quebra de linha (serpentina): uma linha vertical, sem
                 seta, que desce no lado onde a linha atual termina — direita quando
                 a linha vai da esquerda para a direita, esquerda quando vai da
                 direita para a esquerda — e a próxima linha recomeça exatamente sob
                 ela, alinhada ao centro do nó daquela coluna. */}
              {nextRowFirst && (
                <div className={cn("flex", reversed ? "justify-start" : "justify-end")}>
                  <div className="flex w-44 shrink-0 flex-col items-center py-0.5">
                    <div className={cn("h-4 w-0.5 rounded-full", CONNECTOR_BG[nextRowFirst.status])} />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
