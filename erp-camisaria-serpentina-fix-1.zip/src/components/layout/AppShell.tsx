"use client";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { useAuth } from "@/context/AuthContext";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { LoadingState } from "@/components/common/LoadingState";

export function AppShell({ children }: { children: React.ReactNode }) {
  // Guarda por `empresa`, não por `usuario`: além do login normal, o ADM DO
  // SITE também chega aqui sem `usuario` quando está navegando no contexto
  // de uma empresa (Etapa 26) — nesse caso `empresa` já vem preenchida pelo
  // AuthContext e o acesso é válido.
  const { loading, empresa } = useAuth();
  // Etapa 38 (achado da Etapa 35): quando o acesso cai (ex.: a empresa em
  // contexto foi inativada por outra aba do ADM DO SITE), `empresa` fica
  // null igual a um logout normal de empresa — mas o destino correto não é
  // o mesmo: um ADM DO SITE sem empresa deve voltar ao painel global
  // (/site), não ao login de empresa, mesmo vindo de outra aba/sessão.
  const { admin: platformAdmin, loading: platformLoading } = usePlatformAuth();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const router = useRouter();

  React.useEffect(() => {
    if (loading || platformLoading) return;
    if (!empresa) {
      router.replace(platformAdmin ? "/site" : "/login");
    }
  }, [loading, platformLoading, empresa, platformAdmin, router]);

  if (loading || platformLoading) {
    return (
      <div className="flex h-dvh items-center justify-center bg-background">
        <LoadingState label="Carregando sessão…" />
      </div>
    );
  }

  if (!empresa) return null;

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      <Sidebar mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header onOpenMobile={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-[1400px]">{children}</div>
        </main>
      </div>
    </div>
  );
}
