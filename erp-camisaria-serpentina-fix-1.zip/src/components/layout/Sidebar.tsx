"use client";
import * as React from "react";
import { Link } from "@/lib/next-compat";
import { usePathname } from "@/lib/next-compat";
import { Scissors, X } from "lucide-react";
import { NAV_GROUPS } from "@/constants/navigation";
import { useAuth } from "@/context/AuthContext";
import { cn } from "@/lib/utils";

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export function Sidebar({ mobileOpen, onCloseMobile }: SidebarProps) {
  const pathname = usePathname();
  const { hasPermission, empresa } = useAuth();

  const groups = NAV_GROUPS.map((g) => ({
    ...g,
    items: g.items.filter((i) => hasPermission(i.perm)),
  })).filter((g) => g.items.length > 0);

  const content = (
    <div className="flex h-full flex-col">
      <div className="flex h-14 items-center gap-2 border-b border-sidebar-border px-4">
        <div className="flex h-7 w-7 items-center justify-center rounded-md bg-sidebar-accent/20">
          <Scissors className="h-4 w-4 text-sidebar-accent" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-white">Camisaria ERP</p>
          <p className="truncate text-[11px] text-sidebar-foreground/70">{empresa?.nomeFantasia ?? "—"}</p>
        </div>
        <button onClick={onCloseMobile} className="ml-auto text-sidebar-foreground/70 hover:text-white lg:hidden">
          <X className="h-4 w-4" />
        </button>
      </div>
      <nav className="flex-1 overflow-y-auto px-2.5 py-4">
        {groups.map((group) => (
          <div key={group.label} className="mb-5">
            <p className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/50">
              {group.label}
            </p>
            <div className="flex flex-col gap-0.5">
              {group.items.map((item) => {
                const active = pathname === item.href || pathname.startsWith(item.href + "/");
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={onCloseMobile}
                    className={cn(
                      "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors",
                      active
                        ? "bg-sidebar-accent/15 text-white font-medium"
                        : "text-sidebar-foreground hover:bg-white/5 hover:text-white",
                    )}
                  >
                    <Icon className={cn("h-4 w-4 shrink-0", active ? "text-sidebar-accent" : "text-sidebar-foreground/70")} />
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
      <div className="border-t border-sidebar-border p-3">
        <p className="px-1 text-[10px] leading-relaxed text-sidebar-foreground/40">
          bd_competeV6 · mock local
        </p>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden w-64 shrink-0 border-r border-sidebar-border bg-sidebar lg:block">{content}</aside>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={onCloseMobile} />
          <aside className="absolute inset-y-0 left-0 w-64 bg-sidebar shadow-xl">{content}</aside>
        </div>
      )}
    </>
  );
}
