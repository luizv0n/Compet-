"use client";
import * as React from "react";
import { useParams, useRouter } from "@/lib/next-compat";
import { ArrowLeft, PlayCircle, PauseCircle, XCircle, Send, AlertTriangle } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { LoadingState } from "@/components/common/LoadingState";
import { EmptyState } from "@/components/common/EmptyState";
import { OrdemProducaoStatusBadge } from "@/components/common/StatusBadge";
import { Qty } from "@/components/common/Money";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { EtapaTimeline } from "@/components/producao/EtapaTimeline";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatDateTime } from "@/lib/utils";
import type {
  OrdemProducao,
  OrdemProducaoEtapa,
  MovimentacaoProducao,
  Produto,
  ProdutoVariacao,
  Estoque,
  FluxoProducao,
  Setor,
  MotivoPerda,
  Usuario,
  ProdutoComponente,
  KardexEntry,
} from "@/types";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

export default function OrdemProducaoDetalhePage() {
  const params = useParams<{ id: string }>();
  const opId = Number(params.id);
  const router = useRouter();
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.PRODUCTION_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [op, setOp] = React.useState<OrdemProducao | null>(null);
  const [etapas, setEtapas] = React.useState<OrdemProducaoEtapa[]>([]);
  const [movimentacoes, setMovimentacoes] = React.useState<MovimentacaoProducao[]>([]);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [fluxos, setFluxos] = React.useState<FluxoProducao[]>([]);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [motivos, setMotivos] = React.useState<MotivoPerda[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);
  const [componentes, setComponentes] = React.useState<ProdutoComponente[]>([]);
  const [kardex, setKardex] = React.useState<KardexEntry[]>([]);

  const [quantidadeEnviada, setQuantidadeEnviada] = React.useState("");
  const [quantidadePerdida, setQuantidadePerdida] = React.useState("");
  const [motivoPerdaId, setMotivoPerdaId] = React.useState("");
  const [obsMovimento, setObsMovimento] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [confirmCancel, setConfirmCancel] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [o, et, mv, p, v, e, f, s, m, u] = await Promise.all([
      apiClient.producao.get(opId, empresa.id),
      apiClient.producao.etapas(opId, empresa.id),
      apiClient.producao.movimentacoes(opId, empresa.id),
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.estoques.list(empresa.id),
      apiClient.fluxos.list(empresa.id),
      apiClient.setores.list(empresa.id, true),
      apiClient.motivosPerda.list(empresa.id),
      apiClient.equipe.list(empresa.id, true),
    ]);
    setOp(o ?? null);
    setEtapas(et);
    setMovimentacoes(mv);
    setProdutos(p);
    setVariacoes(v);
    setEstoques(e);
    setFluxos(f);
    setSetores(s);
    setMotivos(m);
    setUsuarios(u);

    if (o) {
      const [comp, kdx] = await Promise.all([apiClient.componentes.list(o.produtoVariacaoId, empresa.id), apiClient.kardex.list(empresa.id)]);
      setComponentes(comp);
      setKardex(kdx);
    } else {
      setComponentes([]);
      setKardex([]);
    }
    setLoading(false);
  }, [empresa, opId]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  if (!empresa) return null;
  if (loading) return <LoadingState />;
  if (!op) return <EmptyState title="Ordem de produção não encontrada" />;

  const variacao = variacoes.find((v) => v.id === op.produtoVariacaoId);
  const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
  const fluxo = fluxos.find((f) => f.id === op.fluxoProducaoId);
  const etapaAtual = etapas.find((e) => e.id === op.etapaAtualId);
  const disponivelNaEtapa = etapaAtual ? etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida : 0;
  const proximaEtapa = etapaAtual ? etapas.find((e) => e.sequencia === etapaAtual.sequencia + 1) : undefined;

  // Componentes da ficha técnica cujo consumo (Kardex PRODUCAO_CONSUMO)
  // ainda está abaixo do necessário para esta OP — indica que a reserva
  // feita na liberação (ou o consumo em alguma etapa concluída) não teve
  // saldo suficiente na época (regra 16: reserva insuficiente não bloqueia,
  // mas o usuário precisa perceber a pendência depois de recarregar a tela).
  // Todos os componentes ativos da ficha técnica, com necessário/consumido/
  // pendente — não só os pendentes (Etapa 9: lacuna encontrada na auditoria,
  // só existia visão do que faltava, nunca do que já tinha sido consumido).
  const componentesConsumo =
    op.status === "PLANEJADA"
      ? []
      : componentes
          .filter((c) => c.ativo)
          .map((c) => {
            const necessario = c.quantidade * op.quantidadePrevista;
            const consumido = kardex
              .filter((k) => k.ordemProducaoId === op.id && k.produtoVariacaoId === c.produtoFilhoId && k.natureza === "PRODUCAO_CONSUMO" && k.sentido === "SAIDA")
              .reduce((acc, k) => acc + k.quantidade, 0);
            const variacaoComp = variacoes.find((v) => v.id === c.produtoFilhoId);
            const produtoComp = variacaoComp ? produtos.find((p) => p.id === variacaoComp.produtoId) : undefined;
            const setorComp = setores.find((s) => s.id === c.setorId);
            return { componente: c, necessario, consumido, pendente: Math.max(0, necessario - consumido), variacaoComp, produtoComp, setorComp };
          });

  const componentesPendentes = componentesConsumo.filter((x) => x.pendente > 1e-9);

  async function handleRelease() {
    if (!actor) return;
    try {
      const { avisos } = await apiClient.producao.release(op!.id, empresa!.id, actor);
      if (avisos.length > 0) {
        toast({ title: "OP liberada com alertas de estoque", description: avisos.join(" "), variant: "error" });
      } else {
        toast({ title: "OP liberada para produção", variant: "success" });
      }
      reload();
    } catch (err) {
      toast({ title: "Não foi possível liberar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  async function handlePauseResume() {
    if (!actor) return;
    try {
      await apiClient.producao.pauseResume(op!.id, empresa!.id, actor);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  async function handleCancel() {
    if (!actor) return;
    await apiClient.producao.cancel(op!.id, empresa!.id, actor);
    toast({ title: "OP cancelada", variant: "success" });
    reload();
  }

  async function handleMove(e: React.FormEvent) {
    e.preventDefault();
    if (!actor) return;
    const enviada = Number(quantidadeEnviada) || 0;
    const perdida = Number(quantidadePerdida) || 0;
    if (enviada <= 0 && perdida <= 0) {
      toast({ title: "Informe a quantidade enviada e/ou perdida.", variant: "error" });
      return;
    }
    if (!Number.isInteger(enviada) || !Number.isInteger(perdida) || enviada < 0 || perdida < 0) {
      toast({ title: "As quantidades devem ser números inteiros maiores ou iguais a zero.", variant: "error" });
      return;
    }
    if (perdida > 0 && !motivoPerdaId) {
      toast({ title: "Selecione o motivo da perda.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      const { avisos } = await apiClient.producao.move(empresa!.id, actor, {
        ordemProducaoId: op!.id,
        quantidadeEnviada: enviada,
        quantidadePerdida: perdida,
        motivoPerdaId: perdida > 0 ? Number(motivoPerdaId) : null,
        observacao: obsMovimento.trim() || undefined,
      });
      if (avisos.length > 0) {
        toast({ title: "Movimentação registrada com alertas de estoque", description: avisos.join(" "), variant: "error" });
      } else {
        toast({ title: "Movimentação registrada", variant: "success" });
      }
      setQuantidadeEnviada("");
      setQuantidadePerdida("");
      setMotivoPerdaId("");
      setObsMovimento("");
      reload();
    } catch (err) {
      toast({ title: "Não foi possível movimentar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <RequirePermission perm={PERMISSIONS.PRODUCTION_VIEW}>
      <Button variant="ghost" size="sm" className="mb-2 -ml-2" onClick={() => router.push("/producao")}>
        <ArrowLeft className="h-4 w-4" /> Voltar para ordens de produção
      </Button>
      <PageHeader
        title={`${op.codigo} — ${produto?.nome ?? ""}`}
        badge={<OrdemProducaoStatusBadge status={op.status} />}
        description={`SKU ${variacao?.sku} · Fluxo: ${fluxo?.nome ?? "—"} · Lote: ${op.lote ?? "—"}`}
        actions={
          canManage && (
            <div className="flex flex-wrap gap-2">
              {op.status === "PLANEJADA" && (
                <Button size="sm" onClick={handleRelease}>
                  <PlayCircle className="h-4 w-4" /> Liberar
                </Button>
              )}
              {(op.status === "EM_PRODUCAO" || op.status === "PAUSADA") && (
                <Button size="sm" variant="secondary" onClick={handlePauseResume}>
                  <PauseCircle className="h-4 w-4" /> {op.status === "PAUSADA" ? "Retomar" : "Pausar"}
                </Button>
              )}
              {op.status !== "CONCLUIDA" && op.status !== "CANCELADA" && (
                <Button size="sm" variant="outline" onClick={() => setConfirmCancel(true)}>
                  <XCircle className="h-4 w-4" /> Cancelar OP
                </Button>
              )}
            </div>
          )
        }
      />

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle>Resumo</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 text-sm">
            {componentesPendentes.length > 0 && (
              <Row
                label="Consumo de componentes"
                value={
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <span className="inline-flex items-center gap-1 rounded-full border border-destructive/40 bg-destructive/10 px-2 py-0.5 text-xs font-medium text-destructive">
                        <AlertTriangle className="h-3.5 w-3.5" /> Pendente por falta de saldo
                      </span>
                    </TooltipTrigger>
                    <TooltipContent className="max-w-xs">
                      <p className="mb-1 font-medium">Componentes com consumo pendente:</p>
                      <ul className="list-disc pl-4">
                        {componentesPendentes.map(({ componente, pendente }) => {
                          const varComp = variacoes.find((v) => v.id === componente.produtoFilhoId);
                          const prodComp = varComp ? produtos.find((p) => p.id === varComp.produtoId) : undefined;
                          return (
                            <li key={componente.id}>
                              {prodComp?.nome ?? "Componente"} ({varComp?.sku ?? componente.produtoFilhoId}): faltam <Qty value={pendente} />
                            </li>
                          );
                        })}
                      </ul>
                    </TooltipContent>
                  </Tooltip>
                }
              />
            )}
            <div className="py-1.5">
              <div className="mb-1.5 flex items-center justify-between text-xs">
                <span className="text-muted-foreground">Progresso</span>
                <span className="font-medium tabular-nums text-foreground">
                  {op.quantidadePrevista > 0 ? Math.round((op.quantidadeProduzida / op.quantidadePrevista) * 100) : 0}%
                </span>
              </div>
              <Progress value={op.quantidadePrevista > 0 ? (op.quantidadeProduzida / op.quantidadePrevista) * 100 : 0} className="h-1.5" />
            </div>
            <Row label="Prevista" value={<Qty value={op.quantidadePrevista} />} />
            <Row label="Produzida" value={<Qty value={op.quantidadeProduzida} className="text-success" />} />
            <Row label="Refugada" value={<Qty value={op.quantidadeRefugada} className={op.quantidadeRefugada > 0 ? "text-destructive" : undefined} />} />
            <Row label="Estoque origem" value={estoques.find((e) => e.id === op.estoqueOrigemId)?.nome ?? "—"} />
            <Row label="Estoque destino" value={estoques.find((e) => e.id === op.estoqueDestinoId)?.nome ?? "—"} />
            <Row label="Aberta em" value={formatDateTime(op.dataAbertura)} />
            {op.observacao && <Row label="Observação" value={op.observacao} />}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Etapas do fluxo</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {etapas.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState title="OP ainda não liberada — sem etapas geradas" />
              </div>
            ) : (
              <div className="border-t px-3 pb-3 pt-1">
                <EtapaTimeline etapas={etapas} setores={setores} etapaAtualId={op.etapaAtualId} />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {componentesConsumo.length > 0 && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle>Componentes da ficha técnica</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="border-t">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Componente</TableHead>
                    <TableHead>Setor de consumo</TableHead>
                    <TableHead className="text-right">Necessário</TableHead>
                    <TableHead className="text-right">Consumido</TableHead>
                    <TableHead className="text-right">Pendente</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {componentesConsumo.map((row) => (
                    <TableRow key={row.componente.id}>
                      <TableCell className="font-medium text-foreground">
                        {row.produtoComp?.nome ?? "Componente"}{" "}
                        <span className="font-mono text-xs text-muted-foreground">({row.variacaoComp?.sku ?? row.componente.produtoFilhoId})</span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{row.setorComp?.nome ?? "1ª etapa"}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        <Qty value={row.necessario} />
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-success">
                        <Qty value={row.consumido} />
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {row.pendente > 1e-9 ? (
                          <span className="text-destructive">
                            <Qty value={row.pendente} />
                          </span>
                        ) : (
                          <span className="text-muted-foreground">0</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {canManage && etapaAtual && (op.status === "EM_PRODUCAO" || op.status === "LIBERADA") && (
        <Card className="mt-4">
          <CardHeader>
            <CardTitle>
              Movimentar — {setores.find((s) => s.id === etapaAtual.setorId)?.nome}
              {proximaEtapa ? ` → ${setores.find((s) => s.id === proximaEtapa.setorId)?.nome}` : " → conclusão"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-1 text-xs text-muted-foreground">
              Disponível na etapa atual: <Qty value={disponivelNaEtapa} />
            </p>
            <p className="mb-3 text-xs text-muted-foreground">
              Registre nesta mesma movimentação o resultado da leva: a parte boa segue para{" "}
              {proximaEtapa ? "a próxima etapa" : "o estoque"} e a parte perdida vira refugo (exige motivo). A soma
              das duas não pode ultrapassar o disponível — ex.: de 100 recebidas, 90 boas + 10 refugadas.
            </p>
            <form onSubmit={handleMove} className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <div className="flex flex-col gap-1.5">
                <Label>Quantidade enviada</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  step={1}
                  value={quantidadeEnviada}
                  onChange={(e) => setQuantidadeEnviada(e.target.value)}
                  placeholder="0"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Quantidade perdida</Label>
                <Input
                  type="number"
                  inputMode="numeric"
                  min={0}
                  step={1}
                  value={quantidadePerdida}
                  onChange={(e) => setQuantidadePerdida(e.target.value)}
                  placeholder="0"
                />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Motivo (se houver perda)</Label>
                <Select value={motivoPerdaId} onValueChange={setMotivoPerdaId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {motivos.map((m) => (
                      <SelectItem key={m.id} value={String(m.id)}>
                        {m.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex flex-col gap-1.5">
                <Label>Observação (opcional)</Label>
                <Textarea value={obsMovimento} onChange={(e) => setObsMovimento(e.target.value)} rows={1} />
              </div>
              <div className="sm:col-span-2 lg:col-span-4">
                <Button type="submit" loading={submitting}>
                  <Send className="h-4 w-4" /> Registrar movimentação
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card className="mt-4">
        <CardHeader>
          <CardTitle>Histórico de movimentações</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {movimentacoes.length === 0 ? (
            <div className="px-5 pb-5">
              <EmptyState title="Nenhuma movimentação registrada" />
            </div>
          ) : (
            <div className="divide-y border-t">
              {movimentacoes.map((mv) => {
                const origem = setores.find((s) => s.id === mv.setorOrigemId);
                const destino = setores.find((s) => s.id === mv.setorDestinoId);
                const usuario = usuarios.find((u) => u.id === mv.usuarioId);
                const motivo = motivos.find((m) => m.id === mv.motivoPerdaId);
                return (
                  <div key={mv.id} className="flex items-center justify-between px-5 py-2.5">
                    <div className="min-w-0">
                      <p className="text-sm text-foreground">
                        {origem?.nome ?? "Abertura"} → {destino?.nome ?? "Conclusão"}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {formatDateTime(mv.dataMovimentacao)} · {usuario?.nome ?? "—"}
                        {mv.observacao ? ` · ${mv.observacao}` : ""}
                        {motivo ? ` · Motivo: ${motivo.nome}` : ""}
                      </p>
                    </div>
                    <div className="shrink-0 text-right text-sm">
                      <span className="font-medium text-success">
                        +<Qty value={mv.quantidade} />
                      </span>
                      {mv.quantidadePerdida > 0 && (
                        <span className="ml-2 font-medium text-destructive">
                          −<Qty value={mv.quantidadePerdida} />
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirmCancel}
        onOpenChange={setConfirmCancel}
        title="Cancelar esta ordem de produção?"
        description="A OP será marcada como cancelada. Movimentações já realizadas não são desfeitas."
        confirmLabel="Cancelar OP"
        destructive
        onConfirm={handleCancel}
      />
    </RequirePermission>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between border-b border-border/60 py-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium text-foreground">{value}</span>
    </div>
  );
}
