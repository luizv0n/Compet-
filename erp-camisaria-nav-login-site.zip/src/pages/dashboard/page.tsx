"use client";
import * as React from "react";
import { Link } from "@/lib/next-compat";
import {
  Package,
  Warehouse,
  Factory,
  ShoppingCart,
  ArrowRight,
  AlertTriangle,
} from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoadingState } from "@/components/common/LoadingState";
import { EmptyState } from "@/components/common/EmptyState";
import { OrdemProducaoStatusBadge } from "@/components/common/StatusBadge";
import { Progress } from "@/components/ui/progress";
import { Qty } from "@/components/common/Money";
import { BarChart, RankingBars } from "@/components/common/SvgCharts";
import { formatDateTime } from "@/lib/utils";
import { KARDEX_NATUREZA_LABEL } from "@/types";
import type { OrdemProducao, Produto, ProdutoVariacao, KardexEntry, Estoque, NotaFiscal, Setor, MovimentacaoProducao, Tamanho, EstoqueMinimo } from "@/types";

// Fallback usado apenas para SKUs de produto acabado que ainda não têm um
// estoque mínimo configurado (Etapa 14 — regra 25 do Prompt Master). Uma
// variação com mínimo configurado em Produtos → SKU → "Mínimo" usa sempre
// o valor configurado; este número só entra quando não há configuração.
const LOW_STOCK_FALLBACK = 15;

export default function DashboardPage() {
  const { empresa, usuario } = useAuth();
  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [saldos, setSaldos] = React.useState<{ produtoVariacaoId: number; estoqueId: number; quantidade: number }[]>([]);
  const [estoques, setEstoques] = React.useState<Estoque[]>([]);
  const [ops, setOps] = React.useState<OrdemProducao[]>([]);
  const [kardex, setKardex] = React.useState<KardexEntry[]>([]);
  const [notas, setNotas] = React.useState<NotaFiscal[]>([]);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [movimentacoes, setMovimentacoes] = React.useState<MovimentacaoProducao[]>([]);
  const [tamanhos, setTamanhos] = React.useState<Tamanho[]>([]);
  const [minimos, setMinimos] = React.useState<EstoqueMinimo[]>([]);

  React.useEffect(() => {
    if (!empresa) return;
    (async () => {
      setLoading(true);
      const [p, v, s, e, o, k, nf, st, mv, tm, mn] = await Promise.all([
        apiClient.produtos.list(empresa.id),
        apiClient.variacoes.list(empresa.id),
        apiClient.estoques.saldos(empresa.id),
        apiClient.estoques.list(empresa.id),
        apiClient.producao.list(empresa.id),
        apiClient.kardex.list(empresa.id),
        apiClient.compras.list(empresa.id),
        apiClient.setores.list(empresa.id),
        apiClient.producao.movimentacoesEmpresa(empresa.id),
        apiClient.tamanhos.list(empresa.id),
        apiClient.estoques.minimos(empresa.id),
      ]);
      setProdutos(p);
      setVariacoes(v);
      setSaldos(s);
      setEstoques(e);
      setOps(o);
      setKardex(k);
      setNotas(nf);
      setSetores(st);
      setMovimentacoes(mv);
      setTamanhos(tm);
      setMinimos(mn);
      setLoading(false);
    })();
  }, [empresa]);

  if (loading || !empresa) return <LoadingState label="Carregando painel…" />;

  const produtosAtivos = produtos.filter((p) => p.ativo).length;
  const skusAtivos = variacoes.filter((v) => v.ativo).length;
  const saldoTotal = saldos.reduce((sum, s) => sum + s.quantidade, 0);
  const opsAtivas = ops.filter((o) => o.status === "EM_PRODUCAO" || o.status === "LIBERADA" || o.status === "PAUSADA");
  const notasAbertas = notas.filter((n) => n.status === "ABERTA");

  // Saldo consolidado por variação (soma entre estoques) para alerta de baixo estoque
  const saldoPorVariacao = new Map<number, number>();
  for (const s of saldos) {
    saldoPorVariacao.set(s.produtoVariacaoId, (saldoPorVariacao.get(s.produtoVariacaoId) ?? 0) + s.quantidade);
  }
  const minimoPorVariacao = new Map(minimos.map((m) => [m.produtoVariacaoId, m.quantidade]));
  const baixoEstoque = variacoes
    .filter((v) => v.ativo)
    .map((v) => ({
      variacao: v,
      produto: produtos.find((p) => p.id === v.produtoId),
      saldo: saldoPorVariacao.get(v.id) ?? 0,
      minimo: minimoPorVariacao.get(v.id) ?? LOW_STOCK_FALLBACK,
    }))
    .filter((row) => row.produto?.tipo === "PC" && row.saldo < row.minimo)
    .sort((a, b) => a.saldo - b.saldo)
    .slice(0, 6);

  const recentKardex = kardex.slice(0, 6);
  const recentOps = ops.slice(0, 5);

  // ---- Gráfico: entrada de peças por setor nos últimos 7 dias ----
  const seteDiasAtras = new Date();
  seteDiasAtras.setDate(seteDiasAtras.getDate() - 6);
  seteDiasAtras.setHours(0, 0, 0, 0);
  const movRecentes = movimentacoes.filter((m) => new Date(m.dataMovimentacao) >= seteDiasAtras);

  const entradaPorSetor = new Map<number, number>();
  const perdaPorSetor = new Map<number, number>();
  const totalPorSetor = new Map<number, number>();
  for (const m of movRecentes) {
    if (m.setorDestinoId) {
      entradaPorSetor.set(m.setorDestinoId, (entradaPorSetor.get(m.setorDestinoId) ?? 0) + m.quantidade);
    }
    if (m.setorOrigemId) {
      perdaPorSetor.set(m.setorOrigemId, (perdaPorSetor.get(m.setorOrigemId) ?? 0) + m.quantidadePerdida);
      totalPorSetor.set(m.setorOrigemId, (totalPorSetor.get(m.setorOrigemId) ?? 0) + m.quantidade + m.quantidadePerdida);
    }
  }
  const setoresProdutivos = setores.filter((s) => s.ativo && (entradaPorSetor.has(s.id) || totalPorSetor.has(s.id)));

  const entradaPorSetorChart = setoresProdutivos.map((s) => ({
    label: s.nome.length > 8 ? `${s.nome.slice(0, 7)}…` : s.nome,
    value: entradaPorSetor.get(s.id) ?? 0,
    tooltip: `${s.nome}: ${entradaPorSetor.get(s.id) ?? 0} peça(s)`,
  }));

  const taxaDefeitosChart = setoresProdutivos.map((s) => {
    const total = totalPorSetor.get(s.id) ?? 0;
    const perda = perdaPorSetor.get(s.id) ?? 0;
    const taxa = total > 0 ? (perda / total) * 100 : 0;
    return {
      label: s.nome.length > 8 ? `${s.nome.slice(0, 7)}…` : s.nome,
      value: Number(taxa.toFixed(1)),
      tooltip: `${s.nome}: ${taxa.toFixed(1)}% (${perda}/${total})`,
    };
  });

  // ---- Ranking: tamanhos mais movimentados (Kardex, últimos 30 dias) ----
  const trintaDiasAtras = new Date();
  trintaDiasAtras.setDate(trintaDiasAtras.getDate() - 29);
  trintaDiasAtras.setHours(0, 0, 0, 0);
  const variacaoPorId = new Map(variacoes.map((v) => [v.id, v]));
  const porTamanho = new Map<number, number>();
  for (const k of kardex) {
    if (new Date(k.dataMovimentacao) < trintaDiasAtras) continue;
    const variacao = variacaoPorId.get(k.produtoVariacaoId);
    if (!variacao?.tamanhoId) continue;
    porTamanho.set(variacao.tamanhoId, (porTamanho.get(variacao.tamanhoId) ?? 0) + k.quantidade);
  }
  const rankingTamanhos = Array.from(porTamanho.entries())
    .map(([tamanhoId, value]) => ({ label: tamanhos.find((t) => t.id === tamanhoId)?.nome ?? "—", value }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 5);

  const kpis = [
    { label: "Produtos ativos", value: produtosAtivos, sub: `${skusAtivos} SKUs`, icon: Package, href: "/produtos" },
    { label: "Saldo em estoque", value: <Qty value={saldoTotal} decimals={0} />, sub: `${estoques.length} locais`, icon: Warehouse, href: "/estoque" },
    { label: "OPs em andamento", value: opsAtivas.length, sub: `${ops.length} no total`, icon: Factory, href: "/producao" },
    { label: "Compras em aberto", value: notasAbertas.length, sub: `${notas.length} lançadas`, icon: ShoppingCart, href: "/compras" },
  ];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">Olá, {usuario?.nome?.split(" ")[0]}</h1>
        <p className="mt-1 text-sm text-muted-foreground">Panorama de {empresa.nomeFantasia} em tempo real.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {kpis.map((kpi) => (
          <Link key={kpi.label} href={kpi.href}>
            <Card className="transition-shadow hover:shadow-md">
              <CardContent className="flex items-start justify-between p-5">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{kpi.label}</p>
                  <p className="mt-2 text-2xl font-semibold tabular-nums text-foreground">{kpi.value}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{kpi.sub}</p>
                </div>
                <div className="rounded-md bg-accent/10 p-2">
                  <kpi.icon className="h-4 w-4 text-accent" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Entrada de peças por setor (7 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <BarChart data={entradaPorSetorChart} valueFormatter={(v) => `${v} peça(s)`} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Taxa de defeitos por setor (7 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <BarChart data={taxaDefeitosChart} barColor="hsl(var(--destructive))" valueFormatter={(v) => `${v}%`} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Tamanhos mais movimentados (30 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <RankingBars data={rankingTamanhos} />
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle>Ordens de produção recentes</CardTitle>
            <Link href="/producao" className="flex items-center gap-1 text-xs font-medium text-accent hover:underline">
              Ver todas <ArrowRight className="h-3 w-3" />
            </Link>
          </CardHeader>
          <CardContent className="p-0">
            {recentOps.length === 0 ? (
              <div className="px-5 pb-5">
                <EmptyState title="Nenhuma ordem de produção" icon={Factory} />
              </div>
            ) : (
              <div className="divide-y border-t">
                {recentOps.map((op) => {
                  const variacao = variacoes.find((v) => v.id === op.produtoVariacaoId);
                  const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                  return (
                    <Link key={op.id} href={`/producao/${op.id}`} className="flex items-center justify-between gap-3 px-5 py-3 hover:bg-secondary/40">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium text-foreground">
                          {op.codigo} · {produto?.nome} {variacao?.sku ? `(${variacao.sku})` : ""}
                        </p>
                        <div className="mt-1.5 flex items-center gap-2">
                          <Progress
                            value={op.quantidadePrevista > 0 ? (op.quantidadeProduzida / op.quantidadePrevista) * 100 : 0}
                            className="h-1 w-24"
                          />
                          <p className="whitespace-nowrap text-xs tabular-nums text-muted-foreground">
                            {op.quantidadeProduzida}/{op.quantidadePrevista}
                          </p>
                          <p className="truncate text-xs text-muted-foreground">· aberta em {formatDateTime(op.dataAbertura)}</p>
                        </div>
                      </div>
                      <OrdemProducaoStatusBadge status={op.status} />
                    </Link>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="flex items-center gap-1.5">
              <AlertTriangle className="h-3.5 w-3.5 text-warning" /> Estoque baixo
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {baixoEstoque.length === 0 ? (
              <div className="px-5 pb-5">
                <p className="text-sm text-muted-foreground">Nenhum produto acabado abaixo do estoque mínimo.</p>
              </div>
            ) : (
              <div className="divide-y border-t">
                {baixoEstoque.map((row) => (
                  <Link
                    key={row.variacao.id}
                    href={`/estoque/kardex?variacao=${row.variacao.id}`}
                    className="flex items-center justify-between px-5 py-2.5 hover:bg-secondary/40"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm text-foreground">{row.produto?.nome}</p>
                      <p className="text-xs text-muted-foreground">{row.variacao.sku}</p>
                    </div>
                    <span className="shrink-0 text-right text-sm font-semibold tabular-nums text-warning">
                      {row.saldo}
                      <span className="block text-[10px] font-normal text-muted-foreground">mín. {row.minimo}</span>
                    </span>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader className="flex-row items-center justify-between space-y-0">
          <CardTitle>Atividade recente do Kardex</CardTitle>
          <Link href="/estoque/kardex" className="flex items-center gap-1 text-xs font-medium text-accent hover:underline">
            Ver histórico completo <ArrowRight className="h-3 w-3" />
          </Link>
        </CardHeader>
        <CardContent className="p-0">
          {recentKardex.length === 0 ? (
            <div className="px-5 pb-5">
              <EmptyState title="Nenhuma movimentação registrada" />
            </div>
          ) : (
            <div className="divide-y border-t">
              {recentKardex.map((k) => {
                const variacao = variacoes.find((v) => v.id === k.produtoVariacaoId);
                const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                return (
                  <Link
                    key={k.id}
                    href={`/estoque/kardex?variacao=${k.produtoVariacaoId}`}
                    className="flex items-center justify-between px-5 py-2.5 hover:bg-secondary/40"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm text-foreground">
                        {produto?.nome} <span className="text-muted-foreground">({variacao?.sku})</span>
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {KARDEX_NATUREZA_LABEL[k.natureza]} · {formatDateTime(k.dataMovimentacao)}
                      </p>
                    </div>
                    <span className={`shrink-0 text-sm font-semibold tabular-nums ${k.sentido === "ENTRADA" ? "text-success" : "text-destructive"}`}>
                      {k.sentido === "ENTRADA" ? "+" : "−"}
                      <Qty value={k.quantidade} />
                    </span>
                  </Link>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
