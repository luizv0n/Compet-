import { Check, CircleDashed, SkipForward } from "lucide-react";
import { cn } from "@/lib/utils";
import { Qty } from "@/components/common/Money";
import type { OrdemProducaoEtapa, OrdemProducaoEtapaStatus, Setor } from "@/types";

interface EtapaTimelineProps {
  etapas: OrdemProducaoEtapa[];
  setores: Setor[];
  etapaAtualId?: number | null;
}

const NODE_STYLE: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "border-success bg-success text-success-foreground",
  EM_EXECUCAO: "border-accent bg-accent text-accent-foreground ring-4 ring-accent/20",
  AGUARDANDO: "border-border bg-card text-muted-foreground",
  PULADA: "border-warning bg-warning text-warning-foreground",
};

const CONNECTOR_STYLE: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "bg-success",
  EM_EXECUCAO: "bg-accent",
  AGUARDANDO: "bg-border",
  PULADA: "bg-warning",
};

/**
 * Timeline horizontal das etapas de uma OP — tela de referência visual
 * (seção 46 do prompt mestre). Substitui a listagem tabular simples por
 * um stepper que comunica de imediato: o que já foi concluído, onde a
 * OP está agora e o que falta, sem esconder as quantidades por etapa.
 *
 * Reutilizável: qualquer fluxo sequencial futuro (ex.: notas de compra
 * com etapas, onboarding de empresa) pode reaproveitar este padrão.
 */
export function EtapaTimeline({ etapas, setores, etapaAtualId }: EtapaTimelineProps) {
  const ordered = [...etapas].sort((a, b) => a.sequencia - b.sequencia);

  return (
    <div className="overflow-x-auto">
      <ol className="flex min-w-max items-stretch gap-0 px-1 py-2">
        {ordered.map((etapa, idx) => {
          const setor = setores.find((s) => s.id === etapa.setorId);
          const isCurrent = etapaAtualId === etapa.id;
          const isLast = idx === ordered.length - 1;

          return (
            <li key={etapa.id} className="flex items-stretch">
              <div className="flex w-44 flex-col items-center text-center">
                <div className="flex w-full items-center">
                  <div className={cn("h-0.5 flex-1", idx === 0 ? "opacity-0" : CONNECTOR_STYLE[etapa.status])} />
                  <div
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold transition-colors",
                      NODE_STYLE[etapa.status],
                    )}
                  >
                    {etapa.status === "CONCLUIDA" ? (
                      <Check className="h-4 w-4" />
                    ) : etapa.status === "PULADA" ? (
                      <SkipForward className="h-3.5 w-3.5" />
                    ) : etapa.status === "AGUARDANDO" ? (
                      <CircleDashed className="h-4 w-4" />
                    ) : (
                      etapa.sequencia
                    )}
                  </div>
                  <div className={cn("h-0.5 flex-1", isLast ? "opacity-0" : CONNECTOR_STYLE[etapas.find((e) => e.sequencia === etapa.sequencia + 1)?.status ?? "AGUARDANDO"])} />
                </div>

                <div
                  className={cn(
                    "mt-2 flex w-full flex-col gap-1.5 rounded-md border px-2.5 py-2",
                    isCurrent ? "border-accent/40 bg-accent/5" : "border-transparent",
                  )}
                >
                  <p className={cn("truncate text-xs font-medium", isCurrent ? "text-accent" : "text-foreground")} title={setor?.nome}>
                    {setor?.nome ?? "Setor"}
                  </p>
                  <div className="flex items-center justify-center gap-2 text-[11px] tabular-nums text-muted-foreground">
                    <span title="Recebida">
                      <Qty value={etapa.quantidadeRecebida} decimals={0} />
                    </span>
                    <span className="text-success" title="Concluída">
                      →<Qty value={etapa.quantidadeConcluida} decimals={0} />
                    </span>
                    {etapa.quantidadePerdida > 0 && (
                      <span className="text-destructive" title="Perdida">
                        −<Qty value={etapa.quantidadePerdida} decimals={0} />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
