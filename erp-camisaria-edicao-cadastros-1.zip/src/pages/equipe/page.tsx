"use client";
import * as React from "react";
import { Plus, Users, Pencil } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { ROLE_NAMES } from "@/constants/permissions";
import type { Usuario, Cargo } from "@/types";

const emptyForm = { nome: "", login: "", email: "", senha: "", cargoId: "" };

export default function EquipePage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.TEAM_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);
  const [cargos, setCargos] = React.useState<Cargo[]>([]);
  const [query, setQuery] = React.useState("");
  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Usuario | null>(null);
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [u, c] = await Promise.all([apiClient.equipe.list(empresa.id, true), apiClient.equipe.cargos(empresa.id)]);
    setUsuarios(u);
    setCargos(c);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const filtered = usuarios.filter((u) => (u.nome + " " + u.login).toLowerCase().includes(query.toLowerCase()));

  function openCreate() {
    setEditing(null);
    setForm({ ...emptyForm, cargoId: cargos[0] ? String(cargos[0].id) : "" });
    setDialogOpen(true);
  }
  function openEdit(item: Usuario) {
    setEditing(item);
    setForm({ nome: item.nome, login: item.login, email: item.email, senha: "", cargoId: String(item.cargoId) });
    setDialogOpen(true);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor) return;
    if (!form.nome.trim() || !form.login.trim() || !form.email.trim() || !form.cargoId) {
      toast({ title: "Preencha todos os campos.", variant: "error" });
      return;
    }
    if (!editing && !form.senha.trim()) {
      toast({ title: "Defina uma senha inicial.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.equipe.update(editing.id, empresa.id, actor, {
          nome: form.nome.trim(),
          login: form.login.trim(),
          email: form.email.trim(),
          cargoId: Number(form.cargoId),
          ...(form.senha.trim() ? { senha: form.senha.trim() } : {}),
        });
        toast({ title: "Usuário atualizado", variant: "success" });
      } else {
        await apiClient.equipe.create(empresa.id, actor, {
          nome: form.nome.trim(),
          login: form.login.trim(),
          email: form.email.trim(),
          senha: form.senha.trim(),
          cargoId: Number(form.cargoId),
        });
        toast({ title: "Usuário cadastrado", variant: "success" });
      }
      setDialogOpen(false);
      reload();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: Usuario) {
    if (!empresa || !actor) return;
    try {
      await apiClient.equipe.toggle(item.id, empresa.id, actor);
      toast({ title: item.ativo ? "Usuário inativado" : "Usuário ativado", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  if (!empresa) return null;

  return (
    <RequirePermission perm={PERMISSIONS.TEAM_MANAGE}>
      <PageHeader
        title="Equipe"
        description="Usuários da empresa e seus cargos (Administrador ou Funcionário)."
        actions={
          canManage && (
            <Button size="sm" onClick={openCreate}>
              <Plus className="h-4 w-4" /> Novo usuário
            </Button>
          )
        }
      />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4">
            <SearchInput value={query} onChange={setQuery} placeholder="Buscar por nome ou login…" />
          </div>
          {filtered.length === 0 ? (
            <EmptyState icon={Users} title="Nenhum usuário encontrado" />
          ) : (
            <div className="rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nome</TableHead>
                    <TableHead>Login</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Cargo</TableHead>
                    <TableHead>Status</TableHead>
                    {canManage && <TableHead className="text-right">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((item) => {
                    const cargo = cargos.find((c) => c.id === item.cargoId);
                    return (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium text-foreground">{item.nome}</TableCell>
                        <TableCell className="font-mono text-xs text-muted-foreground">{item.login}</TableCell>
                        <TableCell className="text-muted-foreground">{item.email}</TableCell>
                        <TableCell>
                          <Badge variant={cargo?.nome === ROLE_NAMES.ADMIN ? "accent" : "info"}>
                            {cargo?.nome === ROLE_NAMES.ADMIN ? "Administrador" : "Funcionário"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <ActiveBadge ativo={item.ativo} />
                        </TableCell>
                        {canManage && (
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-3">
                              <button onClick={() => openEdit(item)} className="text-muted-foreground hover:text-foreground">
                                <Pencil className="h-3.5 w-3.5" />
                              </button>
                              <Switch checked={item.ativo} onCheckedChange={() => handleToggle(item)} disabled={item.id === actor?.id} />
                            </div>
                          </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar usuário" : "Novo usuário"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="unome">Nome</Label>
              <Input id="unome" value={form.nome} onChange={(e) => setForm({ ...form, nome: e.target.value })} autoFocus />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="ulogin">Login</Label>
                <Input id="ulogin" value={form.login} onChange={(e) => setForm({ ...form, login: e.target.value })} />
              </div>
              <div className="flex flex-col gap-1.5">
                <Label htmlFor="uemail">Email</Label>
                <Input id="uemail" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Cargo</Label>
              <Select value={form.cargoId} onValueChange={(v) => setForm({ ...form, cargoId: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {cargos.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.nome === ROLE_NAMES.ADMIN ? "Administrador" : "Funcionário"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="usenha">{editing ? "Nova senha (opcional)" : "Senha inicial"}</Label>
              <Input id="usenha" type="password" value={form.senha} onChange={(e) => setForm({ ...form, senha: e.target.value })} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
