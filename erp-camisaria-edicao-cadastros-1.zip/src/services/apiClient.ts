// =====================================================================
// apiClient.ts — fachada assíncrona de domínio.
//
// Páginas e hooks SÓ importam daqui. Cada função devolve uma Promise,
// pensada para no futuro ser substituída por fetch() para um backend
// real sem alterar nenhuma tela.
// =====================================================================

import * as repo from "./mockRepository";
import type { ID } from "@/types";
import type {
  CreateEmpresaPayload,
  CreatePurchaseNotePayload,
  CreateProductPayload,
  CreateProductionOrderPayload,
  CreateVariantPayload,
  DirectStockInPayload,
  FinishedGoodsEntryPayload,
  ManualStockOutPayload,
  ProductionMovePayload,
  TransferPayload,
} from "@/types/viewmodels";
import type { Empresa, Fornecedor, MotivoPerda, Setor, Estoque, Produto, Usuario } from "@/types";
import { sleep } from "@/lib/utils";

const LATENCY_MS = 260;

async function call<T>(fn: () => T): Promise<T> {
  await sleep(LATENCY_MS);
  return fn();
}

export interface ActorContext {
  id: ID;
  nome: string;
}

export const apiClient = {
  auth: {
    listEmpresas: () => call(() => repo.listEmpresas()),
    login: (empresaId: ID, login: string, senha: string) => call(() => repo.authenticate(empresaId, login, senha)),
    sessionContext: (usuarioId: ID, empresaId: ID) => call(() => repo.getSessionContext(usuarioId, empresaId)),
  },

  // Camada de plataforma (ADM DO SITE) — independente de `auth` acima.
  // Telas que consomem isto pertencem às Etapas 5 (login) e 6 (painel
  // global); esta fachada é a fundação que elas vão usar.
  plataforma: {
    login: (login: string, senha: string) => call(() => repo.authenticatePlataforma(login, senha)),
    sessionContext: (adminId: ID) => call(() => repo.getPlatformSessionContext(adminId)),
    listEmpresas: (includeInactive?: boolean) => call(() => repo.listEmpresasGlobal(includeInactive)),
    getEmpresa: (id: ID) => call(() => repo.getEmpresa(id)),
    createEmpresa: (actor: ActorContext, payload: CreateEmpresaPayload) => call(() => repo.createEmpresaComAdmin(actor, payload)),
    toggleEmpresa: (id: ID, actor: ActorContext) => call(() => repo.toggleEmpresaGlobal(id, actor)),
    updateEmpresa: (
      id: ID,
      actor: ActorContext,
      data: Partial<Omit<Empresa, "id" | "ativo" | "criadoEm" | "atualizadoEm">>,
    ) => call(() => repo.updateEmpresaGlobal(id, actor, data)),
    listUsuarios: () => call(() => repo.listUsuariosGlobal()),
    listCargos: () => call(() => repo.listCargosGlobal()),
    auditoria: {
      list: () => call(() => repo.listAuditLogPlataforma()),
    },
  },

  colecoes: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listColecoes(empresaId, includeInactive)),
    create: (empresaId: ID, nome: string) => call(() => repo.createColecao(empresaId, nome)),
    update: (id: ID, empresaId: ID, nome: string) => call(() => repo.updateColecao(id, empresaId, nome)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleColecao(id, empresaId)),
  },

  cores: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listCores(empresaId, includeInactive)),
    create: (empresaId: ID, nome: string, estampa: string) => call(() => repo.createCor(empresaId, nome, estampa)),
    update: (id: ID, empresaId: ID, nome: string, estampa: string) => call(() => repo.updateCor(id, empresaId, nome, estampa)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleCor(id, empresaId)),
  },

  tamanhos: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listTamanhos(empresaId, includeInactive)),
    create: (empresaId: ID, nome: string) => call(() => repo.createTamanho(empresaId, nome)),
    update: (id: ID, empresaId: ID, nome: string) => call(() => repo.updateTamanho(id, empresaId, nome)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleTamanho(id, empresaId)),
  },

  categorias: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listCategorias(empresaId, includeInactive)),
    create: (empresaId: ID, nome: string) => call(() => repo.createCategoria(empresaId, nome)),
    update: (id: ID, empresaId: ID, nome: string) => call(() => repo.updateCategoria(id, empresaId, nome)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleCategoria(id, empresaId)),
  },

  unidades: {
    list: (includeInactive?: boolean) => call(() => repo.listUnidadesMedida(includeInactive)),
    create: (sigla: string) => call(() => repo.createUnidadeMedida(sigla)),
    update: (id: ID, sigla: string) => call(() => repo.updateUnidadeMedida(id, sigla)),
    toggle: (id: ID) => call(() => repo.toggleUnidadeMedida(id)),
  },

  fornecedores: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listFornecedores(empresaId, includeInactive)),
    create: (empresaId: ID, data: Omit<Fornecedor, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">) =>
      call(() => repo.createFornecedor(empresaId, data)),
    update: (id: ID, empresaId: ID, data: Partial<Fornecedor>) => call(() => repo.updateFornecedor(id, empresaId, data)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleFornecedor(id, empresaId)),
  },

  setores: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listSetores(empresaId, includeInactive)),
    create: (empresaId: ID, data: Omit<Setor, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">) =>
      call(() => repo.createSetor(empresaId, data)),
    update: (id: ID, empresaId: ID, data: Partial<Setor>) => call(() => repo.updateSetor(id, empresaId, data)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleSetor(id, empresaId)),
  },

  motivosPerda: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listMotivosPerda(empresaId, includeInactive)),
    create: (empresaId: ID, nome: string, tipo: MotivoPerda["tipo"]) => call(() => repo.createMotivoPerda(empresaId, nome, tipo)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleMotivoPerda(id, empresaId)),
  },

  estoques: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listEstoques(empresaId, includeInactive)),
    create: (empresaId: ID, actor: ActorContext, data: Omit<Estoque, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">) =>
      call(() => repo.createEstoque(empresaId, actor, data)),
    update: (
      id: ID,
      empresaId: ID,
      actor: ActorContext,
      data: Partial<Omit<Estoque, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">>,
    ) => call(() => repo.updateEstoque(id, empresaId, actor, data)),
    toggle: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.toggleEstoque(id, empresaId, actor)),
    saldos: (empresaId: ID) => call(() => repo.listSaldos(empresaId)),
    saldosDaVariacao: (variacaoId: ID, empresaId: ID) => call(() => repo.getSaldosDaVariacao(variacaoId, empresaId)),
    transfer: (empresaId: ID, actor: ActorContext, payload: TransferPayload) => call(() => repo.transferStock(empresaId, actor, payload)),
    manualOut: (empresaId: ID, actor: ActorContext, payload: ManualStockOutPayload) => call(() => repo.manualStockOut(empresaId, actor, payload)),
    directIn: (empresaId: ID, actor: ActorContext, payload: DirectStockInPayload) => call(() => repo.directStockIn(empresaId, actor, payload)),
  },

  kardex: {
    list: (empresaId: ID) => call(() => repo.listKardex(empresaId)),
  },

  produtos: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listProdutos(empresaId, includeInactive)),
    get: (id: ID, empresaId: ID) => call(() => repo.getProduto(id, empresaId)),
    create: (empresaId: ID, actor: ActorContext, payload: CreateProductPayload) => call(() => repo.createProduto(empresaId, actor, payload)),
    update: (id: ID, empresaId: ID, actor: ActorContext, data: Partial<Produto>) => call(() => repo.updateProduto(id, empresaId, actor, data)),
    toggle: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.toggleProduto(id, empresaId, actor)),
    variacoes: (produtoId: ID, empresaId: ID) => call(() => repo.listVariacoesDoProduto(produtoId, empresaId)),
    addVariacao: (produtoId: ID, empresaId: ID, actor: ActorContext, payload: CreateVariantPayload) =>
      call(() => repo.addVariacao(produtoId, empresaId, actor, payload)),
    updateVariacao: (
      id: ID,
      empresaId: ID,
      actor: ActorContext,
      data: { corId?: ID | null; tamanhoId?: ID | null; sku?: string; codigoBarras?: string | null },
    ) => call(() => repo.updateVariacao(id, empresaId, actor, data)),
    toggleVariacao: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.toggleVariacao(id, empresaId, actor)),
    precosDaVariacao: (variacaoId: ID, empresaId: ID) => call(() => repo.listPrecosDaVariacao(variacaoId, empresaId)),
    updatePrecos: (variacaoId: ID, empresaId: ID, actor: ActorContext, precos: { tipoPagamentoId: ID; valor: number }[]) =>
      call(() => repo.updatePrecos(variacaoId, empresaId, actor, precos)),
  },

  variacoes: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listVariacoes(empresaId, includeInactive)),
    get: (id: ID, empresaId: ID) => call(() => repo.getVariacao(id, empresaId)),
  },

  tiposPagamento: {
    list: (empresaId: ID) => call(() => repo.listTiposPagamento(empresaId)),
  },

  componentes: {
    list: (produtoPaiId: ID, empresaId: ID) => call(() => repo.listComponentes(produtoPaiId, empresaId)),
    add: (
      empresaId: ID,
      actor: ActorContext,
      data: { produtoPaiId: ID; produtoFilhoId: ID; setorId?: ID | null; quantidade: number; observacao?: string | null },
    ) => call(() => repo.addComponente(empresaId, actor, data)),
    update: (id: ID, empresaId: ID, actor: ActorContext, data: Partial<import("@/types").ProdutoComponente>) =>
      call(() => repo.updateComponente(id, empresaId, actor, data)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleComponente(id, empresaId)),
  },

  fluxos: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listFluxos(empresaId, includeInactive)),
    etapas: (fluxoId: ID, empresaId: ID) => call(() => repo.listEtapasDoFluxo(fluxoId, empresaId)),
    create: (empresaId: ID, actor: ActorContext, nome: string, descricao: string | null, etapasSetorIds: ID[]) =>
      call(() => repo.createFluxo(empresaId, actor, nome, descricao, etapasSetorIds)),
    update: (
      id: ID,
      empresaId: ID,
      actor: ActorContext,
      data: { nome?: string; descricao?: string | null; etapasSetorIds?: ID[] },
    ) => call(() => repo.updateFluxo(id, empresaId, actor, data)),
    toggle: (id: ID, empresaId: ID) => call(() => repo.toggleFluxo(id, empresaId)),
  },

  producao: {
    list: (empresaId: ID) => call(() => repo.listOrdensProducao(empresaId)),
    get: (id: ID, empresaId: ID) => call(() => repo.getOrdemProducao(id, empresaId)),
    etapas: (opId: ID, empresaId: ID) => call(() => repo.listEtapasDaOP(opId, empresaId)),
    movimentacoes: (opId: ID, empresaId: ID) => call(() => repo.listMovimentacoesDaOP(opId, empresaId)),
    movimentacoesEmpresa: (empresaId: ID) => call(() => repo.listMovimentacoesProducao(empresaId)),
    create: (empresaId: ID, actor: ActorContext, payload: CreateProductionOrderPayload) => call(() => repo.createOrdemProducao(empresaId, actor, payload)),
    release: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.releaseOrdemProducao(id, empresaId, actor)),
    move: (empresaId: ID, actor: ActorContext, payload: ProductionMovePayload) => call(() => repo.moveProductionOrder(empresaId, actor, payload)),
    cancel: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.cancelOrdemProducao(id, empresaId, actor)),
    pauseResume: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.pauseResumeOrdemProducao(id, empresaId, actor)),
    directEntry: (empresaId: ID, actor: ActorContext, payload: FinishedGoodsEntryPayload) => call(() => repo.finishedGoodsDirectEntry(empresaId, actor, payload)),
  },

  compras: {
    list: (empresaId: ID) => call(() => repo.listNotasFiscais(empresaId)),
    itens: (notaId: ID, empresaId: ID) => call(() => repo.listItensDaNota(notaId, empresaId)),
    create: (empresaId: ID, actor: ActorContext, payload: CreatePurchaseNotePayload) => call(() => repo.createNotaFiscal(empresaId, actor, payload)),
    update: (id: ID, empresaId: ID, actor: ActorContext, payload: CreatePurchaseNotePayload) => call(() => repo.updateNotaFiscal(id, empresaId, actor, payload)),
    complete: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.completeNotaFiscal(id, empresaId, actor)),
    cancel: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.cancelNotaFiscal(id, empresaId, actor)),
  },

  equipe: {
    list: (empresaId: ID, includeInactive?: boolean) => call(() => repo.listUsuarios(empresaId, includeInactive)),
    cargos: (empresaId: ID) => call(() => repo.listCargos(empresaId)),
    create: (empresaId: ID, actor: ActorContext, data: { nome: string; login: string; email: string; senha: string; cargoId: ID }) =>
      call(() => repo.createUsuario(empresaId, actor, data)),
    update: (id: ID, empresaId: ID, actor: ActorContext, data: Partial<Usuario>) => call(() => repo.updateUsuario(id, empresaId, actor, data)),
    toggle: (id: ID, empresaId: ID, actor: ActorContext) => call(() => repo.toggleUsuario(id, empresaId, actor)),
  },

  auditoria: {
    list: (empresaId: ID) => call(() => repo.listAuditLog(empresaId)),
  },

  raw: {
    database: (empresaId: ID) => call(() => repo.rawDatabase()),
  },

  system: {
    reset: () => call(() => repo.resetAll()),
  },
};

export type ApiClient = typeof apiClient;
