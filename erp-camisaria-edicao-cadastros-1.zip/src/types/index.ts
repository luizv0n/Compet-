// =====================================================================
// Tipos de domínio — traduzidos 1:1 do bd_competeV6.sql.
// Todo tipo aqui corresponde a uma tabela real do schema. Nada foi
// inventado; onde a UI precisa de um formato diferente, o tipo de
// apresentação vive em types/viewmodels.ts, nunca aqui.
// =====================================================================

export type ID = number;

/** Campos presentes em toda tabela "de apoio" (ativo + timestamps). */
export interface BaseEntity {
  id: ID;
  ativo: boolean;
  criadoEm: string; // ISO
  atualizadoEm: string; // ISO
}

/** Campos presentes em toda tabela de tenant (empresa_id). */
export interface TenantEntity extends BaseEntity {
  empresaId: ID;
}

// ---------------------------------------------------------------------
// 1. Empresa
// ---------------------------------------------------------------------
export interface Empresa extends BaseEntity {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual?: string | null;
  inscricaoMunicipal?: string | null;
  email: string;
  telefone?: string | null;
  celular?: string | null;
  site?: string | null;
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string | null;
  bairro: string;
  cidade: string;
  estado: string;
}

// ---------------------------------------------------------------------
// 2. Catálogo global e controle de acesso
// ---------------------------------------------------------------------
export interface UnidadeMedida extends BaseEntity {
  sigla: string;
}

export interface Permissao extends TenantEntity {
  nome: string;
  descricao?: string | null;
}

export interface Cargo extends TenantEntity {
  nome: string;
  descricao?: string | null;
  permissaoIds: ID[]; // via cargo_permissao
}

export interface Usuario extends TenantEntity {
  nome: string;
  login: string;
  email: string;
  senha: string; // mock apenas — nunca representa segurança real
  cargoId: ID;
}

// ---------------------------------------------------------------------
// 3. Cadastros de apoio do produto
// ---------------------------------------------------------------------
export interface Colecao extends TenantEntity {
  nome: string;
}

export interface Cor extends TenantEntity {
  nome: string;
  estampa: string;
}

export interface Tamanho extends TenantEntity {
  nome: string;
}

export interface Categoria extends TenantEntity {
  nome: string;
}

// ---------------------------------------------------------------------
// 4. Produto (modelo) + Variação (SKU)
// ---------------------------------------------------------------------
export type ProdutoTipo = "MP" | "AV" | "SC" | "PC";
export const PRODUTO_TIPOS: { value: ProdutoTipo; label: string }[] = [
  { value: "MP", label: "Matéria-Prima" },
  { value: "AV", label: "Aviamento" },
  { value: "SC", label: "Semiacabado" },
  { value: "PC", label: "Produto de Confecção" },
];

export interface Produto extends TenantEntity {
  nome: string;
  tipo: ProdutoTipo;
  colecaoId?: ID | null;
  unidadeMedidaId: ID;
  ncm?: string | null;
  cest?: string | null;
  origem?: string | null;
  categoriaIds: ID[]; // via categoria_produto (N:N)
}

export interface ProdutoVariacao extends TenantEntity {
  produtoId: ID;
  corId?: ID | null;
  tamanhoId?: ID | null;
  sku: string;
  codigoBarras?: string | null;
}

// ---------------------------------------------------------------------
// 5. Preço
// ---------------------------------------------------------------------
export type TipoPagamentoNome = "PIX" | "DINHEIRO" | "DEBITO" | "CREDITO";

export interface TipoPagamento extends TenantEntity {
  nome: string;
}

export interface ProdutoPreco {
  produtoVariacaoId: ID;
  tipoPagamentoId: ID;
  empresaId: ID;
  valor: number;
  ativo: boolean;
  criadoEm: string;
  atualizadoEm: string;
}

// ---------------------------------------------------------------------
// 6. Estoque
// ---------------------------------------------------------------------
export interface Estoque extends TenantEntity {
  nome: string;
  cep?: string | null;
  logradouro?: string | null;
  numero?: string | null;
  complemento?: string | null;
  bairro?: string | null;
  cidade?: string | null;
  estado?: string | null;
}

export interface ProdutoEstoque {
  produtoVariacaoId: ID;
  estoqueId: ID;
  empresaId: ID;
  quantidade: number;
  quantidadeReservada: number;
  criadoEm: string;
  atualizadoEm: string;
}

// ---------------------------------------------------------------------
// 7. Compras — fornecedor e nota fiscal de entrada
// ---------------------------------------------------------------------
export interface Fornecedor extends TenantEntity {
  nome: string;
  cnpj?: string | null;
  email?: string | null;
  telefone?: string | null;
}

export type NotaFiscalStatus = "ABERTA" | "CONCLUIDA" | "CANCELADA";

export interface NotaFiscal extends TenantEntity {
  numero: string;
  chaveAcesso?: string | null;
  fornecedorId: ID;
  estoqueId: ID;
  dataEmissao: string;
  dataEntrada?: string | null;
  valorTotal?: number | null;
  observacao?: string | null;
  status: NotaFiscalStatus; // campo de controle de UI sobre o ciclo de vida
}

export interface NotaFiscalItem {
  id: ID;
  empresaId: ID;
  notaFiscalId: ID;
  produtoVariacaoId: ID;
  unidadeMedidaId: ID;
  quantidade: number;
  valorUnitario: number;
  valorTotal: number; // gerado (quantidade * valorUnitario)
  criadoEm: string;
  atualizadoEm: string;
}

// ---------------------------------------------------------------------
// 8. Ficha técnica (BOM)
// ---------------------------------------------------------------------
export interface ProdutoComponente extends TenantEntity {
  produtoPaiId: ID; // produto_variacao
  produtoFilhoId: ID; // produto_variacao
  setorId?: ID | null;
  quantidade: number;
  observacao?: string | null;
}

// ---------------------------------------------------------------------
// 9. Produção — modelo
// ---------------------------------------------------------------------
export type SetorTipo = "INTERNO" | "TERCEIRO";

export interface Setor extends TenantEntity {
  codigo?: string | null;
  nome: string;
  tipo: SetorTipo;
  fornecedorId?: ID | null;
  responsavelUsuarioId?: ID | null;
}

export interface FluxoProducao extends TenantEntity {
  nome: string;
  descricao?: string | null;
}

export interface FluxoProducaoEtapa extends TenantEntity {
  fluxoProducaoId: ID;
  setorId: ID;
  sequencia: number;
}

// ---------------------------------------------------------------------
// 10. Produção — execução
// ---------------------------------------------------------------------
export type OrdemProducaoStatus =
  | "PLANEJADA"
  | "LIBERADA"
  | "EM_PRODUCAO"
  | "PAUSADA"
  | "CONCLUIDA"
  | "CANCELADA";

export const OP_STATUS_LABEL: Record<OrdemProducaoStatus, string> = {
  PLANEJADA: "Planejada",
  LIBERADA: "Liberada",
  EM_PRODUCAO: "Em produção",
  PAUSADA: "Pausada",
  CONCLUIDA: "Concluída",
  CANCELADA: "Cancelada",
};

export interface OrdemProducao extends TenantEntity {
  codigo: string;
  produtoVariacaoId: ID;
  fluxoProducaoId: ID;
  etapaAtualId?: ID | null;
  estoqueOrigemId?: ID | null;
  estoqueDestinoId?: ID | null;
  status: OrdemProducaoStatus;
  quantidadePrevista: number;
  quantidadeProduzida: number;
  quantidadeRefugada: number;
  lote?: string | null;
  dataAbertura: string;
  observacao?: string | null;
  usuarioId?: ID | null;
}

export type OrdemProducaoEtapaStatus =
  | "AGUARDANDO"
  | "EM_EXECUCAO"
  | "CONCLUIDA"
  | "PULADA";

export const OP_ETAPA_STATUS_LABEL: Record<OrdemProducaoEtapaStatus, string> = {
  AGUARDANDO: "Aguardando",
  EM_EXECUCAO: "Em execução",
  CONCLUIDA: "Concluída",
  PULADA: "Pulada",
};

export interface OrdemProducaoEtapa {
  id: ID;
  empresaId: ID;
  ordemProducaoId: ID;
  setorId: ID;
  sequencia: number;
  status: OrdemProducaoEtapaStatus;
  quantidadePrevista: number;
  quantidadeRecebida: number;
  quantidadeConcluida: number;
  quantidadePerdida: number;
  dataEntrada?: string | null;
  dataSaida?: string | null;
  usuarioResponsavelId?: ID | null;
  fornecedorId?: ID | null;
  observacao?: string | null;
  criadoEm: string;
  atualizadoEm: string;
}

export type MotivoPerdaTipo = "MATERIAL" | "PROCESSO" | "MANUSEIO" | "OUTRO";

export interface MotivoPerda extends TenantEntity {
  nome: string;
  tipo: MotivoPerdaTipo;
}

export type MovimentacaoProducaoTipo =
  | "TRANSFERENCIA"
  | "RETORNO"
  | "REFUGO"
  | "AJUSTE";

export interface MovimentacaoProducao {
  id: ID;
  empresaId: ID;
  ordemProducaoId: ID;
  etapaOrigemId?: ID | null;
  etapaDestinoId?: ID | null;
  setorOrigemId?: ID | null;
  setorDestinoId?: ID | null;
  tipo: MovimentacaoProducaoTipo;
  quantidade: number;
  quantidadePerdida: number;
  motivoPerdaId?: ID | null;
  dataMovimentacao: string;
  usuarioId?: ID | null;
  observacao?: string | null;
  criadoEm: string;
}

// ---------------------------------------------------------------------
// 11. Kardex — razão de estoque (imutável)
// ---------------------------------------------------------------------
export type KardexSentido = "ENTRADA" | "SAIDA";

export type KardexNatureza =
  | "COMPRA"
  | "PRODUCAO_CONSUMO"
  | "PRODUCAO_ENTRADA"
  | "TRANSFERENCIA"
  | "DEVOLUCAO"
  | "PERDA"
  | "AJUSTE";

export const KARDEX_NATUREZA_LABEL: Record<KardexNatureza, string> = {
  COMPRA: "Compra",
  PRODUCAO_CONSUMO: "Consumo de produção",
  PRODUCAO_ENTRADA: "Entrada de produção",
  TRANSFERENCIA: "Transferência",
  DEVOLUCAO: "Devolução",
  PERDA: "Perda",
  AJUSTE: "Ajuste",
};

export interface KardexEntry {
  id: ID;
  empresaId: ID;
  produtoVariacaoId: ID;
  estoqueId: ID;
  sentido: KardexSentido;
  natureza: KardexNatureza;
  quantidade: number;
  saldoAnterior: number;
  saldoResultante: number;
  notaFiscalItemId?: ID | null;
  ordemProducaoId?: ID | null;
  movimentacaoProducaoId?: ID | null;
  usuarioId?: ID | null;
  observacao?: string | null;
  dataMovimentacao: string;
  criadoEm: string;
}

// ---------------------------------------------------------------------
// Auditoria — trilha de ações relevantes (suporte de UI sobre as
// operações descritas no prompt; não é uma tabela do SQL, mas um log
// de aplicação que registra o resultado das operações acima)
// ---------------------------------------------------------------------
export type AuditAction =
  | "CRIACAO"
  | "EDICAO"
  | "ATIVACAO"
  | "INATIVACAO"
  | "ENTRADA"
  | "BAIXA"
  | "TRANSFERENCIA"
  | "CONCLUSAO_COMPRA"
  | "PRODUCAO"
  | "REFUGO"
  | "LOGIN";

export interface AuditLogEntry {
  id: ID;
  empresaId: ID;
  usuarioId: ID;
  usuarioNome: string;
  acao: AuditAction;
  entidade: string;
  descricao: string;
  dataHora: string;
}

// ---------------------------------------------------------------------
// Sessão mock
// ---------------------------------------------------------------------
export interface Sessao {
  usuarioId: ID;
  empresaId: ID;
  cargoId: ID;
  usuarioNome: string;
  cargoNome: string;
  permissoes: string[];
}

// ---------------------------------------------------------------------
// 12. Plataforma — ADM DO SITE (Etapa 3: Fundação Multiempresa)
//
// LIMITAÇÃO DE BANCO (registrada conforme a seção 4 do Prompt Master —
// "se uma funcionalidade não puder ser representada exatamente pelo
// banco existente, não altere o banco, implemente no Frontend/Mock e
// registre a limitação"):
//
// A tabela `usuario` do bd_competeV6.sql declara `empresa_id INT NOT
// NULL` com FK obrigatória para `empresa`, e o comentário da própria
// tabela no SQL é explícito: "usuario — pertence a UMA empresa". Não
// existe, no schema atual, like de representar um usuário sem
// empresa — criar isso exigiria alterar o banco (tornar a coluna
// nullable ou criar uma tabela nova), o que é proibido nesta etapa.
//
// Por isso o ADM DO SITE NÃO é modelado como `Usuario` (que estende
// `TenantEntity` e sempre carrega `empresaId`). Ele é uma entidade
// própria desta camada de Frontend/Mock, sem tabela correspondente no
// SQL. Quando o Backend real for implementado, essa decisão precisará
// ser tomada explicitamente por quem definir o schema definitivo —
// provavelmente uma tabela `admin_plataforma` separada (a opção mais
// coerente com o NOT NULL acima), mas isso NÃO deve ser presumido ou
// decidido por esta etapa.
// ---------------------------------------------------------------------
export interface AdminPlataforma extends BaseEntity {
  nome: string;
  login: string;
  email: string;
  senha: string; // mock apenas — nunca representa segurança real
}

/**
 * Sessão mock do ADM DO SITE — paralela a `Sessao`, mas sem `empresaId`
 * fixo (ver nota de limitação acima). `empresaContextoId` representa a
 * empresa que o ADM DO SITE está "visitando" no momento (seção 16 do
 * prompt mestre — "Contexto da Empresa"), e pode ser nula quando ele
 * está navegando no painel global, fora de qualquer empresa.
 */
export interface PlataformaSessao {
  adminId: ID;
  adminNome: string;
  empresaContextoId: ID | null;
}

/**
 * Trilha de auditoria de ações do ADM DO SITE que não pertencem a
 * nenhuma empresa específica (criar empresa, ativar/inativar empresa).
 * Ações que o ADM DO SITE executa DENTRO do contexto de uma empresa
 * continuam usando `AuditLogEntry` normalmente (mesma trilha que os
 * usuários da própria empresa usam) — esta trilha é só para a parte
 * "de plataforma" da seção 20 do prompt mestre ("Auditoria Global").
 */
export interface AuditLogPlataformaEntry {
  id: ID;
  adminId: ID;
  adminNome: string;
  acao: AuditAction;
  entidade: string;
  descricao: string;
  dataHora: string;
}
