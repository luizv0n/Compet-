"use client";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { useAuth } from "@/context/AuthContext";
import { LoadingState } from "@/components/common/LoadingState";

export function AppShell({ children }: { children: React.ReactNode }) {
  const { loading, usuario } = useAuth();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const router = useRouter();

  React.useEffect(() => {
    if (!loading && !usuario) {
      router.replace("/login");
    }
  }, [loading, usuario, router]);

  if (loading) {
    return (
      <div className="flex h-dvh items-center justify-center bg-background">
        <LoadingState label="Carregando sessão…" />
      </div>
    );
  }

  if (!usuario) return null;

  return (
    <div className="flex h-dvh overflow-hidden bg-background">
      <Sidebar mobileOpen={mobileOpen} onCloseMobile={() => setMobileOpen(false)} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header onOpenMobile={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-[1400px]">{children}</div>
        </main>
      </div>
    </div>
  );
}
