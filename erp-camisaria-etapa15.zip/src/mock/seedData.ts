// =====================================================================
// seedData.ts — dados iniciais do mock, alinhados 1:1 ao bd_competeV6.sql.
//
// NINGUÉM além de storage.ts deve importar este arquivo. Páginas e
// componentes só enxergam dados através de apiClient.ts.
//
// Duas empresas são criadas para validar isolamento multiempresa
// (seção 7 do prompt): dados de uma nunca podem aparecer para a outra.
// =====================================================================

import type {
  AdminPlataforma,
  AuditLogEntry,
  AuditLogPlataformaEntry,
  Cargo,
  Categoria,
  Colecao,
  Cor,
  Empresa,
  Estoque,
  EstoqueMinimo,
  FluxoProducao,
  FluxoProducaoEtapa,
  Fornecedor,
  KardexEntry,
  MotivoPerda,
  MovimentacaoProducao,
  NotaFiscal,
  NotaFiscalItem,
  OrdemProducao,
  OrdemProducaoEtapa,
  Permissao,
  Produto,
  ProdutoComponente,
  ProdutoEstoque,
  ProdutoPreco,
  ProdutoVariacao,
  Setor,
  Tamanho,
  TipoPagamento,
  UnidadeMedida,
  Usuario,
} from "@/types";
import {
  FUNCIONARIO_PERMISSIONS,
  PERMISSIONS,
  ROLE_NAMES,
  ALL_PERMISSIONS,
} from "@/constants/permissions";

/** Incrementar força um novo seed em todos os clientes (storage.ts lê este valor). */
export const CURRENT_SEED_VERSION = 3;

export interface Database {
  __seedVersion: number;

  /** ADM DO SITE — camada de plataforma, sem tabela correspondente no SQL. Ver nota em types/index.ts. */
  adminsPlataforma: AdminPlataforma[];
  /** Auditoria global de ações de plataforma (criar/ativar/inativar empresa). Ver nota em types/index.ts. */
  auditLogPlataforma: AuditLogPlataformaEntry[];

  empresas: Empresa[];
  unidadesMedida: UnidadeMedida[];
  permissoes: Permissao[];
  cargos: Cargo[];
  usuarios: Usuario[];

  colecoes: Colecao[];
  cores: Cor[];
  tamanhos: Tamanho[];
  categorias: Categoria[];

  produtos: Produto[];
  variacoes: ProdutoVariacao[];

  tiposPagamento: TipoPagamento[];
  precos: ProdutoPreco[];

  estoques: Estoque[];
  saldos: ProdutoEstoque[];
  /** Estoque mínimo por SKU — sem tabela correspondente no SQL (ver nota em types/index.ts). */
  estoquesMinimos: EstoqueMinimo[];

  fornecedores: Fornecedor[];
  notasFiscais: NotaFiscal[];
  notasFiscaisItens: NotaFiscalItem[];

  componentes: ProdutoComponente[];

  setores: Setor[];
  fluxos: FluxoProducao[];
  fluxosEtapas: FluxoProducaoEtapa[];

  ordensProducao: OrdemProducao[];
  ordensProducaoEtapas: OrdemProducaoEtapa[];
  motivosPerda: MotivoPerda[];
  movimentacoesProducao: MovimentacaoProducao[];

  kardex: KardexEntry[];

  auditLog: AuditLogEntry[];

  __seq: Record<string, number>;
}

// Contador de IDs por "tabela", só existe durante a construção do seed.
function makeSeq() {
  const counters: Record<string, number> = {};
  return (table: string): number => {
    counters[table] = (counters[table] ?? 0) + 1;
    return counters[table];
  };
}

export function buildSeedDatabase(): Database {
  const seq = makeSeq();
  const nid = (table: string) => seq(table);
  const now = new Date();
  const iso = (daysAgo = 0, hour = 9, minute = 0) => {
    const d = new Date(now);
    d.setDate(d.getDate() - daysAgo);
    d.setHours(hour, minute, 0, 0);
    return d.toISOString();
  };
  const base = { ativo: true, criadoEm: iso(120), atualizadoEm: iso(30) };

  // -------------------------------------------------------------
  // Empresas
  // -------------------------------------------------------------
  const empresas: Empresa[] = [
    {
      id: nid("empresa"),
      razaoSocial: "Malharia Estrela Confecções LTDA",
      nomeFantasia: "Malharia Estrela",
      cnpj: "12345678000190",
      inscricaoEstadual: "123456789",
      inscricaoMunicipal: null,
      email: "contato@malhariaestrela.com.br",
      telefone: "1132221100",
      celular: "11988887777",
      site: "https://malhariaestrela.com.br",
      cep: "01310100",
      logradouro: "Av. Paulista",
      numero: "1500",
      complemento: "Galpão 3",
      bairro: "Bela Vista",
      cidade: "São Paulo",
      estado: "SP",
      ...base,
    },
    {
      id: nid("empresa"),
      razaoSocial: "Vitória Malhas e Confecções ME",
      nomeFantasia: "Vitória Malhas",
      cnpj: "98765432000155",
      inscricaoEstadual: "987654321",
      inscricaoMunicipal: null,
      email: "contato@vitoriamalhas.com.br",
      telefone: "4732221100",
      celular: "47988886666",
      site: null,
      cep: "89201100",
      logradouro: "Rua Blumenau",
      numero: "420",
      complemento: null,
      bairro: "Centro",
      cidade: "Joinville",
      estado: "SC",
      ...base,
    },
  ];
  const [E1, E2] = empresas.map((e) => e.id);

  // -------------------------------------------------------------
  // ADM DO SITE (plataforma) — um único administrador global de
  // seed, fora da estrutura de empresa/cargo. Ver nota de limitação
  // de banco em types/index.ts (AdminPlataforma).
  // -------------------------------------------------------------
  const adminsPlataforma: AdminPlataforma[] = [
    {
      id: nid("adminPlataforma"),
      nome: "Suporte Camisaria ERP",
      login: "adm.plataforma",
      email: "plataforma@camisariaerp.com.br",
      senha: "123456",
      ...base,
    },
  ];

  // Auditoria de plataforma começa vazia — ações do ADM DO SITE (criar
  // empresa, ativar/inativar empresa) são registradas em tempo real
  // pelo mockRepository, não inventadas no seed.
  const auditLogPlataforma: AuditLogPlataformaEntry[] = [];

  // -------------------------------------------------------------
  // Unidade de medida (global — sem empresa_id)
  // -------------------------------------------------------------
  const unidadesMedida: UnidadeMedida[] = [
    { id: nid("um"), sigla: "UN", ...base },
    { id: nid("um"), sigla: "MT", ...base },
    { id: nid("um"), sigla: "KG", ...base },
    { id: nid("um"), sigla: "CX", ...base },
    { id: nid("um"), sigla: "PC", ...base },
    { id: nid("um"), sigla: "RL", ...base },
  ];
  const UM = Object.fromEntries(unidadesMedida.map((u) => [u.sigla, u.id]));

  // -------------------------------------------------------------
  // Permissões + cargos + usuários (por empresa)
  // -------------------------------------------------------------
  const permissoes: Permissao[] = [];
  const cargos: Cargo[] = [];
  const usuarios: Usuario[] = [];

  for (const empresaId of [E1, E2]) {
    const permIds: Record<string, number> = {};
    for (const key of ALL_PERMISSIONS) {
      const id = nid("permissao");
      permissoes.push({
        id,
        empresaId,
        nome: key,
        descricao: null,
        ...base,
      });
      permIds[key] = id;
    }

    const adminCargoId = nid("cargo");
    cargos.push({
      id: adminCargoId,
      empresaId,
      nome: ROLE_NAMES.ADMIN,
      descricao: "Acesso total ao sistema",
      permissaoIds: Object.values(permIds),
      ...base,
    });

    const funcCargoId = nid("cargo");
    cargos.push({
      id: funcCargoId,
      empresaId,
      nome: ROLE_NAMES.FUNCIONARIO,
      descricao: "Operações de fábrica, produção, compras e estoque",
      permissaoIds: FUNCIONARIO_PERMISSIONS.map((k) => permIds[k]),
      ...base,
    });

    const suffix = empresaId === E1 ? "estrela" : "vitoria";
    usuarios.push({
      id: nid("usuario"),
      empresaId,
      nome: empresaId === E1 ? "Fernanda Souza" : "Ricardo Bittencourt",
      login: `admin.${suffix}`,
      email: `admin@${suffix === "estrela" ? "malhariaestrela" : "vitoriamalhas"}.com.br`,
      senha: "123456",
      cargoId: adminCargoId,
      ...base,
    });
    usuarios.push({
      id: nid("usuario"),
      empresaId,
      nome: empresaId === E1 ? "João Pereira" : "Camila Ramos",
      login: `producao.${suffix}`,
      email: `producao@${suffix === "estrela" ? "malhariaestrela" : "vitoriamalhas"}.com.br`,
      senha: "123456",
      cargoId: funcCargoId,
      ...base,
    });
    usuarios.push({
      id: nid("usuario"),
      empresaId,
      nome: empresaId === E1 ? "Patrícia Lima" : "Bruno Cardoso",
      login: `estoque.${suffix}`,
      email: `estoque@${suffix === "estrela" ? "malhariaestrela" : "vitoriamalhas"}.com.br`,
      senha: "123456",
      cargoId: funcCargoId,
      ...base,
    });
  }

  const cargoAdminE1 = cargos.find((c) => c.empresaId === E1 && c.nome === ROLE_NAMES.ADMIN)!.id;
  const cargoFuncE1 = cargos.find((c) => c.empresaId === E1 && c.nome === ROLE_NAMES.FUNCIONARIO)!.id;
  const usuarioAdminE1 = usuarios.find((u) => u.empresaId === E1 && u.cargoId === cargoAdminE1)!.id;
  const usuarioProducaoE1 = usuarios.find(
    (u) => u.empresaId === E1 && u.cargoId === cargoFuncE1 && u.login.startsWith("producao"),
  )!.id;
  const usuarioEstoqueE1 = usuarios.find(
    (u) => u.empresaId === E1 && u.cargoId === cargoFuncE1 && u.login.startsWith("estoque"),
  )!.id;

  // -------------------------------------------------------------
  // Cadastros de apoio — cores, tamanhos, coleções, categorias
  // -------------------------------------------------------------
  const cores: Cor[] = [
    { id: nid("cor"), empresaId: E1, nome: "Preto", estampa: "", ...base },
    { id: nid("cor"), empresaId: E1, nome: "Branco", estampa: "", ...base },
    { id: nid("cor"), empresaId: E1, nome: "Azul Marinho", estampa: "", ...base },
    { id: nid("cor"), empresaId: E1, nome: "Cinza Mescla", estampa: "", ...base },
    { id: nid("cor"), empresaId: E1, nome: "Branco", estampa: "Listrado Azul", ...base },
    { id: nid("cor"), empresaId: E2, nome: "Preto", estampa: "", ...base },
    { id: nid("cor"), empresaId: E2, nome: "Vinho", estampa: "", ...base },
    { id: nid("cor"), empresaId: E2, nome: "Verde Musgo", estampa: "", ...base },
  ];

  const tamanhos: Tamanho[] = [
    { id: nid("tamanho"), empresaId: E1, nome: "P", ...base },
    { id: nid("tamanho"), empresaId: E1, nome: "M", ...base },
    { id: nid("tamanho"), empresaId: E1, nome: "G", ...base },
    { id: nid("tamanho"), empresaId: E1, nome: "GG", ...base },
    { id: nid("tamanho"), empresaId: E2, nome: "P", ...base },
    { id: nid("tamanho"), empresaId: E2, nome: "M", ...base },
    { id: nid("tamanho"), empresaId: E2, nome: "G", ...base },
  ];

  const colecoes: Colecao[] = [
    { id: nid("colecao"), empresaId: E1, nome: "Verão 2026", ...base },
    { id: nid("colecao"), empresaId: E1, nome: "Inverno 2026", ...base },
    { id: nid("colecao"), empresaId: E2, nome: "Coleção Básica", ...base },
  ];

  const categorias: Categoria[] = [
    { id: nid("categoria"), empresaId: E1, nome: "Camisetas", ...base },
    { id: nid("categoria"), empresaId: E1, nome: "Polos", ...base },
    { id: nid("categoria"), empresaId: E1, nome: "Básicos", ...base },
    { id: nid("categoria"), empresaId: E2, nome: "Camisetas", ...base },
  ];

  // -------------------------------------------------------------
  // Produtos + variações (E1 — catálogo principal para demonstração)
  // -------------------------------------------------------------
  const produtos: Produto[] = [];
  const variacoes: ProdutoVariacao[] = [];

  const corPreto = cores.find((c) => c.empresaId === E1 && c.nome === "Preto")!.id;
  const corBranco = cores.find((c) => c.empresaId === E1 && c.nome === "Branco" && c.estampa === "")!.id;
  const corMarinho = cores.find((c) => c.empresaId === E1 && c.nome === "Azul Marinho")!.id;
  const tamP = tamanhos.find((t) => t.empresaId === E1 && t.nome === "P")!.id;
  const tamM = tamanhos.find((t) => t.empresaId === E1 && t.nome === "M")!.id;
  const tamG = tamanhos.find((t) => t.empresaId === E1 && t.nome === "G")!.id;
  const colVerao = colecoes.find((c) => c.empresaId === E1 && c.nome === "Verão 2026")!.id;
  const catCamisetas = categorias.find((c) => c.empresaId === E1 && c.nome === "Camisetas")!.id;
  const catBasicos = categorias.find((c) => c.empresaId === E1 && c.nome === "Básicos")!.id;
  const catPolos = categorias.find((c) => c.empresaId === E1 && c.nome === "Polos")!.id;

  // Matéria-prima: Tecido malha (por cor, sem tamanho)
  const prodTecido = nid("produto");
  produtos.push({
    id: prodTecido,
    empresaId: E1,
    nome: "Tecido Malha PV",
    tipo: "MP",
    colecaoId: null,
    unidadeMedidaId: UM.MT,
    ncm: "60041000",
    cest: null,
    origem: "0",
    categoriaIds: [],
    ...base,
  });
  const varTecidoPreto = nid("variacao");
  variacoes.push({ id: varTecidoPreto, empresaId: E1, produtoId: prodTecido, corId: corPreto, tamanhoId: null, sku: "MP-TEC-PV-PRETO", codigoBarras: null, ...base });
  const varTecidoBranco = nid("variacao");
  variacoes.push({ id: varTecidoBranco, empresaId: E1, produtoId: prodTecido, corId: corBranco, tamanhoId: null, sku: "MP-TEC-PV-BRANCO", codigoBarras: null, ...base });

  // Aviamento: Linha e Etiqueta (não se desdobram — variação padrão única)
  const prodLinha = nid("produto");
  produtos.push({ id: prodLinha, empresaId: E1, nome: "Linha de Costura", tipo: "AV", colecaoId: null, unidadeMedidaId: UM.RL, ncm: "52040000", cest: null, origem: "0", categoriaIds: [], ...base });
  const varLinha = nid("variacao");
  variacoes.push({ id: varLinha, empresaId: E1, produtoId: prodLinha, corId: null, tamanhoId: null, sku: "AV-LINHA-PRETA", codigoBarras: null, ...base });

  const prodEtiqueta = nid("produto");
  produtos.push({ id: prodEtiqueta, empresaId: E1, nome: "Etiqueta Composição", tipo: "AV", colecaoId: null, unidadeMedidaId: UM.UN, ncm: "58071000", cest: null, origem: "0", categoriaIds: [], ...base });
  const varEtiqueta = nid("variacao");
  variacoes.push({ id: varEtiqueta, empresaId: E1, produtoId: prodEtiqueta, corId: null, tamanhoId: null, sku: "AV-ETIQ-COMP", codigoBarras: null, ...base });

  // Semiacabado: Corpo da camiseta cortado (por cor e tamanho)
  const prodSemiacabado = nid("produto");
  produtos.push({ id: prodSemiacabado, empresaId: E1, nome: "Corpo Camiseta Cortado", tipo: "SC", colecaoId: colVerao, unidadeMedidaId: UM.PC, ncm: null, cest: null, origem: null, categoriaIds: [catBasicos], ...base });
  const varSemiPretoM = nid("variacao");
  variacoes.push({ id: varSemiPretoM, empresaId: E1, produtoId: prodSemiacabado, corId: corPreto, tamanhoId: tamM, sku: "SC-CORPO-PRETO-M", codigoBarras: null, ...base });

  // Produto de confecção: Camiseta Básica (PC) — cor x tamanho
  const prodCamiseta = nid("produto");
  produtos.push({
    id: prodCamiseta,
    empresaId: E1,
    nome: "Camiseta Básica",
    tipo: "PC",
    colecaoId: colVerao,
    unidadeMedidaId: UM.UN,
    ncm: "61091000",
    cest: "0104200",
    origem: "0",
    categoriaIds: [catCamisetas, catBasicos],
    ...base,
  });
  const camisetaVars: { id: number; cor: number; tam: number; sku: string }[] = [
    { id: nid("variacao"), cor: corPreto, tam: tamP, sku: "PC-CAM-PRETO-P" },
    { id: nid("variacao"), cor: corPreto, tam: tamM, sku: "PC-CAM-PRETO-M" },
    { id: nid("variacao"), cor: corPreto, tam: tamG, sku: "PC-CAM-PRETO-G" },
    { id: nid("variacao"), cor: corBranco, tam: tamP, sku: "PC-CAM-BRANCO-P" },
    { id: nid("variacao"), cor: corBranco, tam: tamM, sku: "PC-CAM-BRANCO-M" },
    { id: nid("variacao"), cor: corMarinho, tam: tamM, sku: "PC-CAM-MARINHO-M" },
  ];
  for (const v of camisetaVars) {
    variacoes.push({ id: v.id, empresaId: E1, produtoId: prodCamiseta, corId: v.cor, tamanhoId: v.tam, sku: v.sku, codigoBarras: `789${v.sku.length}${v.id}0001`, ...base });
  }

  // Produto de confecção: Polo Piquet
  const prodPolo = nid("produto");
  produtos.push({
    id: prodPolo,
    empresaId: E1,
    nome: "Polo Piquet",
    tipo: "PC",
    colecaoId: colecoes.find((c) => c.empresaId === E1 && c.nome === "Inverno 2026")!.id,
    unidadeMedidaId: UM.UN,
    ncm: "61051000",
    cest: "0104201",
    origem: "0",
    categoriaIds: [catPolos],
    ...base,
  });
  const poloVars: { id: number; cor: number; tam: number; sku: string }[] = [
    { id: nid("variacao"), cor: corPreto, tam: tamM, sku: "PC-POLO-PRETO-M" },
    { id: nid("variacao"), cor: corMarinho, tam: tamG, sku: "PC-POLO-MARINHO-G" },
  ];
  for (const v of poloVars) {
    variacoes.push({ id: v.id, empresaId: E1, produtoId: prodPolo, corId: v.cor, tamanhoId: v.tam, sku: v.sku, codigoBarras: `789${v.id}0002`, ...base });
  }

  // ---- Empresa 2 — catálogo menor, isolado ----
  const corPretoE2 = cores.find((c) => c.empresaId === E2 && c.nome === "Preto")!.id;
  const corVinhoE2 = cores.find((c) => c.empresaId === E2 && c.nome === "Vinho")!.id;
  const tamPE2 = tamanhos.find((t) => t.empresaId === E2 && t.nome === "P")!.id;
  const tamME2 = tamanhos.find((t) => t.empresaId === E2 && t.nome === "M")!.id;
  const catCamisetasE2 = categorias.find((c) => c.empresaId === E2)!.id;
  const colBasicaE2 = colecoes.find((c) => c.empresaId === E2)!.id;

  const prodTecidoE2 = nid("produto");
  produtos.push({ id: prodTecidoE2, empresaId: E2, nome: "Tecido Algodão", tipo: "MP", colecaoId: null, unidadeMedidaId: UM.MT, ncm: "52081100", cest: null, origem: "0", categoriaIds: [], ...base });
  const varTecidoE2 = nid("variacao");
  variacoes.push({ id: varTecidoE2, empresaId: E2, produtoId: prodTecidoE2, corId: corPretoE2, tamanhoId: null, sku: "MP-TEC-ALG-PRETO", codigoBarras: null, ...base });

  const prodCamisetaE2 = nid("produto");
  produtos.push({ id: prodCamisetaE2, empresaId: E2, nome: "Camiseta Gola V", tipo: "PC", colecaoId: colBasicaE2, unidadeMedidaId: UM.UN, ncm: "61091000", cest: "0104200", origem: "0", categoriaIds: [catCamisetasE2], ...base });
  const camisetaVarsE2 = [
    { id: nid("variacao"), cor: corPretoE2, tam: tamPE2, sku: "PC-GV-PRETO-P" },
    { id: nid("variacao"), cor: corVinhoE2, tam: tamME2, sku: "PC-GV-VINHO-M" },
  ];
  for (const v of camisetaVarsE2) {
    variacoes.push({ id: v.id, empresaId: E2, produtoId: prodCamisetaE2, corId: v.cor, tamanhoId: v.tam, sku: v.sku, codigoBarras: null, ...base });
  }

  // -------------------------------------------------------------
  // Tipos de pagamento + preços (4 por variação PC/SC vendável)
  // -------------------------------------------------------------
  const tiposPagamento: TipoPagamento[] = [];
  const precos: ProdutoPreco[] = [];
  const paymentNames: string[] = ["PIX", "DINHEIRO", "DEBITO", "CREDITO"];

  for (const empresaId of [E1, E2]) {
    for (const nome of paymentNames) {
      tiposPagamento.push({ id: nid("tipoPagamento"), empresaId, nome, ...base });
    }
  }
  const tpE1 = Object.fromEntries(
    tiposPagamento.filter((t) => t.empresaId === E1).map((t) => [t.nome, t.id]),
  );
  const tpE2 = Object.fromEntries(
    tiposPagamento.filter((t) => t.empresaId === E2).map((t) => [t.nome, t.id]),
  );

  function addPrecos(variacaoId: number, empresaId: number, baseValor: number) {
    const tp = empresaId === E1 ? tpE1 : tpE2;
    const valores: Record<string, number> = {
      PIX: baseValor,
      DINHEIRO: baseValor,
      DEBITO: Math.round(baseValor * 1.03 * 100) / 100,
      CREDITO: Math.round(baseValor * 1.08 * 100) / 100,
    };
    for (const nome of paymentNames) {
      precos.push({
        produtoVariacaoId: variacaoId,
        tipoPagamentoId: tp[nome],
        empresaId,
        valor: valores[nome],
        ativo: true,
        criadoEm: base.criadoEm,
        atualizadoEm: base.atualizadoEm,
      });
    }
  }

  for (const v of camisetaVars) addPrecos(v.id, E1, 39.9);
  for (const v of poloVars) addPrecos(v.id, E1, 69.9);
  addPrecos(varSemiPretoM, E1, 0);
  for (const v of camisetaVarsE2) addPrecos(v.id, E2, 34.9);

  // -------------------------------------------------------------
  // Estoques (locais físicos)
  // -------------------------------------------------------------
  const estoques: Estoque[] = [
    { id: nid("estoque"), empresaId: E1, nome: "Fábrica", cep: "01310100", logradouro: "Av. Paulista", numero: "1500", complemento: "Galpão 3", bairro: "Bela Vista", cidade: "São Paulo", estado: "SP", ...base },
    { id: nid("estoque"), empresaId: E1, nome: "Loja Centro", cep: "01001000", logradouro: "Rua Direita", numero: "88", complemento: null, bairro: "Centro", cidade: "São Paulo", estado: "SP", ...base },
    { id: nid("estoque"), empresaId: E1, nome: "Loja Norte", cep: "02710000", logradouro: "Av. Santa Marina", numero: "300", complemento: null, bairro: "Vila Nova Cachoeirinha", cidade: "São Paulo", estado: "SP", ...base },
    { id: nid("estoque"), empresaId: E2, nome: "Fábrica", cep: "89201100", logradouro: "Rua Blumenau", numero: "420", complemento: null, bairro: "Centro", cidade: "Joinville", estado: "SC", ...base },
    { id: nid("estoque"), empresaId: E2, nome: "Loja Joinville", cep: "89202000", logradouro: "Rua 9 de Março", numero: "150", complemento: null, bairro: "América", cidade: "Joinville", estado: "SC", ...base },
  ];
  const estFabricaE1 = estoques.find((e) => e.empresaId === E1 && e.nome === "Fábrica")!.id;
  const estCentroE1 = estoques.find((e) => e.empresaId === E1 && e.nome === "Loja Centro")!.id;
  const estNorteE1 = estoques.find((e) => e.empresaId === E1 && e.nome === "Loja Norte")!.id;
  const estFabricaE2 = estoques.find((e) => e.empresaId === E2 && e.nome === "Fábrica")!.id;
  const estLojaE2 = estoques.find((e) => e.empresaId === E2 && e.nome === "Loja Joinville")!.id;

  // -------------------------------------------------------------
  // Fornecedores
  // -------------------------------------------------------------
  const fornecedores: Fornecedor[] = [
    { id: nid("fornecedor"), empresaId: E1, nome: "Têxtil Ipiranga LTDA", cnpj: "11222333000144", email: "vendas@textilipiranga.com.br", telefone: "1132223344", ...base },
    { id: nid("fornecedor"), empresaId: E1, nome: "Aviamentos São Bento", cnpj: "22333444000155", email: "contato@aviamentossaobento.com.br", telefone: "1133334455", ...base },
    { id: nid("fornecedor"), empresaId: E1, nome: "Facção Del Rey (terceirizado)", cnpj: "33444555000166", email: "delrey@faccao.com.br", telefone: "1144445566", ...base },
    { id: nid("fornecedor"), empresaId: E2, nome: "Malhas Santa Catarina LTDA", cnpj: "44555666000177", email: "vendas@malhassc.com.br", telefone: "4733334455", ...base },
  ];
  const fornTextilE1 = fornecedores.find((f) => f.empresaId === E1 && f.nome.includes("Ipiranga"))!.id;
  const fornAviamentoE1 = fornecedores.find((f) => f.empresaId === E1 && f.nome.includes("São Bento"))!.id;
  const fornFaccaoE1 = fornecedores.find((f) => f.empresaId === E1 && f.nome.includes("Facção"))!.id;

  // -------------------------------------------------------------
  // Setores (produção)
  // -------------------------------------------------------------
  const setores: Setor[] = [
    { id: nid("setor"), empresaId: E1, codigo: "COR", nome: "Corte", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: usuarioProducaoE1, ...base },
    { id: nid("setor"), empresaId: E1, codigo: "COS", nome: "Costura", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: usuarioProducaoE1, ...base },
    { id: nid("setor"), empresaId: E1, codigo: "LAV", nome: "Lavanderia", tipo: "TERCEIRO", fornecedorId: fornFaccaoE1, responsavelUsuarioId: null, ...base },
    { id: nid("setor"), empresaId: E1, codigo: "SEC", nome: "Secagem", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: null, ...base },
    { id: nid("setor"), empresaId: E1, codigo: "ACB", nome: "Acabamento", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: usuarioProducaoE1, ...base },
    { id: nid("setor"), empresaId: E1, codigo: "EXP", nome: "Expedição", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: null, ...base },
  ];
  const setCorte = setores[0].id;
  const setCostura = setores[1].id;
  const setLavanderia = setores[2].id;
  const setSecagem = setores[3].id;
  const setAcabamento = setores[4].id;
  const setExpedicao = setores[5].id;

  const setoresE2: Setor[] = [
    { id: nid("setor"), empresaId: E2, codigo: "COR", nome: "Corte", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: null, ...base },
    { id: nid("setor"), empresaId: E2, codigo: "COS", nome: "Costura", tipo: "INTERNO", fornecedorId: null, responsavelUsuarioId: null, ...base },
  ];
  setores.push(...setoresE2);

  // -------------------------------------------------------------
  // Fluxos de produção + etapas
  // -------------------------------------------------------------
  const fluxos: FluxoProducao[] = [
    { id: nid("fluxo"), empresaId: E1, nome: "Fluxo Camiseta Básica", descricao: "Corte, costura, lavagem, secagem, acabamento e expedição", ...base },
    { id: nid("fluxo"), empresaId: E1, nome: "Fluxo Polo Piquet", descricao: "Corte, costura e acabamento (sem lavagem)", ...base },
  ];
  const fluxoCamiseta = fluxos[0].id;
  const fluxoPolo = fluxos[1].id;

  const fluxosEtapas: FluxoProducaoEtapa[] = [
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setCorte, sequencia: 1, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setCostura, sequencia: 2, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setLavanderia, sequencia: 3, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setSecagem, sequencia: 4, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setAcabamento, sequencia: 5, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoCamiseta, setorId: setExpedicao, sequencia: 6, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoPolo, setorId: setCorte, sequencia: 1, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoPolo, setorId: setCostura, sequencia: 2, ...base },
    { id: nid("fluxoEtapa"), empresaId: E1, fluxoProducaoId: fluxoPolo, setorId: setAcabamento, sequencia: 3, ...base },
  ];

  // -------------------------------------------------------------
  // Motivos de perda
  // -------------------------------------------------------------
  const motivosPerda: MotivoPerda[] = [
    { id: nid("motivoPerda"), empresaId: E1, nome: "Defeito de tecido", tipo: "MATERIAL", ...base },
    { id: nid("motivoPerda"), empresaId: E1, nome: "Costura fora do padrão", tipo: "PROCESSO", ...base },
    { id: nid("motivoPerda"), empresaId: E1, nome: "Mancha no manuseio", tipo: "MANUSEIO", ...base },
    { id: nid("motivoPerda"), empresaId: E1, nome: "Outro", tipo: "OUTRO", ...base },
    { id: nid("motivoPerda"), empresaId: E2, nome: "Defeito de tecido", tipo: "MATERIAL", ...base },
    { id: nid("motivoPerda"), empresaId: E2, nome: "Outro", tipo: "OUTRO", ...base },
  ];
  const motivoDefeitoTecidoE1 = motivosPerda.find((m) => m.empresaId === E1 && m.nome === "Defeito de tecido")!.id;
  const motivoCosturaE1 = motivosPerda.find((m) => m.empresaId === E1 && m.nome.includes("Costura"))!.id;

  // -------------------------------------------------------------
  // Ficha técnica (BOM) — Camiseta Básica Preta M consome tecido,
  // linha e etiqueta
  // -------------------------------------------------------------
  const camisetaPretoM = camisetaVars.find((v) => v.sku === "PC-CAM-PRETO-M")!.id;
  const componentes: ProdutoComponente[] = [
    { id: nid("componente"), empresaId: E1, produtoPaiId: camisetaPretoM, produtoFilhoId: varTecidoPreto, setorId: setCorte, quantidade: 0.85, observacao: "Tecido para corte", ...base },
    { id: nid("componente"), empresaId: E1, produtoPaiId: camisetaPretoM, produtoFilhoId: varLinha, setorId: setCostura, quantidade: 12, observacao: "Linha para costura", ...base },
    { id: nid("componente"), empresaId: E1, produtoPaiId: camisetaPretoM, produtoFilhoId: varEtiqueta, setorId: setAcabamento, quantidade: 1, observacao: "Etiqueta de composição", ...base },
  ];

  // -------------------------------------------------------------
  // Notas fiscais de entrada (compras)
  // -------------------------------------------------------------
  const notasFiscais: NotaFiscal[] = [];
  const notasFiscaisItens: NotaFiscalItem[] = [];

  // Nota concluída — já gerou entrada no estoque (kardex COMPRA abaixo)
  const nfConcluidaId = nid("notaFiscal");
  notasFiscais.push({
    id: nfConcluidaId,
    empresaId: E1,
    numero: "000123",
    chaveAcesso: null,
    fornecedorId: fornTextilE1,
    estoqueId: estFabricaE1,
    dataEmissao: iso(20),
    dataEntrada: iso(19),
    valorTotal: 2550,
    observacao: "Compra mensal de tecido malha",
    status: "CONCLUIDA",
    ativo: true,
    criadoEm: iso(20),
    atualizadoEm: iso(19),
  });
  const nfItemConcluidaId = nid("notaFiscalItem");
  notasFiscaisItens.push({
    id: nfItemConcluidaId,
    empresaId: E1,
    notaFiscalId: nfConcluidaId,
    produtoVariacaoId: varTecidoPreto,
    unidadeMedidaId: UM.MT,
    quantidade: 300,
    valorUnitario: 8.5,
    valorTotal: 2550,
    criadoEm: iso(20),
    atualizadoEm: iso(19),
  });

  // Nota aberta — ainda não afeta saldo
  const nfAbertaId = nid("notaFiscal");
  notasFiscais.push({
    id: nfAbertaId,
    empresaId: E1,
    numero: "000124",
    chaveAcesso: null,
    fornecedorId: fornAviamentoE1,
    estoqueId: estFabricaE1,
    dataEmissao: iso(2),
    dataEntrada: null,
    valorTotal: 480,
    observacao: "Reposição de linha e etiquetas",
    status: "ABERTA",
    ativo: true,
    criadoEm: iso(2),
    atualizadoEm: iso(2),
  });
  notasFiscaisItens.push({
    id: nid("notaFiscalItem"),
    empresaId: E1,
    notaFiscalId: nfAbertaId,
    produtoVariacaoId: varLinha,
    unidadeMedidaId: UM.RL,
    quantidade: 40,
    valorUnitario: 9,
    valorTotal: 360,
    criadoEm: iso(2),
    atualizadoEm: iso(2),
  });
  notasFiscaisItens.push({
    id: nid("notaFiscalItem"),
    empresaId: E1,
    notaFiscalId: nfAbertaId,
    produtoVariacaoId: varEtiqueta,
    unidadeMedidaId: UM.UN,
    quantidade: 400,
    valorUnitario: 0.3,
    valorTotal: 120,
    criadoEm: iso(2),
    atualizadoEm: iso(2),
  });

  // -------------------------------------------------------------
  // Ordens de produção (com histórico de movimentação/kardex)
  // -------------------------------------------------------------
  const ordensProducao: OrdemProducao[] = [];
  const ordensProducaoEtapas: OrdemProducaoEtapa[] = [];
  const movimentacoesProducao: MovimentacaoProducao[] = [];

  // OP #0001 — concluída, 100 previstas, 90 produzidas, 10 refugadas
  const op1Id = nid("ordemProducao");
  const op1EtapasIds = {
    corte: nid("opEtapa"),
    costura: nid("opEtapa"),
    lavanderia: nid("opEtapa"),
    secagem: nid("opEtapa"),
    acabamento: nid("opEtapa"),
    expedicao: nid("opEtapa"),
  };
  ordensProducaoEtapas.push(
    { id: op1EtapasIds.corte, empresaId: E1, ordemProducaoId: op1Id, setorId: setCorte, sequencia: 1, status: "CONCLUIDA", quantidadePrevista: 100, quantidadeRecebida: 100, quantidadeConcluida: 100, quantidadePerdida: 0, dataEntrada: iso(15), dataSaida: iso(14), usuarioResponsavelId: usuarioProducaoE1, fornecedorId: null, observacao: null, criadoEm: iso(15), atualizadoEm: iso(14) },
    { id: op1EtapasIds.costura, empresaId: E1, ordemProducaoId: op1Id, setorId: setCostura, sequencia: 2, status: "CONCLUIDA", quantidadePrevista: 100, quantidadeRecebida: 100, quantidadeConcluida: 95, quantidadePerdida: 5, dataEntrada: iso(14), dataSaida: iso(12), usuarioResponsavelId: usuarioProducaoE1, fornecedorId: null, observacao: null, criadoEm: iso(14), atualizadoEm: iso(12) },
    { id: op1EtapasIds.lavanderia, empresaId: E1, ordemProducaoId: op1Id, setorId: setLavanderia, sequencia: 3, status: "CONCLUIDA", quantidadePrevista: 95, quantidadeRecebida: 95, quantidadeConcluida: 93, quantidadePerdida: 2, dataEntrada: iso(12), dataSaida: iso(10), usuarioResponsavelId: null, fornecedorId: fornFaccaoE1, observacao: null, criadoEm: iso(12), atualizadoEm: iso(10) },
    { id: op1EtapasIds.secagem, empresaId: E1, ordemProducaoId: op1Id, setorId: setSecagem, sequencia: 4, status: "CONCLUIDA", quantidadePrevista: 93, quantidadeRecebida: 93, quantidadeConcluida: 93, quantidadePerdida: 0, dataEntrada: iso(10), dataSaida: iso(9), usuarioResponsavelId: null, fornecedorId: null, observacao: null, criadoEm: iso(10), atualizadoEm: iso(9) },
    { id: op1EtapasIds.acabamento, empresaId: E1, ordemProducaoId: op1Id, setorId: setAcabamento, sequencia: 5, status: "CONCLUIDA", quantidadePrevista: 93, quantidadeRecebida: 93, quantidadeConcluida: 90, quantidadePerdida: 3, dataEntrada: iso(9), dataSaida: iso(7), usuarioResponsavelId: usuarioProducaoE1, fornecedorId: null, observacao: null, criadoEm: iso(9), atualizadoEm: iso(7) },
    { id: op1EtapasIds.expedicao, empresaId: E1, ordemProducaoId: op1Id, setorId: setExpedicao, sequencia: 6, status: "CONCLUIDA", quantidadePrevista: 90, quantidadeRecebida: 90, quantidadeConcluida: 90, quantidadePerdida: 0, dataEntrada: iso(7), dataSaida: iso(6), usuarioResponsavelId: null, fornecedorId: null, observacao: null, criadoEm: iso(7), atualizadoEm: iso(6) },
  );
  ordensProducao.push({
    id: op1Id,
    empresaId: E1,
    codigo: "OP-0001",
    produtoVariacaoId: camisetaPretoM,
    fluxoProducaoId: fluxoCamiseta,
    etapaAtualId: op1EtapasIds.expedicao,
    estoqueOrigemId: estFabricaE1,
    estoqueDestinoId: estFabricaE1,
    status: "CONCLUIDA",
    quantidadePrevista: 100,
    quantidadeProduzida: 90,
    quantidadeRefugada: 10,
    lote: "L-2026-001",
    dataAbertura: iso(15),
    observacao: "Lote piloto da coleção Verão 2026",
    usuarioId: usuarioProducaoE1,
    ativo: true,
    criadoEm: iso(15),
    atualizadoEm: iso(6),
  });

  movimentacoesProducao.push(
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: null, etapaDestinoId: op1EtapasIds.corte, setorOrigemId: null, setorDestinoId: setCorte, tipo: "TRANSFERENCIA", quantidade: 100, quantidadePerdida: 0, motivoPerdaId: null, dataMovimentacao: iso(15), usuarioId: usuarioProducaoE1, observacao: "Abertura da OP", criadoEm: iso(15) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.corte, etapaDestinoId: op1EtapasIds.costura, setorOrigemId: setCorte, setorDestinoId: setCostura, tipo: "TRANSFERENCIA", quantidade: 100, quantidadePerdida: 0, motivoPerdaId: null, dataMovimentacao: iso(14), usuarioId: usuarioProducaoE1, observacao: null, criadoEm: iso(14) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.costura, etapaDestinoId: op1EtapasIds.lavanderia, setorOrigemId: setCostura, setorDestinoId: setLavanderia, tipo: "TRANSFERENCIA", quantidade: 95, quantidadePerdida: 5, motivoPerdaId: motivoCosturaE1, dataMovimentacao: iso(12), usuarioId: usuarioProducaoE1, observacao: "5 peças com costura fora do padrão", criadoEm: iso(12) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.lavanderia, etapaDestinoId: op1EtapasIds.secagem, setorOrigemId: setLavanderia, setorDestinoId: setSecagem, tipo: "TRANSFERENCIA", quantidade: 93, quantidadePerdida: 2, motivoPerdaId: motivoDefeitoTecidoE1, dataMovimentacao: iso(10), usuarioId: null, observacao: "2 peças com mancha na lavagem", criadoEm: iso(10) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.secagem, etapaDestinoId: op1EtapasIds.acabamento, setorOrigemId: setSecagem, setorDestinoId: setAcabamento, tipo: "TRANSFERENCIA", quantidade: 93, quantidadePerdida: 0, motivoPerdaId: null, dataMovimentacao: iso(9), usuarioId: usuarioProducaoE1, observacao: null, criadoEm: iso(9) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.acabamento, etapaDestinoId: op1EtapasIds.expedicao, setorOrigemId: setAcabamento, setorDestinoId: setExpedicao, tipo: "TRANSFERENCIA", quantidade: 90, quantidadePerdida: 3, motivoPerdaId: motivoDefeitoTecidoE1, dataMovimentacao: iso(7), usuarioId: usuarioProducaoE1, observacao: "3 peças com defeito de tecido", criadoEm: iso(7) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op1Id, etapaOrigemId: op1EtapasIds.expedicao, etapaDestinoId: null, setorOrigemId: setExpedicao, setorDestinoId: null, tipo: "TRANSFERENCIA", quantidade: 90, quantidadePerdida: 0, motivoPerdaId: null, dataMovimentacao: iso(6), usuarioId: usuarioProducaoE1, observacao: "Entrada em estoque de produto acabado", criadoEm: iso(6) },
  );

  // OP #0002 — em produção (na Costura), 150 previstas
  const op2Id = nid("ordemProducao");
  const op2EtapaCorte = nid("opEtapa");
  const op2EtapaCostura = nid("opEtapa");
  const op2EtapaLavanderia = nid("opEtapa");
  const op2EtapaSecagem = nid("opEtapa");
  const op2EtapaAcabamento = nid("opEtapa");
  const op2EtapaExpedicao = nid("opEtapa");
  ordensProducaoEtapas.push(
    { id: op2EtapaCorte, empresaId: E1, ordemProducaoId: op2Id, setorId: setCorte, sequencia: 1, status: "CONCLUIDA", quantidadePrevista: 150, quantidadeRecebida: 150, quantidadeConcluida: 148, quantidadePerdida: 2, dataEntrada: iso(5), dataSaida: iso(4), usuarioResponsavelId: usuarioProducaoE1, fornecedorId: null, observacao: null, criadoEm: iso(5), atualizadoEm: iso(4) },
    { id: op2EtapaCostura, empresaId: E1, ordemProducaoId: op2Id, setorId: setCostura, sequencia: 2, status: "EM_EXECUCAO", quantidadePrevista: 148, quantidadeRecebida: 148, quantidadeConcluida: 0, quantidadePerdida: 0, dataEntrada: iso(4), dataSaida: null, usuarioResponsavelId: usuarioProducaoE1, fornecedorId: null, observacao: null, criadoEm: iso(4), atualizadoEm: iso(4) },
    { id: op2EtapaLavanderia, empresaId: E1, ordemProducaoId: op2Id, setorId: setLavanderia, sequencia: 3, status: "AGUARDANDO", quantidadePrevista: 148, quantidadeRecebida: 0, quantidadeConcluida: 0, quantidadePerdida: 0, dataEntrada: null, dataSaida: null, usuarioResponsavelId: null, fornecedorId: fornFaccaoE1, observacao: null, criadoEm: iso(5), atualizadoEm: iso(5) },
    { id: op2EtapaSecagem, empresaId: E1, ordemProducaoId: op2Id, setorId: setSecagem, sequencia: 4, status: "AGUARDANDO", quantidadePrevista: 148, quantidadeRecebida: 0, quantidadeConcluida: 0, quantidadePerdida: 0, dataEntrada: null, dataSaida: null, usuarioResponsavelId: null, fornecedorId: null, observacao: null, criadoEm: iso(5), atualizadoEm: iso(5) },
    { id: op2EtapaAcabamento, empresaId: E1, ordemProducaoId: op2Id, setorId: setAcabamento, sequencia: 5, status: "AGUARDANDO", quantidadePrevista: 148, quantidadeRecebida: 0, quantidadeConcluida: 0, quantidadePerdida: 0, dataEntrada: null, dataSaida: null, usuarioResponsavelId: null, fornecedorId: null, observacao: null, criadoEm: iso(5), atualizadoEm: iso(5) },
    { id: op2EtapaExpedicao, empresaId: E1, ordemProducaoId: op2Id, setorId: setExpedicao, sequencia: 6, status: "AGUARDANDO", quantidadePrevista: 148, quantidadeRecebida: 0, quantidadeConcluida: 0, quantidadePerdida: 0, dataEntrada: null, dataSaida: null, usuarioResponsavelId: null, fornecedorId: null, observacao: null, criadoEm: iso(5), atualizadoEm: iso(5) },
  );
  ordensProducao.push({
    id: op2Id,
    empresaId: E1,
    codigo: "OP-0002",
    produtoVariacaoId: camisetaVars.find((v) => v.sku === "PC-CAM-BRANCO-M")!.id,
    fluxoProducaoId: fluxoCamiseta,
    etapaAtualId: op2EtapaCostura,
    estoqueOrigemId: estFabricaE1,
    estoqueDestinoId: estFabricaE1,
    status: "EM_PRODUCAO",
    quantidadePrevista: 150,
    quantidadeProduzida: 0,
    quantidadeRefugada: 2,
    lote: "L-2026-002",
    dataAbertura: iso(5),
    observacao: null,
    usuarioId: usuarioProducaoE1,
    ativo: true,
    criadoEm: iso(5),
    atualizadoEm: iso(4),
  });
  movimentacoesProducao.push(
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op2Id, etapaOrigemId: null, etapaDestinoId: op2EtapaCorte, setorOrigemId: null, setorDestinoId: setCorte, tipo: "TRANSFERENCIA", quantidade: 150, quantidadePerdida: 0, motivoPerdaId: null, dataMovimentacao: iso(5), usuarioId: usuarioProducaoE1, observacao: "Abertura da OP", criadoEm: iso(5) },
    { id: nid("movProducao"), empresaId: E1, ordemProducaoId: op2Id, etapaOrigemId: op2EtapaCorte, etapaDestinoId: op2EtapaCostura, setorOrigemId: setCorte, setorDestinoId: setCostura, tipo: "TRANSFERENCIA", quantidade: 148, quantidadePerdida: 2, motivoPerdaId: motivoDefeitoTecidoE1, dataMovimentacao: iso(4), usuarioId: usuarioProducaoE1, observacao: "2 peças com defeito de tecido no corte", criadoEm: iso(4) },
  );

  // OP #0003 — planejada (ainda não liberada)
  const op3Id = nid("ordemProducao");
  ordensProducao.push({
    id: op3Id,
    empresaId: E1,
    codigo: "OP-0003",
    produtoVariacaoId: poloVars.find((v) => v.sku === "PC-POLO-PRETO-M")!.id,
    fluxoProducaoId: fluxoPolo,
    etapaAtualId: null,
    estoqueOrigemId: estFabricaE1,
    estoqueDestinoId: estFabricaE1,
    status: "PLANEJADA",
    quantidadePrevista: 60,
    quantidadeProduzida: 0,
    quantidadeRefugada: 0,
    lote: "L-2026-003",
    dataAbertura: iso(1),
    observacao: "Aguardando liberação",
    usuarioId: usuarioAdminE1,
    ativo: true,
    criadoEm: iso(1),
    atualizadoEm: iso(1),
  });

  // -------------------------------------------------------------
  // Estoque — saldos por SKU e local
  // -------------------------------------------------------------
  const saldos: ProdutoEstoque[] = [];
  function setSaldo(produtoVariacaoId: number, estoqueId: number, empresaId: number, quantidade: number, reservada = 0) {
    saldos.push({ produtoVariacaoId, estoqueId, empresaId, quantidade, quantidadeReservada: reservada, criadoEm: base.criadoEm, atualizadoEm: base.atualizadoEm });
  }

  // Matéria-prima / aviamentos — só na Fábrica
  setSaldo(varTecidoPreto, estFabricaE1, E1, 216); // 300 compradas - 84 consumidas na OP-0001 (0.85*100... ver kardex abaixo, ajustado)
  setSaldo(varTecidoBranco, estFabricaE1, E1, 40);
  setSaldo(varLinha, estFabricaE1, E1, 88);
  setSaldo(varEtiqueta, estFabricaE1, E1, 900);
  setSaldo(varSemiPretoM, estFabricaE1, E1, 5);

  // Produto acabado — Camiseta Preto M: 90 produzidas na OP-0001, distribuídas
  setSaldo(camisetaPretoM, estFabricaE1, E1, 40);
  setSaldo(camisetaPretoM, estCentroE1, E1, 30);
  setSaldo(camisetaPretoM, estNorteE1, E1, 20);

  // Demais variações de camiseta — saldo inicial de catálogo
  for (const v of camisetaVars) {
    if (v.id === camisetaPretoM) continue;
    setSaldo(v.id, estFabricaE1, E1, 60);
    setSaldo(v.id, estCentroE1, E1, 25);
  }
  for (const v of poloVars) {
    setSaldo(v.id, estFabricaE1, E1, 35);
  }

  // Empresa 2
  setSaldo(varTecidoE2, estFabricaE2, E2, 150);
  for (const v of camisetaVarsE2) {
    setSaldo(v.id, estFabricaE2, E2, 45);
    setSaldo(v.id, estLojaE2, E2, 20);
  }

  // -------------------------------------------------------------
  // Estoque mínimo por SKU (Etapa 14 — regra 25 do Prompt Master;
  // ver nota de limitação de banco em types/index.ts). Só uma parte
  // das variações recebe um mínimo configurado no seed — as demais
  // ficam sem configuração (comportamento normal: sem mínimo definido,
  // a variação simplesmente não participa do alerta de estoque baixo).
  // Alguns SKUs ficam propositalmente ABAIXO do mínimo (disparam
  // alerta) e outros ACIMA (não disparam), nas duas empresas — para
  // validar tanto a regra 45 quanto o isolamento multiempresa (regra
  // 17) do card "Estoque baixo" do Dashboard.
  // -------------------------------------------------------------
  const estoquesMinimos: EstoqueMinimo[] = [];
  function setMinimo(produtoVariacaoId: number, empresaId: number, quantidade: number) {
    estoquesMinimos.push({ produtoVariacaoId, empresaId, quantidade, atualizadoEm: base.atualizadoEm });
  }
  setMinimo(camisetaPretoM, E1, 40); // saldo total 90 — acima do mínimo
  setMinimo(camisetaVars.find((v) => v.sku === "PC-CAM-PRETO-P")!.id, E1, 100); // saldo 85 — abaixo do mínimo
  setMinimo(camisetaVars.find((v) => v.sku === "PC-CAM-BRANCO-M")!.id, E1, 90); // saldo 85 — abaixo do mínimo
  setMinimo(poloVars.find((v) => v.sku === "PC-POLO-PRETO-M")!.id, E1, 50); // saldo 35 — abaixo do mínimo
  setMinimo(poloVars.find((v) => v.sku === "PC-POLO-MARINHO-G")!.id, E1, 20); // saldo 35 — acima do mínimo
  setMinimo(camisetaVarsE2[0].id, E2, 80); // saldo 65 — abaixo do mínimo (isolado da Empresa 1)
  setMinimo(camisetaVarsE2[1].id, E2, 30); // saldo 65 — acima do mínimo

  // -------------------------------------------------------------
  // Kardex — histórico consistente com os saldos acima
  // -------------------------------------------------------------
  const kardex: KardexEntry[] = [];
  function addKardex(entry: Omit<KardexEntry, "id" | "criadoEm">) {
    kardex.push({ id: nid("kardex"), criadoEm: entry.dataMovimentacao, ...entry });
  }

  // Compra concluída — entrada de 300m de tecido preto
  addKardex({
    empresaId: E1,
    produtoVariacaoId: varTecidoPreto,
    estoqueId: estFabricaE1,
    sentido: "ENTRADA",
    natureza: "COMPRA",
    quantidade: 300,
    saldoAnterior: 0,
    saldoResultante: 300,
    notaFiscalItemId: nfItemConcluidaId,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
    usuarioId: usuarioEstoqueE1,
    observacao: "Nota fiscal 000123",
    dataMovimentacao: iso(19),
  });
  // Consumo de produção — 100 peças * 0,85m = 85m (ficha técnica corte)
  addKardex({
    empresaId: E1,
    produtoVariacaoId: varTecidoPreto,
    estoqueId: estFabricaE1,
    sentido: "SAIDA",
    natureza: "PRODUCAO_CONSUMO",
    quantidade: 85,
    saldoAnterior: 300,
    saldoResultante: 215,
    notaFiscalItemId: null,
    ordemProducaoId: op1Id,
    movimentacaoProducaoId: null,
    usuarioId: usuarioProducaoE1,
    observacao: "Consumo de corte — OP-0001",
    dataMovimentacao: iso(15),
  });
  addKardex({
    empresaId: E1,
    produtoVariacaoId: varTecidoPreto,
    estoqueId: estFabricaE1,
    sentido: "ENTRADA",
    natureza: "AJUSTE",
    quantidade: 1,
    saldoAnterior: 215,
    saldoResultante: 216,
    notaFiscalItemId: null,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
    usuarioId: usuarioEstoqueE1,
    observacao: "Ajuste de contagem de inventário",
    dataMovimentacao: iso(3),
  });
  // Entrada de produção — 90 camisetas concluídas
  addKardex({
    empresaId: E1,
    produtoVariacaoId: camisetaPretoM,
    estoqueId: estFabricaE1,
    sentido: "ENTRADA",
    natureza: "PRODUCAO_ENTRADA",
    quantidade: 90,
    saldoAnterior: 0,
    saldoResultante: 90,
    notaFiscalItemId: null,
    ordemProducaoId: op1Id,
    movimentacaoProducaoId: null,
    usuarioId: usuarioProducaoE1,
    observacao: "Conclusão da OP-0001",
    dataMovimentacao: iso(6),
  });
  // Transferências para as lojas
  addKardex({
    empresaId: E1,
    produtoVariacaoId: camisetaPretoM,
    estoqueId: estFabricaE1,
    sentido: "SAIDA",
    natureza: "TRANSFERENCIA",
    quantidade: 30,
    saldoAnterior: 90,
    saldoResultante: 60,
    usuarioId: usuarioEstoqueE1,
    observacao: "Transferência para Loja Centro",
    dataMovimentacao: iso(5),
    notaFiscalItemId: null,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
  });
  addKardex({
    empresaId: E1,
    produtoVariacaoId: camisetaPretoM,
    estoqueId: estCentroE1,
    sentido: "ENTRADA",
    natureza: "TRANSFERENCIA",
    quantidade: 30,
    saldoAnterior: 0,
    saldoResultante: 30,
    usuarioId: usuarioEstoqueE1,
    observacao: "Transferência de Fábrica",
    dataMovimentacao: iso(5),
    notaFiscalItemId: null,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
  });
  addKardex({
    empresaId: E1,
    produtoVariacaoId: camisetaPretoM,
    estoqueId: estFabricaE1,
    sentido: "SAIDA",
    natureza: "TRANSFERENCIA",
    quantidade: 20,
    saldoAnterior: 60,
    saldoResultante: 40,
    usuarioId: usuarioEstoqueE1,
    observacao: "Transferência para Loja Norte",
    dataMovimentacao: iso(4),
    notaFiscalItemId: null,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
  });
  addKardex({
    empresaId: E1,
    produtoVariacaoId: camisetaPretoM,
    estoqueId: estNorteE1,
    sentido: "ENTRADA",
    natureza: "TRANSFERENCIA",
    quantidade: 20,
    saldoAnterior: 0,
    saldoResultante: 20,
    usuarioId: usuarioEstoqueE1,
    observacao: "Transferência de Fábrica",
    dataMovimentacao: iso(4),
    notaFiscalItemId: null,
    ordemProducaoId: null,
    movimentacaoProducaoId: null,
  });

  // -------------------------------------------------------------
  // Auditoria
  // -------------------------------------------------------------
  const auditLog: AuditLogEntry[] = [
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioEstoqueE1, usuarioNome: "Patrícia Lima", acao: "CONCLUSAO_COMPRA", entidade: "Nota Fiscal", descricao: "Concluiu a nota fiscal 000123 — Têxtil Ipiranga LTDA", dataHora: iso(19) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioProducaoE1, usuarioNome: "João Pereira", acao: "PRODUCAO", entidade: "Ordem de Produção", descricao: "Abriu a OP-0001 — Camiseta Básica Preto M (100 un.)", dataHora: iso(15) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioProducaoE1, usuarioNome: "João Pereira", acao: "REFUGO", entidade: "Ordem de Produção", descricao: "Registrou 5 peças refugadas na Costura — OP-0001", dataHora: iso(12) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioProducaoE1, usuarioNome: "João Pereira", acao: "PRODUCAO", entidade: "Ordem de Produção", descricao: "Concluiu a OP-0001 — 90 peças produzidas, 10 refugadas", dataHora: iso(6) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioEstoqueE1, usuarioNome: "Patrícia Lima", acao: "TRANSFERENCIA", entidade: "Estoque", descricao: "Transferiu 30 un. de Camiseta Básica Preto M — Fábrica → Loja Centro", dataHora: iso(5) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioEstoqueE1, usuarioNome: "Patrícia Lima", acao: "TRANSFERENCIA", entidade: "Estoque", descricao: "Transferiu 20 un. de Camiseta Básica Preto M — Fábrica → Loja Norte", dataHora: iso(4) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioEstoqueE1, usuarioNome: "Patrícia Lima", acao: "BAIXA", entidade: "Estoque", descricao: "Ajuste de contagem de inventário — Tecido Malha PV Preto (+1m)", dataHora: iso(3) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioProducaoE1, usuarioNome: "João Pereira", acao: "PRODUCAO", entidade: "Ordem de Produção", descricao: "Abriu a OP-0002 — Camiseta Básica Branco M (150 un.)", dataHora: iso(5) },
    { id: nid("audit"), empresaId: E1, usuarioId: usuarioAdminE1, usuarioNome: "Fernanda Souza", acao: "CRIACAO", entidade: "Ordem de Produção", descricao: "Criou a OP-0003 — Polo Piquet Preto M (60 un.), aguardando liberação", dataHora: iso(1) },
  ];

  return {
    __seedVersion: CURRENT_SEED_VERSION,
    adminsPlataforma,
    auditLogPlataforma,
    empresas,
    unidadesMedida,
    permissoes,
    cargos,
    usuarios,
    colecoes,
    cores,
    tamanhos,
    categorias,
    produtos,
    variacoes,
    tiposPagamento,
    precos,
    estoques,
    saldos,
    estoquesMinimos,
    fornecedores,
    notasFiscais,
    notasFiscaisItens,
    componentes,
    setores,
    fluxos,
    fluxosEtapas,
    ordensProducao,
    ordensProducaoEtapas,
    motivosPerda,
    movimentacoesProducao,
    kardex,
    auditLog,
    __seq: {},
  };
}
