import {
  LayoutDashboard,
  Shirt,
  Palette,
  Warehouse,
  ArrowLeftRight,
  ScrollText,
  Truck,
  ShoppingCart,
  Factory,
  Route,
  Workflow,
  AlertTriangle,
  Users,
  History,
  Building2,
  PackagePlus,
} from "lucide-react";
import { PERMISSIONS, type PermissionKey } from "@/constants/permissions";

export interface NavItem {
  label: string;
  href: string;
  icon: typeof LayoutDashboard;
  perm: PermissionKey;
}

export interface NavGroup {
  label: string;
  items: NavItem[];
}

export const NAV_GROUPS: NavGroup[] = [
  {
    label: "Visão geral",
    items: [{ label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, perm: PERMISSIONS.DASHBOARD_VIEW }],
  },
  {
    label: "Catálogo",
    items: [
      { label: "Produtos", href: "/produtos", icon: Shirt, perm: PERMISSIONS.PRODUCTS_VIEW },
      { label: "Cadastros", href: "/cadastros", icon: Palette, perm: PERMISSIONS.SUPPORT_TABLES_VIEW },
      { label: "Fornecedores", href: "/fornecedores", icon: Truck, perm: PERMISSIONS.SUPPLIERS_VIEW },
    ],
  },
  {
    label: "Estoque",
    items: [
      { label: "Saldos", href: "/estoque", icon: Warehouse, perm: PERMISSIONS.INVENTORY_VIEW },
      { label: "Transferências", href: "/estoque/transferencias", icon: ArrowLeftRight, perm: PERMISSIONS.TRANSFERS_MANAGE },
      { label: "Kardex", href: "/estoque/kardex", icon: ScrollText, perm: PERMISSIONS.KARDEX_VIEW },
      { label: "Locais", href: "/estoque/locais", icon: Building2, perm: PERMISSIONS.STOCK_LOCATIONS_MANAGE },
      { label: "Entradas", href: "/estoque/entradas", icon: PackagePlus, perm: PERMISSIONS.INVENTORY_MANAGE },
    ],
  },
  {
    label: "Compras",
    items: [{ label: "Notas fiscais", href: "/compras", icon: ShoppingCart, perm: PERMISSIONS.PURCHASES_VIEW }],
  },
  {
    label: "Produção (PCP)",
    items: [
      { label: "Ordens de produção", href: "/producao", icon: Factory, perm: PERMISSIONS.PRODUCTION_VIEW },
      { label: "Fluxos e setores", href: "/producao/fluxos", icon: Route, perm: PERMISSIONS.FLOWS_MANAGE },
      { label: "Fichas técnicas", href: "/producao/fichas-tecnicas", icon: Workflow, perm: PERMISSIONS.BOM_MANAGE },
      { label: "Refugos", href: "/producao/refugos", icon: AlertTriangle, perm: PERMISSIONS.DEFECTS_VIEW },
    ],
  },
  {
    label: "Administração",
    items: [
      { label: "Equipe", href: "/equipe", icon: Users, perm: PERMISSIONS.TEAM_MANAGE },
      { label: "Auditoria", href: "/auditoria", icon: History, perm: PERMISSIONS.AUDIT_VIEW },
    ],
  },
];
