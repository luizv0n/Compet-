// =====================================================================
// Catálogo de permissões — espelha a tabela `permissao`, com nomes
// estáveis usados pela camada de RBAC do frontend (cargo -> cargo_permissao
// -> permissao). ADMINISTRADOR recebe todas; FUNCIONARIO recebe o
// subconjunto operacional listado no prompt (produção, compras, estoque,
// transferências, consultas, Kardex).
// =====================================================================

export const PERMISSIONS = {
  DASHBOARD_VIEW: "dashboard.visualizar",

  PRODUCTS_VIEW: "produtos.visualizar",
  PRODUCTS_MANAGE: "produtos.gerenciar",

  SUPPORT_TABLES_VIEW: "cadastros.visualizar",
  SUPPORT_TABLES_MANAGE: "cadastros.gerenciar",

  SUPPLIERS_VIEW: "fornecedores.visualizar",
  SUPPLIERS_MANAGE: "fornecedores.gerenciar",

  INVENTORY_VIEW: "estoque.visualizar",
  INVENTORY_MANAGE: "estoque.gerenciar",
  STOCK_LOCATIONS_MANAGE: "estoque.locais.gerenciar",
  TRANSFERS_MANAGE: "transferencias.gerenciar",
  KARDEX_VIEW: "kardex.visualizar",

  PURCHASES_VIEW: "compras.visualizar",
  PURCHASES_MANAGE: "compras.gerenciar",

  PRODUCTION_VIEW: "producao.visualizar",
  PRODUCTION_MANAGE: "producao.gerenciar",
  BOM_MANAGE: "fichatecnica.gerenciar",
  FLOWS_MANAGE: "fluxos.gerenciar",
  SECTORS_MANAGE: "setores.gerenciar",
  DEFECTS_VIEW: "refugos.visualizar",
  DEFECTS_MANAGE: "refugos.gerenciar",

  TEAM_MANAGE: "equipe.gerenciar",
  AUDIT_VIEW: "auditoria.visualizar",
} as const;

export type PermissionKey = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

export const ALL_PERMISSIONS: PermissionKey[] = Object.values(PERMISSIONS);

export const ROLE_NAMES = {
  ADMIN: "ADMINISTRADOR",
  FUNCIONARIO: "FUNCIONARIO",
} as const;

/** Permissões padrão do cargo FUNCIONARIO no seed. */
export const FUNCIONARIO_PERMISSIONS: PermissionKey[] = [
  PERMISSIONS.DASHBOARD_VIEW,
  PERMISSIONS.PRODUCTS_VIEW,
  PERMISSIONS.SUPPORT_TABLES_VIEW,
  PERMISSIONS.SUPPLIERS_VIEW,
  PERMISSIONS.INVENTORY_VIEW,
  PERMISSIONS.INVENTORY_MANAGE,
  PERMISSIONS.TRANSFERS_MANAGE,
  PERMISSIONS.KARDEX_VIEW,
  PERMISSIONS.PURCHASES_VIEW,
  PERMISSIONS.PURCHASES_MANAGE,
  PERMISSIONS.PRODUCTION_VIEW,
  PERMISSIONS.PRODUCTION_MANAGE,
  PERMISSIONS.BOM_MANAGE,
  PERMISSIONS.FLOWS_MANAGE,
  PERMISSIONS.SECTORS_MANAGE,
  PERMISSIONS.DEFECTS_VIEW,
  PERMISSIONS.DEFECTS_MANAGE,
];
