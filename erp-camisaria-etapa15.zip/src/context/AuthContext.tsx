"use client";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { apiClient } from "@/services/apiClient";
import { loadSession, saveSession, clearSession } from "@/services/storage";
import type { Empresa, ID, Usuario } from "@/types";
import type { PermissionKey } from "@/constants/permissions";

interface AuthState {
  loading: boolean;
  usuario: Usuario | null;
  empresa: Empresa | null;
  cargoNome: string | null;
  permissoes: string[];
}

interface AuthContextValue extends AuthState {
  login: (empresaId: ID, login: string, senha: string) => Promise<void>;
  logout: () => void;
  hasPermission: (perm: PermissionKey) => boolean;
  isAdmin: boolean;
  actor: { id: ID; nome: string } | null;
  /** Troca o usuário logado sem senha, mantendo a mesma empresa — atalho para alternar entre perfis durante testes. */
  switchUser: (usuarioId: ID) => Promise<void>;
}

const AuthContext = React.createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = React.useState<AuthState>({
    loading: true,
    usuario: null,
    empresa: null,
    cargoNome: null,
    permissoes: [],
  });
  const router = useRouter();

  const hydrate = React.useCallback(async () => {
    const stored = loadSession();
    if (!stored) {
      setState((s) => ({ ...s, loading: false }));
      return;
    }
    const ctx = await apiClient.auth.sessionContext(stored.usuarioId, stored.empresaId);
    if (!ctx || !ctx.usuario.ativo) {
      clearSession();
      setState((s) => ({ ...s, loading: false }));
      return;
    }
    setState({
      loading: false,
      usuario: ctx.usuario,
      empresa: ctx.empresa ?? null,
      cargoNome: ctx.cargo?.nome ?? null,
      permissoes: ctx.permissoes,
    });
  }, []);

  React.useEffect(() => {
    hydrate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const login = React.useCallback(async (empresaId: ID, login: string, senha: string) => {
    const usuario = await apiClient.auth.login(empresaId, login, senha);
    saveSession({ usuarioId: usuario.id, empresaId });
    await hydrate();
  }, [hydrate]);

  const switchUser = React.useCallback(async (usuarioId: ID) => {
    if (!state.empresa) return;
    saveSession({ usuarioId, empresaId: state.empresa.id });
    await hydrate();
  }, [state.empresa, hydrate]);

  const logout = React.useCallback(() => {
    clearSession();
    setState({ loading: false, usuario: null, empresa: null, cargoNome: null, permissoes: [] });
    router.push("/login");
  }, [router]);

  const hasPermission = React.useCallback(
    (perm: PermissionKey) => state.permissoes.includes(perm),
    [state.permissoes],
  );

  const value: AuthContextValue = {
    ...state,
    login,
    logout,
    hasPermission,
    isAdmin: state.cargoNome === "ADMINISTRADOR",
    actor: state.usuario ? { id: state.usuario.id, nome: state.usuario.nome } : null,
    switchUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = React.useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProvider");
  return ctx;
}
