"use client";
// =====================================================================
// SitePlatformLoginPage — portal de login do ADM DO SITE (/site/login).
//
// Deliberadamente separado, visual e logicamente, do /login de empresa
// (seção 12 do prompt mestre): não há seletor de empresa aqui, não há
// campo "empresa", e o ADM DO SITE não aparece como opção dentro do
// /login normal. Reaproveita a estrutura de layout de login-page.tsx
// (grid editorial + formulário) mas com identidade visual escura
// ("Portal da Plataforma") para não ser confundido com o portal de
// empresa.
//
// Decisão sobre sessão dupla (seção "considerar e documentar" da
// Etapa 5): uma sessão de empresa (/login) e uma sessão de plataforma
// (/site/login) podem coexistir sem conflito técnico — cada uma usa
// sua própria chave de localStorage (ver services/storage.ts). Se o
// usuário já tiver uma sessão de empresa ativa ao abrir esta tela,
// mostramos um aviso não bloqueante (ele pode ser, por exemplo, um
// administrador de empresa que também precisa entrar como ADM DO
// SITE em outra aba). Não bloqueamos nem encerramos a outra sessão
// automaticamente.
// =====================================================================
import * as React from "react";
import { ShieldCheck, ChevronRight, Building2 } from "lucide-react";
import { useRouter } from "@/lib/next-compat";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function SitePlatformLoginPage() {
  const { login, admin, loading: platformLoading } = usePlatformAuth();
  const { usuario: empresaUsuario, empresa: empresaAtiva } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const [loginValue, setLoginValue] = React.useState("");
  const [senha, setSenha] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    if (!platformLoading && admin) router.replace("/site");
  }, [platformLoading, admin, router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!loginValue.trim() || !senha) {
      setError("Preencha login e senha.");
      return;
    }
    setSubmitting(true);
    try {
      await login(loginValue.trim(), senha);
      toast({ title: "Login realizado", variant: "success" });
      router.replace("/site");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível entrar.");
    } finally {
      setSubmitting(false);
    }
  }

  function fillDemo() {
    setLoginValue("adm.plataforma");
    setSenha("123456");
  }

  return (
    <div className="grid min-h-dvh grid-cols-1 lg:grid-cols-[1.05fr_1fr]">
      {/* Painel editorial — identidade de plataforma (não têxtil: este portal é da equipe do produto, não da empresa cliente) */}
      <div className="relative hidden overflow-hidden bg-foreground text-background lg:flex lg:flex-col lg:justify-between">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.08]"
          style={{
            backgroundImage:
              "radial-gradient(circle at 1px 1px, hsl(0 0% 100% / 0.5) 1px, transparent 0)",
            backgroundSize: "24px 24px",
          }}
        />
        <div className="relative z-10 p-10">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-accent/20">
              <ShieldCheck className="h-5 w-5 text-accent" />
            </div>
            <span className="text-lg font-semibold">Camisaria ERP</span>
          </div>
        </div>
        <div className="relative z-10 px-10 pb-14">
          <div className="mb-6 flex items-center gap-2 text-accent">
            <ShieldCheck className="h-4 w-4" />
            <span className="font-mono text-xs uppercase tracking-[0.2em]">Portal da Plataforma</span>
          </div>
          <h1 className="max-w-md text-3xl font-semibold leading-tight tracking-tight">
            Administração global do Camisaria ERP.
          </h1>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-background/70">
            Acesso restrito ao ADM DO SITE: criação de empresas, ativação/inativação e auditoria
            global. Este portal é independente do login usado pelas empresas clientes.
          </p>
        </div>
      </div>

      {/* Formulário */}
      <div className="flex items-center justify-center bg-background px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-foreground">
              <ShieldCheck className="h-5 w-5 text-accent" />
            </div>
            <span className="text-lg font-semibold text-foreground">Camisaria ERP</span>
          </div>

          <div className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            <ShieldCheck className="h-3.5 w-3.5" />
            Portal da plataforma
          </div>
          <h2 className="text-xl font-semibold tracking-tight text-foreground">Entrar como ADM DO SITE</h2>
          <p className="mt-1 text-sm text-muted-foreground">Informe suas credenciais de administrador global.</p>

          {empresaUsuario && (
            <div className="mt-4 flex items-start gap-2 rounded-md border border-border bg-secondary/40 px-3 py-2 text-xs text-muted-foreground">
              <Building2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>
                Você também está logado como <strong className="text-foreground">{empresaUsuario.nome}</strong>
                {empresaAtiva ? <> em {empresaAtiva.nomeFantasia}</> : null}. Essa sessão de empresa continua ativa
                separadamente — entrar aqui não a encerra.
              </span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="login">Login</Label>
              <Input
                id="login"
                autoComplete="username"
                value={loginValue}
                onChange={(e) => setLoginValue(e.target.value)}
                placeholder="adm.plataforma"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="senha">Senha</Label>
              <Input
                id="senha"
                type="password"
                autoComplete="current-password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="••••••••"
              />
            </div>

            {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}

            <Button type="submit" size="lg" loading={submitting} className="mt-1">
              Entrar
              <ChevronRight className="h-4 w-4" />
            </Button>
          </form>

          <div className="mt-8 rounded-lg border bg-secondary/40 p-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Acesso de demonstração
            </p>
            <button
              type="button"
              onClick={fillDemo}
              className="flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm hover:bg-secondary"
            >
              <span>ADM DO SITE</span>
              <code className="font-mono text-xs text-muted-foreground">adm.plataforma</code>
            </button>
            <p className="mt-2 text-xs text-muted-foreground">
              Senha: <code className="font-mono">123456</code>
            </p>
          </div>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            É usuário de uma empresa?{" "}
            <a href="/login" className="font-medium text-foreground underline underline-offset-2">
              Acesse o login da empresa
            </a>
            .
          </p>
        </div>
      </div>
    </div>
  );
}
