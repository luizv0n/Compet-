"use client";
// =====================================================================
// NovaEmpresaPage (/site/nova-empresa) — seção 13 do prompt mestre.
//
// Fluxo: Dados da Empresa -> Administrador Inicial -> Criar.
// Os cargos padrão (ADMINISTRADOR/FUNCIONARIO), as permissões e o
// local de estoque "Fábrica" já são criados automaticamente pelo mock
// (mockRepository.createEmpresaComAdmin, ver Etapa 3/4) — esta tela só
// coleta os dois grupos de campos e chama apiClient.plataforma.createEmpresa.
// Dados operacionais (produtos, fornecedores, categorias, coleções)
// propositalmente NÃO são criados — a empresa nasce vazia.
// =====================================================================
import * as React from "react";
import { Building2, UserCog, ChevronRight } from "lucide-react";
import { useRouter } from "@/lib/next-compat";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PageHeader } from "@/components/common/PageHeader";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const emptyEmpresa = {
  razaoSocial: "",
  nomeFantasia: "",
  cnpj: "",
  inscricaoEstadual: "",
  inscricaoMunicipal: "",
  email: "",
  telefone: "",
  celular: "",
  site: "",
  cep: "",
  logradouro: "",
  numero: "",
  complemento: "",
  bairro: "",
  cidade: "",
  estado: "",
};

const emptyAdmin = { nome: "", login: "", email: "", senha: "" };

export default function NovaEmpresaPage() {
  const { actor } = usePlatformAuth();
  const { toast } = useToast();
  const router = useRouter();

  const [empresaForm, setEmpresaForm] = React.useState(emptyEmpresa);
  const [adminForm, setAdminForm] = React.useState(emptyAdmin);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  function setEmpresaField<K extends keyof typeof emptyEmpresa>(key: K, value: string) {
    setEmpresaForm((f) => ({ ...f, [key]: value }));
  }
  function setAdminField<K extends keyof typeof emptyAdmin>(key: K, value: string) {
    setAdminForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!actor) return;

    const requiredEmpresa: (keyof typeof emptyEmpresa)[] = [
      "razaoSocial",
      "nomeFantasia",
      "cnpj",
      "email",
      "cep",
      "logradouro",
      "numero",
      "bairro",
      "cidade",
      "estado",
    ];
    const missingEmpresa = requiredEmpresa.some((k) => !empresaForm[k].trim());
    const missingAdmin = !adminForm.nome.trim() || !adminForm.login.trim() || !adminForm.email.trim() || !adminForm.senha.trim();
    if (missingEmpresa || missingAdmin) {
      setError("Preencha todos os campos obrigatórios de empresa e administrador inicial.");
      return;
    }

    setSubmitting(true);
    try {
      await apiClient.plataforma.createEmpresa(actor, {
        empresa: {
          razaoSocial: empresaForm.razaoSocial.trim(),
          nomeFantasia: empresaForm.nomeFantasia.trim(),
          cnpj: empresaForm.cnpj.trim(),
          inscricaoEstadual: empresaForm.inscricaoEstadual.trim() || null,
          inscricaoMunicipal: empresaForm.inscricaoMunicipal.trim() || null,
          email: empresaForm.email.trim(),
          telefone: empresaForm.telefone.trim() || null,
          celular: empresaForm.celular.trim() || null,
          site: empresaForm.site.trim() || null,
          cep: empresaForm.cep.trim(),
          logradouro: empresaForm.logradouro.trim(),
          numero: empresaForm.numero.trim(),
          complemento: empresaForm.complemento.trim() || null,
          bairro: empresaForm.bairro.trim(),
          cidade: empresaForm.cidade.trim(),
          estado: empresaForm.estado.trim(),
        },
        administradorInicial: {
          nome: adminForm.nome.trim(),
          login: adminForm.login.trim(),
          email: adminForm.email.trim(),
          senha: adminForm.senha.trim(),
        },
      });
      toast({ title: "Empresa criada", description: `${empresaForm.nomeFantasia} está pronta para operar.`, variant: "success" });
      router.replace("/site");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível criar a empresa.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div>
      <PageHeader title="Nova Empresa" description="Dados da Empresa → Administrador Inicial → Criar." />

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-primary" />
              <CardTitle>Dados da Empresa</CardTitle>
            </div>
            <CardDescription>Identificação, contato e endereço da nova empresa cliente.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Razão social" value={empresaForm.razaoSocial} onChange={(v) => setEmpresaField("razaoSocial", v)} />
            <Field label="Nome fantasia" value={empresaForm.nomeFantasia} onChange={(v) => setEmpresaField("nomeFantasia", v)} />
            <Field label="CNPJ" value={empresaForm.cnpj} onChange={(v) => setEmpresaField("cnpj", v)} placeholder="00000000000000" />
            <Field label="E-mail" type="email" value={empresaForm.email} onChange={(v) => setEmpresaField("email", v)} />
            <Field label="Inscrição estadual" required={false} value={empresaForm.inscricaoEstadual} onChange={(v) => setEmpresaField("inscricaoEstadual", v)} />
            <Field label="Inscrição municipal" required={false} value={empresaForm.inscricaoMunicipal} onChange={(v) => setEmpresaField("inscricaoMunicipal", v)} />
            <Field label="Telefone" required={false} value={empresaForm.telefone} onChange={(v) => setEmpresaField("telefone", v)} />
            <Field label="Celular" required={false} value={empresaForm.celular} onChange={(v) => setEmpresaField("celular", v)} />
            <Field label="Site" required={false} value={empresaForm.site} onChange={(v) => setEmpresaField("site", v)} placeholder="https://" />
            <Field label="CEP" value={empresaForm.cep} onChange={(v) => setEmpresaField("cep", v)} />
            <Field label="Logradouro" value={empresaForm.logradouro} onChange={(v) => setEmpresaField("logradouro", v)} />
            <Field label="Número" value={empresaForm.numero} onChange={(v) => setEmpresaField("numero", v)} />
            <Field label="Complemento" required={false} value={empresaForm.complemento} onChange={(v) => setEmpresaField("complemento", v)} />
            <Field label="Bairro" value={empresaForm.bairro} onChange={(v) => setEmpresaField("bairro", v)} />
            <Field label="Cidade" value={empresaForm.cidade} onChange={(v) => setEmpresaField("cidade", v)} />
            <Field label="Estado (UF)" value={empresaForm.estado} onChange={(v) => setEmpresaField("estado", v.toUpperCase())} placeholder="SP" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <UserCog className="h-4 w-4 text-primary" />
              <CardTitle>Administrador Inicial</CardTitle>
            </div>
            <CardDescription>
              Este usuário nasce com o cargo Administrador da empresa e poderá criar os demais
              funcionários (seção 11.2 do prompt mestre).
            </CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Nome" value={adminForm.nome} onChange={(v) => setAdminField("nome", v)} />
            <Field label="Login" value={adminForm.login} onChange={(v) => setAdminField("login", v)} placeholder="admin.empresa" />
            <Field label="E-mail" type="email" value={adminForm.email} onChange={(v) => setAdminField("email", v)} />
            <Field label="Senha inicial" type="password" value={adminForm.senha} onChange={(v) => setAdminField("senha", v)} />
          </CardContent>
        </Card>

        {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}

        <div className="flex items-center gap-2">
          <Button type="submit" loading={submitting}>
            Criar empresa
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button type="button" variant="outline" onClick={() => router.replace("/site")} disabled={submitting}>
            Cancelar
          </Button>
        </div>
      </form>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  placeholder,
  required = true,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  placeholder?: string;
  required?: boolean;
}) {
  const id = React.useId();
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>
        {label}
        {!required && <span className="ml-1 font-normal text-muted-foreground">(opcional)</span>}
      </Label>
      <Input id={id} type={type} value={value} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
