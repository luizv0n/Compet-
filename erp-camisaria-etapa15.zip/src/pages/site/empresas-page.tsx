"use client";
// =====================================================================
// SitePlataformaEmpresasPage (/site/empresas) — seção 14 do prompt
// mestre: tabela Empresa/CNPJ/Administrador/Status/Ações, com
// Abrir/Editar/Inativar (ativar quando inativa). Empresas NUNCA são
// excluídas fisicamente pela interface — só ativadas/inativadas
// (apiClient.plataforma.toggleEmpresa, já existente desde a Etapa 3/4).
//
// "Abrir" (seção 16 — Contexto da Empresa): define empresaContextoId
// via PlatformAuthContext.setEmpresaContexto e volta para o Dashboard,
// onde o banner de contexto fica visível. Não navega para dentro dos
// módulos operacionais da empresa — isso é uma pendência explícita
// documentada no prompt de continuação desta etapa.
//
// "Editar" abre um formulário com os mesmos campos cadastrais de
// /site/nova-empresa (seção 13), mas sem o bloco de Administrador
// Inicial: trocar o administrador responsável é uma operação de
// Equipe (RBAC) e não pertence a esta tela.
// =====================================================================
import * as React from "react";
import { Building2, Pencil, LogIn } from "lucide-react";
import { useRouter } from "@/lib/next-compat";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PageHeader } from "@/components/common/PageHeader";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/common/ConfirmDialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { ROLE_NAMES } from "@/constants/permissions";
import type { Empresa, Usuario, Cargo } from "@/types";

const emptyForm = {
  razaoSocial: "",
  nomeFantasia: "",
  cnpj: "",
  inscricaoEstadual: "",
  inscricaoMunicipal: "",
  email: "",
  telefone: "",
  celular: "",
  site: "",
  cep: "",
  logradouro: "",
  numero: "",
  complemento: "",
  bairro: "",
  cidade: "",
  estado: "",
};

export default function SitePlataformaEmpresasPage() {
  const { actor, setEmpresaContexto } = usePlatformAuth();
  const { toast } = useToast();
  const router = useRouter();

  const [loading, setLoading] = React.useState(true);
  const [empresas, setEmpresas] = React.useState<Empresa[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);
  const [cargos, setCargos] = React.useState<Cargo[]>([]);
  const [query, setQuery] = React.useState("");

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<Empresa | null>(null);
  const [form, setForm] = React.useState(emptyForm);
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [confirmToggle, setConfirmToggle] = React.useState<Empresa | null>(null);

  const reload = React.useCallback(async () => {
    setLoading(true);
    const [e, u, c] = await Promise.all([
      apiClient.plataforma.listEmpresas(true),
      apiClient.plataforma.listUsuarios(),
      apiClient.plataforma.listCargos(),
    ]);
    setEmpresas(e);
    setUsuarios(u);
    setCargos(c);
    setLoading(false);
  }, []);

  React.useEffect(() => {
    reload();
  }, [reload]);

  function administradorDe(empresa: Empresa): string {
    const cargoIds = new Set(cargos.filter((c) => c.empresaId === empresa.id && c.nome === ROLE_NAMES.ADMIN).map((c) => c.id));
    const admin =
      usuarios.find((u) => u.empresaId === empresa.id && u.ativo && cargoIds.has(u.cargoId)) ??
      usuarios.find((u) => u.empresaId === empresa.id && cargoIds.has(u.cargoId));
    return admin?.nome ?? "—";
  }

  const filtered = empresas.filter((e) =>
    `${e.nomeFantasia} ${e.razaoSocial} ${e.cnpj}`.toLowerCase().includes(query.toLowerCase()),
  );
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query]);

  function setField<K extends keyof typeof emptyForm>(key: K, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function openEdit(empresa: Empresa) {
    setEditing(empresa);
    setError(null);
    setForm({
      razaoSocial: empresa.razaoSocial,
      nomeFantasia: empresa.nomeFantasia,
      cnpj: empresa.cnpj,
      inscricaoEstadual: empresa.inscricaoEstadual ?? "",
      inscricaoMunicipal: empresa.inscricaoMunicipal ?? "",
      email: empresa.email,
      telefone: empresa.telefone ?? "",
      celular: empresa.celular ?? "",
      site: empresa.site ?? "",
      cep: empresa.cep,
      logradouro: empresa.logradouro,
      numero: empresa.numero,
      complemento: empresa.complemento ?? "",
      bairro: empresa.bairro,
      cidade: empresa.cidade,
      estado: empresa.estado,
    });
    setDialogOpen(true);
  }

  function handleAbrir(empresa: Empresa) {
    setEmpresaContexto(empresa.id);
    toast({ title: `Contexto definido: ${empresa.nomeFantasia}`, variant: "success" });
    router.push("/site");
  }

  function usuariosAtivosDe(empresa: Empresa): number {
    return usuarios.filter((u) => u.empresaId === empresa.id && u.ativo).length;
  }

  // Ativar é uma ação segura e reversível a qualquer momento — aplica direto.
  // Inativar bloqueia o acesso de todos os usuários da empresa, então pedimos
  // confirmação (regra 61 — UX: evitar erro em ação de alto impacto).
  function handleToggleRequest(empresa: Empresa) {
    if (empresa.ativo) {
      setConfirmToggle(empresa);
    } else {
      handleToggle(empresa);
    }
  }

  async function handleToggle(empresa: Empresa) {
    if (!actor) return;
    try {
      await apiClient.plataforma.toggleEmpresa(empresa.id, actor);
      toast({ title: empresa.ativo ? "Empresa inativada" : "Empresa ativada", variant: "success" });
      reload();
    } catch (err) {
      toast({ title: "Não foi possível alterar o status", description: err instanceof Error ? err.message : undefined, variant: "error" });
    }
  }

  async function handleConfirmToggle() {
    if (!confirmToggle) return;
    await handleToggle(confirmToggle);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!actor || !editing) return;
    setError(null);

    const required: (keyof typeof emptyForm)[] = [
      "razaoSocial",
      "nomeFantasia",
      "cnpj",
      "email",
      "cep",
      "logradouro",
      "numero",
      "bairro",
      "cidade",
      "estado",
    ];
    if (required.some((k) => !form[k].trim())) {
      setError("Preencha todos os campos obrigatórios.");
      return;
    }

    setSubmitting(true);
    try {
      await apiClient.plataforma.updateEmpresa(editing.id, actor, {
        razaoSocial: form.razaoSocial.trim(),
        nomeFantasia: form.nomeFantasia.trim(),
        cnpj: form.cnpj.trim(),
        inscricaoEstadual: form.inscricaoEstadual.trim() || null,
        inscricaoMunicipal: form.inscricaoMunicipal.trim() || null,
        email: form.email.trim(),
        telefone: form.telefone.trim() || null,
        celular: form.celular.trim() || null,
        site: form.site.trim() || null,
        cep: form.cep.trim(),
        logradouro: form.logradouro.trim(),
        numero: form.numero.trim(),
        complemento: form.complemento.trim() || null,
        bairro: form.bairro.trim(),
        cidade: form.cidade.trim(),
        estado: form.estado.trim(),
      });
      toast({ title: "Empresa atualizada", variant: "success" });
      setDialogOpen(false);
      reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível salvar as alterações.");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <LoadingState label="Carregando empresas…" />;

  return (
    <div>
      <PageHeader title="Empresas" description="Gestão das empresas clientes da plataforma." />

      <div className="mb-4">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar por nome, razão social ou CNPJ…" />
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={Building2} title="Nenhuma empresa encontrada" />
      ) : (
        <>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Empresa</TableHead>
                  <TableHead>CNPJ</TableHead>
                  <TableHead>Administrador</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((empresa) => (
                  <TableRow key={empresa.id}>
                    <TableCell className="font-medium text-foreground">
                      {empresa.nomeFantasia}
                      <p className="text-xs font-normal text-muted-foreground">{empresa.razaoSocial}</p>
                    </TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{empresa.cnpj}</TableCell>
                    <TableCell className="text-muted-foreground">{administradorDe(empresa)}</TableCell>
                    <TableCell>
                      <ActiveBadge ativo={empresa.ativo} />
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button
                          onClick={() => handleAbrir(empresa)}
                          title="Abrir contexto desta empresa"
                          className="text-muted-foreground hover:text-foreground"
                        >
                          <LogIn className="h-3.5 w-3.5" />
                        </button>
                        <button onClick={() => openEdit(empresa)} title="Editar" className="text-muted-foreground hover:text-foreground">
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <Switch checked={empresa.ativo} onCheckedChange={() => handleToggleRequest(empresa)} />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent size="lg">
          <DialogHeader>
            <DialogTitle>Editar empresa</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <Field label="Razão social" value={form.razaoSocial} onChange={(v) => setField("razaoSocial", v)} />
              <Field label="Nome fantasia" value={form.nomeFantasia} onChange={(v) => setField("nomeFantasia", v)} />
              <Field label="CNPJ" value={form.cnpj} onChange={(v) => setField("cnpj", v)} />
              <Field label="E-mail" type="email" value={form.email} onChange={(v) => setField("email", v)} />
              <Field label="Inscrição estadual" required={false} value={form.inscricaoEstadual} onChange={(v) => setField("inscricaoEstadual", v)} />
              <Field label="Inscrição municipal" required={false} value={form.inscricaoMunicipal} onChange={(v) => setField("inscricaoMunicipal", v)} />
              <Field label="Telefone" required={false} value={form.telefone} onChange={(v) => setField("telefone", v)} />
              <Field label="Celular" required={false} value={form.celular} onChange={(v) => setField("celular", v)} />
              <Field label="Site" required={false} value={form.site} onChange={(v) => setField("site", v)} />
              <Field label="CEP" value={form.cep} onChange={(v) => setField("cep", v)} />
              <Field label="Logradouro" value={form.logradouro} onChange={(v) => setField("logradouro", v)} />
              <Field label="Número" value={form.numero} onChange={(v) => setField("numero", v)} />
              <Field label="Complemento" required={false} value={form.complemento} onChange={(v) => setField("complemento", v)} />
              <Field label="Bairro" value={form.bairro} onChange={(v) => setField("bairro", v)} />
              <Field label="Cidade" value={form.cidade} onChange={(v) => setField("cidade", v)} />
              <Field label="Estado (UF)" value={form.estado} onChange={(v) => setField("estado", v.toUpperCase())} />
            </div>
            {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} disabled={submitting}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!confirmToggle}
        onOpenChange={(o) => !o && setConfirmToggle(null)}
        title={confirmToggle ? `Inativar ${confirmToggle.nomeFantasia}?` : ""}
        description={
          confirmToggle
            ? `${usuariosAtivosDe(confirmToggle)} usuário(s) ativo(s) desta empresa perderão o acesso ao sistema imediatamente. A empresa pode ser reativada a qualquer momento.`
            : undefined
        }
        confirmLabel="Inativar empresa"
        destructive
        onConfirm={handleConfirmToggle}
      />
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  required = true,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
  required?: boolean;
}) {
  const id = React.useId();
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id}>
        {label}
        {!required && <span className="ml-1 font-normal text-muted-foreground">(opcional)</span>}
      </Label>
      <Input id={id} type={type} value={value} onChange={(e) => onChange(e.target.value)} />
    </div>
  );
}
