"use client";
import * as React from "react";
import { useRouter } from "@/lib/next-compat";
import { Scissors, Ruler, ChevronRight } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { useToast } from "@/context/ToastContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Empresa } from "@/types";

export default function LoginPage() {
  const { login, usuario, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const [empresas, setEmpresas] = React.useState<Empresa[]>([]);
  const [empresaId, setEmpresaId] = React.useState<string>("");
  const [loginValue, setLoginValue] = React.useState("");
  const [senha, setSenha] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  React.useEffect(() => {
    apiClient.auth.listEmpresas().then((list) => {
      setEmpresas(list);
    });
  }, []);

  // Seleciona a primeira empresa só depois que os itens do Select existem
  // (o Radix Select ignora um value cujo item ainda não foi registrado).
  React.useEffect(() => {
    if (!empresaId && empresas.length > 0) setEmpresaId(String(empresas[0].id));
  }, [empresas, empresaId]);



  React.useEffect(() => {
    if (!authLoading && usuario) router.replace("/dashboard");
  }, [authLoading, usuario, router]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (!empresaId || !loginValue || !senha) {
      setError("Preencha empresa, login e senha.");
      return;
    }
    setSubmitting(true);
    try {
      await login(Number(empresaId), loginValue.trim(), senha);
      toast({ title: "Login realizado", variant: "success" });
      router.replace("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível entrar.");
    } finally {
      setSubmitting(false);
    }
  }

  function fillDemo(login: string) {
    setLoginValue(login);
    setSenha("123456");
  }

  return (
    <div className="grid min-h-dvh grid-cols-1 lg:grid-cols-[1.05fr_1fr]">
      {/* Painel editorial — motivo têxtil (fita métrica + carretel) */}
      <div className="relative hidden overflow-hidden bg-primary text-primary-foreground lg:flex lg:flex-col lg:justify-between">
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.14]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(90deg, transparent, transparent 38px, hsl(210 30% 98% / 0.6) 38px, hsl(210 30% 98% / 0.6) 40px)",
          }}
        />
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.1]"
          style={{
            backgroundImage:
              "repeating-linear-gradient(0deg, transparent, transparent 78px, hsl(210 30% 98% / 0.6) 78px, hsl(210 30% 98% / 0.6) 80px)",
          }}
        />
        <div className="relative z-10 p-10">
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-accent/20">
              <Scissors className="h-5 w-5 text-accent" />
            </div>
            <span className="text-lg font-semibold">Camisaria ERP</span>
          </div>
        </div>
        <div className="relative z-10 px-10 pb-14">
          <div className="mb-6 flex items-center gap-2 text-accent">
            <Ruler className="h-4 w-4" />
            <span className="font-mono text-xs uppercase tracking-[0.2em]">Corte · Costura · Estoque · PCP</span>
          </div>
          <h1 className="max-w-md text-3xl font-semibold leading-tight tracking-tight">
            Do rolo de tecido à peça acabada, cada metro rastreado.
          </h1>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-primary-foreground/70">
            Produto, ficha técnica, estoque multiempresa, compras e ordens de produção — tudo em um só
            Kardex, do corte à expedição.
          </p>
        </div>
      </div>

      {/* Formulário */}
      <div className="flex items-center justify-center bg-background px-6 py-12">
        <div className="w-full max-w-sm">
          <div className="mb-8 flex items-center gap-2.5 lg:hidden">
            <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary">
              <Scissors className="h-5 w-5 text-accent" />
            </div>
            <span className="text-lg font-semibold text-foreground">Camisaria ERP</span>
          </div>

          <h2 className="text-xl font-semibold tracking-tight text-foreground">Entrar</h2>
          <p className="mt-1 text-sm text-muted-foreground">Selecione a empresa e informe suas credenciais.</p>

          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="empresa">Empresa</Label>
              <Select value={empresaId} onValueChange={setEmpresaId}>
                <SelectTrigger id="empresa">
                  <SelectValue placeholder="Selecione a empresa" />
                </SelectTrigger>
                <SelectContent>
                  {empresas.map((e) => (
                    <SelectItem key={e.id} value={String(e.id)}>
                      {e.nomeFantasia}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="login">Login</Label>
              <Input id="login" autoComplete="username" value={loginValue} onChange={(e) => setLoginValue(e.target.value)} placeholder="admin.estrela" />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="senha">Senha</Label>
              <Input id="senha" type="password" autoComplete="current-password" value={senha} onChange={(e) => setSenha(e.target.value)} placeholder="••••••••" />
            </div>

            {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}

            <Button type="submit" size="lg" loading={submitting} className="mt-1">
              Entrar
              <ChevronRight className="h-4 w-4" />
            </Button>
          </form>

          <div className="mt-8 rounded-lg border bg-secondary/40 p-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Acesso de demonstração</p>
            <div className="flex flex-col gap-1.5 text-sm">
              <button type="button" onClick={() => fillDemo("admin.estrela")} className="flex items-center justify-between rounded-md px-2 py-1.5 text-left hover:bg-secondary">
                <span>Administrador — Malharia Estrela</span>
                <code className="font-mono text-xs text-muted-foreground">admin.estrela</code>
              </button>
              <button type="button" onClick={() => fillDemo("producao.estrela")} className="flex items-center justify-between rounded-md px-2 py-1.5 text-left hover:bg-secondary">
                <span>Funcionário (produção/estoque)</span>
                <code className="font-mono text-xs text-muted-foreground">producao.estrela</code>
              </button>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Senha para ambos: <code className="font-mono">123456</code></p>
          </div>
        </div>
      </div>
    </div>
  );
}
