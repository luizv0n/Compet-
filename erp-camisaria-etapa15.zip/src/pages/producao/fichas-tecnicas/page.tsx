"use client";
import * as React from "react";
import { Plus, Pencil, FileSpreadsheet } from "lucide-react";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { ActiveBadge } from "@/components/common/StatusBadge";
import { Qty } from "@/components/common/Money";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "@/context/ToastContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import type { Produto, ProdutoVariacao, Setor, ProdutoComponente, UnidadeMedida } from "@/types";

export default function FichasTecnicasPage() {
  const { empresa, actor, hasPermission } = useAuth();
  const { toast } = useToast();
  const canManage = hasPermission(PERMISSIONS.BOM_MANAGE);

  const [loading, setLoading] = React.useState(true);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [unidades, setUnidades] = React.useState<UnidadeMedida[]>([]);

  const [produtoPaiVariacaoId, setProdutoPaiVariacaoId] = React.useState("");
  const [componentes, setComponentes] = React.useState<ProdutoComponente[]>([]);
  const [componentesLoading, setComponentesLoading] = React.useState(false);

  const [dialogOpen, setDialogOpen] = React.useState(false);
  const [editing, setEditing] = React.useState<ProdutoComponente | null>(null);
  const [produtoFilhoId, setProdutoFilhoId] = React.useState("");
  const [setorId, setSetorId] = React.useState("");
  const [quantidade, setQuantidade] = React.useState("");
  const [observacao, setObservacao] = React.useState("");
  const [submitting, setSubmitting] = React.useState(false);

  function openCreate() {
    setEditing(null);
    setProdutoFilhoId("");
    setSetorId("");
    setQuantidade("");
    setObservacao("");
    setDialogOpen(true);
  }

  function openEdit(item: ProdutoComponente) {
    setEditing(item);
    setProdutoFilhoId(String(item.produtoFilhoId));
    setSetorId(item.setorId ? String(item.setorId) : "");
    setQuantidade(String(item.quantidade).replace(".", ","));
    setObservacao(item.observacao ?? "");
    setDialogOpen(true);
  }

  const reload = React.useCallback(async () => {
    if (!empresa) return;
    setLoading(true);
    const [p, v, s, u] = await Promise.all([
      apiClient.produtos.list(empresa.id),
      apiClient.variacoes.list(empresa.id),
      apiClient.setores.list(empresa.id),
      apiClient.unidades.list(),
    ]);
    setProdutos(p);
    setVariacoes(v);
    setSetores(s);
    setUnidades(u);
    setLoading(false);
  }, [empresa]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  const reloadComponentes = React.useCallback(async () => {
    if (!empresa || !produtoPaiVariacaoId) {
      setComponentes([]);
      return;
    }
    setComponentesLoading(true);
    setComponentes(await apiClient.componentes.list(Number(produtoPaiVariacaoId), empresa.id));
    setComponentesLoading(false);
  }, [empresa, produtoPaiVariacaoId]);

  React.useEffect(() => {
    reloadComponentes();
  }, [reloadComponentes]);

  // Variações candidatas a "pai": tipicamente PC ou SC (produtos com transformação)
  const variacoesPai = variacoes.filter((v) => {
    const produto = produtos.find((p) => p.id === v.produtoId);
    return produto && (produto.tipo === "PC" || produto.tipo === "SC");
  });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!empresa || !actor || !produtoPaiVariacaoId || !produtoFilhoId || !quantidade) {
      toast({ title: "Preencha o componente e a quantidade.", variant: "error" });
      return;
    }
    const quantidadeNum = Number(quantidade.replace(",", "."));
    if (!Number.isFinite(quantidadeNum) || quantidadeNum <= 0) {
      toast({ title: "A quantidade deve ser maior que zero.", variant: "error" });
      return;
    }
    setSubmitting(true);
    try {
      if (editing) {
        await apiClient.componentes.update(editing.id, empresa.id, actor, {
          setorId: setorId ? Number(setorId) : null,
          quantidade: quantidadeNum,
          observacao: observacao.trim() || null,
        });
        toast({ title: "Ficha técnica atualizada", variant: "success" });
      } else {
        await apiClient.componentes.add(empresa.id, actor, {
          produtoPaiId: Number(produtoPaiVariacaoId),
          produtoFilhoId: Number(produtoFilhoId),
          setorId: setorId ? Number(setorId) : null,
          quantidade: quantidadeNum,
          observacao: observacao.trim() || null,
        });
        toast({ title: "Componente adicionado à ficha técnica", variant: "success" });
      }
      setDialogOpen(false);
      setEditing(null);
      setProdutoFilhoId("");
      setSetorId("");
      setQuantidade("");
      setObservacao("");
      reloadComponentes();
    } catch (err) {
      toast({ title: "Não foi possível salvar", description: err instanceof Error ? err.message : undefined, variant: "error" });
    } finally {
      setSubmitting(false);
    }
  }

  async function handleToggle(item: ProdutoComponente) {
    if (!empresa) return;
    await apiClient.componentes.toggle(item.id, empresa.id);
    toast({ title: item.ativo ? "Componente inativado" : "Componente ativado", variant: "success" });
    reloadComponentes();
  }

  if (!empresa) return null;

  const paiSelecionado = variacoes.find((v) => v.id === Number(produtoPaiVariacaoId));
  const produtoPai = paiSelecionado ? produtos.find((p) => p.id === paiSelecionado.produtoId) : undefined;

  return (
    <RequirePermission perm={PERMISSIONS.BOM_MANAGE}>
      <PageHeader title="Ficha técnica" description="Componentes consumidos por cada SKU de produto de confecção ou semiacabado." />

      {loading ? (
        <LoadingState />
      ) : (
        <>
          <div className="mb-4 max-w-lg">
            <Label className="mb-1.5 block">Selecione o SKU (produto pai)</Label>
            <Select value={produtoPaiVariacaoId} onValueChange={setProdutoPaiVariacaoId}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um produto de confecção ou semiacabado" />
              </SelectTrigger>
              <SelectContent>
                {variacoesPai.map((v) => {
                  const produto = produtos.find((p) => p.id === v.produtoId);
                  return (
                    <SelectItem key={v.id} value={String(v.id)}>
                      {produto?.nome} — {v.sku}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>

          {!produtoPaiVariacaoId ? (
            <EmptyState icon={FileSpreadsheet} title="Selecione um SKU para ver ou editar sua ficha técnica" />
          ) : componentesLoading ? (
            <LoadingState />
          ) : (
            <div className="rounded-lg border">
              <div className="flex items-center justify-between border-b px-4 py-3">
                <p className="text-sm font-medium text-foreground">
                  {produtoPai?.nome} — {paiSelecionado?.sku}
                </p>
                {canManage && (
                  <Button size="sm" onClick={openCreate}>
                    <Plus className="h-4 w-4" /> Adicionar componente
                  </Button>
                )}
              </div>
              {componentes.length === 0 ? (
                <div className="p-5">
                  <EmptyState title="Nenhum componente cadastrado para este SKU" />
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Componente</TableHead>
                      <TableHead>Setor de consumo</TableHead>
                      <TableHead className="text-right">Quantidade</TableHead>
                      <TableHead>Observação</TableHead>
                      <TableHead>Status</TableHead>
                      {canManage && <TableHead className="text-right">Ações</TableHead>}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {componentes.map((c) => {
                      const filhoVariacao = variacoes.find((v) => v.id === c.produtoFilhoId);
                      const filhoProduto = filhoVariacao ? produtos.find((p) => p.id === filhoVariacao.produtoId) : undefined;
                      const unidade = unidades.find((u) => u.id === filhoProduto?.unidadeMedidaId);
                      const setor = setores.find((s) => s.id === c.setorId);
                      return (
                        <TableRow key={c.id}>
                          <TableCell className="font-medium text-foreground">
                            {filhoProduto?.nome} <span className="text-muted-foreground">({filhoVariacao?.sku})</span>
                          </TableCell>
                          <TableCell className="text-muted-foreground">{setor?.nome ?? "—"}</TableCell>
                          <TableCell className="text-right tabular-nums">
                            <Qty value={c.quantidade} unit={unidade?.sigla} />
                          </TableCell>
                          <TableCell className="text-xs text-muted-foreground">{c.observacao ?? "—"}</TableCell>
                          <TableCell>
                            <ActiveBadge ativo={c.ativo} />
                          </TableCell>
                          {canManage && (
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-3">
                                <button onClick={() => openEdit(c)} className="text-muted-foreground hover:text-foreground" aria-label="Editar componente">
                                  <Pencil className="h-3.5 w-3.5" />
                                </button>
                                <Switch checked={c.ativo} onCheckedChange={() => handleToggle(c)} />
                              </div>
                            </TableCell>
                          )}
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </div>
          )}
        </>
      )}

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) setEditing(null);
        }}
      >
        <DialogContent size="sm">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar componente" : "Adicionar componente"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <Label>Componente (matéria-prima / aviamento / semiacabado)</Label>
              <Select value={produtoFilhoId} onValueChange={setProdutoFilhoId} disabled={!!editing}>
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  {variacoes
                    .filter((v) => v.id !== Number(produtoPaiVariacaoId))
                    .map((v) => {
                      const produto = produtos.find((p) => p.id === v.produtoId);
                      return (
                        <SelectItem key={v.id} value={String(v.id)}>
                          {produto?.nome} — {v.sku}
                        </SelectItem>
                      );
                    })}
                </SelectContent>
              </Select>
              {editing && <p className="text-xs text-muted-foreground">Para trocar o componente, inative este e adicione um novo.</p>}
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Setor de consumo (opcional)</Label>
              <Select value={setorId} onValueChange={setSetorId}>
                <SelectTrigger>
                  <SelectValue placeholder="Nenhum" />
                </SelectTrigger>
                <SelectContent>
                  {setores.map((s) => (
                    <SelectItem key={s.id} value={String(s.id)}>
                      {s.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Quantidade (por unidade produzida)</Label>
              <Input value={quantidade} onChange={(e) => setQuantidade(e.target.value)} placeholder="Ex.: 0,85" />
            </div>
            <div className="flex flex-col gap-1.5">
              <Label>Observação (opcional)</Label>
              <Textarea value={observacao} onChange={(e) => setObservacao(e.target.value)} rows={2} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" loading={submitting}>
                Salvar
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </RequirePermission>
  );
}
