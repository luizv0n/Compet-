"use client";
import * as React from "react";
import { AlertTriangle } from "lucide-react";
import { Link } from "@/lib/next-compat";
import { PageHeader } from "@/components/common/PageHeader";
import { RequirePermission } from "@/components/common/RequirePermission";
import { SearchInput } from "@/components/common/SearchInput";
import { EmptyState } from "@/components/common/EmptyState";
import { LoadingState } from "@/components/common/LoadingState";
import { Qty } from "@/components/common/Money";
import { ShowMoreButton } from "@/components/common/ShowMoreButton";
import { useProgressiveList } from "@/hooks/useProgressiveList";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table";
import { useAuth } from "@/context/AuthContext";
import { apiClient } from "@/services/apiClient";
import { PERMISSIONS } from "@/constants/permissions";
import { formatDateTime } from "@/lib/utils";
import type { OrdemProducao, MovimentacaoProducao, Produto, ProdutoVariacao, Setor, MotivoPerda, Usuario } from "@/types";

export default function RefugosPage() {
  const { empresa } = useAuth();
  const [loading, setLoading] = React.useState(true);
  const [movimentacoes, setMovimentacoes] = React.useState<MovimentacaoProducao[]>([]);
  const [ops, setOps] = React.useState<OrdemProducao[]>([]);
  const [produtos, setProdutos] = React.useState<Produto[]>([]);
  const [variacoes, setVariacoes] = React.useState<ProdutoVariacao[]>([]);
  const [setores, setSetores] = React.useState<Setor[]>([]);
  const [motivos, setMotivos] = React.useState<MotivoPerda[]>([]);
  const [usuarios, setUsuarios] = React.useState<Usuario[]>([]);

  const [query, setQuery] = React.useState("");
  const [motivoFiltro, setMotivoFiltro] = React.useState("TODOS");

  React.useEffect(() => {
    if (!empresa) return;
    (async () => {
      setLoading(true);
      const [ops, produtos, variacoes, setores, motivos, usuarios] = await Promise.all([
        apiClient.producao.list(empresa.id),
        apiClient.produtos.list(empresa.id),
        apiClient.variacoes.list(empresa.id),
        apiClient.setores.list(empresa.id, true),
        apiClient.motivosPerda.list(empresa.id, true),
        apiClient.equipe.list(empresa.id, true),
      ]);
      const movs: MovimentacaoProducao[] = [];
      for (const op of ops) {
        const opMovs = await apiClient.producao.movimentacoes(op.id, empresa.id);
        movs.push(...opMovs.filter((m) => m.quantidadePerdida > 0));
      }
      movs.sort((a, b) => (a.dataMovimentacao < b.dataMovimentacao ? 1 : -1));
      setOps(ops);
      setProdutos(produtos);
      setVariacoes(variacoes);
      setSetores(setores);
      setMotivos(motivos);
      setUsuarios(usuarios);
      setMovimentacoes(movs);
      setLoading(false);
    })();
  }, [empresa]);


  const filtered = movimentacoes.filter((m) => {
    if (motivoFiltro !== "TODOS" && m.motivoPerdaId !== Number(motivoFiltro)) return false;
    if (query) {
      const op = ops.find((o) => o.id === m.ordemProducaoId);
      const variacao = op ? variacoes.find((v) => v.id === op.produtoVariacaoId) : undefined;
      const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
      if (!`${op?.codigo ?? ""} ${produto?.nome ?? ""} ${variacao?.sku ?? ""}`.toLowerCase().includes(query.toLowerCase())) return false;
    }
    return true;
  });
  const { visible, hasMore, showMore, remaining } = useProgressiveList(filtered, [query, motivoFiltro]);

  if (!empresa) return null;
  if (loading) return <LoadingState />;
  const totalPerdido = filtered.reduce((sum, m) => sum + m.quantidadePerdida, 0);

  return (
    <RequirePermission perm={PERMISSIONS.DEFECTS_VIEW}>
      <PageHeader title="Defeitos e refugos" description="Peças perdidas durante a produção, por ordem, setor e motivo." />

      <Card className="mb-4 max-w-xs">
        <CardContent className="p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Total refugado (filtro atual)</p>
          <p className="mt-1 text-2xl font-semibold tabular-nums text-destructive">
            <Qty value={totalPerdido} decimals={0} />
          </p>
        </CardContent>
      </Card>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <SearchInput value={query} onChange={setQuery} placeholder="Buscar por OP, produto ou SKU…" />
        <Select value={motivoFiltro} onValueChange={setMotivoFiltro}>
          <SelectTrigger className="w-full sm:w-56">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TODOS">Todos os motivos</SelectItem>
            {motivos.map((m) => (
              <SelectItem key={m.id} value={String(m.id)}>
                {m.nome}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon={AlertTriangle} title="Nenhum refugo registrado" />
      ) : (
        <>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Data</TableHead>
                  <TableHead>OP</TableHead>
                  <TableHead>Produto</TableHead>
                  <TableHead>Setor</TableHead>
                  <TableHead className="text-right">Quantidade</TableHead>
                  <TableHead>Motivo</TableHead>
                  <TableHead>Usuário</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visible.map((m) => {
                  const op = ops.find((o) => o.id === m.ordemProducaoId);
                  const variacao = op ? variacoes.find((v) => v.id === op.produtoVariacaoId) : undefined;
                  const produto = variacao ? produtos.find((p) => p.id === variacao.produtoId) : undefined;
                  const setor = setores.find((s) => s.id === m.setorOrigemId);
                  const motivo = motivos.find((mo) => mo.id === m.motivoPerdaId);
                  const usuario = usuarios.find((u) => u.id === m.usuarioId);
                  return (
                    <TableRow key={m.id}>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">{formatDateTime(m.dataMovimentacao)}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {op ? (
                          <Link href={`/producao/${op.id}`} className="text-accent hover:underline">
                            {op.codigo}
                          </Link>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                      <TableCell>
                        {produto?.nome} <span className="text-muted-foreground">({variacao?.sku})</span>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{setor?.nome ?? "—"}</TableCell>
                      <TableCell className="text-right font-medium tabular-nums text-destructive">
                        <Qty value={m.quantidadePerdida} />
                      </TableCell>
                      <TableCell className="text-muted-foreground">{motivo?.nome ?? "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">{usuario?.nome ?? "—"}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
          {hasMore && <ShowMoreButton remaining={remaining} onClick={showMore} />}
        </>
      )}
    </RequirePermission>
  );
}
