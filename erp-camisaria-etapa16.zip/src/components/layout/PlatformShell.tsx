"use client";
// =====================================================================
// PlatformShell.tsx — guarda de rota + chrome para as telas do ADM DO
// SITE (seção 12 do prompt mestre: portal separado do /login de
// empresa). Mesmo papel que AppShell.tsx cumpre para o portal de
// empresa: redireciona para /site/login se não houver sessão de
// plataforma.
//
// Etapa 6 (Painel Global — seções 14/16/19/20): evolui o shell mínimo
// da Etapa 5 para incluir a navegação entre as telas de plataforma
// (Dashboard / Empresas / Auditoria Global / Nova Empresa) e o
// indicador + seletor de "Contexto da Empresa" da seção 16 ("Modo:
// Administração da Plataforma" + "Empresa atual: X ▾"). Ainda não é
// uma sidebar nos moldes do AppShell de empresa — só 4 destinos, então
// uma barra de navegação horizontal é suficiente e evita duplicar o
// Design System (seção 42: mesmo Design System, navegação diferente).
//
// O que o seletor de contexto FAZ nesta etapa: guarda qual empresa o
// ADM DO SITE está "olhando" (persistido via setEmpresaContexto, já
// existente desde a Etapa 3) e mostra isso com destaque visual, para
// nunca ficar ambíguo em qual empresa uma ação futura seria aplicada.
// O que ele NÃO faz ainda: abrir os módulos operacionais (produção,
// estoque, compras...) daquela empresa dentro do painel de plataforma
// — isso exigiria ponte com AuthContext/AppShell (que modelam sessão
// em cima de Usuario, sempre vinculado a uma empresa) e fica
// documentado como pendência explícita da Etapa 7+ no prompt de
// continuação, em vez de implementado pela metade aqui.
// =====================================================================
import * as React from "react";
import { LogOut, ShieldCheck, LayoutDashboard, Building2, History, PlusCircle, X, Sun, Moon } from "lucide-react";
import { useRouter, usePathname, Link } from "@/lib/next-compat";
import { usePlatformAuth } from "@/context/PlatformAuthContext";
import { useTheme } from "@/context/ThemeContext";
import { apiClient } from "@/services/apiClient";
import { LoadingState } from "@/components/common/LoadingState";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { Empresa } from "@/types";

const NAV_ITEMS = [
  { href: "/site", label: "Dashboard", icon: LayoutDashboard },
  { href: "/site/empresas", label: "Empresas", icon: Building2 },
  { href: "/site/auditoria", label: "Auditoria Global", icon: History },
];

export function PlatformShell({ children }: { children: React.ReactNode }) {
  const { loading, admin, logout, empresaContextoId, setEmpresaContexto } = usePlatformAuth();
  const { theme, toggleTheme } = useTheme();
  const router = useRouter();
  const pathname = usePathname();
  const [empresas, setEmpresas] = React.useState<Empresa[]>([]);

  React.useEffect(() => {
    if (!loading && !admin) {
      router.replace("/site/login");
    }
  }, [loading, admin, router]);

  React.useEffect(() => {
    if (!admin) return;
    apiClient.plataforma.listEmpresas(false).then(setEmpresas);
  }, [admin]);

  if (loading) {
    return (
      <div className="flex h-dvh items-center justify-center bg-background">
        <LoadingState label="Carregando sessão da plataforma…" />
      </div>
    );
  }

  if (!admin) return null;

  const empresaAtual = empresas.find((e) => e.id === empresaContextoId) ?? null;

  return (
    <div className="flex min-h-dvh flex-col bg-background">
      <header className="flex items-center justify-between border-b border-border bg-foreground px-4 py-3 text-background sm:px-6">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/20">
            <ShieldCheck className="h-4.5 w-4.5 text-accent" />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-semibold">Camisaria ERP</p>
            <p className="text-[11px] uppercase tracking-[0.16em] text-background/60">
              Modo: Administração da Plataforma
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="hidden text-sm text-background/80 sm:inline">{admin.nome}</span>
          <button
            onClick={toggleTheme}
            title={theme === "dark" ? "Mudar para tema claro" : "Mudar para tema escuro"}
            className="flex h-8 w-8 items-center justify-center rounded-md text-background/80 hover:bg-background/10 hover:text-background"
          >
            {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </button>
          <Button
            variant="ghost"
            size="sm"
            className="text-background hover:bg-background/10 hover:text-background"
            onClick={logout}
          >
            <LogOut className="h-4 w-4" />
            Sair
          </Button>
        </div>
      </header>

      <div className="flex flex-col gap-3 border-b border-border bg-secondary/40 px-4 py-2.5 sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <nav className="flex items-center gap-1 overflow-x-auto">
          {NAV_ITEMS.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                  active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                )}
              >
                <item.icon className="h-3.5 w-3.5" />
                {item.label}
              </Link>
            );
          })}
          <Link
            href="/site/nova-empresa"
            className={cn(
              "flex shrink-0 items-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
              pathname === "/site/nova-empresa"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:bg-secondary hover:text-foreground",
            )}
          >
            <PlusCircle className="h-3.5 w-3.5" />
            Nova Empresa
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <span className="hidden text-xs font-medium uppercase tracking-wide text-muted-foreground sm:inline">
            Empresa atual
          </span>
          <Select
            value={empresaContextoId ? String(empresaContextoId) : "GLOBAL"}
            onValueChange={(v) => setEmpresaContexto(v === "GLOBAL" ? null : Number(v))}
          >
            <SelectTrigger className="w-56">
              <SelectValue placeholder="Visão global" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="GLOBAL">Nenhuma (visão global)</SelectItem>
              {empresas.map((e) => (
                <SelectItem key={e.id} value={String(e.id)}>
                  {e.nomeFantasia}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {empresaAtual && (
        <div className="flex items-center justify-between gap-3 border-b border-accent/30 bg-accent/10 px-4 py-2 text-sm text-foreground sm:px-6">
          <p>
            Visitando o contexto de <span className="font-semibold">{empresaAtual.nomeFantasia}</span>. A navegação
            completa dentro dos módulos desta empresa chega em uma etapa futura — por enquanto isto só marca o
            contexto para as próximas ações de plataforma.
          </p>
          <button
            onClick={() => setEmpresaContexto(null)}
            className="flex shrink-0 items-center gap-1 text-xs font-medium text-muted-foreground hover:text-foreground"
          >
            <X className="h-3.5 w-3.5" />
            Sair do contexto
          </button>
        </div>
      )}

      <main className="flex-1 overflow-y-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-6xl">{children}</div>
      </main>
    </div>
  );
}
