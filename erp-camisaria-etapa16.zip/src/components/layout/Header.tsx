"use client";
import * as React from "react";
import { Menu, ChevronDown, LogOut, User as UserIcon, Repeat, Sun, Moon } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { useTheme } from "@/context/ThemeContext";
import { apiClient } from "@/services/apiClient";
import type { Usuario, Cargo } from "@/types";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Header({ onOpenMobile }: { onOpenMobile: () => void }) {
  const { usuario, empresa, cargoNome, logout, switchUser } = useAuth();
  const { theme, toggleTheme } = useTheme();

  const [equipe, setEquipe] = React.useState<Usuario[]>([]);
  const [cargos, setCargos] = React.useState<Cargo[]>([]);

  React.useEffect(() => {
    if (!empresa) return;
    (async () => {
      const [u, c] = await Promise.all([apiClient.equipe.list(empresa.id), apiClient.equipe.cargos(empresa.id)]);
      setEquipe(u);
      setCargos(c);
    })();
  }, [empresa, usuario?.id]);

  const initials = (usuario?.nome ?? "?")
    .split(" ")
    .slice(0, 2)
    .map((p) => p[0])
    .join("")
    .toUpperCase();

  // Outros usuários ativos da mesma empresa — atalho para alternar perfil (Admin/Funcionário) durante testes.
  const outrosUsuarios = equipe.filter((u) => u.id !== usuario?.id);

  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b bg-card px-4 sm:px-6">
      <div className="flex items-center gap-3">
        <button onClick={onOpenMobile} className="text-muted-foreground hover:text-foreground lg:hidden">
          <Menu className="h-5 w-5" />
        </button>
        <div className="hidden sm:block">
          <p className="text-xs text-muted-foreground">{empresa?.nomeFantasia}</p>
        </div>
      </div>

      <div className="flex items-center gap-1">
        <button
          onClick={toggleTheme}
          title={theme === "dark" ? "Mudar para tema claro" : "Mudar para tema escuro"}
          className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-secondary hover:text-foreground"
        >
          {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <DropdownMenu>
          <DropdownMenuTrigger className="flex items-center gap-2 rounded-md px-2 py-1.5 outline-none hover:bg-secondary">
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
            {initials}
          </div>
          <div className="hidden text-left sm:block">
            <p className="text-sm font-medium leading-tight text-foreground">{usuario?.nome}</p>
            <p className="text-[11px] leading-tight text-muted-foreground">{cargoNome}</p>
          </div>
          <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-64">
          <DropdownMenuLabel>
            <p className="font-medium">{usuario?.nome}</p>
            <p className="text-xs font-normal text-muted-foreground">{usuario?.email}</p>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem disabled>
            <UserIcon className="h-4 w-4" /> {cargoNome}
          </DropdownMenuItem>

          {outrosUsuarios.length > 0 && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-[11px] font-normal uppercase tracking-wide text-muted-foreground">
                Alternar perfil (teste)
              </DropdownMenuLabel>
              {outrosUsuarios.map((u) => {
                const cargo = cargos.find((c) => c.id === u.cargoId);
                return (
                  <DropdownMenuItem key={u.id} onClick={() => switchUser(u.id)}>
                    <Repeat className="h-4 w-4" />
                    <span className="flex-1 truncate">{u.nome}</span>
                    <span className="text-[11px] text-muted-foreground">{cargo?.nome}</span>
                  </DropdownMenuItem>
                );
              })}
            </>
          )}

          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={logout} className="text-destructive focus:text-destructive">
            <LogOut className="h-4 w-4" /> Sair
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      </div>
    </header>
  );
}
