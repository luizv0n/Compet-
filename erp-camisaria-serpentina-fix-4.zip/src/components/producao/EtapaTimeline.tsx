"use client";
import * as React from "react";
import { Check, CircleDashed, SkipForward } from "lucide-react";
import { cn } from "@/lib/utils";
import { Qty } from "@/components/common/Money";
import type { OrdemProducaoEtapa, OrdemProducaoEtapaStatus, Setor } from "@/types";

interface EtapaTimelineProps {
  etapas: OrdemProducaoEtapa[];
  setores: Setor[];
  etapaAtualId?: number | null;
}

const NODE_STYLE: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "border-success bg-success text-success-foreground",
  EM_EXECUCAO: "border-accent bg-accent text-accent-foreground ring-4 ring-accent/20",
  AGUARDANDO: "border-border bg-card text-muted-foreground",
  PULADA: "border-warning bg-warning text-warning-foreground",
};

/** Cor de fundo dos conectores (linhas horizontais entre etapas e linha vertical de quebra). */
const CONNECTOR_BG: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "bg-success",
  EM_EXECUCAO: "bg-accent",
  AGUARDANDO: "bg-border",
  PULADA: "bg-warning",
};

// Largura "confortável" de um card (igual ao antigo w-44 = 176px). É o alvo
// que o layout tenta manter sempre que há espaço suficiente no container.
const PREFERRED_CARD_WIDTH = 176;
// Largura mínima aceitável para um card continuar legível. Nunca desenhamos
// cards menores que isso — se não couberem, sobram para a linha seguinte.
const MIN_CARD_WIDTH = 112;
// Largura mínima/máxima do trecho de conector horizontal entre dois cards da
// mesma linha. O espaço restante da linha (depois de acomodar os cards) é
// distribuído entre os conectores via flexbox, então isso é só um limite.
const CONNECTOR_MIN_WIDTH = 16;
const CONNECTOR_MAX_WIDTH = 56;

interface RowLayout {
  itemsPerRow: number;
  cardWidth: number;
}

/**
 * Calcula, a partir da largura real disponível, quantas etapas cabem por
 * linha e qual a largura de cada card, sem nunca ultrapassar o espaço
 * disponível (regra de "zero overflow"). Não depende de window.innerWidth —
 * o chamador mede o container com ResizeObserver e passa o valor aqui.
 */
function computeRowLayout(containerWidth: number, totalItems: number): RowLayout {
  if (!(containerWidth > 0) || totalItems <= 0) {
    return { itemsPerRow: 1, cardWidth: PREFERRED_CARD_WIDTH };
  }

  const fitsAtWidth = (cardWidth: number, count: number) => cardWidth * count + CONNECTOR_MIN_WIDTH * (count - 1) <= containerWidth;

  // Quantas colunas cabem mantendo a largura "confortável" do card.
  let itemsPerRow = 1;
  for (let candidate = Math.min(totalItems, Math.floor(containerWidth / MIN_CARD_WIDTH) || 1); candidate >= 1; candidate--) {
    if (fitsAtWidth(PREFERRED_CARD_WIDTH, candidate)) {
      itemsPerRow = candidate;
      break;
    }
  }
  itemsPerRow = Math.max(1, Math.min(itemsPerRow, totalItems));

  // Largura real do card nessa configuração: tenta manter a preferida, mas
  // encolhe até o mínimo se o container for mais apertado que o esperado
  // (ex.: 1 card por linha em um painel muito estreito).
  const available = containerWidth - CONNECTOR_MIN_WIDTH * (itemsPerRow - 1);
  const cardWidth = Math.max(MIN_CARD_WIDTH, Math.min(PREFERRED_CARD_WIDTH, Math.floor(available / itemsPerRow)));

  return { itemsPerRow, cardWidth };
}

/** Observa a largura real de um elemento (não a da janela). */
function useContainerWidth<T extends HTMLElement>() {
  const ref = React.useRef<T | null>(null);
  const [width, setWidth] = React.useState(0);

  React.useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;

    setWidth(el.clientWidth);

    if (typeof ResizeObserver === "undefined") {
      const onResize = () => setWidth(el.clientWidth);
      window.addEventListener("resize", onResize);
      return () => window.removeEventListener("resize", onResize);
    }

    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) setWidth(entry.contentRect.width);
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return { ref, width };
}

/**
 * Timeline das etapas de uma OP em formato serpentina/zigue-zague.
 *
 * A quantidade de cards por linha e a largura de cada card são calculadas a
 * partir da largura real do container (via ResizeObserver), nunca fixas —
 * o layout se adapta a qualquer quantidade de etapas e a qualquer largura
 * disponível, sem gerar rolagem horizontal.
 *
 * As etapas continuam na ordem original do fluxo (sequencia); a cada linha o
 * caminho desce e a linha seguinte percorre no sentido oposto (zigue-zague).
 * Os conectores horizontais nascem da borda de um card e terminam na borda
 * do próximo (via flexbox, sem coordenadas fixas), e o conector vertical de
 * quebra de linha sai exatamente da coluna onde a linha anterior termina.
 * Não há setas: a continuidade é comunicada só pelas linhas.
 *
 * Cards, cores, ícones de status e indicadores de quantidade permanecem
 * exatamente os mesmos; apenas a estrutura externa do layout foi refeita.
 */
export function EtapaTimeline({ etapas, setores, etapaAtualId }: EtapaTimelineProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);
  const { ref: containerRef, width: containerWidth } = useContainerWidth<HTMLDivElement>();

  const { itemsPerRow, cardWidth } = React.useMemo(
    () => computeRowLayout(containerWidth, ordered.length),
    [containerWidth, ordered.length],
  );

  const rows: OrdemProducaoEtapa[][] = React.useMemo(() => {
    const result: OrdemProducaoEtapa[][] = [];
    for (let i = 0; i < ordered.length; i += itemsPerRow) {
      result.push(ordered.slice(i, i + itemsPerRow));
    }
    return result;
  }, [ordered, itemsPerRow]);

  // Enquanto a largura real ainda não foi medida (primeiro paint), não
  // desenhamos a serpentina para evitar um flash com o layout errado.
  const ready = containerWidth > 0;

  return (
    <div ref={containerRef} className="w-full overflow-hidden px-1 py-2">
      {ready && (
        <div className="flex flex-col">
          {rows.map((row, rowIdx) => {
            const reversed = rowIdx % 2 === 1;
            const nextRowFirst = rows[rowIdx + 1]?.[0];

            return (
              <div key={rowIdx} className="flex flex-col">
                <ol className={cn("flex items-stretch justify-center", reversed && "flex-row-reverse")}>
                  {row.map((etapa, idx) => {
                    const setor = setores.find((s) => s.id === etapa.setorId);
                    const isCurrent = etapaAtualId === etapa.id;
                    const isLastInRow = idx === row.length - 1;
                    const proximaNaLinha = row[idx + 1];

                    return (
                      <li key={etapa.id} className="flex items-stretch">
                        <div className="flex shrink-0 flex-col items-center text-center" style={{ width: cardWidth }}>
                          <div
                            className={cn(
                              "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold transition-colors",
                              NODE_STYLE[etapa.status],
                            )}
                          >
                            {etapa.status === "CONCLUIDA" ? (
                              <Check className="h-4 w-4" />
                            ) : etapa.status === "PULADA" ? (
                              <SkipForward className="h-3.5 w-3.5" />
                            ) : etapa.status === "AGUARDANDO" ? (
                              <CircleDashed className="h-4 w-4" />
                            ) : (
                              etapa.sequencia
                            )}
                          </div>

                          <div
                            className={cn(
                              "mt-2 flex w-full flex-col gap-1.5 rounded-md border px-2.5 py-2",
                              isCurrent ? "border-accent/40 bg-accent/5" : "border-transparent",
                            )}
                          >
                            <p className={cn("truncate text-xs font-medium", isCurrent ? "text-accent" : "text-foreground")} title={setor?.nome}>
                              {setor?.nome ?? "Setor"}
                            </p>
                            <div className="flex items-center justify-center gap-2 text-[11px] tabular-nums text-muted-foreground">
                              <span title="Recebida">
                                <Qty value={etapa.quantidadeRecebida} decimals={0} />
                              </span>
                              <span className="text-success" title="Concluída">
                                →<Qty value={etapa.quantidadeConcluida} decimals={0} />
                              </span>
                              {etapa.quantidadePerdida > 0 && (
                                <span className="text-destructive" title="Perdida">
                                  −<Qty value={etapa.quantidadePerdida} decimals={0} />
                                </span>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Trecho de conector horizontal até o próximo card da mesma
                           linha. A largura é flexível (flex-1, com limites min/max)
                           para que ela nasça exatamente na borda de um card e termine
                           exatamente na borda do próximo, seja qual for a largura real
                           do card — sem coordenadas fixas. Sem seta: a cor reflete o
                           status da etapa de destino do trecho. */}
                        {!isLastInRow && (
                          <div
                            className="flex shrink items-center justify-center"
                            style={{ flex: "1 1 auto", minWidth: CONNECTOR_MIN_WIDTH, maxWidth: CONNECTOR_MAX_WIDTH }}
                          >
                            <div className={cn("h-0.5 w-full rounded-full", CONNECTOR_BG[proximaNaLinha?.status ?? "AGUARDANDO"])} />
                          </div>
                        )}
                      </li>
                    );
                  })}
                </ol>

                {/* Conector de quebra de linha (serpentina): uma linha vertical, sem
                   seta, alinhada exatamente sob a coluna onde a linha atual termina —
                   à direita quando a linha vai da esquerda para a direita, à esquerda
                   quando vai da direita para a esquerda — e a próxima linha recomeça
                   sob ela, alinhada ao centro do card daquela coluna. A largura da
                   coluna usada aqui é a mesma (cardWidth) calculada para os cards,
                   então o alinhamento se mantém em qualquer tamanho de tela. */}
                {nextRowFirst && (
                  <div className={cn("flex", reversed ? "justify-start" : "justify-end")}>
                    <div className="flex shrink-0 flex-col items-center py-0.5" style={{ width: cardWidth }}>
                      <div className={cn("h-4 w-0.5 rounded-full", CONNECTOR_BG[nextRowFirst.status])} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
