"use client";
import * as React from "react";
import type { FluxoProducaoEtapa, Setor } from "@/types";

interface FluxoEtapasSerpentinaProps {
  etapas: FluxoProducaoEtapa[];
  setores: Setor[];
}

// Nenhuma largura de bloco é assumida antecipadamente: o número de colunas
// da trilha é recalculado a partir da largura real do container e da
// largura real do maior bloco (medida em DOM, com o mesmo conteúdo e
// tipografia do bloco visível). MAX_PER_ROW é apenas o teto do padrão
// visual (5 por linha); nunca é usado para posicionar conectores, que são
// sempre calculados a partir da posição real de cada bloco após o layout.
const MAX_PER_ROW = 5;
const MIN_PER_ROW = 1;
const COLUMN_GAP_PX = 24;
const ROW_GAP_PX = 40;

interface ConnectorPath {
  id: string;
  d: string;
}

/**
 * Etapas de um fluxo de produção apresentadas como uma trilha contínua em
 * zigue-zague/serpentina.
 *
 * ARQUITETURA
 * -----------
 * Diferente de uma implementação baseada em `flex` (onde cada linha decide
 * seu próprio espaçamento — o que produz gaps diferentes entre uma linha
 * cheia e a última linha parcial), aqui todas as linhas compartilham a
 * MESMA grade de colunas (`grid-template-columns` fixo, com `itemsPerRow`
 * colunas). Cada bloco recebe uma coluna explícita, calculada por uma
 * única fórmula:
 *
 *   coluna(k) = invertida ? (itemsPerRow - 1 - k) : k
 *
 * onde `k` é a posição do bloco dentro da própria linha (0-based) e
 * `invertida` alterna a cada linha (0 = esquerda→direita, 1 =
 * direita→esquerda, ...). Isso garante, sem nenhuma coordenada fixa e sem
 * `flex-row-reverse`:
 *
 *   - espaçamento idêntico em todas as linhas (mesmas trilhas da grade);
 *   - alinhamento correto mesmo na última linha, quando ela é parcial
 *     (os blocos ficam nas mesmas colunas que ocupariam se a linha
 *     estivesse cheia — nunca centralizados);
 *   - continuidade geométrica entre linhas: o último bloco de uma linha e
 *     o primeiro bloco da linha seguinte SEMPRE caem na mesma coluna
 *     (prova: se a linha N é direta, seu último bloco cai na coluna
 *     itemsPerRow-1; a linha N+1 é necessariamente invertida, e seu
 *     primeiro bloco [k=0] cai em itemsPerRow-1-0 = itemsPerRow-1 — a
 *     mesma coluna. O raciocínio simétrico vale quando a linha N é
 *     invertida). Por isso o conector vertical entre linhas é sempre uma
 *     linha reta, nunca um "salto" horizontal solto.
 *
 * Os conectores em si (traço entre um bloco e o próximo) são desenhados
 * num SVG sobreposto, a partir da posição real (medida em DOM, via
 * getBoundingClientRect) de cada bloco — nunca de larguras ou posições
 * assumidas. Por isso tocam sempre exatamente a borda dos blocos,
 * independentemente do tamanho de cada um.
 *
 * A ordem lógica das etapas (sequencia) nunca é alterada — apenas a
 * coluna/linha em que cada bloco é desenhado.
 */
export function FluxoEtapasSerpentina({ etapas, setores }: FluxoEtapasSerpentinaProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);

  const wrapperRef = React.useRef<HTMLDivElement>(null);
  const gridRef = React.useRef<HTMLDivElement>(null);
  const measureRefs = React.useRef<Array<HTMLSpanElement | null>>([]);
  const cardRefs = React.useRef<Array<HTMLDivElement | null>>([]);

  const [itemsPerRow, setItemsPerRow] = React.useState(MAX_PER_ROW);
  const [connectors, setConnectors] = React.useState<ConnectorPath[]>([]);
  const [svgSize, setSvgSize] = React.useState({ width: 0, height: 0 });

  // Quantas colunas cabem na trilha, a partir da largura real do wrapper e
  // da largura real do maior bloco (medida via elementos ocultos com o
  // mesmo conteúdo/tipografia do bloco visível). O cálculo é sempre
  // conservador (assume que toda coluna pode chegar a ter a largura do
  // maior bloco existente), então a trilha nunca ultrapassa a largura
  // disponível — sem overflow horizontal.
  const recomputeItemsPerRow = React.useCallback(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper || ordered.length === 0) return;
    const availableWidth = wrapper.clientWidth;
    if (availableWidth <= 0) return;
    const widths = measureRefs.current.slice(0, ordered.length).map((el) => el?.offsetWidth ?? 0);
    if (widths.length === 0 || widths.some((w) => w === 0)) return;
    const maxCardWidth = Math.max(...widths);
    const slot = maxCardWidth + COLUMN_GAP_PX;
    const n = Math.floor((availableWidth + COLUMN_GAP_PX) / slot);
    setItemsPerRow(Math.min(MAX_PER_ROW, Math.max(MIN_PER_ROW, n)));
  }, [ordered.length]);

  React.useLayoutEffect(() => {
    recomputeItemsPerRow();
  }, [recomputeItemsPerRow]);

  // Se a fonte ainda não tiver terminado de carregar no primeiro layout, a
  // largura medida dos blocos pode vir zerada/errada e o cálculo é
  // descartado (ver guarda em recomputeItemsPerRow). Refaz o cálculo assim
  // que as fontes terminarem de carregar, para não travar num número de
  // colunas maior do que realmente cabe.
  React.useEffect(() => {
    const fonts = (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts;
    if (!fonts?.ready) return;
    let cancelled = false;
    fonts.ready.then(() => {
      if (!cancelled) recomputeItemsPerRow();
    });
    return () => {
      cancelled = true;
    };
  }, [recomputeItemsPerRow]);

  React.useEffect(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => recomputeItemsPerRow());
    ro.observe(wrapper);
    return () => ro.disconnect();
  }, [recomputeItemsPerRow]);

  // Linhas (chunks da ordem original — a sequência dos dados nunca é
  // invertida, só a coluna em que cada bloco é desenhado).
  const rows = React.useMemo(() => {
    const chunks: FluxoProducaoEtapa[][] = [];
    for (let i = 0; i < ordered.length; i += itemsPerRow) {
      chunks.push(ordered.slice(i, i + itemsPerRow));
    }
    return chunks;
  }, [ordered, itemsPerRow]);

  // Desenha os conectores a partir da posição real (pós-layout) de cada
  // bloco. Uma linha reta quando origem e destino estão na mesma linha
  // visual (liga borda com borda, no sentido em que os blocos realmente
  // estão dispostos); um traço vertical (com leve cotovelo apenas se, por
  // arredondamento de fonte, os centros não caírem exatamente na mesma
  // coluna) quando a etapa muda de linha.
  const recomputeConnectors = React.useCallback(() => {
    const grid = gridRef.current;
    if (!grid || ordered.length === 0) return;
    const gridRect = grid.getBoundingClientRect();
    const rects = cardRefs.current.slice(0, ordered.length).map((el) => el?.getBoundingClientRect() ?? null);
    if (rects.length !== ordered.length || rects.some((r) => r === null)) return;

    const paths: ConnectorPath[] = [];
    for (let i = 0; i < ordered.length - 1; i++) {
      const a = rects[i]!;
      const b = rects[i + 1]!;
      const ax = a.left - gridRect.left;
      const ay = a.top - gridRect.top;
      const bx = b.left - gridRect.left;
      const by = b.top - gridRect.top;
      const sameRow = Math.abs(ay - by) < 1;

      if (sameRow) {
        const y = ay + a.height / 2;
        const goingRight = bx >= ax;
        const x1 = goingRight ? ax + a.width : ax;
        const x2 = goingRight ? bx : bx + b.width;
        paths.push({ id: `c-${i}`, d: `M ${x1} ${y} L ${x2} ${y}` });
      } else {
        const x1 = ax + a.width / 2;
        const y1 = ay + a.height;
        const x2 = bx + b.width / 2;
        const y2 = by;
        const midY = y1 + (y2 - y1) / 2;
        paths.push({ id: `c-${i}`, d: `M ${x1} ${y1} L ${x1} ${midY} L ${x2} ${midY} L ${x2} ${y2}` });
      }
    }
    setConnectors(paths);
    setSvgSize({ width: grid.clientWidth, height: grid.clientHeight });
  }, [ordered.length]);

  React.useLayoutEffect(() => {
    recomputeConnectors();
  }, [recomputeConnectors, rows]);

  React.useEffect(() => {
    const fonts = (document as Document & { fonts?: { ready: Promise<unknown> } }).fonts;
    if (!fonts?.ready) return;
    let cancelled = false;
    fonts.ready.then(() => {
      if (!cancelled) recomputeConnectors();
    });
    return () => {
      cancelled = true;
    };
  }, [recomputeConnectors]);

  React.useEffect(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver(() => {
      requestAnimationFrame(() => recomputeConnectors());
    });
    ro.observe(wrapper);
    // Rede de segurança adicional: além do ResizeObserver (fonte primária
    // de verdade sobre a largura real do container), reage também a
    // resize/orientationchange da janela — cobre casos como zoom do
    // navegador ou rotação de tela em que o container muda de largura no
    // mesmo instante em que a janela muda.
    const onWindowResize = () => requestAnimationFrame(() => recomputeConnectors());
    window.addEventListener("resize", onWindowResize);
    window.addEventListener("orientationchange", onWindowResize);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", onWindowResize);
      window.removeEventListener("orientationchange", onWindowResize);
    };
  }, [recomputeConnectors]);

  if (ordered.length === 0) return null;

  return (
    <div ref={wrapperRef} className="relative mt-3 w-full min-w-0 overflow-hidden">
      {/* min-w-0 é essencial: sem isso, caso este componente esteja dentro
         de um ancestral flex/grid, o navegador pode recusar encolher o
         wrapper abaixo do conteúdo intrínseco, e o ResizeObserver nunca
         reportaria a largura menor de fato disponível — a trilha ficaria
         "presa" num número de colunas maior do que cabe. */}
      {/* Camada de medição: invisível e sem afetar o layout da página,
         usada apenas para descobrir a largura real de cada bloco antes de
         decidir quantas colunas cabem na trilha. */}
      <div className="pointer-events-none absolute left-0 top-0 -z-10 flex opacity-0" aria-hidden="true">
        {ordered.map((etapa, idx) => {
          const setor = setores.find((s) => s.id === etapa.setorId);
          return (
            <span
              key={etapa.id}
              ref={(el) => {
                measureRefs.current[idx] = el;
              }}
              className="whitespace-nowrap rounded-md border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground"
            >
              {etapa.sequencia}. {setor?.nome ?? "—"}
            </span>
          );
        })}
      </div>

      <div className="relative">
        <svg
          className="pointer-events-none absolute left-0 top-0 -z-10"
          width={svgSize.width}
          height={svgSize.height}
          aria-hidden="true"
        >
          {connectors.map((c) => (
            <path key={c.id} d={c.d} fill="none" stroke="currentColor" strokeWidth={1.5} className="text-muted-foreground/50" />
          ))}
        </svg>

        <div
          ref={gridRef}
          className="grid w-fit max-w-full"
          style={{
            gridTemplateColumns: `repeat(${itemsPerRow}, max-content)`,
            columnGap: COLUMN_GAP_PX,
            rowGap: ROW_GAP_PX,
          }}
        >
          {rows.map((row, rowIdx) => {
            const invertida = rowIdx % 2 === 1;
            const startIndex = rowIdx * itemsPerRow;

            return row.map((etapa, k) => {
              const globalIndex = startIndex + k;
              const setor = setores.find((s) => s.id === etapa.setorId);
              const coluna = invertida ? itemsPerRow - 1 - k : k;

              return (
                <div
                  key={etapa.id}
                  ref={(el) => {
                    cardRefs.current[globalIndex] = el;
                  }}
                  style={{ gridColumn: coluna + 1, gridRow: rowIdx + 1 }}
                  className="rounded-md border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground"
                >
                  {etapa.sequencia}. {setor?.nome ?? "—"}
                </div>
              );
            });
          })}
        </div>
      </div>
    </div>
  );
}
