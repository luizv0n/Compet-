// =====================================================================
// mockRepository.ts — regras de negócio sobre o banco mock.
//
// Único arquivo (além de storage.ts) que manipula o objeto Database
// diretamente. apiClient.ts chama estas funções e as expõe como
// operações de domínio assíncronas para a UI.
//
// Toda operação que afeta saldo grava produto_estoque + kardex na
// "mesma transação" (aqui, síncrona, antes de persistir).
// =====================================================================

import type { Database } from "@/mock/seedData";
import { loadDatabase, saveDatabase } from "@/services/storage";
import type {
  AdminPlataforma,
  AuditAction,
  Cargo,
  Categoria,
  Colecao,
  ConfiguracaoEmpresa,
  Cor,
  Empresa,
  Estoque,
  FluxoProducao,
  FluxoProducaoEtapa,
  Fornecedor,
  ID,
  KardexEntry,
  KardexNatureza,
  MotivoPerda,
  MovimentacaoProducao,
  NotaFiscal,
  OrdemProducao,
  OrdemProducaoEtapa,

  Produto,
  ProdutoComponente,
  Setor,
  Tamanho,
  Usuario,
} from "@/types";
import type {
  CreateEmpresaPayload,
  CreatePurchaseNotePayload,
  CreateProductPayload,
  CreateProductionOrderPayload,
  DirectStockInPayload,
  FinishedGoodsEntryPayload,
  ManualStockOutPayload,
  ProductionMovePayload,
  TransferPayload,
} from "@/types/viewmodels";
import { ALL_PERMISSIONS, FUNCIONARIO_PERMISSIONS, PERMISSIONS, ROLE_NAMES } from "@/constants/permissions";
import { nowISO, pad } from "@/lib/utils";

export class RepositoryError extends Error {}

let db: Database | null = null;

function D(): Database {
  if (!db) db = loadDatabase();
  return db;
}

function persist() {
  saveDatabase(D());
}

function nextIdFor<T extends { id: ID }>(list: T[]): ID {
  return list.reduce((max, item) => Math.max(max, item.id), 0) + 1;
}

// -----------------------------------------------------------------
// Auditoria
// -----------------------------------------------------------------
export function logAudit(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  acao: AuditAction,
  entidade: string,
  descricao: string,
) {
  const database = D();
  database.auditLog.unshift({
    id: nextIdFor(database.auditLog),
    empresaId,
    usuarioId: usuario.id,
    usuarioNome: usuario.nome,
    acao,
    entidade,
    descricao,
    dataHora: nowISO(),
  });
}

export function resetAll() {
  db = null;
}

// -----------------------------------------------------------------
// Autenticação mock
// -----------------------------------------------------------------
export function listEmpresas() {
  return D().empresas.filter((e) => e.ativo);
}

export function authenticate(empresaId: ID, login: string, senha: string): Usuario {
  const usuario = D().usuarios.find(
    (u) => u.empresaId === empresaId && u.login === login && u.ativo,
  );
  if (!usuario || usuario.senha !== senha) {
    throw new RepositoryError("Usuário, empresa ou senha inválidos.");
  }
  logAudit(empresaId, { id: usuario.id, nome: usuario.nome }, "LOGIN", "Sessão", `${usuario.nome} entrou no sistema`);
  persist();
  return usuario;
}

export function getSessionContext(usuarioId: ID, empresaId: ID) {
  const database = D();
  const usuario = database.usuarios.find((u) => u.id === usuarioId && u.empresaId === empresaId);
  if (!usuario) return null;
  const cargo = database.cargos.find((c) => c.id === usuario.cargoId && c.empresaId === empresaId);
  const permissoes = cargo
    ? database.permissoes.filter((p) => cargo.permissaoIds.includes(p.id)).map((p) => p.nome)
    : [];
  const empresa = database.empresas.find((e) => e.id === empresaId);
  return { usuario, cargo, permissoes, empresa };
}

// -----------------------------------------------------------------
// Autenticação mock — ADM DO SITE (plataforma)
//
// Estrutura paralela e independente de authenticate()/getSessionContext()
// acima: o ADM DO SITE não é um Usuario de empresa (ver nota de
// limitação de banco em types/index.ts), então não reaproveita a
// mesma tabela nem a mesma cadeia usuario -> cargo -> permissao. Seu
// acesso é global por definição (seção 11.1 do prompt mestre), então
// não há lista de "permissoes" a calcular aqui.
// -----------------------------------------------------------------
export function authenticatePlataforma(login: string, senha: string): AdminPlataforma {
  const admin = D().adminsPlataforma.find((a) => a.login === login && a.ativo);
  if (!admin || admin.senha !== senha) {
    throw new RepositoryError("Login ou senha inválidos.");
  }
  logAuditPlataforma(admin, "LOGIN", "Sessão de plataforma", `${admin.nome} entrou no painel da plataforma`);
  persist();
  return admin;
}

export function getPlatformSessionContext(adminId: ID) {
  const admin = D().adminsPlataforma.find((a) => a.id === adminId);
  if (!admin) return null;
  return { admin };
}

/** Auditoria de ações do ADM DO SITE que não pertencem a nenhuma empresa (criar/ativar/inativar empresa). */
export function logAuditPlataforma(
  admin: { id: ID; nome: string },
  acao: AuditAction,
  entidade: string,
  descricao: string,
) {
  const database = D();
  database.auditLogPlataforma.unshift({
    id: nextIdFor(database.auditLogPlataforma),
    adminId: admin.id,
    adminNome: admin.nome,
    acao,
    entidade,
    descricao,
    dataHora: nowISO(),
  });
}

export function listAuditLogPlataforma() {
  return D().auditLogPlataforma;
}

// -----------------------------------------------------------------
// Empresas — visão de plataforma (ADM DO SITE)
//
// `listEmpresas()` (acima) continua servindo, sem alteração, o
// seletor do /login de empresa — só empresas ativas, porque uma
// empresa inativada não deve nem aparecer como opção de login. Estas
// funções abaixo servem exclusivamente a camada de plataforma.
// -----------------------------------------------------------------
export function listEmpresasGlobal(includeInactive = true): Empresa[] {
  const empresas = D().empresas;
  return includeInactive ? empresas : empresas.filter((e) => e.ativo);
}

export function getEmpresa(id: ID): Empresa | undefined {
  return D().empresas.find((e) => e.id === id);
}

/**
 * Cria uma empresa nova junto com sua estrutura inicial mínima (seção
 * 13 do prompt mestre): as permissões e os dois cargos padrão
 * (ADMINISTRADOR/FUNCIONARIO — mesmo catálogo usado no seed, nenhuma
 * segunda fonte de verdade de RBAC), o administrador inicial informado
 * e um único local de estoque padrão para a empresa poder operar de
 * imediato. Dados operacionais específicos (produtos, fornecedores,
 * categorias, coleções) propositalmente NÃO são criados — a seção 13
 * exige que comecem vazios.
 */
export function createEmpresaComAdmin(
  admin: { id: ID; nome: string },
  payload: CreateEmpresaPayload,
): { empresa: Empresa; adminUsuario: Usuario } {
  const database = D();

  const cnpjClash = database.empresas.find((e) => e.cnpj === payload.empresa.cnpj);
  if (cnpjClash) throw new RepositoryError("Já existe uma empresa cadastrada com este CNPJ.");
  const emailClash = database.empresas.find((e) => e.email.toLowerCase() === payload.empresa.email.toLowerCase());
  if (emailClash) throw new RepositoryError("Já existe uma empresa cadastrada com este email.");

  const empresa: Empresa = {
    id: nextIdFor(database.empresas),
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
    ...payload.empresa,
  };
  database.empresas.push(empresa);

  const permIds: Record<string, ID> = {};
  for (const key of ALL_PERMISSIONS) {
    const id = nextIdFor(database.permissoes);
    database.permissoes.push({
      id,
      empresaId: empresa.id,
      nome: key,
      descricao: null,
      ativo: true,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    });
    permIds[key] = id;
  }

  const adminCargoId = nextIdFor(database.cargos);
  database.cargos.push({
    id: adminCargoId,
    empresaId: empresa.id,
    nome: ROLE_NAMES.ADMIN,
    descricao: "Acesso total ao sistema",
    permissaoIds: Object.values(permIds),
    isAdmin: true,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  });
  const funcCargoId = nextIdFor(database.cargos);
  database.cargos.push({
    id: funcCargoId,
    empresaId: empresa.id,
    nome: ROLE_NAMES.FUNCIONARIO,
    descricao: "Operações de fábrica, produção, compras e estoque",
    permissaoIds: FUNCIONARIO_PERMISSIONS.map((k) => permIds[k]),
    isAdmin: false,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  });

  const loginClash = database.usuarios.find(
    (u) => u.empresaId === empresa.id && u.login === payload.administradorInicial.login,
  );
  if (loginClash) throw new RepositoryError("Este login já está em uso nesta empresa.");
  const adminUsuario: Usuario = {
    id: nextIdFor(database.usuarios),
    empresaId: empresa.id,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
    nome: payload.administradorInicial.nome,
    login: payload.administradorInicial.login,
    email: payload.administradorInicial.email,
    senha: payload.administradorInicial.senha,
    cargoId: adminCargoId,
  };
  database.usuarios.push(adminUsuario);

  database.estoques.push({
    id: nextIdFor(database.estoques),
    empresaId: empresa.id,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
    nome: "Fábrica",
    cep: null,
    logradouro: null,
    numero: null,
    complemento: null,
    bairro: null,
    cidade: null,
    estado: null,
  });

  logAuditPlataforma(
    admin,
    "CRIACAO",
    "Empresa",
    `Criou a empresa "${empresa.nomeFantasia}" e o administrador inicial "${adminUsuario.nome}"`,
  );
  persist();
  return { empresa, adminUsuario };
}

export function toggleEmpresaGlobal(id: ID, admin: { id: ID; nome: string }): Empresa {
  const empresa = D().empresas.find((e) => e.id === id);
  if (!empresa) throw new RepositoryError("Empresa não encontrada.");
  empresa.ativo = !empresa.ativo;
  empresa.atualizadoEm = nowISO();
  logAuditPlataforma(
    admin,
    empresa.ativo ? "ATIVACAO" : "INATIVACAO",
    "Empresa",
    `${empresa.ativo ? "Ativou" : "Inativou"} a empresa "${empresa.nomeFantasia}"`,
  );
  persist();
  return empresa;
}

/**
 * Edição dos dados cadastrais da empresa pelo ADM DO SITE (seção 14 do
 * prompt mestre — ação "Editar" na tela de gerenciamento de empresas).
 * Só altera os campos da própria tabela `empresa`; não mexe em
 * administrador, cargos ou estrutura operacional.
 */
export function updateEmpresaGlobal(
  id: ID,
  admin: { id: ID; nome: string },
  data: Partial<Omit<Empresa, "id" | "ativo" | "criadoEm" | "atualizadoEm">>,
): Empresa {
  const empresa = D().empresas.find((e) => e.id === id);
  if (!empresa) throw new RepositoryError("Empresa não encontrada.");
  if (data.cnpj && data.cnpj !== empresa.cnpj) {
    const clash = D().empresas.find((e) => e.id !== id && e.cnpj === data.cnpj);
    if (clash) throw new RepositoryError("Já existe uma empresa cadastrada com este CNPJ.");
  }
  if (data.email && data.email.toLowerCase() !== empresa.email.toLowerCase()) {
    const clash = D().empresas.find((e) => e.id !== id && e.email.toLowerCase() === data.email!.toLowerCase());
    if (clash) throw new RepositoryError("Já existe uma empresa cadastrada com este email.");
  }
  Object.assign(empresa, data);
  empresa.atualizadoEm = nowISO();
  logAuditPlataforma(admin, "EDICAO", "Empresa", `Editou os dados cadastrais da empresa "${empresa.nomeFantasia}"`);
  persist();
  return empresa;
}

/**
 * Usuários de TODAS as empresas — exclusivo da camada de plataforma
 * (seção 11.1: o ADM DO SITE é a exceção com acesso global, seção 17).
 * `listUsuarios(empresaId, ...)` acima continua isolado por tenant e é
 * o que as telas de empresa usam; esta função é só para o Dashboard e
 * a tela de Empresas do painel global calcularem KPIs/administrador
 * responsável sem vazar isolamento para dentro do app de empresa.
 */
export function listUsuariosGlobal(): Usuario[] {
  return D().usuarios;
}

/** Cargos de todas as empresas — mesmo racional de listUsuariosGlobal(). */
export function listCargosGlobal(): Cargo[] {
  return D().cargos;
}

// -----------------------------------------------------------------
// Helper genérico de CRUD para cadastros simples de apoio
// (colecao, cor, tamanho, categoria, fornecedor, setor, motivo_perda...)
// -----------------------------------------------------------------
function listByEmpresa<T extends { empresaId: ID; ativo: boolean }>(
  list: T[],
  empresaId: ID,
  includeInactive: boolean,
): T[] {
  return list.filter((item) => item.empresaId === empresaId && (includeInactive || item.ativo));
}

function assertUniqueName<T extends { empresaId: ID; nome: string; id?: ID }>(
  list: T[],
  empresaId: ID,
  nome: string,
  ignoreId?: ID,
) {
  const clash = list.find(
    (item) =>
      item.empresaId === empresaId &&
      item.nome.trim().toLowerCase() === nome.trim().toLowerCase() &&
      item.id !== ignoreId,
  );
  if (clash) throw new RepositoryError(`Já existe um registro chamado "${nome}" nesta empresa.`);
}

// ---- Coleções ----
export function listColecoes(empresaId: ID, includeInactive = false): Colecao[] {
  return listByEmpresa(D().colecoes, empresaId, includeInactive);
}
export function createColecao(empresaId: ID, nome: string): Colecao {
  const database = D();
  assertUniqueName(database.colecoes, empresaId, nome);
  const item: Colecao = { id: nextIdFor(database.colecoes), empresaId, nome, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.colecoes.push(item);
  persist();
  return item;
}
export function updateColecao(id: ID, empresaId: ID, nome: string): Colecao {
  const database = D();
  assertUniqueName(database.colecoes, empresaId, nome, id);
  const item = database.colecoes.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Coleção não encontrada.");
  item.nome = nome;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleColecao(id: ID, empresaId: ID): Colecao {
  const item = D().colecoes.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Coleção não encontrada.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Cores ----
export function listCores(empresaId: ID, includeInactive = false): Cor[] {
  return listByEmpresa(D().cores, empresaId, includeInactive);
}
export function createCor(empresaId: ID, nome: string, estampa: string): Cor {
  const database = D();
  const clash = database.cores.find(
    (c) => c.empresaId === empresaId && c.nome.toLowerCase() === nome.toLowerCase() && c.estampa.toLowerCase() === estampa.toLowerCase(),
  );
  if (clash) throw new RepositoryError("Já existe uma cor com este nome e estampa.");
  const item: Cor = { id: nextIdFor(database.cores), empresaId, nome, estampa, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.cores.push(item);
  persist();
  return item;
}
export function updateCor(id: ID, empresaId: ID, nome: string, estampa: string): Cor {
  const database = D();
  const item = database.cores.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Cor não encontrada.");
  item.nome = nome;
  item.estampa = estampa;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleCor(id: ID, empresaId: ID): Cor {
  const item = D().cores.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Cor não encontrada.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Tamanhos ----
export function listTamanhos(empresaId: ID, includeInactive = false): Tamanho[] {
  return listByEmpresa(D().tamanhos, empresaId, includeInactive);
}
export function createTamanho(empresaId: ID, nome: string): Tamanho {
  const database = D();
  assertUniqueName(database.tamanhos, empresaId, nome);
  const item: Tamanho = { id: nextIdFor(database.tamanhos), empresaId, nome, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.tamanhos.push(item);
  persist();
  return item;
}
export function updateTamanho(id: ID, empresaId: ID, nome: string): Tamanho {
  const database = D();
  assertUniqueName(database.tamanhos, empresaId, nome, id);
  const item = database.tamanhos.find((t) => t.id === id && t.empresaId === empresaId);
  if (!item) throw new RepositoryError("Tamanho não encontrado.");
  item.nome = nome;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleTamanho(id: ID, empresaId: ID): Tamanho {
  const item = D().tamanhos.find((t) => t.id === id && t.empresaId === empresaId);
  if (!item) throw new RepositoryError("Tamanho não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Categorias ----
export function listCategorias(empresaId: ID, includeInactive = false): Categoria[] {
  return listByEmpresa(D().categorias, empresaId, includeInactive);
}
export function createCategoria(empresaId: ID, nome: string): Categoria {
  const database = D();
  assertUniqueName(database.categorias, empresaId, nome);
  const item: Categoria = { id: nextIdFor(database.categorias), empresaId, nome, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.categorias.push(item);
  persist();
  return item;
}
export function updateCategoria(id: ID, empresaId: ID, nome: string): Categoria {
  const database = D();
  assertUniqueName(database.categorias, empresaId, nome, id);
  const item = database.categorias.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Categoria não encontrada.");
  item.nome = nome;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleCategoria(id: ID, empresaId: ID): Categoria {
  const item = D().categorias.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Categoria não encontrada.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Unidades de medida (globais, somente leitura na UI padrão) ----
export function listUnidadesMedida(includeInactive = false) {
  return D().unidadesMedida.filter((u) => includeInactive || u.ativo);
}
export function createUnidadeMedida(sigla: string) {
  const database = D();
  const clash = database.unidadesMedida.find((u) => u.sigla.toLowerCase() === sigla.toLowerCase());
  if (clash) throw new RepositoryError("Já existe uma unidade com esta sigla.");
  const item = { id: nextIdFor(database.unidadesMedida), sigla: sigla.toUpperCase(), ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.unidadesMedida.push(item);
  persist();
  return item;
}
export function updateUnidadeMedida(id: ID, sigla: string) {
  const database = D();
  const item = database.unidadesMedida.find((u) => u.id === id);
  if (!item) throw new RepositoryError("Unidade não encontrada.");
  const clash = database.unidadesMedida.find((u) => u.id !== id && u.sigla.toLowerCase() === sigla.toLowerCase());
  if (clash) throw new RepositoryError("Já existe uma unidade com esta sigla.");
  item.sigla = sigla.toUpperCase();
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleUnidadeMedida(id: ID) {
  const item = D().unidadesMedida.find((u) => u.id === id);
  if (!item) throw new RepositoryError("Unidade não encontrada.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Fornecedores ----
export function listFornecedores(empresaId: ID, includeInactive = false): Fornecedor[] {
  return listByEmpresa(D().fornecedores, empresaId, includeInactive);
}
export function createFornecedor(empresaId: ID, data: Omit<Fornecedor, keyof { id: 1; empresaId: 1; ativo: 1; criadoEm: 1; atualizadoEm: 1 }>): Fornecedor {
  const database = D();
  assertUniqueName(database.fornecedores, empresaId, data.nome);
  const item: Fornecedor = { id: nextIdFor(database.fornecedores), empresaId, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO(), ...data };
  database.fornecedores.push(item);
  persist();
  return item;
}
export function updateFornecedor(id: ID, empresaId: ID, data: Partial<Fornecedor>): Fornecedor {
  const database = D();
  const item = database.fornecedores.find((f) => f.id === id && f.empresaId === empresaId);
  if (!item) throw new RepositoryError("Fornecedor não encontrado.");
  Object.assign(item, data, { atualizadoEm: nowISO() });
  persist();
  return item;
}
export function toggleFornecedor(id: ID, empresaId: ID): Fornecedor {
  const item = D().fornecedores.find((f) => f.id === id && f.empresaId === empresaId);
  if (!item) throw new RepositoryError("Fornecedor não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Setores ----
export function listSetores(empresaId: ID, includeInactive = false): Setor[] {
  return listByEmpresa(D().setores, empresaId, includeInactive);
}
export function createSetor(empresaId: ID, data: Omit<Setor, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">): Setor {
  const database = D();
  assertUniqueName(database.setores, empresaId, data.nome);
  const item: Setor = { id: nextIdFor(database.setores), empresaId, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO(), ...data };
  database.setores.push(item);
  persist();
  return item;
}
export function updateSetor(id: ID, empresaId: ID, data: Partial<Setor>): Setor {
  const database = D();
  const item = database.setores.find((s) => s.id === id && s.empresaId === empresaId);
  if (!item) throw new RepositoryError("Setor não encontrado.");
  Object.assign(item, data, { atualizadoEm: nowISO() });
  persist();
  return item;
}
export function toggleSetor(id: ID, empresaId: ID): Setor {
  const item = D().setores.find((s) => s.id === id && s.empresaId === empresaId);
  if (!item) throw new RepositoryError("Setor não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// ---- Motivos de perda ----
export function listMotivosPerda(empresaId: ID, includeInactive = false): MotivoPerda[] {
  return listByEmpresa(D().motivosPerda, empresaId, includeInactive);
}
export function createMotivoPerda(empresaId: ID, nome: string, tipo: MotivoPerda["tipo"], descricao?: string | null): MotivoPerda {
  const database = D();
  assertUniqueName(database.motivosPerda, empresaId, nome);
  const item: MotivoPerda = {
    id: nextIdFor(database.motivosPerda),
    empresaId,
    nome,
    tipo,
    descricao: descricao?.trim() ? descricao.trim() : null,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.motivosPerda.push(item);
  persist();
  return item;
}
export function updateMotivoPerda(id: ID, empresaId: ID, nome: string, tipo: MotivoPerda["tipo"], descricao?: string | null): MotivoPerda {
  const database = D();
  assertUniqueName(database.motivosPerda, empresaId, nome, id);
  const item = database.motivosPerda.find((m) => m.id === id && m.empresaId === empresaId);
  if (!item) throw new RepositoryError("Motivo não encontrado.");
  item.nome = nome;
  item.tipo = tipo;
  item.descricao = descricao?.trim() ? descricao.trim() : null;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}
export function toggleMotivoPerda(id: ID, empresaId: ID): MotivoPerda {
  const item = D().motivosPerda.find((m) => m.id === id && m.empresaId === empresaId);
  if (!item) throw new RepositoryError("Motivo não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// -----------------------------------------------------------------
// Estoques (locais físicos)
// -----------------------------------------------------------------
export function listEstoques(empresaId: ID, includeInactive = false): Estoque[] {
  return listByEmpresa(D().estoques, empresaId, includeInactive);
}
export function createEstoque(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  data: Omit<Estoque, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">,
): Estoque {
  const database = D();
  assertUniqueName(database.estoques, empresaId, data.nome);
  const item: Estoque = { id: nextIdFor(database.estoques), empresaId, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO(), ...data };
  database.estoques.push(item);
  // BUG REAL ENCONTRADO (Etapa 13 — auditoria de RBAC): ao contrário de
  // TODAS as demais operações restritas a permissões elevadas (ex.:
  // criar/editar/ativar usuário — regra 24 do prompt mestre exige o
  // mesmo tratamento para "cadastrar novos locais de estoque"),
  // createEstoque/toggleEstoque não geravam nenhum registro de
  // auditoria. Locais de estoque têm permissão própria e mais
  // restrita (STOCK_LOCATIONS_MANAGE, distinta da genérica
  // SUPPORT_TABLES_MANAGE usada por coleção/cor/tamanho/categoria),
  // então merecem o mesmo tratamento de auditoria dado a Usuário —
  // não o tratamento "silencioso" dos cadastros de apoio comuns.
  // Corrigido reaproveitando o padrão logAudit já existente (nenhuma
  // segunda arquitetura de auditoria foi criada).
  logAudit(empresaId, usuario, "CRIACAO", "Estoque (local)", `Cadastrou o local de estoque "${item.nome}"`);
  persist();
  return item;
}
export function updateEstoque(
  id: ID,
  empresaId: ID,
  usuario: { id: ID; nome: string },
  data: Partial<Omit<Estoque, "id" | "empresaId" | "ativo" | "criadoEm" | "atualizadoEm">>,
): Estoque {
  const database = D();
  const item = database.estoques.find((e) => e.id === id && e.empresaId === empresaId);
  if (!item) throw new RepositoryError("Estoque não encontrado.");
  if (data.nome) assertUniqueName(database.estoques, empresaId, data.nome, id);
  Object.assign(item, data, { atualizadoEm: nowISO() });
  logAudit(empresaId, usuario, "EDICAO", "Estoque (local)", `Editou o local de estoque "${item.nome}"`);
  persist();
  return item;
}
export function toggleEstoque(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): Estoque {
  const item = D().estoques.find((e) => e.id === id && e.empresaId === empresaId);
  if (!item) throw new RepositoryError("Estoque não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  logAudit(
    empresaId,
    usuario,
    item.ativo ? "ATIVACAO" : "INATIVACAO",
    "Estoque (local)",
    `${item.ativo ? "Ativou" : "Inativou"} o local de estoque "${item.nome}"`,
  );
  persist();
  return item;
}

function getSaldoRow(produtoVariacaoId: ID, estoqueId: ID, empresaId: ID) {
  const database = D();
  let row = database.saldos.find((s) => s.produtoVariacaoId === produtoVariacaoId && s.estoqueId === estoqueId);
  if (!row) {
    row = { produtoVariacaoId, estoqueId, empresaId, quantidade: 0, quantidadeReservada: 0, criadoEm: nowISO(), atualizadoEm: nowISO() };
    database.saldos.push(row);
  }
  return row;
}

export function getSaldosDaVariacao(produtoVariacaoId: ID, empresaId: ID) {
  return D().saldos.filter((s) => s.produtoVariacaoId === produtoVariacaoId && s.empresaId === empresaId);
}

export function listSaldos(empresaId: ID) {
  return D().saldos.filter((s) => s.empresaId === empresaId);
}

function writeKardex(entry: Omit<KardexEntry, "id" | "criadoEm">): KardexEntry {
  const database = D();
  const row: KardexEntry = { id: nextIdFor(database.kardex), criadoEm: entry.dataMovimentacao, ...entry };
  database.kardex.push(row);
  return row;
}

function applyKardexAndBalance(
  empresaId: ID,
  produtoVariacaoId: ID,
  estoqueId: ID,
  sentido: "ENTRADA" | "SAIDA",
  natureza: KardexNatureza,
  quantidade: number,
  opts: {
    notaFiscalItemId?: ID | null;
    ordemProducaoId?: ID | null;
    movimentacaoProducaoId?: ID | null;
    usuarioId?: ID | null;
    observacao?: string | null;
  } = {},
) {
  const saldoRow = getSaldoRow(produtoVariacaoId, estoqueId, empresaId);
  const saldoAnterior = saldoRow.quantidade;
  if (sentido === "SAIDA" && quantidade > saldoRow.quantidade + 1e-9) {
    throw new RepositoryError("Quantidade solicitada excede o saldo disponível neste estoque.");
  }
  saldoRow.quantidade = sentido === "ENTRADA" ? saldoRow.quantidade + quantidade : saldoRow.quantidade - quantidade;
  saldoRow.atualizadoEm = nowISO();
  const saldoResultante = saldoRow.quantidade;
  return writeKardex({
    empresaId,
    produtoVariacaoId,
    estoqueId,
    sentido,
    natureza,
    quantidade,
    saldoAnterior,
    saldoResultante,
    notaFiscalItemId: opts.notaFiscalItemId ?? null,
    ordemProducaoId: opts.ordemProducaoId ?? null,
    movimentacaoProducaoId: opts.movimentacaoProducaoId ?? null,
    usuarioId: opts.usuarioId ?? null,
    observacao: opts.observacao ?? null,
    dataMovimentacao: nowISO(),
  });
}

export function transferStock(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: TransferPayload,
) {
  if (payload.estoqueOrigemId === payload.estoqueDestinoId) {
    throw new RepositoryError("Estoque de origem e destino devem ser diferentes.");
  }
  if (payload.quantidade <= 0) {
    throw new RepositoryError("A quantidade deve ser maior que zero.");
  }
  applyKardexAndBalance(empresaId, payload.produtoVariacaoId, payload.estoqueOrigemId, "SAIDA", "TRANSFERENCIA", payload.quantidade, {
    usuarioId: usuario.id,
    observacao: payload.observacao ?? "Transferência entre estoques",
  });
  applyKardexAndBalance(empresaId, payload.produtoVariacaoId, payload.estoqueDestinoId, "ENTRADA", "TRANSFERENCIA", payload.quantidade, {
    usuarioId: usuario.id,
    observacao: payload.observacao ?? "Transferência entre estoques",
  });
  const database = D();
  const variacao = database.variacoes.find((v) => v.id === payload.produtoVariacaoId);
  const produto = variacao ? database.produtos.find((p) => p.id === variacao.produtoId) : undefined;
  const origem = database.estoques.find((e) => e.id === payload.estoqueOrigemId);
  const destino = database.estoques.find((e) => e.id === payload.estoqueDestinoId);
  logAudit(
    empresaId,
    usuario,
    "TRANSFERENCIA",
    "Estoque",
    `Transferiu ${payload.quantidade} un. de ${produto?.nome ?? "produto"} (${variacao?.sku}) — ${origem?.nome} → ${destino?.nome}`,
  );
  persist();
}

export function manualStockOut(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: ManualStockOutPayload,
) {
  if (payload.quantidade <= 0) throw new RepositoryError("A quantidade deve ser maior que zero.");
  if (!payload.observacao?.trim()) throw new RepositoryError("Informe o motivo da baixa.");
  applyKardexAndBalance(empresaId, payload.produtoVariacaoId, payload.estoqueId, "SAIDA", payload.natureza, payload.quantidade, {
    usuarioId: usuario.id,
    observacao: payload.observacao,
  });
  const database = D();
  const variacao = database.variacoes.find((v) => v.id === payload.produtoVariacaoId);
  const produto = variacao ? database.produtos.find((p) => p.id === variacao.produtoId) : undefined;
  logAudit(empresaId, usuario, "BAIXA", "Estoque", `Baixa manual de ${payload.quantidade} un. de ${produto?.nome ?? "produto"} (${variacao?.sku}) — ${payload.observacao}`);
  persist();
}

export function directStockIn(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: DirectStockInPayload,
) {
  if (payload.quantidade <= 0) throw new RepositoryError("A quantidade deve ser maior que zero.");
  applyKardexAndBalance(empresaId, payload.produtoVariacaoId, payload.estoqueId, "ENTRADA", "AJUSTE", payload.quantidade, {
    usuarioId: usuario.id,
    observacao: payload.observacao || "Entrada direta de produto acabado",
  });
  const database = D();
  const variacao = database.variacoes.find((v) => v.id === payload.produtoVariacaoId);
  const produto = variacao ? database.produtos.find((p) => p.id === variacao.produtoId) : undefined;
  logAudit(empresaId, usuario, "ENTRADA", "Estoque", `Entrada direta de ${payload.quantidade} un. de ${produto?.nome ?? "produto"} (${variacao?.sku})`);
  persist();
}

export function listKardex(empresaId: ID) {
  return D().kardex.filter((k) => k.empresaId === empresaId).sort((a, b) => (a.dataMovimentacao < b.dataMovimentacao ? 1 : -1));
}

// -----------------------------------------------------------------
// Produtos + variações + preços + categorias
// -----------------------------------------------------------------
export function listProdutos(empresaId: ID, includeInactive = false): Produto[] {
  return listByEmpresa(D().produtos, empresaId, includeInactive);
}
export function getProduto(id: ID, empresaId: ID): Produto | undefined {
  return D().produtos.find((p) => p.id === id && p.empresaId === empresaId);
}
export function listVariacoesDoProduto(produtoId: ID, empresaId: ID) {
  return D().variacoes.filter((v) => v.produtoId === produtoId && v.empresaId === empresaId);
}
export function listVariacoes(empresaId: ID, includeInactive = false) {
  return listByEmpresa(D().variacoes, empresaId, includeInactive);
}
export function getVariacao(id: ID, empresaId: ID) {
  return D().variacoes.find((v) => v.id === id && v.empresaId === empresaId);
}
export function listPrecosDaVariacao(variacaoId: ID, empresaId: ID) {
  const database = D();
  return database.precos
    .filter((p) => p.produtoVariacaoId === variacaoId && p.empresaId === empresaId)
    .map((p) => ({ ...p, tipoPagamentoNome: database.tiposPagamento.find((t) => t.id === p.tipoPagamentoId)?.nome ?? "" }));
}
export function listTiposPagamento(empresaId: ID) {
  return D().tiposPagamento.filter((t) => t.empresaId === empresaId && t.ativo);
}

// Gera o próximo SKU sequencial no formato "CAM-000001", escopado por
// empresa (mesmo padrão de unicidade de SKU já usado em createProduto/
// addVariacao/updateVariacao). Não depende de nome/cor/tamanho — apenas
// do maior número já usado nesse padrão para esta empresa — para que
// alterações posteriores nesses atributos nunca exijam trocar o SKU.
// É uma sugestão somente-leitura: o valor é calculado no momento em que
// o formulário abre e só é persistido quando a variação é de fato salva.
const SKU_PREFIX = "CAM-";
const SKU_SEQ_RE = /^CAM-(\d{6,})$/;
export function nextSku(empresaId: ID): string {
  const database = D();
  let max = 0;
  for (const v of database.variacoes) {
    if (v.empresaId !== empresaId) continue;
    const match = SKU_SEQ_RE.exec(v.sku.trim().toUpperCase());
    if (match) {
      const n = parseInt(match[1], 10);
      if (n > max) max = n;
    }
  }
  return `${SKU_PREFIX}${String(max + 1).padStart(6, "0")}`;
}

export function createProduto(empresaId: ID, usuario: { id: ID; nome: string }, payload: CreateProductPayload): Produto {
  const database = D();
  assertUniqueName(database.produtos, empresaId, payload.nome);
  if (payload.variacoes.length === 0) throw new RepositoryError("Cadastre ao menos uma variação (SKU).");

  const semDesdobramento = payload.variacoes.every((v) => !v.corId && !v.tamanhoId);
  if (semDesdobramento && payload.variacoes.length > 1) {
    throw new RepositoryError("Produto sem cor/tamanho pode ter apenas uma variação padrão.");
  }
  const combos = new Set<string>();
  for (const v of payload.variacoes) {
    const key = `${v.corId ?? "null"}-${v.tamanhoId ?? "null"}`;
    if (combos.has(key)) throw new RepositoryError("Combinação de cor e tamanho duplicada entre as variações.");
    combos.add(key);
    const skuClash = database.variacoes.find((existing) => existing.empresaId === empresaId && existing.sku.toLowerCase() === v.sku.toLowerCase());
    if (skuClash) throw new RepositoryError(`SKU "${v.sku}" já está em uso nesta empresa.`);
  }

  const produto: Produto = {
    id: nextIdFor(database.produtos),
    empresaId,
    nome: payload.nome,
    tipo: payload.tipo,
    colecaoId: payload.colecaoId ?? null,
    unidadeMedidaId: payload.unidadeMedidaId,
    ncm: payload.ncm ?? null,
    cest: payload.cest ?? null,
    origem: payload.origem ?? null,
    categoriaIds: payload.categoriaIds,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.produtos.push(produto);

  for (const v of payload.variacoes) {
    const variacaoId = nextIdFor(database.variacoes);
    database.variacoes.push({
      id: variacaoId,
      empresaId,
      produtoId: produto.id,
      corId: v.corId ?? null,
      tamanhoId: v.tamanhoId ?? null,
      sku: v.sku,
      codigoBarras: v.codigoBarras ?? null,
      ativo: true,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    });
    for (const preco of v.precos) {
      database.precos.push({
        produtoVariacaoId: variacaoId,
        tipoPagamentoId: preco.tipoPagamentoId,
        empresaId,
        valor: preco.valor,
        ativo: true,
        criadoEm: nowISO(),
        atualizadoEm: nowISO(),
      });
    }
  }

  logAudit(empresaId, usuario, "CRIACAO", "Produto", `Cadastrou o produto "${produto.nome}" com ${payload.variacoes.length} variação(ões)`);
  persist();
  return produto;
}

export function updateProduto(id: ID, empresaId: ID, usuario: { id: ID; nome: string }, data: Partial<Produto>): Produto {
  const database = D();
  const item = database.produtos.find((p) => p.id === id && p.empresaId === empresaId);
  if (!item) throw new RepositoryError("Produto não encontrado.");
  if (data.nome) assertUniqueName(database.produtos, empresaId, data.nome, id);
  Object.assign(item, data, { atualizadoEm: nowISO() });
  logAudit(empresaId, usuario, "EDICAO", "Produto", `Editou o produto "${item.nome}"`);
  persist();
  return item;
}

export function toggleProduto(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): Produto {
  const database = D();
  const item = database.produtos.find((p) => p.id === id && p.empresaId === empresaId);
  if (!item) throw new RepositoryError("Produto não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  // Inativar o produto inativa também suas variações (deixam de aparecer em seleções)
  for (const v of database.variacoes.filter((v) => v.produtoId === id && v.empresaId === empresaId)) {
    v.ativo = item.ativo;
    v.atualizadoEm = nowISO();
  }
  logAudit(empresaId, usuario, item.ativo ? "ATIVACAO" : "INATIVACAO", "Produto", `${item.ativo ? "Ativou" : "Inativou"} o produto "${item.nome}"`);
  persist();
  return item;
}

export function addVariacao(
  produtoId: ID,
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: import("@/types/viewmodels").CreateVariantPayload,
) {
  const database = D();
  const produto = database.produtos.find((p) => p.id === produtoId && p.empresaId === empresaId);
  if (!produto) throw new RepositoryError("Produto não encontrado.");
  const existentes = database.variacoes.filter((v) => v.produtoId === produtoId && v.empresaId === empresaId);
  const semDesdobramento = !payload.corId && !payload.tamanhoId;
  if (semDesdobramento && existentes.some((v) => !v.corId && !v.tamanhoId)) {
    throw new RepositoryError("Este produto já possui uma variação padrão sem cor/tamanho.");
  }
  const comboClash = existentes.find((v) => v.corId === (payload.corId ?? null) && v.tamanhoId === (payload.tamanhoId ?? null));
  if (comboClash) throw new RepositoryError("Já existe uma variação com esta combinação de cor e tamanho.");
  const skuClash = database.variacoes.find((v) => v.empresaId === empresaId && v.sku.toLowerCase() === payload.sku.toLowerCase());
  if (skuClash) throw new RepositoryError(`SKU "${payload.sku}" já está em uso nesta empresa.`);

  const variacaoId = nextIdFor(database.variacoes);
  database.variacoes.push({
    id: variacaoId,
    empresaId,
    produtoId,
    corId: payload.corId ?? null,
    tamanhoId: payload.tamanhoId ?? null,
    sku: payload.sku,
    codigoBarras: payload.codigoBarras ?? null,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  });
  for (const preco of payload.precos) {
    database.precos.push({ produtoVariacaoId: variacaoId, tipoPagamentoId: preco.tipoPagamentoId, empresaId, valor: preco.valor, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() });
  }
  logAudit(empresaId, usuario, "CRIACAO", "Variação", `Adicionou o SKU "${payload.sku}" ao produto "${produto.nome}"`);
  persist();
  return database.variacoes.find((v) => v.id === variacaoId)!;
}

export function updateVariacao(
  id: ID,
  empresaId: ID,
  usuario: { id: ID; nome: string },
  data: { corId?: ID | null; tamanhoId?: ID | null; sku?: string; codigoBarras?: string | null },
) {
  const database = D();
  const item = database.variacoes.find((v) => v.id === id && v.empresaId === empresaId);
  if (!item) throw new RepositoryError("Variação não encontrada.");

  const novoCorId = data.corId !== undefined ? data.corId : item.corId;
  const novoTamanhoId = data.tamanhoId !== undefined ? data.tamanhoId : item.tamanhoId;
  const novoSku = data.sku !== undefined ? data.sku : item.sku;

  const semDesdobramento = !novoCorId && !novoTamanhoId;
  const existentes = database.variacoes.filter((v) => v.produtoId === item.produtoId && v.empresaId === empresaId && v.id !== id);
  if (semDesdobramento && existentes.some((v) => !v.corId && !v.tamanhoId)) {
    throw new RepositoryError("Este produto já possui uma variação padrão sem cor/tamanho.");
  }
  const comboClash = existentes.find((v) => v.corId === (novoCorId ?? null) && v.tamanhoId === (novoTamanhoId ?? null));
  if (comboClash) throw new RepositoryError("Já existe uma variação com esta combinação de cor e tamanho.");
  if (data.sku !== undefined) {
    const skuClash = database.variacoes.find((v) => v.id !== id && v.empresaId === empresaId && v.sku.toLowerCase() === novoSku.toLowerCase());
    if (skuClash) throw new RepositoryError(`SKU "${novoSku}" já está em uso nesta empresa.`);
  }

  // Identidade da variação (id, empresaId, produtoId) é preservada — apenas
  // os dados cadastrais são atualizados. Saldo/Kardex/preços referenciam
  // produtoVariacaoId, que não muda aqui.
  if (data.corId !== undefined) item.corId = data.corId;
  if (data.tamanhoId !== undefined) item.tamanhoId = data.tamanhoId;
  if (data.sku !== undefined) item.sku = data.sku;
  if (data.codigoBarras !== undefined) item.codigoBarras = data.codigoBarras;
  item.atualizadoEm = nowISO();

  logAudit(empresaId, usuario, "EDICAO", "Variação", `Editou o SKU "${item.sku}"`);
  persist();
  return item;
}

export function toggleVariacao(id: ID, empresaId: ID, usuario: { id: ID; nome: string }) {
  const database = D();
  const item = database.variacoes.find((v) => v.id === id && v.empresaId === empresaId);
  if (!item) throw new RepositoryError("Variação não encontrada.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, item.ativo ? "ATIVACAO" : "INATIVACAO", "Variação", `${item.ativo ? "Ativou" : "Inativou"} o SKU "${item.sku}"`);
  persist();
  return item;
}

export function updatePrecos(variacaoId: ID, empresaId: ID, usuario: { id: ID; nome: string }, precos: { tipoPagamentoId: ID; valor: number }[]) {
  const database = D();
  for (const p of precos) {
    if (p.valor < 0) throw new RepositoryError("Preço não pode ser negativo.");
    let row = database.precos.find((row) => row.produtoVariacaoId === variacaoId && row.tipoPagamentoId === p.tipoPagamentoId && row.empresaId === empresaId);
    if (!row) {
      row = { produtoVariacaoId: variacaoId, tipoPagamentoId: p.tipoPagamentoId, empresaId, valor: p.valor, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
      database.precos.push(row);
    } else {
      row.valor = p.valor;
      row.atualizadoEm = nowISO();
    }
  }
  const variacao = database.variacoes.find((v) => v.id === variacaoId);
  logAudit(empresaId, usuario, "EDICAO", "Preço", `Atualizou os preços do SKU "${variacao?.sku}"`);
  persist();
}

// -----------------------------------------------------------------
// Estoque mínimo (Etapa 14 — regra 25 do Prompt Master). Sem tabela
// correspondente no bd_competeV6.sql — ver nota de limitação em
// types/index.ts (EstoqueMinimo) e em mock/seedData.ts. Mesmo padrão
// de upsert de updatePrecos acima: se não houver linha, cria; se
// houver, atualiza.
// -----------------------------------------------------------------
export function listEstoquesMinimos(empresaId: ID) {
  return D().estoquesMinimos.filter((m) => m.empresaId === empresaId);
}

export function getEstoqueMinimo(variacaoId: ID, empresaId: ID): number | null {
  const row = D().estoquesMinimos.find((m) => m.produtoVariacaoId === variacaoId && m.empresaId === empresaId);
  return row ? row.quantidade : null;
}

export function setEstoqueMinimo(variacaoId: ID, empresaId: ID, usuario: { id: ID; nome: string }, quantidade: number) {
  if (quantidade < 0) throw new RepositoryError("O estoque mínimo não pode ser negativo.");
  const database = D();
  const variacao = database.variacoes.find((v) => v.id === variacaoId && v.empresaId === empresaId);
  if (!variacao) throw new RepositoryError("Variação não encontrada.");
  let row = database.estoquesMinimos.find((m) => m.produtoVariacaoId === variacaoId && m.empresaId === empresaId);
  if (!row) {
    row = { produtoVariacaoId: variacaoId, empresaId, quantidade, atualizadoEm: nowISO() };
    database.estoquesMinimos.push(row);
  } else {
    row.quantidade = quantidade;
    row.atualizadoEm = nowISO();
  }
  logAudit(empresaId, usuario, "EDICAO", "Estoque mínimo", `Definiu o estoque mínimo do SKU "${variacao.sku}" para ${quantidade}`);
  persist();
}

// -----------------------------------------------------------------
// Configurações da empresa (Etapa 15). Sem tabela correspondente no
// bd_competeV6.sql — ver nota de limitação em types/index.ts
// (ConfiguracaoEmpresa). Mesmo padrão de upsert de setEstoqueMinimo
// acima: uma única linha por empresa; se não houver, cria; se houver,
// atualiza.
// -----------------------------------------------------------------
export function getConfiguracaoEmpresa(empresaId: ID): ConfiguracaoEmpresa | null {
  return D().configuracoesEmpresa.find((c) => c.empresaId === empresaId) ?? null;
}

/**
 * Define o estoque padrão para entrada de matéria-prima da empresa
 * (seção 6 do prompt). `estoqueId` precisa pertencer à MESMA empresa
 * (seção 19 — segurança multi-tenant: nunca aceitar um estoque de
 * outra empresa aqui) e estar ativo (não faz sentido configurar como
 * padrão um estoque já inativo/removido).
 */
export function setEstoquePadraoEntradaMP(empresaId: ID, usuario: { id: ID; nome: string }, estoqueId: ID): ConfiguracaoEmpresa {
  const database = D();
  const estoque = database.estoques.find((e) => e.id === estoqueId && e.empresaId === empresaId);
  if (!estoque) throw new RepositoryError("Estoque não encontrado.");
  if (!estoque.ativo) throw new RepositoryError("Não é possível definir um estoque inativo como padrão.");

  let config = database.configuracoesEmpresa.find((c) => c.empresaId === empresaId);
  if (!config) {
    config = { empresaId, estoquePadraoEntradaMpId: estoqueId, atualizadoEm: nowISO() };
    database.configuracoesEmpresa.push(config);
  } else {
    config.estoquePadraoEntradaMpId = estoqueId;
    config.atualizadoEm = nowISO();
  }
  logAudit(empresaId, usuario, "EDICAO", "Configurações", `Definiu "${estoque.nome}" como estoque padrão para entrada de matéria-prima`);
  persist();
  return config;
  return row;
}

// -----------------------------------------------------------------
// Ficha técnica (BOM)
// -----------------------------------------------------------------
export function listComponentes(produtoPaiId: ID, empresaId: ID): ProdutoComponente[] {
  return D().componentes.filter((c) => c.produtoPaiId === produtoPaiId && c.empresaId === empresaId);
}
/**
 * Resumo agregado (contagem de ativos/inativos por produtoPaiId) para toda
 * a empresa, usado pela árvore Produto Pai → Variação da tela de Ficha
 * Técnica para saber, sem carregar os componentes de cada ficha, se uma
 * variação já tem ficha cadastrada e se ela está ativa ou inativa (item 15
 * do prompt: não carregar componentes detalhados de todas as fichas ao
 * abrir a listagem). Os componentes de uma ficha específica continuam
 * sendo buscados sob demanda via listComponentes, quando o usuário abre a
 * ficha de uma variação.
 */
export function listComponentesResumoPorPai(empresaId: ID): Record<ID, { ativos: number; inativos: number }> {
  const resumo: Record<ID, { ativos: number; inativos: number }> = {};
  for (const c of D().componentes) {
    if (c.empresaId !== empresaId) continue;
    const entry = resumo[c.produtoPaiId] ?? (resumo[c.produtoPaiId] = { ativos: 0, inativos: 0 });
    if (c.ativo) entry.ativos += 1;
    else entry.inativos += 1;
  }
  return resumo;
}
export function addComponente(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  data: { produtoPaiId: ID; produtoFilhoId: ID; setorId?: ID | null; quantidade: number; observacao?: string | null },
): ProdutoComponente {
  if (data.produtoPaiId === data.produtoFilhoId) throw new RepositoryError("Um componente não pode consumir a si mesmo.");
  if (data.quantidade <= 0) throw new RepositoryError("A quantidade deve ser maior que zero.");
  const database = D();
  const clash = database.componentes.find((c) => c.produtoPaiId === data.produtoPaiId && c.produtoFilhoId === data.produtoFilhoId);
  if (clash) throw new RepositoryError("Este componente já está na ficha técnica.");
  const item: ProdutoComponente = {
    id: nextIdFor(database.componentes),
    empresaId,
    produtoPaiId: data.produtoPaiId,
    produtoFilhoId: data.produtoFilhoId,
    setorId: data.setorId ?? null,
    quantidade: data.quantidade,
    observacao: data.observacao ?? null,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.componentes.push(item);
  logAudit(empresaId, usuario, "CRIACAO", "Ficha Técnica", "Adicionou um componente à ficha técnica");
  persist();
  return item;
}
export function updateComponente(id: ID, empresaId: ID, usuario: { id: ID; nome: string }, data: Partial<ProdutoComponente>) {
  const database = D();
  const item = database.componentes.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Componente não encontrado.");
  if (data.quantidade !== undefined && data.quantidade <= 0) throw new RepositoryError("A quantidade deve ser maior que zero.");
  Object.assign(item, data, { atualizadoEm: nowISO() });
  logAudit(empresaId, usuario, "EDICAO", "Ficha Técnica", "Atualizou um componente da ficha técnica");
  persist();
  return item;
}
export function toggleComponente(id: ID, empresaId: ID) {
  const item = D().componentes.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Componente não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// -----------------------------------------------------------------
// Fluxos de produção
// -----------------------------------------------------------------
export function listFluxos(empresaId: ID, includeInactive = false): FluxoProducao[] {
  return listByEmpresa(D().fluxos, empresaId, includeInactive);
}
export function listEtapasDoFluxo(fluxoId: ID, empresaId: ID): FluxoProducaoEtapa[] {
  return D()
    .fluxosEtapas.filter((e) => e.fluxoProducaoId === fluxoId && e.empresaId === empresaId)
    .sort((a, b) => a.sequencia - b.sequencia);
}
export function createFluxo(empresaId: ID, usuario: { id: ID; nome: string }, nome: string, descricao: string | null, etapasSetorIds: ID[]): FluxoProducao {
  const database = D();
  assertUniqueName(database.fluxos, empresaId, nome);
  if (etapasSetorIds.length === 0) throw new RepositoryError("Adicione ao menos uma etapa ao fluxo.");
  const fluxo: FluxoProducao = { id: nextIdFor(database.fluxos), empresaId, nome, descricao, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO() };
  database.fluxos.push(fluxo);
  etapasSetorIds.forEach((setorId, idx) => {
    database.fluxosEtapas.push({
      id: nextIdFor(database.fluxosEtapas),
      empresaId,
      fluxoProducaoId: fluxo.id,
      setorId,
      sequencia: idx + 1,
      ativo: true,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    });
  });
  logAudit(empresaId, usuario, "CRIACAO", "Fluxo de Produção", `Criou o fluxo "${nome}" com ${etapasSetorIds.length} etapa(s)`);
  persist();
  return fluxo;
}
export function updateFluxo(
  id: ID,
  empresaId: ID,
  usuario: { id: ID; nome: string },
  data: { nome?: string; descricao?: string | null; etapasSetorIds?: ID[] },
): FluxoProducao {
  const database = D();
  const fluxo = database.fluxos.find((f) => f.id === id && f.empresaId === empresaId);
  if (!fluxo) throw new RepositoryError("Fluxo não encontrado.");
  if (data.nome) assertUniqueName(database.fluxos, empresaId, data.nome, id);

  if (data.nome !== undefined) fluxo.nome = data.nome;
  if (data.descricao !== undefined) fluxo.descricao = data.descricao;

  if (data.etapasSetorIds) {
    if (data.etapasSetorIds.length === 0) throw new RepositoryError("Adicione ao menos uma etapa ao fluxo.");
    // As etapas do fluxo (fluxosEtapas) só são referenciadas por OPs depois
    // de "congeladas" em ordensProducaoEtapas no momento da liberação (ver
    // releaseOrdemProducao) — OPs já liberadas mantêm sua própria cópia e
    // não são afetadas por esta edição. É seguro substituir a lista aqui.
    database.fluxosEtapas = database.fluxosEtapas.filter((e) => !(e.fluxoProducaoId === id && e.empresaId === empresaId));
    data.etapasSetorIds.forEach((setorId, idx) => {
      database.fluxosEtapas.push({
        id: nextIdFor(database.fluxosEtapas),
        empresaId,
        fluxoProducaoId: id,
        setorId,
        sequencia: idx + 1,
        ativo: true,
        criadoEm: nowISO(),
        atualizadoEm: nowISO(),
      });
    });
  }

  fluxo.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, "EDICAO", "Fluxo de Produção", `Editou o fluxo "${fluxo.nome}"`);
  persist();
  return fluxo;
}
export function toggleFluxo(id: ID, empresaId: ID): FluxoProducao {
  const item = D().fluxos.find((f) => f.id === id && f.empresaId === empresaId);
  if (!item) throw new RepositoryError("Fluxo não encontrado.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  persist();
  return item;
}

// -----------------------------------------------------------------
// Ordens de produção — execução
// -----------------------------------------------------------------
export function listOrdensProducao(empresaId: ID): OrdemProducao[] {
  return D().ordensProducao.filter((op) => op.empresaId === empresaId).sort((a, b) => (a.dataAbertura < b.dataAbertura ? 1 : -1));
}
export function getOrdemProducao(id: ID, empresaId: ID) {
  return D().ordensProducao.find((op) => op.id === id && op.empresaId === empresaId);
}
export function listEtapasDaOP(opId: ID, empresaId: ID) {
  return D()
    .ordensProducaoEtapas.filter((e) => e.ordemProducaoId === opId && e.empresaId === empresaId)
    .sort((a, b) => a.sequencia - b.sequencia);
}
export function listMovimentacoesDaOP(opId: ID, empresaId: ID) {
  return D()
    .movimentacoesProducao.filter((m) => m.ordemProducaoId === opId && m.empresaId === empresaId)
    .sort((a, b) => (a.dataMovimentacao < b.dataMovimentacao ? 1 : -1));
}
/** Todas as movimentações de produção da empresa (todas as OPs) — usado nos gráficos do Dashboard. */
export function listMovimentacoesProducao(empresaId: ID) {
  return D()
    .movimentacoesProducao.filter((m) => m.empresaId === empresaId)
    .sort((a, b) => (a.dataMovimentacao < b.dataMovimentacao ? 1 : -1));
}

export function createOrdemProducao(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: CreateProductionOrderPayload,
): OrdemProducao {
  const database = D();
  if (!Number.isInteger(payload.quantidadePrevista) || payload.quantidadePrevista <= 0) {
    throw new RepositoryError("Quantidade prevista deve ser um número inteiro maior que zero.");
  }
  const variacao = database.variacoes.find((v) => v.id === payload.produtoVariacaoId && v.empresaId === empresaId);
  if (!variacao) throw new RepositoryError("Produto/SKU não encontrado.");
  const produto = database.produtos.find((p) => p.id === variacao.produtoId && p.empresaId === empresaId);
  if (!produto || (produto.tipo !== "PC" && produto.tipo !== "SC")) {
    throw new RepositoryError("Somente produtos de confecção ou semiacabados podem ser produzidos em uma OP.");
  }
  const fluxo = database.fluxos.find((f) => f.id === payload.fluxoProducaoId && f.empresaId === empresaId);
  if (!fluxo) throw new RepositoryError("Fluxo de produção não encontrado.");
  const seq = database.ordensProducao.filter((op) => op.empresaId === empresaId).length + 1;
  const codigo = `OP-${pad(seq)}`;
  const op: OrdemProducao = {
    id: nextIdFor(database.ordensProducao),
    empresaId,
    codigo,
    produtoVariacaoId: payload.produtoVariacaoId,
    fluxoProducaoId: payload.fluxoProducaoId,
    etapaAtualId: null,
    estoqueOrigemId: payload.estoqueOrigemId ?? null,
    estoqueDestinoId: payload.estoqueDestinoId ?? null,
    status: "PLANEJADA",
    quantidadePrevista: payload.quantidadePrevista,
    quantidadeProduzida: 0,
    quantidadeRefugada: 0,
    lote: payload.lote ?? null,
    dataAbertura: payload.dataAbertura,
    observacao: payload.observacao ?? null,
    usuarioId: usuario.id,
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.ordensProducao.push(op);
  logAudit(empresaId, usuario, "CRIACAO", "Ordem de Produção", `Criou a ${codigo} (${payload.quantidadePrevista} un.), aguardando liberação`);
  persist();
  return op;
}

/**
 * Quanto já foi efetivamente consumido (Kardex PRODUCAO_CONSUMO) de um
 * componente para uma OP específica. Não há uma tabela de "reserva" no
 * banco — quantidade_reservada é um agregado por (variação, estoque).
 * O quanto ESTA OP já consumiu deste componente é sempre derivável do
 * próprio Kardex (fonte de verdade), então não precisamos inventar
 * nenhuma estrutura nova para rastrear isso.
 */
function consumoJaLancado(empresaId: ID, ordemProducaoId: ID, produtoVariacaoId: ID): number {
  return D()
    .kardex.filter(
      (k) =>
        k.empresaId === empresaId &&
        k.ordemProducaoId === ordemProducaoId &&
        k.produtoVariacaoId === produtoVariacaoId &&
        k.natureza === "PRODUCAO_CONSUMO" &&
        k.sentido === "SAIDA",
    )
    .reduce((acc, k) => acc + k.quantidade, 0);
}

/**
 * Reserva (produto_estoque.quantidade_reservada) os componentes da ficha
 * técnica do produto pai de uma OP, no estoque de origem. Não consome —
 * regra 16 do prompt mestre: "reserva não é consumo". Se faltar saldo,
 * reserva o que houver e devolve um aviso (nunca bloqueia a liberação).
 */
function reservarComponentesDaOP(empresaId: ID, op: OrdemProducao, avisos: string[]) {
  if (!op.estoqueOrigemId) return;
  const database = D();
  const componentes = database.componentes.filter((c) => c.produtoPaiId === op.produtoVariacaoId && c.ativo);
  for (const comp of componentes) {
    const necessario = comp.quantidade * op.quantidadePrevista;
    const saldoRow = getSaldoRow(comp.produtoFilhoId, op.estoqueOrigemId, empresaId);
    const disponivel = Math.max(0, saldoRow.quantidade - saldoRow.quantidadeReservada);
    const reservar = Math.min(necessario, disponivel);
    if (reservar > 0) {
      saldoRow.quantidadeReservada += reservar;
      saldoRow.atualizadoEm = nowISO();
    }
    if (reservar < necessario - 1e-9) {
      const variacaoComp = database.variacoes.find((v) => v.id === comp.produtoFilhoId);
      const produtoComp = variacaoComp ? database.produtos.find((p) => p.id === variacaoComp.produtoId) : undefined;
      avisos.push(
        `Estoque insuficiente de ${produtoComp?.nome ?? "componente"} (${variacaoComp?.sku ?? comp.produtoFilhoId}): reservado ${reservar} de ${necessario} necessários — faltam ${(necessario - reservar).toFixed(2)}.`,
      );
    }
  }
}

/**
 * Consome (baixa físico + Kardex PRODUCAO_CONSUMO) os componentes ativos
 * da ficha técnica do produto pai de uma OP que ainda estejam pendentes,
 * opcionalmente restritos a um setor específico. Baixa também a reserva
 * feita na liberação. Nunca bloqueia: se a reserva não cobrir o
 * necessário, consome o que houver de saldo físico e devolve um aviso.
 */
function consumirComponentesPendentes(
  empresaId: ID,
  op: OrdemProducao,
  usuario: { id: ID; nome: string },
  avisos: string[],
  setorId?: ID | null,
) {
  if (!op.estoqueOrigemId) return;
  const database = D();
  const componentes = database.componentes.filter(
    (c) => c.produtoPaiId === op.produtoVariacaoId && c.ativo && (setorId === undefined || c.setorId === setorId),
  );
  for (const comp of componentes) {
    const necessario = comp.quantidade * op.quantidadePrevista;
    const jaConsumido = consumoJaLancado(empresaId, op.id, comp.produtoFilhoId);
    const pendente = necessario - jaConsumido;
    if (pendente <= 1e-9) continue;

    const saldoRow = getSaldoRow(comp.produtoFilhoId, op.estoqueOrigemId, empresaId);
    // Não consumir mais do que foi reservado para esta OP, nem mais do
    // que existe fisicamente — o que for menor.
    const consumir = Math.max(0, Math.min(pendente, saldoRow.quantidadeReservada, saldoRow.quantidade));
    if (consumir > 0) {
      applyKardexAndBalance(empresaId, comp.produtoFilhoId, op.estoqueOrigemId, "SAIDA", "PRODUCAO_CONSUMO", consumir, {
        ordemProducaoId: op.id,
        usuarioId: usuario.id,
        observacao: `Consumo de ficha técnica — ${op.codigo}`,
      });
      saldoRow.quantidadeReservada = Math.max(0, saldoRow.quantidadeReservada - consumir);
      saldoRow.atualizadoEm = nowISO();
    }
    if (consumir < pendente - 1e-9) {
      const variacaoComp = database.variacoes.find((v) => v.id === comp.produtoFilhoId);
      const produtoComp = variacaoComp ? database.produtos.find((p) => p.id === variacaoComp.produtoId) : undefined;
      avisos.push(
        `Consumo parcial de ${produtoComp?.nome ?? "componente"} (${variacaoComp?.sku ?? comp.produtoFilhoId}): consumido ${consumir} de ${pendente.toFixed(2)} pendentes — faltam ${(pendente - consumir).toFixed(2)}.`,
      );
    }
  }
}

/**
 * Libera de volta ao estoque disponível toda reserva de componentes
 * ainda pendente de consumo desta OP (usado no cancelamento — regra 25:
 * não deixar saldo "preso" numa OP cancelada).
 */
function liberarReservasPendentesDaOP(empresaId: ID, op: OrdemProducao) {
  if (!op.estoqueOrigemId) return;
  const database = D();
  const componentes = database.componentes.filter((c) => c.produtoPaiId === op.produtoVariacaoId && c.ativo);
  for (const comp of componentes) {
    const necessario = comp.quantidade * op.quantidadePrevista;
    const jaConsumido = consumoJaLancado(empresaId, op.id, comp.produtoFilhoId);
    const pendente = necessario - jaConsumido;
    if (pendente <= 1e-9) continue;
    const saldoRow = getSaldoRow(comp.produtoFilhoId, op.estoqueOrigemId, empresaId);
    const liberar = Math.min(pendente, saldoRow.quantidadeReservada);
    if (liberar > 0) {
      saldoRow.quantidadeReservada = Math.max(0, saldoRow.quantidadeReservada - liberar);
      saldoRow.atualizadoEm = nowISO();
    }
  }
}

export function releaseOrdemProducao(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): { op: OrdemProducao; avisos: string[] } {
  const database = D();
  const op = database.ordensProducao.find((o) => o.id === id && o.empresaId === empresaId);
  if (!op) throw new RepositoryError("Ordem de produção não encontrada.");
  if (op.status !== "PLANEJADA") throw new RepositoryError("Somente OPs planejadas podem ser liberadas.");

  const etapasFluxo = listEtapasDoFluxo(op.fluxoProducaoId, empresaId);
  if (etapasFluxo.length === 0) throw new RepositoryError("O fluxo selecionado não possui etapas.");

  // snapshot das etapas do fluxo para a OP
  const criadas: OrdemProducaoEtapa[] = etapasFluxo.map((fe, idx) =>
    ({
      id: nextIdFor(database.ordensProducaoEtapas) + idx,
      empresaId,
      ordemProducaoId: op.id,
      setorId: fe.setorId,
      sequencia: fe.sequencia,
      status: "AGUARDANDO",
      quantidadePrevista: op.quantidadePrevista,
      quantidadeRecebida: 0,
      quantidadeConcluida: 0,
      quantidadePerdida: 0,
      dataEntrada: null,
      dataSaida: null,
      usuarioResponsavelId: null,
      fornecedorId: null,
      observacao: null,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    }),
  );
  database.ordensProducaoEtapas.push(...criadas);

  const primeira = criadas[0];
  primeira.status = "EM_EXECUCAO";
  primeira.quantidadeRecebida = op.quantidadePrevista;
  primeira.dataEntrada = nowISO();

  op.status = "LIBERADA";
  op.etapaAtualId = primeira.id;
  op.atualizadoEm = nowISO();

  database.movimentacoesProducao.push({
    id: nextIdFor(database.movimentacoesProducao),
    empresaId,
    ordemProducaoId: op.id,
    etapaOrigemId: null,
    etapaDestinoId: primeira.id,
    setorOrigemId: null,
    setorDestinoId: primeira.setorId,
    tipo: "TRANSFERENCIA",
    quantidade: op.quantidadePrevista,
    quantidadePerdida: 0,
    motivoPerdaId: null,
    dataMovimentacao: nowISO(),
    usuarioId: usuario.id,
    observacao: "Liberação da OP",
    criadoEm: nowISO(),
  });

  // Reserva os componentes da ficha técnica no estoque de origem — ainda
  // NÃO consome. O consumo de cada componente acontece na conclusão da
  // etapa cujo setor bate com produto_componente.setor_id (ou da 1ª
  // etapa, se setor_id for NULL — comentário original do banco).
  const avisos: string[] = [];
  reservarComponentesDaOP(empresaId, op, avisos);

  op.status = "EM_PRODUCAO";
  if (avisos.length > 0) {
    logAudit(empresaId, usuario, "PRODUCAO", "Ordem de Produção", `Liberou a ${op.codigo} com ${avisos.length} alerta(s) de estoque insuficiente para reserva`);
  } else {
    logAudit(empresaId, usuario, "PRODUCAO", "Ordem de Produção", `Liberou a ${op.codigo} para produção`);
  }
  persist();
  return { op, avisos };
}

export function moveProductionOrder(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: ProductionMovePayload,
): { op: OrdemProducao; avisos: string[] } {
  const database = D();
  const op = database.ordensProducao.find((o) => o.id === payload.ordemProducaoId && o.empresaId === empresaId);
  if (!op) throw new RepositoryError("Ordem de produção não encontrada.");
  // Reforço explícito (auditoria da Etapa 9): sem isso, uma OP cancelada só
  // ficava protegida "por acidente" — cancelOrdemProducao zera etapaAtualId,
  // e o check abaixo (!op.etapaAtualId) barrava a movimentação, mas com uma
  // mensagem genérica que não explica o motivo real. Deixando explícito para
  // não depender desse efeito colateral caso etapaAtualId volte a existir em
  // algum refactor futuro, e para dar um erro claro ao usuário.
  if (op.status === "CANCELADA" || op.status === "CONCLUIDA") {
    throw new RepositoryError("Esta OP já foi encerrada e não pode receber novas movimentações.");
  }
  if (!op.etapaAtualId) throw new RepositoryError("Esta OP não possui uma etapa ativa.");
  const etapaAtual = database.ordensProducaoEtapas.find((e) => e.id === op.etapaAtualId);
  if (!etapaAtual) throw new RepositoryError("Etapa atual não encontrada.");

  if (!Number.isInteger(payload.quantidadeEnviada) || payload.quantidadeEnviada < 0) {
    throw new RepositoryError("A quantidade enviada deve ser um número inteiro maior ou igual a zero.");
  }
  if (!Number.isInteger(payload.quantidadePerdida) || payload.quantidadePerdida < 0) {
    throw new RepositoryError("A quantidade perdida deve ser um número inteiro maior ou igual a zero.");
  }

  const disponivel = etapaAtual.quantidadeRecebida - etapaAtual.quantidadeConcluida - etapaAtual.quantidadePerdida;
  const total = payload.quantidadeEnviada + payload.quantidadePerdida;
  if (total <= 0) throw new RepositoryError("Informe a quantidade enviada e/ou perdida.");
  if (total > disponivel + 1e-9) {
    throw new RepositoryError(`A quantidade enviada + perdida (${total}) não pode ultrapassar o disponível na etapa (${disponivel}).`);
  }
  if (payload.quantidadePerdida > 0 && !payload.motivoPerdaId) {
    throw new RepositoryError("Selecione o motivo da perda.");
  }

  const avisos: string[] = [];

  etapaAtual.quantidadeConcluida += payload.quantidadeEnviada;
  etapaAtual.quantidadePerdida += payload.quantidadePerdida;
  const etapaEsgotada = etapaAtual.quantidadeConcluida + etapaAtual.quantidadePerdida >= etapaAtual.quantidadeRecebida - 1e-9;
  if (etapaEsgotada) {
    etapaAtual.status = "CONCLUIDA";
    etapaAtual.dataSaida = nowISO();
    // Consome os componentes da ficha técnica cujo setor bate com o
    // setor desta etapa — e, se for a 1ª etapa, também os componentes
    // sem setor definido (setor_id NULL — comentário original do banco).
    consumirComponentesPendentes(empresaId, op, usuario, avisos, etapaAtual.setorId);
    if (etapaAtual.sequencia === 1) {
      consumirComponentesPendentes(empresaId, op, usuario, avisos, null);
    }
  }
  etapaAtual.atualizadoEm = nowISO();

  if (payload.quantidadePerdida > 0) {
    op.quantidadeRefugada += payload.quantidadePerdida;
  }

  const todasEtapas = listEtapasDaOP(op.id, empresaId);
  const proxima = todasEtapas.find((e) => e.sequencia === etapaAtual.sequencia + 1);

  const mv: MovimentacaoProducao = {
    id: nextIdFor(database.movimentacoesProducao),
    empresaId,
    ordemProducaoId: op.id,
    etapaOrigemId: etapaAtual.id,
    etapaDestinoId: proxima?.id ?? null,
    setorOrigemId: etapaAtual.setorId,
    setorDestinoId: proxima?.setorId ?? null,
    tipo: "TRANSFERENCIA",
    quantidade: payload.quantidadeEnviada,
    quantidadePerdida: payload.quantidadePerdida,
    motivoPerdaId: payload.motivoPerdaId ?? null,
    dataMovimentacao: nowISO(),
    usuarioId: usuario.id,
    observacao: payload.observacao ?? null,
    criadoEm: nowISO(),
  };
  database.movimentacoesProducao.push(mv);

  // Consumo real de matérias-primas informado pelo usuário nesta mesma
  // movimentação (etapa "Registrar consumo de matéria-prima" — item 3 do
  // prompt). Reaproveita o mesmo mecanismo de baixa/Kardex já usado pelo
  // consumo automático da ficha técnica (applyKardexAndBalance, natureza
  // PRODUCAO_CONSUMO), só que vinculado a esta movimentação específica —
  // isso é o que evita dupla baixa (regra 18): reenviar o formulário gera
  // uma nova movimentação com novo id, nunca reaplica esta mesma. Não
  // exige que o material esteja na ficha técnica (regra 4) e nunca
  // bloqueia por saldo insuficiente — mesma política de "nunca ir
  // negativo, mas nunca travar" já usada em consumirComponentesPendentes:
  // baixa o que houver de saldo e registra um aviso quando o informado
  // for maior (a confirmação de "quer continuar mesmo assim" já aconteceu
  // na tela antes de chegar aqui).
  if (payload.consumos && payload.consumos.length > 0 && op.estoqueOrigemId) {
    for (const item of payload.consumos) {
      if (!item.quantidade || item.quantidade <= 0) continue;
      const materialVariacao = database.variacoes.find((v) => v.id === item.produtoVariacaoId && v.empresaId === empresaId);
      if (!materialVariacao) continue;
      const saldoRow = getSaldoRow(item.produtoVariacaoId, op.estoqueOrigemId, empresaId);
      const consumir = Math.min(item.quantidade, Math.max(0, saldoRow.quantidade));
      if (consumir > 0) {
        applyKardexAndBalance(empresaId, item.produtoVariacaoId, op.estoqueOrigemId, "SAIDA", "PRODUCAO_CONSUMO", consumir, {
          ordemProducaoId: op.id,
          movimentacaoProducaoId: mv.id,
          usuarioId: usuario.id,
          observacao: `Consumo registrado na etapa — ${op.codigo}`,
        });
      }
      if (consumir < item.quantidade - 1e-9) {
        const materialProduto = database.produtos.find((p) => p.id === materialVariacao.produtoId);
        avisos.push(
          `Estoque insuficiente de ${materialProduto?.nome ?? "material"} (${materialVariacao.sku}): baixado ${consumir} de ${item.quantidade} informados — faltaram ${(item.quantidade - consumir).toFixed(2)}.`,
        );
      }
    }
  }

  if (proxima) {
    proxima.quantidadeRecebida += payload.quantidadeEnviada;
    if (proxima.status === "AGUARDANDO") {
      proxima.status = "EM_EXECUCAO";
      proxima.dataEntrada = nowISO();
    }
    proxima.atualizadoEm = nowISO();
    // BUG CORRIGIDO NA ETAPA 7: antes, a OP "pulava" para a próxima etapa
    // em QUALQUER movimentação com envio > 0, mesmo quando a etapa atual
    // ainda tinha saldo pendente (ex.: recebida=10, enviou só 4 — a OP já
    // virava etapa 2, e os 6 restantes da etapa 1 ficavam órfãos, sem
    // como serem lançados pela tela, já que o formulário de movimentação
    // sempre usa etapaAtualId). Isso quebrava o caso de múltiplas
    // movimentações parciais na mesma etapa (regra 18 do prompt mestre).
    // Agora só trocamos o "ponteiro" de etapa ativa da OP quando a etapa
    // atual realmente se esgotou; até lá, a produção segue sendo
    // encaminhada fisicamente para a próxima etapa (quantidade_recebida
    // acumula normalmente), mas o formulário continua preso à etapa que
    // ainda não fechou.
    if (etapaEsgotada) {
      op.status = "EM_PRODUCAO";
      // BUG REAL ENCONTRADO NA AUDITORIA DA ETAPA 8 (refugo/fracionamento):
      // se TODA a leva de uma etapa vira refugo (quantidade_enviada = 0 em
      // todas as movimentações até esgotar), a próxima etapa nunca recebe
      // nenhuma peça (quantidade_recebida permanece 0), mas mesmo assim
      // virava a etapa "atual" da OP. Como o formulário sempre exige
      // quantidade enviada + perdida > 0, essa etapa fantasma jamais
      // poderia ser fechada — a OP ficava presa para sempre. Encadeamos
      // aqui o fechamento automático de etapas que nascem já esgotadas
      // (0 recebido) até achar uma etapa com material de fato, ou até o
      // fim do fluxo — quando a OP é concluída direto, sem produto
      // acabado adicional (nada sobrou para produzir).
      let destino: OrdemProducaoEtapa | undefined = proxima;
      while (destino && destino.quantidadeRecebida - destino.quantidadeConcluida - destino.quantidadePerdida <= 1e-9) {
        destino.status = "CONCLUIDA";
        destino.dataEntrada = destino.dataEntrada ?? nowISO();
        destino.dataSaida = nowISO();
        destino.atualizadoEm = nowISO();
        consumirComponentesPendentes(empresaId, op, usuario, avisos, destino.setorId);
        destino = todasEtapas.find((e) => e.sequencia === destino!.sequencia + 1);
      }
      if (destino) {
        op.etapaAtualId = destino.id;
      } else {
        // O encadeamento consumiu todas as etapas restantes sem sobrar
        // nenhuma peça boa — conclui a OP diretamente.
        consumirComponentesPendentes(empresaId, op, usuario, avisos);
        op.status = "CONCLUIDA";
        op.etapaAtualId = null;
      }
    }
  } else {
    // Última etapa: entrada de produto acabado no estoque destino
    op.quantidadeProduzida += payload.quantidadeEnviada;
    if (op.estoqueDestinoId && payload.quantidadeEnviada > 0) {
      applyKardexAndBalance(empresaId, op.produtoVariacaoId, op.estoqueDestinoId, "ENTRADA", "PRODUCAO_ENTRADA", payload.quantidadeEnviada, {
        ordemProducaoId: op.id,
        usuarioId: usuario.id,
        observacao: `Conclusão de etapa final — ${op.codigo}`,
      });
    }
    const totalProcessado = op.quantidadeProduzida + op.quantidadeRefugada;
    if (totalProcessado >= op.quantidadePrevista - 1e-9) {
      // Rede de segurança: garante que nenhum componente fique com
      // reserva presa por causa de um setor_id que não bate com
      // nenhuma etapa do fluxo desta OP.
      consumirComponentesPendentes(empresaId, op, usuario, avisos);
      op.status = "CONCLUIDA";
      op.etapaAtualId = null;
    }
  }
  op.atualizadoEm = nowISO();

  if (payload.quantidadePerdida > 0) {
    const variacao = database.variacoes.find((v) => v.id === op.produtoVariacaoId);
    const produto = variacao ? database.produtos.find((p) => p.id === variacao.produtoId) : undefined;
    logAudit(empresaId, usuario, "REFUGO", "Ordem de Produção", `Registrou ${payload.quantidadePerdida} peça(s) refugada(s) na ${etapaAtual.sequencia}ª etapa da ${op.codigo} (${produto?.nome ?? ""})`);
  }
  logAudit(empresaId, usuario, "PRODUCAO", "Ordem de Produção", `Movimentou ${payload.quantidadeEnviada} un. da ${op.codigo}${proxima ? "" : " — conclusão"}`);
  persist();
  return { op, avisos };
}

export function cancelOrdemProducao(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): OrdemProducao {
  const database = D();
  const op = database.ordensProducao.find((o) => o.id === id && o.empresaId === empresaId);
  if (!op) throw new RepositoryError("Ordem de produção não encontrada.");
  if (op.status === "CONCLUIDA" || op.status === "CANCELADA") {
    throw new RepositoryError("Esta OP não pode mais ser cancelada.");
  }
  // Libera de volta ao disponível qualquer reserva de componente que
  // ainda não tenha sido consumida — não deixa saldo preso numa OP
  // cancelada (regra 25: preferir inativar/cancelar sem efeitos colaterais
  // permanentes no restante do sistema).
  liberarReservasPendentesDaOP(empresaId, op);
  op.status = "CANCELADA";
  op.etapaAtualId = null;
  op.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, "EDICAO", "Ordem de Produção", `Cancelou a ${op.codigo}`);
  persist();
  return op;
}

export function pauseResumeOrdemProducao(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): OrdemProducao {
  const database = D();
  const op = database.ordensProducao.find((o) => o.id === id && o.empresaId === empresaId);
  if (!op) throw new RepositoryError("Ordem de produção não encontrada.");
  if (op.status === "EM_PRODUCAO") op.status = "PAUSADA";
  else if (op.status === "PAUSADA") op.status = "EM_PRODUCAO";
  else throw new RepositoryError("Só é possível pausar/retomar OPs em produção.");
  op.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, "EDICAO", "Ordem de Produção", `${op.status === "PAUSADA" ? "Pausou" : "Retomou"} a ${op.codigo}`);
  persist();
  return op;
}

// -----------------------------------------------------------------
// Entrada direta de produto acabado (fora de uma OP)
// -----------------------------------------------------------------
export function finishedGoodsDirectEntry(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: FinishedGoodsEntryPayload,
) {
  if (payload.quantidade <= 0) throw new RepositoryError("A quantidade deve ser maior que zero.");
  applyKardexAndBalance(
    empresaId,
    payload.produtoVariacaoId,
    payload.estoqueId,
    "ENTRADA",
    payload.ordemProducaoId ? "PRODUCAO_ENTRADA" : "AJUSTE",
    payload.quantidade,
    { ordemProducaoId: payload.ordemProducaoId ?? null, usuarioId: usuario.id, observacao: payload.observacao || "Entrada direta de produto acabado" },
  );
  const database = D();
  const variacao = database.variacoes.find((v) => v.id === payload.produtoVariacaoId);
  const produto = variacao ? database.produtos.find((p) => p.id === variacao.produtoId) : undefined;
  logAudit(empresaId, usuario, "ENTRADA", "Estoque", `Entrada direta de ${payload.quantidade} un. de ${produto?.nome ?? "produto"} (${variacao?.sku})`);
  persist();
}

// -----------------------------------------------------------------
// Compras — notas fiscais de entrada
// -----------------------------------------------------------------
export function listNotasFiscais(empresaId: ID): NotaFiscal[] {
  return D()
    .notasFiscais.filter((n) => n.empresaId === empresaId)
    .sort((a, b) => (a.dataEmissao < b.dataEmissao ? 1 : -1));
}
export function listItensDaNota(notaId: ID, empresaId: ID) {
  return D().notasFiscaisItens.filter((i) => i.notaFiscalId === notaId && i.empresaId === empresaId);
}

/**
 * Valida a lista de itens de uma nota fiscal (criação ou edição) —
 * quantidade > 0, valor unitário >= 0 e SEM SKU duplicado dentro da
 * mesma nota, espelhando a UNIQUE (nota_fiscal_id, produto_variacao_id)
 * de nota_fiscal_item no bd_competeV6.sql. Lança ANTES de qualquer
 * mutação no banco em memória — usada por createNotaFiscal e
 * updateNotaFiscal para não deixar o `database` num estado parcial se
 * um item no meio da lista for inválido (BUG REAL ENCONTRADO NA
 * AUDITORIA DA ETAPA 11: createNotaFiscal fazia `push` da nota E dos
 * itens válidos ANTES de validar os itens seguintes — se um item no
 * meio da lista fosse inválido, a nota e os itens já processados
 * ficavam "presos" no `database` em memória, mesmo sem persist() ter
 * sido chamado, corrompendo o estado para a próxima operação).
 */
function validarItensNota(itens: CreatePurchaseNotePayload["itens"]): void {
  if (itens.length === 0) throw new RepositoryError("Adicione ao menos um item à nota.");
  const skusVistos = new Set<ID>();
  for (const item of itens) {
    if (item.quantidade <= 0) throw new RepositoryError("Quantidade do item deve ser maior que zero.");
    if (item.valorUnitario < 0) throw new RepositoryError("Valor unitário não pode ser negativo.");
    if (skusVistos.has(item.produtoVariacaoId)) {
      throw new RepositoryError("Esta nota já possui um item com este SKU. Some a quantidade no item existente em vez de duplicá-lo.");
    }
    skusVistos.add(item.produtoVariacaoId);
  }
}

export function createNotaFiscal(
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: CreatePurchaseNotePayload,
): NotaFiscal {
  const database = D();
  validarItensNota(payload.itens);
  const clash = database.notasFiscais.find((n) => n.empresaId === empresaId && n.fornecedorId === payload.fornecedorId && n.numero === payload.numero);
  if (clash) throw new RepositoryError("Já existe uma nota com este número para este fornecedor.");

  const valorTotal = payload.itens.reduce((sum, i) => sum + i.quantidade * i.valorUnitario, 0);
  const nota: NotaFiscal = {
    id: nextIdFor(database.notasFiscais),
    empresaId,
    numero: payload.numero,
    chaveAcesso: payload.chaveAcesso ?? null,
    fornecedorId: payload.fornecedorId,
    estoqueId: payload.estoqueId,
    dataEmissao: payload.dataEmissao,
    dataEntrada: null,
    valorTotal,
    observacao: payload.observacao ?? null,
    status: "ABERTA",
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.notasFiscais.push(nota);
  for (const item of payload.itens) {
    database.notasFiscaisItens.push({
      id: nextIdFor(database.notasFiscaisItens),
      empresaId,
      notaFiscalId: nota.id,
      produtoVariacaoId: item.produtoVariacaoId,
      unidadeMedidaId: item.unidadeMedidaId,
      quantidade: item.quantidade,
      valorUnitario: item.valorUnitario,
      valorTotal: item.quantidade * item.valorUnitario,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    });
  }
  logAudit(empresaId, usuario, "CRIACAO", "Nota Fiscal", `Lançou a nota ${nota.numero}, em aberto`);
  persist();
  return nota;
}

/**
 * Edita uma nota fiscal EM_ABERTO (regra 21 do prompt mestre: "Nota
 * EM_ABERTO: pode ser editada. Não altera estoque."). Lacuna real
 * encontrada na auditoria da Etapa 11 — só existiam createNotaFiscal,
 * completeNotaFiscal e cancelNotaFiscal; não havia NENHUMA forma de
 * corrigir número, fornecedor, itens etc. de uma nota antes de
 * concluí-la. Substitui a lista de itens inteira (mesmo padrão de
 * "replace" que o formulário da tela já usa para montar o payload de
 * criação) — não faz merge parcial de itens.
 */
export function updateNotaFiscal(
  id: ID,
  empresaId: ID,
  usuario: { id: ID; nome: string },
  payload: CreatePurchaseNotePayload,
): NotaFiscal {
  const database = D();
  const nota = database.notasFiscais.find((n) => n.id === id && n.empresaId === empresaId);
  if (!nota) throw new RepositoryError("Nota fiscal não encontrada.");
  if (nota.status !== "ABERTA") throw new RepositoryError("Somente notas em aberto podem ser editadas.");

  validarItensNota(payload.itens);
  const clash = database.notasFiscais.find(
    (n) => n.id !== id && n.empresaId === empresaId && n.fornecedorId === payload.fornecedorId && n.numero === payload.numero,
  );
  if (clash) throw new RepositoryError("Já existe uma nota com este número para este fornecedor.");

  nota.numero = payload.numero;
  nota.chaveAcesso = payload.chaveAcesso ?? null;
  nota.fornecedorId = payload.fornecedorId;
  nota.estoqueId = payload.estoqueId;
  nota.dataEmissao = payload.dataEmissao;
  nota.observacao = payload.observacao ?? null;
  nota.valorTotal = payload.itens.reduce((sum, i) => sum + i.quantidade * i.valorUnitario, 0);
  nota.atualizadoEm = nowISO();

  // Substitui os itens (a nota ainda está ABERTA — nenhum Kardex/saldo
  // foi gerado a partir dela ainda, então não há nada para reverter).
  database.notasFiscaisItens = database.notasFiscaisItens.filter((i) => i.notaFiscalId !== id);
  for (const item of payload.itens) {
    database.notasFiscaisItens.push({
      id: nextIdFor(database.notasFiscaisItens),
      empresaId,
      notaFiscalId: nota.id,
      produtoVariacaoId: item.produtoVariacaoId,
      unidadeMedidaId: item.unidadeMedidaId,
      quantidade: item.quantidade,
      valorUnitario: item.valorUnitario,
      valorTotal: item.quantidade * item.valorUnitario,
      criadoEm: nowISO(),
      atualizadoEm: nowISO(),
    });
  }
  logAudit(empresaId, usuario, "EDICAO", "Nota Fiscal", `Editou a nota ${nota.numero} (em aberto — estoque não alterado)`);
  persist();
  return nota;
}

export function completeNotaFiscal(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): NotaFiscal {
  const database = D();
  const nota = database.notasFiscais.find((n) => n.id === id && n.empresaId === empresaId);
  if (!nota) throw new RepositoryError("Nota fiscal não encontrada.");
  if (nota.status !== "ABERTA") throw new RepositoryError("Somente notas em aberto podem ser concluídas.");
  const itens = listItensDaNota(id, empresaId);
  for (const item of itens) {
    applyKardexAndBalance(empresaId, item.produtoVariacaoId, nota.estoqueId, "ENTRADA", "COMPRA", item.quantidade, {
      notaFiscalItemId: item.id,
      usuarioId: usuario.id,
      observacao: `Nota fiscal ${nota.numero}`,
    });
  }
  nota.status = "CONCLUIDA";
  nota.dataEntrada = nowISO();
  nota.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, "CONCLUSAO_COMPRA", "Nota Fiscal", `Concluiu a nota ${nota.numero} — estoque atualizado`);
  persist();
  return nota;
}

export function cancelNotaFiscal(id: ID, empresaId: ID, usuario: { id: ID; nome: string }): NotaFiscal {
  const database = D();
  const nota = database.notasFiscais.find((n) => n.id === id && n.empresaId === empresaId);
  if (!nota) throw new RepositoryError("Nota fiscal não encontrada.");
  if (nota.status !== "ABERTA") throw new RepositoryError("Somente notas em aberto podem ser canceladas.");
  nota.status = "CANCELADA";
  nota.atualizadoEm = nowISO();
  logAudit(empresaId, usuario, "EDICAO", "Nota Fiscal", `Cancelou a nota ${nota.numero}`);
  persist();
  return nota;
}

// -----------------------------------------------------------------
// Equipe (usuários + cargos) — somente ADMIN na UI
// -----------------------------------------------------------------
export function listUsuarios(empresaId: ID, includeInactive = false): Usuario[] {
  return listByEmpresa(D().usuarios, empresaId, includeInactive);
}
export function listCargos(empresaId: ID): Cargo[] {
  return D().cargos.filter((c) => c.empresaId === empresaId && c.ativo);
}

// ---- Cargos e permissões ------------------------------------------
// Camada extra de segurança (seção 18 do prompt): a proteção real
// contra escalada de privilégio não pode confiar só na UI, então toda
// operação de escrita sobre cargo abaixo revalida, aqui no repositório,
// que o ator (a) tem a permissão administrativa de equipe e (b) só
// concede permissões que ele próprio já possui.
function getActorContext(empresaId: ID, actorId: ID): { cargo: Cargo | undefined; permissoes: Set<string> } {
  const database = D();
  const usuario = database.usuarios.find((u) => u.id === actorId && u.empresaId === empresaId);
  const cargo = usuario ? database.cargos.find((c) => c.id === usuario.cargoId && c.empresaId === empresaId) : undefined;
  const permissoes = new Set(
    cargo ? database.permissoes.filter((p) => cargo.permissaoIds.includes(p.id)).map((p) => p.nome) : [],
  );
  return { cargo, permissoes };
}

function assertCanManageCargos(empresaId: ID, actor: { id: ID; nome: string }) {
  const { permissoes } = getActorContext(empresaId, actor.id);
  if (!permissoes.has(PERMISSIONS.TEAM_MANAGE)) {
    throw new RepositoryError("Você não tem permissão para administrar cargos e permissões.");
  }
}

/** Garante que o ator não está concedendo a um cargo uma permissão que ele mesmo não possui. */
function assertNoPrivilegeEscalation(empresaId: ID, actor: { id: ID; nome: string }, permissaoIds: ID[]) {
  const { cargo: actorCargo, permissoes: actorPermNomes } = getActorContext(empresaId, actor.id);
  if (actorCargo?.isAdmin) return; // administrador possui todas — nada a validar
  const database = D();
  const permissoesSolicitadas = database.permissoes.filter((p) => permissaoIds.includes(p.id));
  const naoPossuida = permissoesSolicitadas.find((p) => !actorPermNomes.has(p.nome));
  if (naoPossuida) {
    throw new RepositoryError("Você não pode conceder a um cargo uma permissão que você mesmo não possui.");
  }
}

/** Catálogo de permissões da empresa (seção 8) — usado pela tela de cargos para montar os checkboxes por módulo. */
export function listPermissoes(empresaId: ID) {
  return D().permissoes.filter((p) => p.empresaId === empresaId && p.ativo);
}

export function listCargosComContagem(empresaId: ID): (Cargo & { funcionarios: number })[] {
  const database = D();
  return listCargos(empresaId).map((c) => ({
    ...c,
    funcionarios: database.usuarios.filter((u) => u.cargoId === c.id && u.empresaId === empresaId && u.ativo).length,
  }));
}

export function getCargoDetalhe(id: ID, empresaId: ID): { cargo: Cargo; funcionarios: Usuario[] } {
  const database = D();
  const cargo = database.cargos.find((c) => c.id === id && c.empresaId === empresaId);
  if (!cargo) throw new RepositoryError("Cargo não encontrado.");
  const funcionarios = database.usuarios.filter((u) => u.cargoId === id && u.empresaId === empresaId && u.ativo);
  return { cargo, funcionarios };
}

export function createCargo(
  empresaId: ID,
  actor: { id: ID; nome: string },
  data: { nome: string; descricao?: string | null; permissaoIds: ID[] },
): Cargo {
  assertCanManageCargos(empresaId, actor);
  const database = D();
  const nomeClash = database.cargos.find(
    (c) => c.empresaId === empresaId && c.ativo && c.nome.trim().toLowerCase() === data.nome.trim().toLowerCase(),
  );
  if (nomeClash) throw new RepositoryError("Já existe um cargo com este nome.");
  assertNoPrivilegeEscalation(empresaId, actor, data.permissaoIds);
  const validIds = new Set(database.permissoes.filter((p) => p.empresaId === empresaId).map((p) => p.id));
  const permissaoIds = data.permissaoIds.filter((id) => validIds.has(id));
  const item: Cargo = {
    id: nextIdFor(database.cargos),
    empresaId,
    nome: data.nome.trim(),
    descricao: data.descricao ?? null,
    permissaoIds,
    isAdmin: false, // nunca criável pela tela — só existe um por empresa, criado no provisionamento
    ativo: true,
    criadoEm: nowISO(),
    atualizadoEm: nowISO(),
  };
  database.cargos.push(item);
  logAudit(empresaId, actor, "CRIACAO", "Cargo", `Criou o cargo "${item.nome}"`);
  persist();
  return item;
}

export function updateCargo(
  id: ID,
  empresaId: ID,
  actor: { id: ID; nome: string },
  data: { nome?: string; descricao?: string | null; permissaoIds?: ID[] },
): Cargo {
  assertCanManageCargos(empresaId, actor);
  const database = D();
  const item = database.cargos.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Cargo não encontrado.");

  if (item.isAdmin) {
    // Cargo administrativo protegido (seção 4): nome e permissões são
    // travados na estrutura original — só a descrição pode mudar.
    if (data.descricao !== undefined) item.descricao = data.descricao;
    item.atualizadoEm = nowISO();
    logAudit(empresaId, actor, "EDICAO", "Cargo", `Editou o cargo administrativo "${item.nome}"`);
    persist();
    return item;
  }

  if (data.nome !== undefined) {
    const nomeClash = database.cargos.find(
      (c) => c.empresaId === empresaId && c.ativo && c.id !== id && c.nome.trim().toLowerCase() === data.nome!.trim().toLowerCase(),
    );
    if (nomeClash) throw new RepositoryError("Já existe um cargo com este nome.");
    item.nome = data.nome.trim();
  }
  if (data.descricao !== undefined) item.descricao = data.descricao;
  if (data.permissaoIds !== undefined) {
    assertNoPrivilegeEscalation(empresaId, actor, data.permissaoIds);
    const validIds = new Set(database.permissoes.filter((p) => p.empresaId === empresaId).map((p) => p.id));
    item.permissaoIds = data.permissaoIds.filter((pid) => validIds.has(pid));
  }
  item.atualizadoEm = nowISO();
  logAudit(empresaId, actor, "EDICAO", "Cargo", `Editou o cargo "${item.nome}"`);
  persist();
  return item;
}

export function toggleCargo(id: ID, empresaId: ID, actor: { id: ID; nome: string }): Cargo {
  assertCanManageCargos(empresaId, actor);
  const database = D();
  const item = database.cargos.find((c) => c.id === id && c.empresaId === empresaId);
  if (!item) throw new RepositoryError("Cargo não encontrado.");
  if (item.isAdmin) throw new RepositoryError("O cargo administrativo não pode ser excluído.");
  if (item.ativo) {
    const vinculados = database.usuarios.some((u) => u.cargoId === id && u.empresaId === empresaId && u.ativo);
    if (vinculados) {
      throw new RepositoryError("Este cargo possui funcionários vinculados. Altere o cargo desses funcionários antes de excluí-lo.");
    }
  }
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  logAudit(empresaId, actor, item.ativo ? "ATIVACAO" : "INATIVACAO", "Cargo", `${item.ativo ? "Reativou" : "Excluiu"} o cargo "${item.nome}"`);
  persist();
  return item;
}

export function createUsuario(
  empresaId: ID,
  usuarioAtual: { id: ID; nome: string },
  data: { nome: string; login: string; email: string; senha: string; cargoId: ID },
): Usuario {
  const database = D();
  const loginClash = database.usuarios.find((u) => u.empresaId === empresaId && u.login.toLowerCase() === data.login.toLowerCase());
  if (loginClash) throw new RepositoryError("Este login já está em uso.");
  const emailClash = database.usuarios.find((u) => u.empresaId === empresaId && u.email.toLowerCase() === data.email.toLowerCase());
  if (emailClash) throw new RepositoryError("Este email já está em uso.");
  const cargoDestino = database.cargos.find((c) => c.id === data.cargoId && c.empresaId === empresaId);
  if (cargoDestino?.isAdmin) {
    const { cargo: actorCargo } = getActorContext(empresaId, usuarioAtual.id);
    if (!actorCargo?.isAdmin) throw new RepositoryError("Somente um administrador pode atribuir o cargo administrativo a um usuário.");
  }
  const item: Usuario = { id: nextIdFor(database.usuarios), empresaId, ativo: true, criadoEm: nowISO(), atualizadoEm: nowISO(), ...data };
  database.usuarios.push(item);
  logAudit(empresaId, usuarioAtual, "CRIACAO", "Usuário", `Cadastrou o usuário "${data.nome}"`);
  persist();
  return item;
}
export function updateUsuario(id: ID, empresaId: ID, usuarioAtual: { id: ID; nome: string }, data: Partial<Usuario>): Usuario {
  const database = D();
  const item = database.usuarios.find((u) => u.id === id && u.empresaId === empresaId);
  if (!item) throw new RepositoryError("Usuário não encontrado.");
  if (data.cargoId !== undefined && data.cargoId !== item.cargoId) {
    const cargoDestino = database.cargos.find((c) => c.id === data.cargoId && c.empresaId === empresaId);
    if (cargoDestino?.isAdmin) {
      const { cargo: actorCargo } = getActorContext(empresaId, usuarioAtual.id);
      if (!actorCargo?.isAdmin) throw new RepositoryError("Somente um administrador pode atribuir o cargo administrativo a um usuário.");
    }
    const cargoAtual = database.cargos.find((c) => c.id === item.cargoId && c.empresaId === empresaId);
    if (cargoAtual?.isAdmin && !cargoDestino?.isAdmin) {
      const { cargo: actorCargo } = getActorContext(empresaId, usuarioAtual.id);
      if (!actorCargo?.isAdmin) throw new RepositoryError("Somente um administrador pode remover o cargo administrativo de um usuário.");
    }
  }
  Object.assign(item, data, { atualizadoEm: nowISO() });
  logAudit(empresaId, usuarioAtual, "EDICAO", "Usuário", `Editou o usuário "${item.nome}"`);
  persist();
  return item;
}
export function toggleUsuario(id: ID, empresaId: ID, usuarioAtual: { id: ID; nome: string }): Usuario {
  const database = D();
  const item = database.usuarios.find((u) => u.id === id && u.empresaId === empresaId);
  if (!item) throw new RepositoryError("Usuário não encontrado.");
  if (item.id === usuarioAtual.id) throw new RepositoryError("Você não pode inativar seu próprio usuário.");
  item.ativo = !item.ativo;
  item.atualizadoEm = nowISO();
  logAudit(empresaId, usuarioAtual, item.ativo ? "ATIVACAO" : "INATIVACAO", "Usuário", `${item.ativo ? "Ativou" : "Inativou"} o usuário "${item.nome}"`);
  persist();
  return item;
}

// -----------------------------------------------------------------
// Auditoria — leitura
// -----------------------------------------------------------------
export function listAuditLog(empresaId: ID) {
  return D().auditLog.filter((a) => a.empresaId === empresaId);
}

// -----------------------------------------------------------------
// Acesso cru ao banco (para telas de leitura agregada, ex. dashboard)
// -----------------------------------------------------------------
export function rawDatabase(): Database {
  return D();
}
