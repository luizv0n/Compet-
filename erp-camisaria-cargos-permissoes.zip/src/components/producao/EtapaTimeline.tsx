"use client";
import * as React from "react";
import { Check, CircleDashed, SkipForward, ChevronRight, ChevronLeft, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { Qty } from "@/components/common/Money";
import type { OrdemProducaoEtapa, OrdemProducaoEtapaStatus, Setor } from "@/types";

interface EtapaTimelineProps {
  etapas: OrdemProducaoEtapa[];
  setores: Setor[];
  etapaAtualId?: number | null;
}

const NODE_STYLE: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "border-success bg-success text-success-foreground",
  EM_EXECUCAO: "border-accent bg-accent text-accent-foreground ring-4 ring-accent/20",
  AGUARDANDO: "border-border bg-card text-muted-foreground",
  PULADA: "border-warning bg-warning text-warning-foreground",
};

/** Cor de fundo dos conectores (traço vertical entre linhas). */
const CONNECTOR_BG: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "bg-success",
  EM_EXECUCAO: "bg-accent",
  AGUARDANDO: "bg-border",
  PULADA: "bg-warning",
};

/** Cor dos ícones de seta (setas horizontais entre etapas e a seta de quebra de linha). */
const CONNECTOR_TEXT: Record<OrdemProducaoEtapaStatus, string> = {
  CONCLUIDA: "text-success",
  EM_EXECUCAO: "text-accent",
  AGUARDANDO: "text-muted-foreground",
  PULADA: "text-warning",
};

// Largura de cada coluna de etapa (card + nó) — mesma medida do design
// original (w-44 = 176px) — e a folga reservada para a seta entre colunas.
// Usadas apenas para estimar quantas colunas cabem por linha; não alteram
// o tamanho visual do card em si.
const COLUMN_PX = 176;
const CONNECTOR_PX = 32;
const MAX_PER_ROW = 6;
const MIN_PER_ROW = 1;

/**
 * Timeline das etapas de uma OP — agora em formato serpentina/zigue-zague
 * em vez de uma única linha horizontal com rolagem. As etapas continuam na
 * ordem original do fluxo; ao atingir a largura máxima de colunas por
 * linha (calculada a partir do espaço disponível, respeitando um teto
 * fixo), o caminho desce e a linha seguinte percorre no sentido oposto —
 * e assim por diante, alternando direita→esquerda→direita — em vez de
 * crescer indefinidamente para os lados. Cards, cores, ícones de status e
 * indicadores de quantidade permanecem exatamente os mesmos; apenas a
 * estrutura do layout e os conectores entre etapas foram redesenhados.
 */
export function EtapaTimeline({ etapas, setores, etapaAtualId }: EtapaTimelineProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);

  const containerRef = React.useRef<HTMLDivElement>(null);
  const [itemsPerRow, setItemsPerRow] = React.useState(MAX_PER_ROW);

  React.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const slot = COLUMN_PX + CONNECTOR_PX;
    const compute = (width: number) => {
      const n = Math.floor((width + CONNECTOR_PX) / slot);
      setItemsPerRow(Math.min(MAX_PER_ROW, Math.max(MIN_PER_ROW, n)));
    };
    compute(el.clientWidth);
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) compute(entry.contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const rows: OrdemProducaoEtapa[][] = [];
  for (let i = 0; i < ordered.length; i += itemsPerRow) {
    rows.push(ordered.slice(i, i + itemsPerRow));
  }

  return (
    <div ref={containerRef} className="w-full px-1 py-2">
      <div className="flex flex-col">
        {rows.map((row, rowIdx) => {
          const reversed = rowIdx % 2 === 1;
          const nextRowFirst = rows[rowIdx + 1]?.[0];

          return (
            <div key={rowIdx} className="flex flex-col">
              <ol className={cn("flex items-stretch", reversed && "flex-row-reverse")}>
                {row.map((etapa, idx) => {
                  const setor = setores.find((s) => s.id === etapa.setorId);
                  const isCurrent = etapaAtualId === etapa.id;
                  const isLastInRow = idx === row.length - 1;
                  const proximaNaLinha = row[idx + 1];

                  return (
                    <li key={etapa.id} className="flex items-stretch">
                      <div className="flex w-44 shrink-0 flex-col items-center text-center">
                        <div
                          className={cn(
                            "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border-2 text-xs font-semibold transition-colors",
                            NODE_STYLE[etapa.status],
                          )}
                        >
                          {etapa.status === "CONCLUIDA" ? (
                            <Check className="h-4 w-4" />
                          ) : etapa.status === "PULADA" ? (
                            <SkipForward className="h-3.5 w-3.5" />
                          ) : etapa.status === "AGUARDANDO" ? (
                            <CircleDashed className="h-4 w-4" />
                          ) : (
                            etapa.sequencia
                          )}
                        </div>

                        <div
                          className={cn(
                            "mt-2 flex w-full flex-col gap-1.5 rounded-md border px-2.5 py-2",
                            isCurrent ? "border-accent/40 bg-accent/5" : "border-transparent",
                          )}
                        >
                          <p className={cn("truncate text-xs font-medium", isCurrent ? "text-accent" : "text-foreground")} title={setor?.nome}>
                            {setor?.nome ?? "Setor"}
                          </p>
                          <div className="flex items-center justify-center gap-2 text-[11px] tabular-nums text-muted-foreground">
                            <span title="Recebida">
                              <Qty value={etapa.quantidadeRecebida} decimals={0} />
                            </span>
                            <span className="text-success" title="Concluída">
                              →<Qty value={etapa.quantidadeConcluida} decimals={0} />
                            </span>
                            {etapa.quantidadePerdida > 0 && (
                              <span className="text-destructive" title="Perdida">
                                −<Qty value={etapa.quantidadePerdida} decimals={0} />
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Seta horizontal para a próxima etapa da mesma linha — a direção
                         (→ nas linhas pares, ← nas ímpares) segue o sentido de leitura da
                         linha; a cor reflete o status da etapa de destino do trecho. */}
                      {!isLastInRow && (
                        <div className="flex w-7 shrink-0 items-center justify-center sm:w-9">
                          {reversed ? (
                            <ChevronLeft className={cn("h-4 w-4", CONNECTOR_TEXT[proximaNaLinha?.status ?? "AGUARDANDO"])} />
                          ) : (
                            <ChevronRight className={cn("h-4 w-4", CONNECTOR_TEXT[proximaNaLinha?.status ?? "AGUARDANDO"])} />
                          )}
                        </div>
                      )}
                    </li>
                  );
                })}
              </ol>

              {/* Conector de quebra de linha (serpentina): desce no lado onde a
                 linha atual termina — direita quando a linha vai da esquerda para
                 a direita, esquerda quando vai da direita para a esquerda — e a
                 próxima linha recomeça exatamente sob essa seta. */}
              {nextRowFirst && (
                <div className={cn("flex", reversed ? "justify-start" : "justify-end")}>
                  <div className="flex w-44 shrink-0 flex-col items-center py-0.5">
                    <div className={cn("h-3 w-0.5", CONNECTOR_BG[nextRowFirst.status])} />
                    <ChevronDown className={cn("-mt-1 h-4 w-4", CONNECTOR_TEXT[nextRowFirst.status])} />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
