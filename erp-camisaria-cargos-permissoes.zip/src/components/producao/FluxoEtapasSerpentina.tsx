"use client";
import * as React from "react";
import { ChevronRight, ChevronLeft, ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils";
import type { FluxoProducaoEtapa, Setor } from "@/types";

interface FluxoEtapasSerpentinaProps {
  etapas: FluxoProducaoEtapa[];
  setores: Setor[];
}

// Largura estimada de cada bloco de etapa (texto + padding) e do espaço
// reservado para o conector entre blocos — usadas somente para calcular
// quantos blocos cabem por linha a partir da largura disponível do
// container. O tamanho real de cada bloco continua definido pelo próprio
// conteúdo (texto do setor), sem alterar o visual do bloco em si.
const COLUMN_PX = 168;
const CONNECTOR_PX = 28;
const MAX_PER_ROW = 6;
const MIN_PER_ROW = 1;

/**
 * Etapas de um fluxo de produção (tela "Fluxos de produção") em formato
 * serpentina/zigue-zague, no lugar de uma simples lista com flex-wrap.
 * A ordem das etapas continua exatamente a cadastrada (sequencia); ao
 * atingir o número máximo de blocos por linha — calculado a partir do
 * espaço disponível, com um teto fixo — o caminho desce e a linha
 * seguinte passa a percorrer no sentido oposto, alternando
 * direita→esquerda→direita, em vez de crescer indefinidamente para os
 * lados. O visual de cada bloco (cor, borda, tipografia, número da etapa
 * e nome do setor) é o mesmo já usado nesta tela; apenas o agrupamento em
 * linhas e os conectores entre blocos foram adaptados.
 */
export function FluxoEtapasSerpentina({ etapas, setores }: FluxoEtapasSerpentinaProps) {
  const ordered = React.useMemo(() => [...etapas].sort((a, b) => a.sequencia - b.sequencia), [etapas]);

  const containerRef = React.useRef<HTMLDivElement>(null);
  const [itemsPerRow, setItemsPerRow] = React.useState(MAX_PER_ROW);

  React.useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const slot = COLUMN_PX + CONNECTOR_PX;
    const compute = (width: number) => {
      const n = Math.floor((width + CONNECTOR_PX) / slot);
      setItemsPerRow(Math.min(MAX_PER_ROW, Math.max(MIN_PER_ROW, n)));
    };
    compute(el.clientWidth);
    if (typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) compute(entry.contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  if (ordered.length === 0) return null;

  const rows: FluxoProducaoEtapa[][] = [];
  for (let i = 0; i < ordered.length; i += itemsPerRow) {
    rows.push(ordered.slice(i, i + itemsPerRow));
  }

  return (
    <div ref={containerRef} className="mt-3 w-full">
      <div className="flex flex-col gap-1">
        {rows.map((row, rowIdx) => {
          const reversed = rowIdx % 2 === 1;
          const nextRowFirst = rows[rowIdx + 1]?.[0];

          return (
            <div key={rowIdx} className="flex flex-col">
              <ol className={cn("flex flex-wrap items-center gap-1.5", reversed && "flex-row-reverse")}>
                {row.map((etapa, idx) => {
                  const setor = setores.find((s) => s.id === etapa.setorId);
                  const isLastInRow = idx === row.length - 1;
                  return (
                    <li key={etapa.id} className="flex items-center gap-1.5">
                      <span className="rounded-md border bg-secondary/60 px-2.5 py-1 text-xs font-medium text-foreground">
                        {etapa.sequencia}. {setor?.nome ?? "—"}
                      </span>
                      {!isLastInRow &&
                        (reversed ? (
                          <ChevronLeft className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                        ))}
                    </li>
                  );
                })}
              </ol>

              {/* Conector de quebra de linha: desce no lado onde a linha atual
                 termina e a próxima linha recomeça exatamente ali, deixando
                 claro que o produto segue do último setor desta linha para o
                 primeiro setor da linha seguinte. */}
              {nextRowFirst && (
                <div className={cn("flex", reversed ? "justify-start" : "justify-end")}>
                  <ChevronDown className="my-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
